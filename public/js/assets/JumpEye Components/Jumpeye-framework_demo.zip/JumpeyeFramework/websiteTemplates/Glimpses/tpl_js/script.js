JFBase(document).ready(function() {    
	JFBase('#content').on('contentLoadError contentLoadStart', function(e) {
        //console.log(e);
	})
	
	JFBase('#content').on('contentLoadComplete', function(e) {
        //console.log(e);
		
		// We need to reinitialize the Form js object because of the ajax loading, when the content is loaded
		JFBase.fn.JFforms.init();
				
		/* Magnifier hover effect for images
		 *  		   
		 * mandatory html structure: <a><img class="image" /></a>
		 * key class for jQuery is "image" in order to apply the hover effect for img elements
		 *
		 * On touchscreen the hover effect will be disabled
		 */        		
        if(JC.isTouchable() == 0) {
            // firstly we add dynamic divs
            JFBase('.image').parent().wrap('<div class="image_wrapper" />');
            JFBase('.image').parent().after('<div class="cover" /><div class="magnifier" />')
             
            // make magnifier div clickable and get href
            JFBase('.image_wrapper div.magnifier').on('click',function() {
               var loc = JFBase(this).siblings('a').attr('href');
               if(loc!=undefined){
                   window.location = JFBase(this).siblings('a').attr('href'); 
               }
            });
            
            // show / hide handlers for image cover layer  
            JFBase('.image_wrapper').on('mouseover',function() {
               JFBase(this).find('div.cover').show();
               JFBase(this).find('div.magnifier').show();
            });
           
            JFBase('.image_wrapper').on('mouseout',function() {
               JFBase(this).find('div.cover').hide();
               JFBase(this).find('div.magnifier').hide();
            });
        }
		/* End of Magnifier hover effect for images */


		/* 	"More" functionality
			
		*	Using the class "more_content" for a <div> or <p> its content will be hidden by default 
		*	and by clicking the link <a class="more">read more</a> the content will be revealed with a vertical slide effect.
		*	The container element (<div> or <p>) need to be at the same level with the <a> tag.
		*/				
		JFBase('.more').on('click', function(){
			var controller = JFBase(this);
			if(controller.parent().find('.more_content').is(':visible')){
				controller.parent().find('.more_content').slideUp('500', function(){
					controller.text('read more ...');    
				});
			} else {
				controller.parent().find('.more_content').slideDown('500', function(){
					controller.text('less');    
				});
			}
		});
		/* 	End of "More" functionality */
		

		/* 	
			Call function adjustColumns after the content is loaded.
			To solve the delayed loading problem we apply adjustColumns in a setInterval 
		*/
        var counter = 0;
        var interval_ID = setInterval(function(){
                if(counter==100){
                    clearInterval(interval_ID);
                } else {
                    JC.adjustColumns();
                }
                counter++;
            }, 300
        );      
    })

	// First load - load Home
    loader(); 

    // Verify the url periodically - if it changed, load new content
    var intervalID = setInterval(function(){
			if(location.href!=JC.pageObj.path){
                loader();				
            }
        }, 300
    );
	
	
	/* 	Adjust columns to the same height
	
	* 	Use class "adjust" in order to have the same height for all child div elements of a row (the maximum height of the child div elements).
	* 	This class is useful when the child div elements have background colors or textures.
	*/
    JC.adjustColumns = function(){ 
        var win_width = getWindowWidth();       
        if(win_width < 768){
            JFBase('.row.adjust > .columns, .row.adjust > .column').css('height','');
        } else {
            JFBase('.row.adjust').each(function(){
                JFBase(this).find('> .columns, > .column').css('height','auto');
                JFBase(this).find('> .columns, > .column').css('height',JFBase(this).height());
            }); 
        }    
    }

    // Resize handler - adjust columns on resize
    var resizeTimer;
    JFBase(window).resize(function() {
        
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(function(){
            
            var win_width = getWindowWidth();
            if(win_width < 768){
                // prevent columns' height fallback in IE8 - mobile view
                if( !JFBase.browser.msie || (JFBase.browser.msie && parseInt(JFBase.browser.version, 10) > 8) ){
                    JFBase('.row.adjust').each(function(){
                        JFBase(this).find('> .columns, > .column').css('height','');    
                    });
                }                     
            } else {
                JC.adjustColumns();
            }                                   
            
        },1);
    });  
	
})


// Get the width of browser window
function getWindowWidth(){
    if(JFBase.browser.webkit){
        return JFBase(window).width();    
    } else {
        return (JC.GRID.isScrollbarVisible()) ? 
               (JFBase(window).width() + JC.GRID.scrollbarWidth()) : 
                JFBase(window).width();
    }     
}


// If the url changed, this function loads the current content specified by the url (part of the url after the #)
function loader(){
    if (JC.hasHash(location.href)) {
		JC.loadPage('tpl_content/' + location.href.split('#').pop() + '.html');
	} else {
	    JC.loadPage("tpl_content/home.html");
	}
}
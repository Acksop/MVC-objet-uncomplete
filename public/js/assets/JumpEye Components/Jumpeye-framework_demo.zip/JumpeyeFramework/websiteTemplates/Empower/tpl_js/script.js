JFBase(document).ready(function(){
    JFBase('#content').on('contentLoadError contentLoadStart contentLoadComplete', function(e) {
        //console.log(e);
    })

	// First load - load Home
    loader(); 

    // Verify the url periodically - if it changed, load new content
    var intervalID = setInterval(function(){
            if(location.href!=JC.pageObj.path){
                loader();
            }
        }, 300
    );
})


// If the url changed, this function loads the current content specified by the url (part of the url after the #)
function loader(){
    if (JC.hasHash(location.href)) {
		JC.loadPage('tpl_content/' + location.href.split('#').pop() + '.html');
	} else {
	    JC.loadPage("tpl_content/home.html");
	}
}


// Use this function to display your latest tweets on the page
// Parameters: 	index - index of the tweet (0-based, tweet with index 0 is the newest)
// 				prop - property that you want to display
//				target - id of the target html container 
function getTweet(index, prop, target) {	
	// Change the Twitter id (jecomponents) with your id to get your tweets
	JFBase.getJSON("https://api.twitter.com/1/statuses/user_timeline/jecomponents.json?count=5&include_rts=1&callback=?", function(data) {            
		if(prop == "created_at")
			JFBase('#'+target).append(parseTwitterDate(data[index][prop]));
		else
			JFBase('#'+target).append(linkify(data[index][prop]));
	});	
}


function parseTwitterDate(stamp){
    var _time  = stamp.substr(10,6);
    var _month = stamp.substr(4,3);
    var _day   = stamp.substr(8,2);
    var _year  = stamp.substr(stamp.length-4,4); 
    
    // convert to local string and remove seconds and year  
	var date = new Date(Date.parse(stamp)).toLocaleString().substr(0, 16);
    
    // get the two digit hour //
	var hour = date.substr(-5, 2);
    // convert to AM or PM //
	var ampm = hour<12 ? 'am' : 'pm';
    return _month + ' ' + _day + ', ' + _year + ' at ' + _time + ampm; 
}


function linkify(inputText) {
	var replacedText, replacePattern1, replacePattern2, replacePattern3;

	//URLs starting with http://, https://, or ftp://
	replacePattern1 = /(\b(https?|ftp):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/gim;
	replacedText = inputText.replace(replacePattern1, '<a href="$1" target="_blank">$1</a>');

	//URLs starting with "www." (without // before it, or it'd re-link the ones done above).
	replacePattern2 = /(^|[^\/])(www\.[\S]+(\b|$))/gim;
	replacedText = replacedText.replace(replacePattern2, '$1<a href="http://$2" target="_blank">$2</a>');

	//Change email addresses to mailto:: links.
	replacePattern3 = /(\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,6})/gim;
	replacedText = replacedText.replace(replacePattern3, '<a href="mailto:$1">$1</a>');

	return replacedText;
}
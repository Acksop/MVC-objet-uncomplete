<?php
/*
    Plugin Name: JF-UI-Elements
    Plugin URI: http://www.jumpeye.com/ui-elements
    Description: Jumpeye framework user interface elements. Add buttons, menus, tabs and other UI elements to your JF theme by using the shortcode of the elements.
    Version: 1.0
    Author: Jumpeye Components
    Author URI: http://www.jumpeyecomponents.com/
    License: GPL2
*/


/*  Copyright 2012  Jumpeye Components  (email : contact@jumpeyecomponents.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as 
    published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

class JF_UI_elements {

    /** framework object */
    protected $framework;
    
    /** domain key */
    private $domain_key = null;
    
    /** constants and variables */
    private $default_cols = 12; // for GRID-plugin
    private $close_effect = ''; // for ALERT-plugin  
    private $menu_classes = ''; // for MENU-plugin 
    
    /** for PANEL-plugin */
    private $panel_special_styles = array('style-5','style-7','style-8','style-9');
    private $panel_atts = null;
    
    /** Retrieve options from database if any, or use default options instead */
    private function getValue($settings, $element, $key=''){
    	$option = get_option('jf_ui_'.$element.'_options') ? get_option('jf_ui_'.$element.'_options') : Array();
    	$option = array_merge($settings, $option);
        return ($key) ? $option[$key] : $option;
    } 
        
    /** make slug (permalinks, nice urls) */    
    private function slugify($text)	{ 
        // replace non letter or digits by -
        $text = preg_replace('~[^\\pL\d]+~u', '-', $text);
        // trim
        $text = trim($text, '-');
        // transliterate
        $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);
        // lowercase
        $text = strtolower($text);
        // remove unwanted characters
        $text = preg_replace('~[^-\w]+~', '', $text);
        
        return (empty($text)) ? 'n-a' : $text;  
    }
    
    
    /** add http:// url prefix if it is missing */
    private function urlPrefix($_url){
        return ( (strpos($_url, 'http://')===false) && 
                 (strpos($_url, 'https://')===false) &&
                 (strpos($_url, 'ftp://')===false) ) ? 'http://' : '';
    }
    
        
    /** constructor : add shortcodes */    
	public function __construct(){
       
        //$this->framework = new Framework();
       
        // get domain key
        $opts = get_option( 'jf_theme_general_settings' );
        if($opts){
            $this->domain_key = $opts['domain_keys'];
        }
        
	    // add plugin shortcodes
        // site banner
        add_shortcode('jf_site_banner', array($this, 'shortcode_site_banner'));
                
        // theme images ( folder: /themename/images/ )
        add_shortcode('jf_theme_image', array($this, 'shortcode_theme_image'));
        
        // grid
        add_shortcode('jf_row', array($this, 'shortcode_row'));
        add_shortcode('jf_row_end', array($this, 'shortcode_row_end'));
        add_shortcode('jf_col', array($this, 'shortcode_cols'));
        add_shortcode('jf_col_end', array($this, 'shortcode_cols_end'));
        
        // alert
        add_shortcode('jf_alert', array($this, 'shortcode_alert'));
        add_shortcode('jf_alert_end', array($this, 'shortcode_alert_end'));
        
        // button
        add_shortcode('jf_button', array($this, 'shortcode_button'));
        
        // menu
        add_shortcode('jf_menu', array($this, 'shortcode_menu'));
        add_shortcode('jf_menu_end', array($this, 'shortcode_menu_end'));        
        add_shortcode('jf_menu_main_item', array($this, 'shortcode_main_item'));
        add_shortcode('jf_menu_main_item_end', array($this, 'shortcode_main_item_end'));
        add_shortcode('jf_menu_sub_item', array($this, 'shortcode_sub_item'));
        add_shortcode('jf_menu_sub_item_end', array($this, 'shortcode_sub_item_end'));         
        
        // panel
        add_shortcode('jf_panel',  array($this, 'shortcode_panel'));
        add_shortcode('jf_panel_end',  array($this, 'shortcode_panel_end')); 
        
        // table
        add_shortcode('jf_table', array($this, 'shortcode_table'));
        add_shortcode('jf_table_end', array($this, 'shortcode_table_end'));  
        add_shortcode('jf_table_head', array($this, 'shortcode_table_head'));
        add_shortcode('jf_table_head_end', array($this, 'shortcode_table_head_end')); 
        add_shortcode('jf_table_th', array($this, 'shortcode_table_th')); 
        add_shortcode('jf_table_th_end', array($this, 'shortcode_table_th_end'));
        add_shortcode('jf_table_body', array($this, 'shortcode_table_body'));
        add_shortcode('jf_table_body_end', array($this, 'shortcode_table_body_end'));         
        add_shortcode('jf_table_tr', array($this, 'shortcode_table_tr')); 
        add_shortcode('jf_table_tr_end', array($this, 'shortcode_table_tr_end')); 
        add_shortcode('jf_table_td', array($this, 'shortcode_table_td')); 
        add_shortcode('jf_table_td_end', array($this, 'shortcode_table_td_end'));  
        
        // tab
        add_shortcode('jf_tab', array($this, 'shortcode_tab'));
        add_shortcode('jf_tab_end', array($this, 'shortcode_tab_end'));
        add_shortcode('jf_tab_title_holder', array($this, 'shortcode_tab_title_holder'));
        add_shortcode('jf_tab_title', array($this, 'shortcode_tab_title'));        
        add_shortcode('jf_tab_title_holder_end', array($this, 'shortcode_tab_title_holder_end'));
        add_shortcode('jf_tab_content_holder', array($this, 'shortcode_tab_content_holder'));
        add_shortcode('jf_tab_content', array($this, 'shortcode_tab_content'));
        add_shortcode('jf_tab_content_end', array($this, 'shortcode_tab_content_end'));        
        add_shortcode('jf_tab_content_holder_end', array($this, 'shortcode_tab_content_holder_end')); 
        
        // tooltip
        add_shortcode('jf_tooltip', array($this, 'shortcode_tooltip'));
        add_shortcode('jf_tooltip_end', array($this, 'shortcode_tooltip_end')); 
        
        // form
        add_shortcode('jf_form', array($this, 'shortcode_form'));
        add_shortcode('jf_form_end', array($this, 'shortcode_form_end')); 
        add_shortcode('jf_label', array($this, 'shortcode_label'));        
        add_shortcode('jf_text_input', array($this, 'shortcode_text_input'));
        add_shortcode('jf_password_input', array($this, 'shortcode_password_input')); 
        add_shortcode('jf_button_input', array($this, 'shortcode_button_input'));
        add_shortcode('jf_searchbox', array($this, 'shortcode_searchbox'));
        add_shortcode('jf_textarea', array($this, 'shortcode_textarea'));
        add_shortcode('jf_submit_input', array($this, 'shortcode_submit_input'));
        add_shortcode('jf_fieldset', array($this, 'shortcode_fieldset'));
        add_shortcode('jf_fieldset_end', array($this, 'shortcode_fieldset_end'));     
        add_shortcode('jf_select', array($this, 'shortcode_select')); 
        add_shortcode('jf_select_end', array($this, 'shortcode_select_end'));
        add_shortcode('jf_option', array($this, 'shortcode_option'));
        add_shortcode('jf_radiogroup', array($this, 'shortcode_radiogroup')); 
        add_shortcode('jf_radiogroup_end', array($this, 'shortcode_radiogroup_end'));   
        add_shortcode('jf_radio', array($this, 'shortcode_radio'));     
        add_shortcode('jf_checkbox', array($this, 'shortcode_checkbox')); 
         
        
        // DASHBOARD
        add_action('admin_init', array($this, 'jf_ui_initialize_general_options')); 
        add_action('admin_init', array($this, 'jf_ui_initialize_grid_options')); 
        add_action('admin_init', array($this, 'jf_ui_initialize_button_options'));
        add_action('admin_init', array($this, 'jf_ui_initialize_tab_options'));
        add_action('admin_init', array($this, 'jf_ui_initialize_menu_options'));   
        add_action('admin_init', array($this, 'jf_ui_initialize_panel_options'));
        add_action('admin_init', array($this, 'jf_ui_initialize_form_options'));  
        add_action('admin_init', array($this, 'jf_ui_initialize_alert_options'));
        add_action('admin_init', array($this, 'jf_ui_initialize_tooltip_options'));
        add_action('admin_init', array($this, 'jf_ui_initialize_table_options')); 
        
        // AJAX for testing shortcodes
        add_action( 'admin_footer' , array( $this, 'ajax_script') );  
        add_action( 'wp_ajax_shortcode_preview', array( $this, 'shortcode_preview_callback') );   

	}


    /** ajax to handle shortcode previews */
    function ajax_script() {
    ?>
    <script type="text/javascript" >
    function _aRefreshTestarea(){
    	var data = {
    		action: 'shortcode_preview',
            shortcode : jQuery('#test_shortcode').val()
    	};

        jQuery.ajaxSetup({
           beforeSend: function(){
               jQuery('#preview_wrapper').contents().find('#preview').html('loading...'); 
           }
        });

        jQuery.post(ajaxurl, data,
        	function( response ) {
                jQuery('#preview_wrapper').contents().find('#preview').html(response);
                document.getElementById("preview_wrapper").contentWindow.rebootHandlers();
        	}
        );
    } 
    </script>
    <?php
    }
    
    
    /** ajax handler */
    function shortcode_preview_callback() {

        echo do_shortcode(stripslashes($_POST['shortcode']));
    
    	die(); // this is required to return a proper result
    } 
    
           
    /** SITE BANNER */
    public function shortcode_site_banner($atts, $content = null){
         extract(shortcode_atts(array(
              'title' => '',
              'button_class' => '',
              'button_text' => ''
              
         ), $atts));        
         
         if($button_text == ''){
            return "<div class='row'>
                        <div class='site_banner'>
                            <div class='columns grid_12'>
                                <h3>{$title}</h3>
                                <p>{$content}</p>
                            </div>
                        </div>
	                </div>";            
         } else {
             return "<div class='row'>
                        <div class='site_banner'>
                            <div class='columns grid_10'>
                                <h3>{$title}</h3>
                                <p>{$content}</p>
                            </div>    
                            <div class='columns grid_2'>
                                <button class='{$button_class}'>{$button_text}</button>
                            </div>
                        </div>
                   </div>";   
         }
    }
    
    
    /** THEME IMAGES */
    
    public function shortcode_theme_image($atts){
         extract(shortcode_atts(array(
              'class' => 'site_widget_icon',
              'src'  => ''
         ), $atts));
         
         return "<img class='{$site_widget_icon}' src='".get_template_directory_uri()."{$src}' />";        
    }


    /** GRID */
    
    /** add a row container */    
    public function shortcode_row(){
         return "<div class='row'>";  
    }
    
    
    /** add close </div> tag to row container */     
    public function shortcode_row_end(){
         return "</div>";  
    }    


    /** add a grid container */    
	public function shortcode_cols($atts){
         extract(shortcode_atts(array(
              'value'  => $this->default_cols,
         ), $atts));
         
         $value = (int)$value;
         if(is_int($value)){
            if($value <= 0 || $value > $this->default_cols){
                $value = $this->default_cols;
            }
         } else {
            $value = $this->default_cols;
         }
         
         return "<div class='grid_{$value} columns'>";
	}
    
    
    /** add close </div> tag to the grid container */     
    public function shortcode_cols_end(){
         return "</div>";  
    } 
    
    
    /** ALERTS */
    private $alert_effect = '';
    public function shortcode_alert($atts){
        
         $settings = array(
            'type' => 'message',
            'style' => 'style-1',
            'rounded' => 'false',
            'bordered' => 'false',
            'effect' => 'fade');
            
         extract(shortcode_atts(array(
            'type' => $this->getValue($settings,'alert','type'),
            'style' => $this->getValue($settings,'alert','style'),
            'rounded' => $this->getValue($settings,'alert','rounded'),
            'bordered' => $this->getValue($settings,'alert','bordered'),
            'effect' => $this->getValue($settings,'alert','effect')
         ), $atts)); 
         
         $this->alert_effect = $effect;
         $bordered = ($bordered=='false') ? '' : 'bordered';
         $rounded = ($rounded=='false') ? '' : 'rounded';
            
         return "<div class='alert {$type} {$style} {$bordered} {$rounded}'>";  
    }
    
    public function shortcode_alert_end(){
        return "<a href='#' class='close {$this->alert_effect}'>x</a></div>";
    }
      
      
    /** BUTTONS */    
	public function shortcode_button($atts){
	   
         $settings = array(
            'style'=>'style-1',
            'color'=>'blue',
            'size'=>'medium');
                     
         extract(shortcode_atts(array(
    	      'label' => 'Button label',
              'style' => $this->getValue($settings,'button','style'),
              'color' => $this->getValue($settings,'button','color'),
              'size' => $this->getValue($settings,'button','size')
         ), $atts));
          
         return "<button class='button {$style} {$size} {$color}'>{$label}</button>";
	} 
    
    
    /** MENUS */
    
    /** check is menu vertical or not */
    private function isVertical(){
        return (strpos($this->menu_classes,'vertical')!==false) ? true : false;    
    }
    
    
    /** open menu structure */    
    public function shortcode_menu($atts){
         $settings = array(
              'style'  => 'style-1',
              'color' => '',
              'orientation' => 'horizontal'
         );
         extract(shortcode_atts(array(
              'style'  => $this->getValue($settings,'menu','style'),
              'color' => $this->getValue($settings,'menu','color'),
              'orientation' => $this->getValue($settings,'menu','orientation'),
         ), $atts)); 

         $c = (in_array($style, array('style-6', 'style-7', 'style-8'))) ? $color : '';
         $d = ($orientation == 'horizontal') ? '' : 'vertical';

         $this->menu_classes = $style.' '.$c.' '.$d;
                  
         return "<div class='menu {$style} {$c} {$d}'><ul class='main-level'>";  
    }
    
    
    /** close menu structure */     
    public function shortcode_menu_end(){
         return "</ul></div>";  
    } 
    
    
    /** define a main-level item */     
    public function shortcode_main_item($atts){
         extract(shortcode_atts(array(
              'label'  => 'Item label',
              'url' => '#',
              'type' => ''
         ), $atts));    
         
         switch($type){
            case 'down' :
                if($this->isVertical()){
                    return "<li class='down'><a>{$label}</a><span class='arrow-down'></span><ul class='sub-level'>";    
                } else {
                    return "<li class='down'><a>{$label}</a><span class='arrow-down'></span><ul class='sub-level'>";    
                }
                
            
            default:
                $url=$this->urlPrefix($url).$url; 
                return "<li><a href='{$url}' target='_blank'>{$label}</a></li>";
         }
    }  
    
    
    /** close a main-level item */     
    public function shortcode_main_item_end(){
        return '</ul></li>';
    }    
    
    
    /** define a sub-level item */     
    public function shortcode_sub_item($atts){
         extract(shortcode_atts(array(
              'label'  => 'Item label',
              'url' => '#',
              'target' => '_self',
              'type' => ''
         ), $atts));    
         
         // sanitize $target
         $target = '_'.str_replace('_','',$target);
         
         switch($type){
          
            case 'flyout' : 
                if($this->isVertical()){
                    return "<li class='flyout'><a target='{$target}'>{$label}</a><span class='arrow-right'></span><ul class='sub-level'>";
                } else {
                    return "<li class='flyout'><a target='{$target}'>{$label}</a><span class='arrow-right'></span><ul class='sub-level'>";
                }    
            
            default: 
                $url=$this->urlPrefix($url).$url;
                return "<li><a href='{$url}' target='_blank'>{$label}</a></li>";
         }
    }  
    
    
    /** close a sub-level item */     
    public function shortcode_sub_item_end(){
        return '</ul></li>';
    }    
      
      
      
    /** PANELS */
    
    /** panel starter tag */    
    public function shortcode_panel($atts){
         $this->panel_atts = $atts; // make a copy of the $atts

         $settings = array(
              'style' => 'style-1',
              'color' => ''
         );
         
         extract(shortcode_atts(array(
    	      'title' => 'Panel Title',
              'style' => $this->getValue($settings,'panel','style'),
              'color' => $this->getValue($settings,'panel','color'),
              'min_height' => 'auto',
              'img_src' => '',
              'img_class' => ''
         ), $atts));
         
         if($min_height!=='auto'){
            $minH = "style='min-height:{$min_height}px;'";
         } else {
            $minH = 'auto';
         }
         
         // needs an extra div in case of special styles
         if(in_array($style,$this->panel_special_styles)){
             $st = ($min_height!="auto") ? $minH : "";
             $div_open = "<div class='__inner-panel-container' {$st}>";
         } else {
            $div_open = "";
         }
         
         if($img_src==''){
            $img = '';
         } else{
            $img = "<img class='{$img_class}' src='".get_template_directory_uri()."{$img_src}' />";    
         }
         
         $c = ($style=='style-10') ? $color : ''; 
         
         return "<div class='panel {$style} {$c}' {$minH}>{$div_open} <h5>{$img} {$title}</h5> <p>";        
    }
    
    
    /** end of panel */    
    public function shortcode_panel_end(){
        $close_div = (in_array($this->panel_atts['style'],$this->panel_special_styles)) ? '</div>' : '';
        return "</p>{$close_div}</div>";
    }    
    
        

    /** TABLES */
    
    /** open table structure */    
    public function shortcode_table($atts){
         $settings = array(
            'style' => 'style-1',
            'color' => ''
         );
         extract(shortcode_atts(array(
              'style' => $this->getValue($settings,'table','style'),
              'color' => $this->getValue($settings,'table','color')
         ), $atts)); 
         // sanitize setting if user selected color and a not colorified style
         $c = ($style=='style-6') ? $color : '';
         
         return "<table class='table {$style} {$c}'>";  
    }
    
    
    /** close table structure */     
    public function shortcode_table_end(){
         return "</table>";  
    } 
    

    /** open thead structure */     
    public function shortcode_table_head(){
         return "<thead>";  
    } 
    
  
    /** close thead structure */     
    public function shortcode_table_head_end(){
         return "</thead>";  
    }         


    /** open tbody structure */     
    public function shortcode_table_body(){
         return "<tbody>";  
    } 
    
  
    /** close tbody structure */     
    public function shortcode_table_body_end(){
         return "</tbody>";  
    } 
    
    
    /** open th structure */     
    public function shortcode_table_th(){
         return "<th>";  
    }  
  
  
    /** close th structure */     
    public function shortcode_table_th_end(){
         return "</th>";  
    }  
      
       
    /** open td structure */     
    public function shortcode_table_td($atts){
        extract(shortcode_atts(array(
            'data_title' => ''
        ), $atts));         
        return "<td data-title='{$data_title}'>";  
    }  
     
     
    /** close td structure */     
    public function shortcode_table_td_end(){
         return "</td>";  
    } 
    
    
    /** open tr structure */     
    public function shortcode_table_tr(){
         return "<tr>";  
    }  
     
     
    /** close tr structure */     
    public function shortcode_table_tr_end(){
         return "</tr>";  
    } 
    
   
    /** TABS */
    
    /** open tab */
    public function shortcode_tab($atts){
         $settings = array(
            'style' => 'style-1',
            'color' => ''
         );
         extract(shortcode_atts(array(
              'style'  => $this->getValue($settings,'tab','style'),
              'color' => $this->getValue($settings,'tab','color')
         ), $atts)); 
         
         $c = ($style == 'style-10') ? $color : '';
         return "<div class='tab {$style} {$c}'>";          
    }
    
    /** close tab */
    public function shortcode_tab_end(){
        return "</div>";
    }
    
    /** open tab title */    
    public function shortcode_tab_title_holder($atts){
        return "<dl>";   
    }
    
    
    /** close tab title holder */    
    public function shortcode_tab_title_holder_end(){
         return "</dl>";  
    }    
    
    
    /** tab title */    
    public function shortcode_tab_title($atts){
         extract(shortcode_atts(array(
              'title' => 'Title',
              'active' => 'false'
         ), $atts)); 
         
         $href = $this->slugify($title);
         $act = ($active == 'true') ? 'active' : '';
         return "<dd><a href='#{$href}' class='{$act}'>{$title}</a></dd>";    
    } 
    
    
    /** open tab content holder */        
    public function shortcode_tab_content_holder(){
         return "<ul>";  
    }  

    /** tab content holder end tag */    
    public function shortcode_tab_content_holder_end(){
         return "</ul>";  
    } 

    /** tab content */    
    public function shortcode_tab_content($atts){
         extract(shortcode_atts(array(
              'active' => 'false'
         ), $atts)); 
         $act = ($active == 'true') ? 'active' : '';
         return "<li class='{$act}'>";    
    } 
    
    /** tab content end */
    public function shortcode_tab_content_end(){
        return "</li>";
    }

    /** TOOLTIPS */
    
    /** tooltip (open tag) */    
	public function shortcode_tooltip($atts){
         
         $settings = array(
              'data_width' => 150,
              'style'      => 'style-1',
              'color'      => 'dark',
              'placement'  => ''          
         );
            
         extract(shortcode_atts(array(
              'text'       => 'Tooltip',
              'data_width' => $this->getValue($settings,'tooltip','data_width'),
              'style'      => $this->getValue($settings,'tooltip','style'),
              'color'      => $this->getValue($settings,'tooltip','color'),
              'placement'  => $this->getValue($settings,'tooltip','placement') 
         ), $atts));
         
         return "<span data-width='{$data_width}' class='tooltip {$style} {$color} {$placement}' title='{$text}'>";
	}
    
    
    /** tooltip close tag */     
    public function shortcode_tooltip_end(){
         return "</span>";  
    }
    
    

    /** FORMS */
    
    /** open form */    
    public function shortcode_form($atts){
         $settings = array(
              'style' => 'style-1'
         );
         
         extract(shortcode_atts(array(
              'id' => '',
              'name' => '',         
              'style'  => $this->getValue($settings,'form','style'),
              'action' => '',
              'method' => 'post'              
         ), $atts)); 
         
         return "<form id='{$id}' name='{$name}' class='{$style}' action='{$action}' method='{$method}'>";  
    }
    
    
    /** close form */     
    public function shortcode_form_end(){
         return "</form>";  
    } 

    /** label */     
    public function shortcode_label($atts){
         extract(shortcode_atts(array(
             'id' => '',
             'name' => '',
             'text'  => 'Label text',
             'for' => ''
         ), $atts));         
         return "<label id='{$id}' name='{$name}' for='{$for}'>{$text}</label>";  
    } 
    
    /** open fieldset structure */     
    public function shortcode_fieldset($atts){
         extract(shortcode_atts(array(
             'id' => '',
             'name' => '',
             'legend'  => 'Fieldset title',
             'disabled' => 'false'
         ), $atts));
         
         $is_disabled = ($disabled=='false' || $disabled=='') ? '' : 'disabled="disabled"';
                  
         return "<fieldset id='{$id}' name='{$name}' {$is_disabled}><legend>{$legend}</legend>";  
    } 
    
          
    /** close fieldset structure */     
    public function shortcode_fieldset_end($atts){
         return "</fieldset>";  
    }
    
    
    /** input textfield */     
    public function shortcode_text_input($atts){
         extract(shortcode_atts(array(
              'id'  => '',
              'name' => '',
              'placeholder' => 'Type here...',
              'value' => '',
              'disabled' => 'false',
              'error' => 'false'
         ), $atts)); 
         
         $is_disabled = ($disabled=='false' || $disabled=='') ? '' : 'disabled="disabled"';
         $class =  ($disabled=='false' || $disabled=='') ? '' : 'disabled';  
         $error = ($error == 'false') ? '' : 'error';
         
         return "<input type='text' id='{$id}' name='{$name}' class='{$class} {$error}' placeholder='{$placeholder}' value='{$value}' {$is_disabled} />";  
    }  
    

    /** password field */     
    public function shortcode_password_input($atts){
         extract(shortcode_atts(array(
              'id'  => '',
              'name' => '',
              'disabled' => 'false',
              'error' => 'false'
         ), $atts)); 
         
         $is_disabled = ($disabled=='false' || $disabled=='') ? '' : 'disabled="disabled"';  
         $error = ($error == 'false') ? '' : 'error';
         $class =  ($disabled=='false' || $disabled=='') ? '' : 'disabled';
         return "<input type='password' id='{$id}' name='{$name}' class='{$class} {$error}' {$is_disabled} />";  
    }
    
    /** button input */     
    public function shortcode_button_input($atts){
         extract(shortcode_atts(array(
              'id' => '',
              'name' => '',
              'label'  => 'Button',
              'size' => 'medium',
              'style' => 'style-1',
              'color' => 'blue',
              'disabled' => 'false'
         ), $atts)); 
         
         $is_disabled = ($disabled=='false' || $disabled=='') ? '' : 'disabled="disabled"';  
         $class =  ($disabled=='false' || $disabled=='') ? '' : 'disabled';
         return "<input type='button' id='{$id}' name='{$name}' class='button {$style} {$size} {$color} {$class}' value='{$label}' {$is_disabled} />";  
    }
    
    /** submit input */     
    public function shortcode_submit_input($atts){
         extract(shortcode_atts(array(
              'id' => '',
              'name' => '',
              'label'  => 'Button',
              'size' => 'medium',
              'style' => 'style-1',
              'color' => 'blue',
              'disabled' => 'false'
         ), $atts)); 
         
         $is_disabled = ($disabled=='false' || $disabled=='') ? '' : 'disabled="disabled"';  
         $class =  ($disabled=='false' || $disabled=='') ? '' : 'disabled';
         return "<input type='submit' id='{$id}' name='{$name}' class='button {$style} {$size} {$color} {$class}' value='{$label}' {$is_disabled} />";  
    }
        
    /** searchbox */
    public function shortcode_searchbox($atts){
        
         extract(shortcode_atts(array(
              'placeholder'  => 'Search ...',
              'disabled' => 'false'
         ), $atts));  
         
        $is_disabled = ($disabled=='false' || $disabled=='') ? '' : 'disabled="disabled"'; 
        $class = ($disabled==false || $disabled=='false' || $disabled=='') ? '' : 'disabled';
              
        return "<div class='search-box' class='{$class}'>".
			   "<div class='search-input'>".
			   "<input placeholder='{$placeholder}' type='text' {$is_disabled}/>".
			   "</div>".
			   "<div class='search-icon'><a></a></div>".
		       "</div>";
    }
        
        
    /** textarea */     
    public function shortcode_textarea($atts){
         extract(shortcode_atts(array(
              'id' => '',
              'name' => '',
              'placeholder'  => 'Type here...',
              'value' => '',
              'disabled' => 'false',
              'min_height' => 150,
              'error' => 'false'
         ), $atts)); 
         
         $is_disabled = ($disabled=='false' || $disabled=='') ? '' : 'disabled="disabled"';  
         $error = ($error == 'false') ? '' : 'error';
              
         return "<textarea id='{$id}' name='{$name}' class='{$error}' placeholder='{$placeholder}' style='min-height: {$min_height}px;' {$is_disabled} />{$value}</textarea>";  
    } 


    /** custom select open tag */     
    public function shortcode_select($atts){
         extract(shortcode_atts(array(
              'id'  => 'select_id',
              'name' => '',
              'disabled' => 'false'
         ), $atts)); 
         $is_disabled = ($disabled=='false' || $disabled=='') ? '' : 'disabled="disabled"';        
         return "<select id='{$id}' name='{$name}' class='custom-select' {$is_disabled}>";  
    } 
    
    
    /** custom select close tag */     
    public function shortcode_select_end(){
         return "</select>";  
    } 
    
      
    /** custom select option tag */     
    public function shortcode_option($atts){
         extract(shortcode_atts(array(
              'text'  => 'Option',
              'selected' => 'false',
              'value' => '',
              'disabled' => 'false'
         ), $atts)); 
                 
         $is_selected = ($selected=='false' || $selected=='') ? '' : 'selected="selected"';
         $is_disabled = ($disabled=='false' || $disabled=='') ? '' : 'disabled="disabled"';
         return "<option value='{$value}' {$is_selected} {$is_disabled}>{$text}</option>";  
    } 
    
     
    /** custom radiobuttons */
    
    private $radio_group_id = '';
         
    public function shortcode_radiogroup($atts){
         extract(shortcode_atts(array(
              'name'  => 'radio-group'
         ), $atts)); 

         $this->radio_group_id = $name;
         return '';
    } 
    
    
    public function shortcode_radio($atts){
         extract(shortcode_atts(array(
              'label'  => 'Radio Button',
              'id' => 'radio-ID',
              'checked' => 'false',
              'disabled' => 'false'
         ), $atts)); 

         $is_disabled = ($disabled=='false' || $disabled=='') ? '' : 'disabled="disabled"';
         $class = ($disabled=='false' || $disabled=='') ? '' : 'disabled';
         $is_checked = ($checked=='false' || $checked=='') ? '' : 'checked="checked"';
         
         return "<input class='{$class}' type='radio' id='{$id}' name='{$this->radio_group_id}' {$is_disabled} {$is_checked}/>".
		        "<label for='{$id}' class='{$class}'>{$label}</label>";
    } 
    
        
    public function shortcode_radiogroup_end(){
        return '';
    }     
     
    
    /** custom checkboxes */
    public function shortcode_checkbox($atts){
         extract(shortcode_atts(array(
              'label'  => 'Checkbox',
              'id' => 'checkbox-ID',
              'checked' => 'false',
              'disabled' => 'false'
         ), $atts)); 

         $is_disabled = ($disabled=='false' || $disabled=='') ? '' : 'disabled="disabled"';
         $class = ($disabled=='false' || $disabled=='') ? '' : 'disabled';
         $is_checked = ($checked=='false' || $checked=='') ? '' : 'checked="checked"';
         
         return "<input class='{$class}' type='checkbox' id='{$id}' {$is_disabled} {$is_checked}/>".
		        "<label for='{$id}' class='{$class}'>{$label}</label>";
    } 
   
   

    
    
    /** DASHBOARD */
    
    /** Renders a tabbed page to display for the theme menu defined above. */ 
    function jf_ui_plugin_display() { 
        $tabs = Array(
            "general_options" => "General",
            "grid_options" => "Grid",
            "menu_options" => "Menus",
            "button_options" => "Buttons",
            "panel_options" => "Panels",
            "tab_options" => "Tabs",
            "form_options" => "Forms",
            "table_options" => "Tables",
            "alert_options" => "Alerts",
            "tooltip_options" => "Tooltips"
        );
    ?> 
        <!-- Create a header in the default WordPress 'wrap' container --> 
        <div class="wrap adm_jumpeye jf_opt_wrapper"> 
         
            <div id="icon-plugins" class="icon32"></div> 
            <h2>UI Elements Options</h2>
            <div style="border-bottom: 1px solid #E6DB55; border-top: 1px solid #E6DB55; padding: 5px 0; margin: 5px 0;">
            &nbsp;&nbsp;&nbsp;Please visit the <a href="http://www.jumpeye.com/ui-elements" target="_blank">Plugin's Homepage</a> for a full specified manual.
            </div> 
            <?php settings_errors(); ?>
            
            <?php  
                $active_tab = isset( $_GET[ 'tab' ] ) ? $_GET[ 'tab' ] : 'general_options';
            ?>   
            
            <h2 class="nav-tab-wrapper">  
            <?php
                foreach($tabs as $k => $v){
            ?>
                <a href="?page=plugins.php?page=jf_ui_plugin_options&tab=<?php echo $k; ?>" class="nav-tab <?php echo $active_tab == $k ? 'nav-tab-active' : ''; ?>"><?php echo $v; ?></a>
            <?php                    
                }
            ?>
            </h2>
                      
            <form method="post" action="options.php"> 
                <?php
                    settings_fields( 'jf_ui_'.$active_tab );  
                    do_settings_sections( 'jf_ui_'.$active_tab );

                    // Submit button appears only on the necessary pages
                    if(!in_array($active_tab, array('general_options','grid_options'))){
                        submit_button();
                    }
                                        
                    if($active_tab != 'general_options'){
                        echo $this->shortcodePreview();
                    }
                ?> 
            </form> 
             
        </div><!-- /.wrap --> 
    <?php 
    }    

    /** ui init general opts */
    function jf_ui_initialize_general_options() { 
     
        // If the theme options don't exist, create them.  
        if( false == get_option( 'jf_ui_general_options' ) ) {    
            add_option( 'jf_ui_general_options' );  
        } // end if  
      
        // First, we register a section. This is necessary since all future options must belong to a   
        add_settings_section(  
            'general_settings_section',               // ID used to identify this section and with which to register options  
            '',                                       // Title to be displayed on the administration page  
            array($this, 'general_options_callback'), // Callback used to render the description of the section  
            'jf_ui_general_options'                   // Page on which to add this section of options  
        );  
          
        // Next, we'll introduce the fields for toggling the visibility of content elements. 
        // @todo : add_settings_field( );
         
        // Finally, we register the fields with WordPress 
        register_setting( 
            'jf_ui_general_options', 
            'jf_ui_general_options' 
        ); 
    }
    
    /** general_options_callback */
    function general_options_callback() { 
        ?>
        <p>By using the included responsive grid system, you can create different page layouts that will adapt to the size of the device displaying the website.<br />
        You can add UI elements in your page by inserting the shortcodes in the text editor.</p>
        <p>You can read more about the original Jumpeye UI elements on<br /><a href="http://www.jumpeye.com/components/" target="_blank">http://www.jumpeye.com/components/</a>.</p>      
        <?php
    } 
    
    /** init grid opts */
    function jf_ui_initialize_grid_options() { 
        if( false == get_option( 'jf_ui_grid_options' ) ) {    
            add_option( 'jf_ui_grid_options' );  
        }  
        add_settings_section(  
            'grid_settings_section',  
            '',                          
            array($this, 'grid_options_callback'),  
            'jf_ui_grid_options'  
        );  
          
        // Next, we'll introduce the fields for toggling the visibility of content elements. 
        // @todo : add_settings_field( );
         
        // Finally, we register the fields with WordPress 
        register_setting( 
            'jf_ui_grid_options', 
            'jf_ui_grid_options' 
        ); 
    }
    
    /** grid opts callback */
    function grid_options_callback() {
    ?>    
    <p>Using the included responsive grid system, you can create different page layouts that will adapt to the size of the device on which the website is displayed. You can create a grid layout by using the HTML code of this (see examples on <a href="http://www.jumpeye.com/ui-elements/grid.html" target="_blank">http://www.jumpeye.com/ui-elements/grid.html</a>) or by using the <strong>&#91;jf_row&#93;</strong> and <strong>&#91;jf_col&#93;</strong> shortcodes.
<br />Below you can see an example of the usage of the grid's shortcode and a complete list with the available attributes.</p>
        <h4>SHORTCODE USAGE:</h4>
        <pre class="code_ex">
    [jf_row]
        [jf_col value="12"]
            [jf_row]
                [jf_col value="6"]
                    ...
                    content panel one
                    ...
                [jf_col_end]
                [jf_col value="6"]
                    ...
                    content panel two
                    ...
                [jf_col_end]
                [jf_col value="6"]
                    ...
                    content panel three
                    ...
                [jf_col_end]  
            [jf_row_end]
        [jf_col_end]
        [jf_col value="6"]
            ...
            sidebar
            ...
        [jf_col_end]  
    [jf_row_end]
        </pre>
        <h4>OPTIONS</h4>
        <p><em>The following attribute can be used with the <strong>&#91;jf_col&#93;</strong> shortcode:</em></p>
        <p><strong>value</strong></p>
        <p class="adm_description">The number of columns used as width for that container element. The default grid built in this theme comes with 18 columns (922px).</p><br />
    <?php            
    }             
     
     
    function jf_ui_initialize_button_options() {
        
        $button_options = array(
            "size" => "The attribute sets the size of the button. Possible values are: small, medium, large.",
            "style" => "The style attribute sets the skin of the button. There are fourteen button skins that can be used, as follows: style-1, style-2, style-3, style-4, style-5, style-6, style-7, style-8, style-9, style-10, style-11, style-12, style-13, style-14.",
            "color" => "This attribute sets the color of the button. Possible values are: yellow, blue, red, green, light-gray, dark-gray, transparent-white, transparent-black.");
        
        $settings_fields = array(
            "style", "size", "color"
        );
                
        if( false == get_option( 'jf_ui_button_options' ) ) {    
            add_option( 'jf_ui_button_options' );  
        }  
        add_settings_section(  
            'button_settings_section',  
            '',                          
            array($this, 'button_options_callback'),  
            'jf_ui_button_options'  
        );  
                  
        // Next, we'll introduce the fields for toggling the visibility of content elements. 
        foreach($button_options as $k => $v){
            add_settings_field(   
                "$k",                        
                "<strong>$k</strong><br /><p class='adm_description'>$v<br /><br /></p>",                             
                array($this, "jf_ui_button_{$k}_callback"),   
                "jf_ui_button_options",   
                "button_settings_section"  
            );              
        }
         
        // Finally, we register the fields with WordPress 
        register_setting( 
            'jf_ui_button_options', 
            'jf_ui_button_options' 
        ); 
         
    }
     
    /** button callbacks */ 
    function button_options_callback() {
    ?><p>You can choose from a huge set of buttons to add to your content. They can be used very easily by adding their HTML code (see examples on <a href="http://www.jumpeye.com/ui-elements/buttons.html" target="_blank">http://www.jumpeye.com/ui-elements/buttons.html</a>) or by using the <strong>&#91;jf_button&#93;</strong> shortcode.
<br />Below you can see an example of the usage of the button's shortcode and a complete list with the available attributes.</p>   
        <h4>SHORTCODE USAGE :</h4>
        <pre class="code_ex">
    [jf_button label="Sign in" size="small" style="style-1" color="blue"]  
        </pre>
        <h4>OPTIONS :</h4>
        <p><em>The following attributes can be used with the <strong>&#91;jf_button&#93;</strong> shortcode:</em></p>
        <p><strong>label</strong></p><p class="adm_description">The label of the button.</p>
    <?php            
    }         
    
    
    function jf_ui_button_style_callback(){
        $styles = 15; // style-1 .. style-14

        $options = get_option('jf_ui_button_options');  
        if ( ! isset( $options['style'] ) ){
            $options['style'] = 'style-1';
        }  
        ?> 
        <select class="adm_select" id="style"  name="jf_ui_button_options[style]">
        <?php
        for($i=1;$i<$styles; $i++){
        ?>
            <option value="<?php echo 'style-'.$i; ?>" <?php selected( $options['style'], 'style-'.$i ); ?>><?php echo 'style-'.$i; ?></option>
        <?php    
        }
        ?>
        </select>
        <?php          
    }
    
    function jf_ui_button_size_callback(){
        // small, medium, large
        $options = get_option('jf_ui_button_options');  
        if ( ! isset( $options['size'] ) ){
            $options['size'] = 'medium';
        }  
        ?> 
        <select class="adm_select" id="size"  name="jf_ui_button_options[size]">
            <option value="small" <?php selected( $options['size'], 'small' ); ?>>small</option>
            <option value="medium" <?php selected( $options['size'], 'medium' ); ?>>medium</option>
            <option value="large" <?php selected( $options['size'], 'large' ); ?>>large</option>
        </select>
        <?php          
    }        
    
    function jf_ui_button_color_callback(){
        $colors = array('yellow', 'blue', 'red', 'green', 'light-gray', 'dark-gray', 'transparent-white', 'transparent-black');
        $options = get_option('jf_ui_button_options');  
        if ( ! isset( $options['color'] ) ){
            $options['color'] = 'blue';
        }  
        ?> 
        <select class="adm_select" id="color" name="jf_ui_button_options[color]">
        <?php
            foreach($colors as $k => $v){
             ?>
            <option value="<?php echo $v; ?>" <?php selected( $options['color'], $v ); ?>><?php echo $v; ?></option>            
            <?php    
            }
        ?>
        </select>
        <?php          
    }
    
    /** tabs */    
    function jf_ui_initialize_tab_options() { 
        $tab_options = array(
            "style" => "The style attribute sets the skin of the tabs. There are ten skins for tabs that can be used, as follows: style-1, style-2, style-3, style-4, style-5, style-6, style-7, style-8, style-9, style-10.",
            "color" => "The color attribute is <strong>available only for skin style-10</strong>. Possible values are: orange, green, blue, purple, aqua, magenta."
        );
        
        if( false == get_option( 'jf_ui_tab_options' ) ) {    
            add_option( 'jf_ui_tab_options' );  
        }
        
        // section-1  
        add_settings_section(  
            'tab_settings_section',  
            '',                          
            array($this, 'tab_options_callback'),  
            'jf_ui_tab_options'  
        );  
          
        foreach($tab_options as $k => $v){
            add_settings_field(   
                "$k",                        
                "<strong>$k</strong><br /><p class='adm_description'>$v<br /><br /></p>",                             
                array($this, "jf_ui_tab_{$k}_callback"),   
                "jf_ui_tab_options",   
                "tab_settings_section"  
            );              
        }
        
        // section-2
        add_settings_section(  
            'tab_settings_section_2',  
            '',                          
            array($this, 'tab_options_callback_2'),  
            'jf_ui_tab_options'  
        ); 
                 
        register_setting( 
            'jf_ui_tab_options', 
            'jf_ui_tab_options' 
        ); 
    }
    
    function tab_options_callback_2(){
        echo '<p><em>The following two attributes can be used with the <strong>&#91;jf_tab_title&#93;</strong> shortcode:</em></p>
              <p><strong>title</strong></p><p class="adm_description">The title of the tab.</p>
              <p class="margin_top_30"><strong>active</strong></p><p class="adm_description">This attribute sets the active state for one tab of the tabs group. Only one of the tabs can be set active at a time. You also need to set active the content with the same index. (E.g. [jf_tab_title title="Tab 1 title" active="true"] … [jf_tab_content active="true"] Tab 1 content [jf_tab_content_end]).</p>
              <p class="margin_top_30"><em>The following attribute can be used with the <strong>&#91;jf_tab_content&#93;</strong> shortcode:</em></p>
              <p><strong>active</strong></p><p class="adm_description">This attribute sets the active state for the content of the active tab.</p>';        
    }
    
    function tab_options_callback() {
    ?>  <p>You can add tabbed content by including the HTML code of the tabs (see examples on <a href="http://www.jumpeye.com/ui-elements/tabs.html" target="_blank">http://www.jumpeye.com/ui-elements/tabs.html</a>) or by using the <strong>&#91;jf_tab&#93;</strong> shortcode.
<br />Below you can see an example of the usage of the tab's shortcode and a complete list with the available attributes.</p>  
        <h4>SHORTCODE USAGE :</h4>
        <pre class="code_ex">
    [jf_tab style="style-10" color="blue"]
        [jf_tab_title_holder]
            [jf_tab_title title="Tab 1 title" active="true"]
            [jf_tab_title title="Tab 2 title"]
            [jf_tab_title title="Tab 3 title"]
        [jf_tab_title_holder_end]
        [jf_tab_content_holder]
            [jf_tab_content active="true"]
                ...
                Tab 1 content
                ...
            [jf_tab_content_end]
            [jf_tab_content]
                ...
                Tab 2 content
                ...
            [jf_tab_content_end]
            [jf_tab_content]
                ...
                Tab 3 content
                ...
            [jf_tab_content_end]
        [jf_tab_content_holder_end]
    [jf_tab_end]
        </pre>
        <h4>OPTIONS :</h4>
        <p><em>The following two attributes can be used with the <strong>&#91;jf_tab&#93;</strong> shortcode:</em></p>
    <?php            
    }
    
    function jf_ui_tab_style_callback(){
        $styles = 11; // style-1 .. style-10
        $options = get_option('jf_ui_tab_options');  
        if ( ! isset( $options['style'] ) ){
            $options['style'] = 'style-1';
        }  
        ?> 
        <select class="adm_select" id="style"  name="jf_ui_tab_options[style]">
        <?php
        for($i=1;$i<$styles; $i++){
        ?>
            <option value="style-<?php echo $i; ?>" <?php selected( $options['style'], 'style-'.$i ); ?>><?php echo 'style-'.$i; ?></option>
        <?php    
        }
        ?>
        </select>
        <?php          
    }
    
    function jf_ui_tab_color_callback(){
        $colors = array('orange', 'green', 'blue', 'purple', 'aqua', 'magenta');
        $options = get_option('jf_ui_tab_options');  
        if ( ! isset( $options['color'] ) ){
            $options['color'] = 'blue';
        }  
        ?> 
        <select class="adm_select" id="color"  name="jf_ui_tab_options[color]">
        <?php
            foreach($colors as $k => $v){
            ?>
            <option value="<?php echo $v; ?>" <?php selected( $options['color'], $v ); ?>><?php echo $v; ?></option>            
            <?php    
            }
        ?>
        </select>
        <?php          
    }
      
    
    /** menus */  
    function jf_ui_initialize_menu_options() {
    
        $menu_options = array(
            "style" => "The style attribute sets the skin of the menu. There are eight menu skins that can be used for both horizontal and vertical menus.<br />Possible values: style-1, style-2, style-3, style-4, style-5, style-6, style-7, style-8.",
            "color" => "The color attribute is <strong>available only for skins style-6, style-7, style-8</strong>. Possible values: orange, green, blue, purple, aqua, magenta.",
            "orientation" => "This parameter sets the orientation of the menu. Possible values: horizontal, vertical.");
            
        if( false == get_option( 'jf_ui_menu_options' ) ) {    
            add_option( 'jf_ui_menu_options' );  
        }  
        
        // section-1
        add_settings_section(  
            'menu_settings_section',  
            '',                          
            array($this, 'menu_options_callback'),  
            'jf_ui_menu_options'  
        );  

        foreach($menu_options as $k => $v){
            add_settings_field(   
                "$k",                        
                "<strong>$k</strong><br /><p class='adm_description'>$v<br /><br /></p>",                             
                array($this, "jf_ui_menu_{$k}_callback"),   
                "jf_ui_menu_options",   
                "menu_settings_section"  
            );              
        }
        
        // section-2
        add_settings_section(  
            'menu_settings_section_2',  
            '',                          
            array($this, 'menu_options_callback_2'),  
            'jf_ui_menu_options'  
        ); 
         
        register_setting( 
            'jf_ui_menu_options', 
            'jf_ui_menu_options' 
        ); 
         
    }
    
    /** section-2 callback */ 
    function menu_options_callback_2(){
        echo '<p><em>The following four attributes can be used with the <strong>[jf_menu_main_item]</strong> and <strong>[jf_menu_sub_item]</strong> shortcodes:</em></p>
              <p><strong>label</strong></p><p class="adm_description">The label of the menu item.</p>
              <p class="margin_top_30"><strong>url</strong></p><p class="adm_description">The URL associated with the menu item.</p>
              <p class="margin_top_30"><strong>target</strong></p><p class="adm_description">Specifies where to open the associated URL of the menu item.</p>
              <p class="margin_top_30"><strong>type</strong></p><p class="adm_description">If the menu item contains submenu items, you can specify where to display these: in the bottom<br />of the parent item (type="down") or in the right side of the parent item (type="flyout"). Possible values: down, flyout.</p>';
    }
    
    /** section-1 callback */ 
    function menu_options_callback() {
    ?><p>You can add horizontal and vertical menus in your page by including the HTML code of the menus (see examples on <a href="http://www.jumpeye.com/ui-elements/drop-down-menus.html" target="_blank">http://www.jumpeye.com/ui-elements/drop-down-menus.html</a>) or even easier by using the <strong>&#91;jf_menu&#93;</strong> shortcode.<br />Below you can see an example of use case for the menu shortcode and a complete list of  the available attributes.</p>
        <h4>SHORTCODE USAGE :</h4>
        <pre class="code_ex">
    [jf_menu style="style-6" color="blue" orientation="horizontal"]      
        [jf_menu_main_item label="Item_1" url="www.item1.com" target="self"]        
        [jf_menu_main_item label="Item_2" type="down"]        
            [jf_menu_sub_item label="Item_2_1" url="www.item2_1.com" target="blank"]        
            [jf_menu_sub_item label="Item_2_2" type="flyout"]        
                [jf_menu_sub_item label="Item_2_2_1" url="www.item2_2_1" target="self"]        
                [jf_menu_sub_item label="Item_2_2_2" url="www.item2_2_2" target="self"]        
                [jf_menu_sub_item label="Item_2_2_3" url="www.item2_2_3" target="self"]        
            [jf_menu_sub_item_end]        
            [jf_menu_sub_item label="Item_2_3" url="www.item2_3.com" target="self"]        
        [jf_menu_main_item_end]        
        [jf_menu_main_item label="Item_3" url="www.item3.com" target="self"]        
    [jf_menu_end]
        </pre>
        <h4>OPTIONS :</h4>
        <p><em>The following three attributes can be used with the <strong>&#91;jf_menu&#93;</strong> shortcode:</em></p>
    <?php            
    }
    
    function jf_ui_menu_style_callback(){

        $styles = 9; // style-1 .. style-8

        $options = get_option('jf_ui_menu_options');  
        if ( ! isset( $options['style'] ) ){
            $options['style'] = 1;
        }  
        ?> 
        <select class="adm_select" id="style"  name="jf_ui_menu_options[style]">
        <?php
        for($i=1;$i<$styles; $i++){
        ?>
            <option value="style-<?php echo $i; ?>" <?php selected( $options['style'], 'style-'.$i ); ?>><?php echo 'style-'.$i; ?></option>
        <?php    
        }
        ?>
        </select>
        <?php          
    }
    
    function jf_ui_menu_color_callback(){
        $colors = array('orange','green','blue','purple','aqua','magenta');
        $options = get_option('jf_ui_menu_options');  
        if ( ! isset( $options['color'] ) ){
            $options['color'] = 'blue';
        }  
        ?> 
        <select class="adm_select" id="color"  name="jf_ui_menu_options[color]">
        <?php
            foreach($colors as $k => $v){
            ?>
            <option value="<?php echo $v; ?>" <?php selected( $options['color'], $v ); ?>><?php echo $v; ?></option>            
            <?php    
            }
        ?>
        </select>
        <?php          
    }
    
    function jf_ui_menu_orientation_callback(){
        $options = get_option('jf_ui_menu_options');  
        if ( ! isset( $options['orientation'] ) ){
            $options['orientation'] = 'horizontal';
        }  
        ?> 
        <select class="adm_select" id="orientation"  name="jf_ui_menu_options[orientation]">
            <option value="horizontal" <?php selected( $options['orientation'], 'horizontal' ); ?>>horizontal</option>
            <option value="vertical" <?php selected( $options['orientation'], 'vertical' ); ?>>vertical</option>
        </select>
        <?php          
    }
    
    
    /** panels */
    function jf_ui_initialize_panel_options() { 
        $panel_options = array(
            "style" => "The style attribute sets the skin of the panel. There are ten skins for panels that can be used, as follows: style-1, style-2, style-3, style-4, style-5, style-6, style-7, style-8, style-9, style-10.",
            "color" => "The color attribute is <strong>available only for skin style-10</strong>. Possible values are: orange, green, blue, purple, aqua, magenta."
        );
                    
        if( false == get_option( 'jf_ui_panel_options' ) ) {    
            add_option( 'jf_ui_panel_options' );  
        }  
        
        // section-1
        add_settings_section(  
            'panel_settings_section',  
            '',                          
            array($this, 'panel_options_callback'),  
            'jf_ui_panel_options'  
        );  
                  
        // Next, we'll introduce the fields for toggling the visibility of content elements. 
        foreach($panel_options as $k => $v){
            add_settings_field(   
                "$k",                        
                "<strong>$k</strong><br /><p class='adm_description'>$v<br /><br /></p>",                             
                array($this, "jf_ui_panel_{$k}_callback"),   
                "jf_ui_panel_options",   
                "panel_settings_section"  
            );              
        }
        
        // section-2
        add_settings_section(  
            'panel_settings_section_2',  
            '',                          
            array($this, 'panel_options_callback_2'),  
            'jf_ui_panel_options'  
        );         
         
        // Finally, we register the fields with WordPress 
        register_setting( 
            'jf_ui_panel_options', 
            'jf_ui_panel_options' 
        ); 
         
    }
     
    
    /** section-2 callback */ 
    function panel_options_callback_2(){
        echo '<p><strong>min_height</strong></p><p class="adm_description">The min_height parameter can be used when you have more panels in the same row and you want to set the same height for each of them. In this case you can set the same value for the min_height attribute for each panel of that row.</p>';
    }
         
    function panel_options_callback() {
    ?>  <p>Panels could be very useful elements when you want to highlight a part of your content. You can add panels to your page by using their HTML code (see examples on <a href="http://www.jumpeye.com/ui-elements/panels.html" target="_blank">http://www.jumpeye.com/ui-elements/panels.html</a>) or by using the <strong>&#91;jf_panel&#93;</strong> shortcode.
<br />Below you can see an example of the usage of the panel's shortcode and a complete list with the available attributes.</p> 
        <h4>SHORTCODE USAGE :</h4>
        <pre class="code_ex">
    [jf_panel title="Panel title" style="style-10" color="blue" min_height="150"]
        ...
        panel content
        ...
    [jf_panel_end]
        </pre>
        <h4>OPTIONS :</h4>
        <p><em>The following attributes can be used with the <strong>&#91;jf_panel&#93;</strong> shortcode:</em></p>
        <p><strong>title</strong></p><p class="adm_description">The title of the panel's content.</p>
    <?php            
    } 
    
    function jf_ui_panel_style_callback(){
        $styles = 11; // style-1 .. style-10
        $options = get_option('jf_ui_panel_options');  
        if ( ! isset( $options['style'] ) ){
            $options['style'] = 'style-1';
        }  
        ?> 
        <select class="adm_select" id="style" name="jf_ui_panel_options[style]">
        <?php
        for($i=1;$i<$styles; $i++){
        ?>
            <option value="style-<?php echo $i; ?>" <?php selected( $options['style'], 'style-'.$i ); ?>><?php echo 'style-'.$i; ?></option>
        <?php    
        }
        ?>
        </select>
        <?php          
    }
    
    function jf_ui_panel_color_callback(){
        $colors = array('orange', 'green', 'blue', 'purple', 'aqua', 'magenta');
        $options = get_option('jf_ui_panel_options');  
        if ( ! isset( $options['color'] ) ){
            $options['color'] = 'blue';
        }  
        ?> 
        <select class="adm_select" id="color"  name="jf_ui_panel_options[color]">
        <?php
            foreach($colors as $k => $v){
            ?>
            <option value="<?php echo $v; ?>" <?php selected( $options['color'], $v ); ?>><?php echo $v; ?></option>            
            <?php    
            }
        ?>
        </select>
        <?php          
    }
    
    
    /** forms */
    function jf_ui_initialize_form_options() { 
        $form_options = array(
            "style" => "The style attribute sets the skin of the form elements. Currently one form skin is available: style-1."
        );
        
        if( false == get_option( 'jf_ui_form_options' ) ) {    
            add_option( 'jf_ui_form_options' );  
        }  
        
        // section-1
        add_settings_section(  
            'form_settings_section',  
            '',                          
            array($this, 'form_options_callback'),  
            'jf_ui_form_options'  
        );  

        foreach($form_options as $k => $v){
            add_settings_field(   
                "$k",                        
                "<strong>$k</strong><br /><p class='adm_description'>$v<br /><br /></p>",                             
                array($this, "jf_ui_form_{$k}_callback"),   
                "jf_ui_form_options",   
                "form_settings_section"  
            );              
        }
        
        // section-2
        add_settings_section(  
            'form_settings_section_2',  
            '',                          
            array($this, 'form_options_callback_2'),  
            'jf_ui_form_options'  
        ); 
                
        register_setting( 
            'jf_ui_form_options', 
            'jf_ui_form_options' 
        ); 
    }
     
    // section callbacks 
    function form_options_callback() {
    ?>  <p>You can add forms in your content by including the HTML code of the form (see examples on <a href="http://www.jumpeye.com/ui-elements/forms.html" target="_blank">http://www.jumpeye.com/ui-elements/forms.html</a>) or by using the <strong>&#91;jf_form&#93;</strong> shortcode.
<br />Below you can see an example of the usage of the form shortcode and a complete list of the available attributes.</p>   
        <h4>SHORTCODE USAGE:</h4>
        <pre class="code_ex">
    [jf_form style="style-1" action="" method="post"]            	
        [jf_label text="Label text" for="text1"]
        [jf_text_input id="text1" placeholder="Type here ..." value=""]
        [jf_label text="Password" for="psw1"]
        [jf_password_input id="psw1"]
        [jf_label text="Error state" for="text2"]
        [jf_text_input id="text2" placeholder="Type here ..." value="" error="true"]
        [jf_button_input label="Button" size="medium" style="style-10" color="light-gray"]
        
        [jf_searchbox placeholder="Search ..."]
        [jf_textarea placeholder="Type here ..." value=""] 
        [jf_submit_input label="Submit" size="medium" style="style-10" color="light-gray"]
        
        [jf_fieldset legend="Fieldset title"]    
            [jf_select id="select1"]
                [jf_option text="Option one" selected="true"]
                [jf_option text="Option two"]
                [jf_option text="Option three"]
            [jf_select_end]
            
            [jf_radiogroup name="radio-group"]
                [jf_radio label="Radio button one" id="radio-1" disabled="true"]
                [jf_radio label="Radio button two" id="radio-2" checked="true"]
                [jf_radio label="Radio button three" id="radio-3"]
            [jf_radiogroup_end]
            
            [jf_checkbox label="Checkbox one" id="check-1" disabled="true"]
            [jf_checkbox label="Checkbox two" id="check-2" checked="true"]
            [jf_checkbox label="Checkbox three" id="check-3"]        
        [jf_fieldset_end]
    [jf_form_end]
            </pre>
        <h4>OPTIONS :</h4>
        <p><em>The following three attributes can be used with any of the form's elements (inputs, textarea, select, radio button, checkbox):</em></p>
        <p><strong>id</strong></p><p class="adm_description">The ID of the input element. You can set this attribute for each input element.</p>
        <p class="margin_top_30"><strong>name</strong></p><p class="adm_description">The name of the input element. You can set this attribute for each input element.</p>
        <p class="margin_top_30"><strong>disabled</strong></p><p class="adm_description">If this attribute is set to false, the input will be disabled. You can set for each input element this attribute.</p>
        <p class="margin_top_30"><em>The following three attributes can be used with the <strong>&#91;jf_form&#93;</strong> shortcode:</em></p>
    <?php            
    }
    
    function form_options_callback_2(){
    ?>
        <p class=""><strong>action</strong></p><p class="adm_description">The URL of the page where the form-data is sent when the form is submitted.</p>
        <p class="margin_top_30"><strong>method</strong></p><p class="adm_description">Specifies the HTTP method to use when sending form-data.</p>
        <p class="margin_top_30"><em>The following two attributes can be used with the <strong>&#91;jf_label&#93;</strong> shortcode:</em></p>
        <p><strong>text</strong></p><p class="adm_description">The text displayed by the label element.</p>
        <p class="margin_top_30"><strong>for</strong></p><p class="adm_description">Specifies which form element a label is bound to.</p>
        <p class="margin_top_30"><em>The following two attributes can be used with the <strong>&#91;jf_textarea&#93;</strong> shortcode:</em></p>
        <p><strong>placeholder</strong></p><p class="adm_description">Specifies a short hint that describes the expected value of a text area.</p>
        <p class="margin_top_30"><strong>value</strong></p><p class="adm_description">Sets the text content displayed inside the text area.</p>

        <p class="margin_top_30"><em>The following two attributes can be used with the <strong>&#91;jf_text_input&#93;</strong> shortcode:</em></p>
        <p><strong>placeholder</strong></p><p class="adm_description">Specifies a short hint that describes the expected value of a text input.</p>
        <p class="margin_top_30"><strong>value</strong></p><p class="adm_description">Specifies the value of the text input element.</p>
    
        <p class="margin_top_30"><em>The following attribute can be used with the <strong>&#91;jf_password_input&#93;</strong> shortcode:</em></p>
        <p><strong>value</strong></p><p class="adm_description">Specifies the value of the password input element.</p>

        <p class="margin_top_30"><em>The following four attributes can be used with the <strong>&#91;jf_button_input&#93;</strong> and <strong>&#91;jf_submit_input&#93;</strong> shortcode:</em></p>
        <p><strong>label</strong></p><p class="adm_description">The label of the button.</p>
        <p class="margin_top_30"><strong>size</strong></p><p class="adm_description">The attribute sets the size of the button. Possible values are: small, medium, large.</p>
        <p class="margin_top_30"><strong>style</strong></p><p class="adm_description">The style attribute sets the skin of the button. There are fourteen button skins that can be used and these are the following: style-1, style-2,<br />style-3, style-4, style-5, style-6, style-7, style-8, style-9, style-10, style-11, style-12, style-13, style-14.</p>
        <p class="margin_top_30"><strong>color</strong></p><p class="adm_description">This attribute sets the color of the button. Possible values are: yellow, blue, red, green, light-gray, dark-gray, transparent-white, transparent-black.</p>
        
        <p class="margin_top_30"><em>The following two attributes can be used with the <strong>&#91;jf_searchbox&#93;</strong> shortcode:</em></p>
        <p><strong>placeholder</strong></p><p class="adm_description">Specifies a short hint for the search box.</p>
        <p class="margin_top_30"><strong>value</strong></p><p class="adm_description">Specifies the value of the search box element.</p>
        
        <p class="margin_top_30"><em>The following attribute can be used with the <strong>&#91;jf_fieldset&#93;</strong> shortcode:</em></p>
        <p><strong>legend</strong></p><p class="adm_description">The label displayed in the fieldset's header.</p>
        
        <p class="margin_top_30"><em>The following two attributes can be used with the <strong>&#91;jf_option&#93;</strong> shortcode:</em></p>
        <p><strong>text</strong></p><p class="adm_description">The value of the option.</p>
        <p class="margin_top_30"><strong>selected</strong></p><p class="adm_description">If this attribute is true, the option will be selected in the select input.</p>
        
        <p class="margin_top_30"><em>The following two attributes can be used with the <strong>&#91;jf_radio&#93;</strong> shortcode:</em></p>
        <p><strong>label</strong></p><p class="adm_description">The label of the radio button.</p>
        <p class="margin_top_30"><strong>checked</strong></p><p class="adm_description">If this attribute is true, the radio button will be checked.</p>
        
        <p class="margin_top_30"><em>The following two attributes can be used with the <strong>&#91;jf_checkbox&#93;</strong> shortcode:</em></p>
        <p><strong>label</strong></p><p class="adm_description">The label of the checkbox.</p>
        <p class="margin_top_30"><strong>checked</strong></p><p class="adm_description">If this attribute is true, the checkbox will be checked.</p>        
    <?php        
    }
    
    
    // form field callbacks
    function jf_ui_form_style_callback(){
        $styles = 1; // style-1 .. style-10
        $options = get_option('jf_ui_form_options');  
        if ( ! isset( $options['style'] ) ){
            $options['style'] = 'style-1';
        }  
        ?> 
        <select class="adm_select" id="style" name="jf_ui_form_options[style]">
        <?php
        for($i=1;$i<=$styles; $i++){
        ?>
            <option value="style-<?php echo $i; ?>" <?php selected( $options['style'], 'style-'.$i ); ?>><?php echo 'style-'.$i; ?></option>
        <?php    
        }
        ?>
        </select>
        <?php         
    }
    
    /** alerts */ 
    function jf_ui_initialize_alert_options() { 
        
        $alert_options = array(
            "type"     => "You can choose from six types of alert boxes. Possible values are: message, success, error, info, warning, question.",
            "style"    => "The style attribute sets the skin of the alert. There are four alert skins that can be used as follows: style-1, style-2, style-3, style-4.",
            "bordered" => "If the attribute is true, a border will be displayed around the alert box. Possible values are: true, false.",
            "rounded"  => "If the attribute is true, the alert box will have rounded corners. Possible values are: true, false.",
            "effect"   => "The effect attribute sets the hide transition of the alert box. Possible values are: fade, slide, fade-slide, scale.",
        );
        
        if( false == get_option( 'jf_ui_alert_options' ) ) {    
            add_option( 'jf_ui_alert_options' );  
        }
          
        add_settings_section(  
            'alert_settings_section',  
            '',                          
            array($this, 'alert_options_callback'),  
            'jf_ui_alert_options'  
        );  
                  
        foreach($alert_options as $k => $v){
            add_settings_field(   
                "$k",                        
                "<strong>$k</strong><br /><p class='adm_description'>$v<br /><br /></p>",                             
                array($this, "jf_ui_alert_{$k}_callback"),   
                "jf_ui_alert_options",   
                "alert_settings_section"  
            );              
        }
         
        register_setting( 
            'jf_ui_alert_options', 
            'jf_ui_alert_options' 
        ); 
    }
     
    
    function jf_ui_alert_type_callback(){
        // message, success, error, info, warning, question
        $options = get_option('jf_ui_alert_options');  
        if ( ! isset( $options['type'] ) ){
            $options['type'] = 'message';
        }  
        ?> 
        <select class="adm_select" id="type"  name="jf_ui_alert_options[type]">
            <option value="message" <?php selected( $options['type'], 'message' ); ?>>message</option>
            <option value="success" <?php selected( $options['type'], 'success' ); ?>>success</option>
            <option value="error" <?php selected( $options['type'], 'error' ); ?>>error</option>
            <option value="info" <?php selected( $options['type'], 'info' ); ?>>info</option>
            <option value="warning" <?php selected( $options['type'], 'warning' ); ?>>warning</option>
            <option value="question" <?php selected( $options['type'], 'question' ); ?>>question</option>
        </select>
        <?php          
    }

    function jf_ui_alert_style_callback(){
        // style-1, style-2, style-3, style-4
        $options = get_option('jf_ui_alert_options');  
        if ( ! isset( $options['style'] ) ){
            $options['style'] = 1;
        }  
        ?> 
        <select class="adm_select" id="style"  name="jf_ui_alert_options[style]">
            <option value="style-1" <?php selected( $options['style'], 'style-1' ); ?>>style-1</option>
            <option value="style-2" <?php selected( $options['style'], 'style-2' ); ?>>style-2</option>
            <option value="style-3" <?php selected( $options['style'], 'style-3' ); ?>>style-3</option>
            <option value="style-4" <?php selected( $options['style'], 'style-4' ); ?>>style-4</option>
        </select>
        <?php          
    }

    function jf_ui_alert_effect_callback(){
        // fade, slide, fade-slide, scale
        $options = get_option('jf_ui_alert_options');  
        if ( ! isset( $options['effect'] ) ){
            $options['effect'] = 1;
        }  
        ?> 
        <select class="adm_select" id="effect"  name="jf_ui_alert_options[effect]">
            <option value="fade" <?php selected( $options['effect'], 'fade' ); ?>>fade</option>
            <option value="slide" <?php selected( $options['effect'], 'slide' ); ?>>slide</option>
            <option value="fade-slide" <?php selected( $options['effect'], 'fade-slide' ); ?>>fade-slide</option>
            <option value="scale" <?php selected( $options['effect'], 'scale' ); ?>>scale</option>
        </select>
        <?php          
    }
     
    function jf_ui_alert_bordered_callback() {  
        $options = get_option('jf_ui_alert_options');  
        if ( ! isset( $options['bordered'] ) ){
            $options['bordered'] = 0;
        }
	    echo '<input type="checkbox" id="bordered" name="jf_ui_alert_options[bordered]" value="1" ' . checked(1, $options['bordered'], false) . '/>';
   
	}

    function jf_ui_alert_rounded_callback() {  
        $options = get_option('jf_ui_alert_options');  
        if ( ! isset( $options['rounded'] ) ){
            $options['rounded'] = 0;
        }        
	    echo '<input type="checkbox" id="rounded" name="jf_ui_alert_options[rounded]" value="1" ' . checked(1, $options['rounded'], false) . '/>';   
	}
             
    function alert_options_callback() {
    ?>  <p>You can use alert boxes by including the HTML code of the alerts (see examples on <a href="http://www.jumpeye.com/ui-elements/alerts.html" target="_blank">http://www.jumpeye.com/ui-elements/alerts.html</a>) or by using the <strong>&#91;jf_alert&#93;</strong> shortcode. 
<br />Below you can see an example of usage for the alert shortcode and a complete list with the available attributes.</p>  
        <h4>SHORTCODE USAGE :</h4>
        <pre class="code_ex">
    [jf_alert type="message" style="style-1" bordered="true" rounded="false" effect="fade"]
        Alert message
    [jf_alert_end]
        </pre>
        <h4>OPTIONS :</h4>
    <?php            
    }
    
    
    /** tooltips */
    function jf_ui_initialize_tooltip_options() { 
        $tooltip_options = array(
            "style" => "The style attribute sets the skin of the tooltip. There are fifteen tooltip skins that can be used, as follows: style-1, style-2, style-3, style-4, style-5, style-6, style-7, style-8, style-9, style-10, style-11, style-12, style-13, style-14, style-15.",
            "color" => "Sets the color of the tooltip. The possible values for this attribute depend on the value of the <strong>style</strong> attribute.",
            "data_width" => "Sets the width of the tooltip.",
            "placement" => "Sets the position of the tooltip relative to the target text. If the placement attribute is not set, the tooltip will follow the mouse’s position.<br />Possible values are: top-left, top-center, top-right, bottom-left, bottom-center, bottom-right, left-top, left-center, left-bottom, right-top, right-center, right-bottom."
        );
        
        if( false == get_option( 'jf_ui_tooltip_options' ) ) {    
            add_option( 'jf_ui_tooltip_options' );  
        }  
        add_settings_section(  
            'tooltip_settings_section',  
            '',                          
            array($this, 'tooltip_options_callback'),  
            'jf_ui_tooltip_options'  
        );  
          
        // Next, we'll introduce the fields for toggling the visibility of content elements. 
        foreach($tooltip_options as $k => $v){
            add_settings_field(   
                "$k",                        
                "<strong>$k</strong><br /><p class='adm_description'>$v<br /><br /></p>",                             
                array($this, "jf_ui_tooltip_{$k}_callback"),   
                "jf_ui_tooltip_options",   
                "tooltip_settings_section"  
            );              
        }
         
        // Finally, we register the fields with WordPress 
        register_setting( 
            'jf_ui_tooltip_options', 
            'jf_ui_tooltip_options' 
        ); 
         
    }
     
     
    function tooltip_options_callback() {
    ?>  <p>Tooltips can be used to provide extended information on a term. You can attach a tooltip to the target text by including the HTML code of the tooltips (see examples on <a href="http://www.jumpeye.com/ui-elements/tooltips.html" target="_blank">http://www.jumpeye.com/ui-elements/tooltips.html</a>) or by using the <strong>&#91;jf_tooltip&#93;</strong> shortcode. 
<br />Below you can see an example of the usage of the tooltip’s shortcode and a complete list with the available attributes.</p>  
        <h4>SHORTCODE USAGE:</h4>
        <pre class="code_ex">
    [jf_tooltip text="Tooltip text" style="style-1" color="dark" data_width="150" placement="top-left"]
        Target text comes here
    [jf_tooltip_end]
        </pre>
        <h4>OPTIONS :</h4>
        <p><strong>text</strong></p>
        <p class="adm_description">The content of the tooltip.</p><br />
    <?php            
    }
    
    function jf_ui_tooltip_data_width_callback(){
        $options = get_option( 'jf_ui_tooltip_options' );  
        $value = 150;
        if( isset( $options['data_width'] ) ) { 
            $value = $options['data_width']; 
        } 
        echo '<input class="adm_input_200" type="text" id="data_width" name="jf_ui_tooltip_options[data_width]" value="' . $value . '" />';
    }
    
    function jf_ui_tooltip_placement_callback(){
        $placements = array(
            'top-left', 'top-center', 'top-right',
            'bottom-left', 'bottom-center', 'bottom-right',
            'left-top', 'left-center', 'left-bottom',
            'right-top', 'right-center', 'right-bottom',
            'mousefollow');
        $options = get_option('jf_ui_tooltip_options');  
        if ( ! isset( $options['placement'] ) ){
            $options['placement'] = 'top-left';
        }  
        ?> 
        <select class="adm_select" id="placement" name="jf_ui_tooltip_options[placement]">
        <?php
            foreach($placements as $k => $v){
            ?>
            <option value="<?php echo $v; ?>" <?php selected( $options['placement'], $v ); ?>><?php echo $v; ?></option>            
            <?php    
            }
        ?>
        </select>
        <?php          
    }      
    
    function jf_ui_tooltip_style_callback(){
        $styles = 16; // style-1 .. style-15
        $options = get_option('jf_ui_tooltip_options');  
        if ( ! isset( $options['style'] ) ){
            $options['style'] = 'style-1';
        }  
        ?> 
        <select class="adm_select" id="style" name="jf_ui_tooltip_options[style]">
        <?php
        for($i=1;$i<$styles; $i++){
        ?>
            <option value="style-<?php echo $i; ?>" <?php selected( $options['style'], 'style-'.$i ); ?>><?php echo 'style-'.$i; ?></option>
        <?php    
        }
        ?>
        </select>
        <?php          
    }
    
    function jf_ui_tooltip_color_callback(){
        $colors = array(
            'dark', 'light',                                   // Color classes for style-1 to style-7
            'gray', 'yellow', 'blue', 'purple', 'green', 'red' // Color classes for style-8 to style-15 
        );
        $options = get_option('jf_ui_tooltip_options');  
        if ( ! isset( $options['color'] ) ){
            $options['color'] = 'dark';
        }  
        ?>
        <select class="adm_select" id="color" name="jf_ui_tooltip_options[color]">
        <?php
            foreach($colors as $k => $v){
            ?>
            <option value="<?php echo $v; ?>" <?php selected( $options['color'], $v ); ?>><?php echo $v; ?></option>            
            <?php    
            }
        ?>
        </select>
        <?php          
    }
    
    
    /** tables */
    function jf_ui_initialize_table_options() {
        $table_options = array(
            "style" => "The style attribute sets the skin of the table. The six table skins that can be used are the following: style-1, style-2, style-3, style-4, style-5, style-6.",
            "color" => "The color attribute is <strong>available only for skin style-6</strong>. Possible values are: orange, green, blue, purple, aqua, magenta."
        );
        
        if( false == get_option( 'jf_ui_table_options' ) ) {    
            add_option( 'jf_ui_table_options' );  
        }  
        
        // section-1
        add_settings_section(  
            'table_settings_section',  
            '',                          
            array($this, 'table_options_callback'),  
            'jf_ui_table_options'  
        );  
          
        foreach($table_options as $k => $v){
            add_settings_field(   
                "$k",                        
                "<strong>$k</strong><br /><p class='adm_description'>$v<br /><br /></p>",                             
                array($this, "jf_ui_table_{$k}_callback"),   
                "jf_ui_table_options",   
                "table_settings_section"  
            );              
        }

        // section-2
        add_settings_section(  
            'table_settings_section_2',  
            '',                          
            array($this, 'table_options_callback_2'),  
            'jf_ui_table_options'  
        );  
                
        register_setting( 
            'jf_ui_table_options', 
            'jf_ui_table_options' 
        ); 
         
    }
     
    // section callbacks 
    function table_options_callback() {
    ?>  <p>You can add tables to your content by including the HTML code of the tables (see examples on <a href="http://www.jumpeye.com/ui-elements/tables.html" target="_blank">http://www.jumpeye.com/ui-elements/tables.html</a>) or by using the <strong>&#91;jf_table&#93;</strong> shortcode.
<br />Below you can see an example of the usage of the table’s shortcode and a complete list with the available attributes.</p>  
        <h4>SHORTCODE USAGE :</h4>
        <pre class="code_ex">
    [jf_table style="style-1" color=""]
        [jf_table_head]
            [jf_table_tr]
                [jf_table_th]Title column 1[jf_table_th_end]
                [jf_table_th]Title column 2[jf_table_th_end]
                [jf_table_th]Title column 3[jf_table_th_end]
            [jf_table_tr_end]
        [jf_table_head_end]
        [jf_table_body]
            [jf_table_tr]
                [jf_table_td data_title="Title column 1"]Cell content[jf_table_td_end]
                [jf_table_td data_title="Title column 2"]Cell content[jf_table_td_end]              
                [jf_table_td data_title="Title column 3"]Cell content[jf_table_td_end]
            [jf_table_tr_end]
            [jf_table_tr]
                [jf_table_td data_title="Title column 1"]Cell content[jf_table_td_end]
                [jf_table_td data_title="Title column 2"]Cell content[jf_table_td_end]              
                [jf_table_td data_title="Title column 3"]Cell content[jf_table_td_end]
            [jf_table_tr_end] 
            [jf_table_tr]
                [jf_table_td data_title="Title column 1"]Cell content[jf_table_td_end]
                [jf_table_td data_title="Title column 2"]Cell content[jf_table_td_end]              
                [jf_table_td data_title="Title column 3"]Cell content[jf_table_td_end]
            [jf_table_tr_end]         
        [jf_table_body_end]
    [jf_table_end]
        </pre>
        <h4>OPTIONS :</h4>
        <p><em>The following two attributes can be used with the <strong>&#91;jf_table&#93;</strong> shortcode:</em></p>        
    <?php            
    }
    
    function table_options_callback_2(){
    ?>    
        <p><em>The following attribute can be used with the <strong>&#91;jf_table_td&#93;</strong> shortcode:</em></p>
        <p><strong>data_title</strong></p><p class="adm_description">You need to set this attribute for each cell of the table's body and the value of this attribute must be the value of the column's title.<br />In mobile view (&lt;768px) this value will be displayed in the left column (Title column) and in the second column will be displayed the value of the cell (Value column).</p>
        <p class="adm_description">E.g.</p>
<pre class="code_ex">
...
[jf_table_th]Title column 1[jf_table_th_end] 
...
[jf_table_td data_title="Title column 1"]Cell content[jf_table_td_end]
...        
</pre>
    <?php    
    }
    
    
    // field callbacks
    function jf_ui_table_style_callback(){
        $styles = 7; // style-1 .. style-6
        $options = get_option('jf_ui_table_options');  
        if ( ! isset( $options['style'] ) ){
            $options['style'] = 'style-1';
        }  
        ?> 
        <select class="adm_select" id="style" name="jf_ui_table_options[style]">
        <?php
        for($i=1;$i<$styles; $i++){
        ?>
            <option value="style-<?php echo $i; ?>" <?php selected( $options['style'], 'style-'.$i ); ?>><?php echo 'style-'.$i; ?></option>
        <?php    
        }
        ?>
        </select>
        <?php          
    } 
    
    function jf_ui_table_color_callback(){
        $colors = array('orange', 'green', 'blue', 'purple', 'aqua', 'magenta');
        $options = get_option('jf_ui_table_options');  
        if ( ! isset( $options['color'] ) ){
            $options['color'] = 'blue';
        }  
        ?> 
        <select class="adm_select" id="color" name="jf_ui_table_options[color]">
        <?php
            foreach($colors as $k => $v){
            ?>
            <option value="<?php echo $v; ?>" <?php selected( $options['color'], $v ); ?>><?php echo $v; ?></option>            
            <?php    
            }
        ?>
        </select>
        <?php          
    }

    
    /** shortcode preview */
    private function shortcodePreview(){
        return '<h4>TEST AREA :</h4>
                <div><textarea placeholder="Type your shortcode here..." id="test_shortcode" style=""></textarea><br />
                <input type="button" class="button button-primary" onclick="_aRefreshTestarea();" value="Apply shortcode" />
                </div>
                <br />
                <div><iframe id="preview_wrapper" style="width: 100%; height: 400px; border: 1px dashed #ccc;" src="'.get_template_directory_uri().'/preview/index.php?domain_key='.base64_encode($this->domain_key).'"></iframe></div> 
               ';   
    }                                              
} // END OF PLUGIN CLASS

    $JF_UI_ELEMENTS = new JF_UI_elements();  

?>
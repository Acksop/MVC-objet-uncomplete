<?php
/*
    Plugin Name: JF-Slider
    Plugin URI: http://www.jumpeye.com/components/image-content-slider/how-to-use.html
    Description: Image and content slider
    Version: 1.0
    Author: Jumpeye Components
    Author URI: http://www.jumpeyecomponents.com/
    License: GPL2
*/


/*  Copyright 2012  Jumpeye Components  (email : contact@jumpeyecomponents.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as 
    published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

    
/*
    USAGE (Shortcode syntax examples)
    
        [jf_slider id="slider-1" imageScaleMode="stretch" maxWidth="922"]
        
            [slide]slide_1.jpg[/slide]
            
            [slide type="html"]<p>html<br /><strong>content</strong></p>[/slide]
            
            [slide]slide_2.jpg[/slide]
            
            [slide]slide_3.jpg[/slide]
        
        [/jf_slider]
*/

class JF_Slider {
      
    /** constants and variables */
    private $slider_id = null;
    
    private $defaults = Array(
          'maxWidth' => 922,
          'maxHeight' => 358,
          'imageScaleMode' => 'scaleCrop',
          'loopContent' => 'false',
          'animationType' => 'slide',
          'animationDuration' => 0.3,
          'autoSlideshow' => 'false',
          'slideshowSpeed' => 6,
          'pauseOnMouseOver' => 'false',
          'startIndex' => 0,
          'captionAlignment' => 'left',
          'captionColor' => 'ffffff',
          'autoHideControls' => 'false',
          'autoHideDelay' => 3,
          'disableAutohideOnMouseOver' => 'false',
          'showTimer' => 'true',
          'showControlBar' => 'true',
          'showNavButtons' => 'true'        
    );
    
    private $imageScaleMode = Array(1=>'scale', 2=>'scaleCrop', 3=>'crop', 4=>'stretch');
    private $animationType = Array(1=>'fade', 2=>'slide', 3=>'none');
    private $captionAlignment = Array(1=>'left', 2=>'center', 3=>'right');
        
    private $config = Array();
            
    
    /** constructor : add shortcodes & init */    
	public function __construct(){
        // init
        if(!is_admin()){
            add_action('wp_enqueue_scripts', array($this,'jf_slide_js_loader')); 
        } else {
            add_action('admin_init', array($this,'jf_slider_intialize_display_options'));
            add_action('admin_init', array($this,'deactivate_plugin'));
        }
       
	    // add plugin shortcodes
        add_shortcode('jf_slider', array($this, 'shortcode_slider'));
        add_shortcode('slide', array($this, 'shortcode_slide'));
        
        // only for debug (to reset options)
        //$this->__deleteOption();
	}

    /** deactivate plugin if WP version lower than 3.5 */
    function deactivate_plugin() {
    	global $wp_version;
    	$plugin = plugin_basename( __FILE__ );
    	$plugin_data = get_plugin_data( __FILE__, false );
    	$require_wp = "3.5";
     
    	if ( version_compare( $wp_version, $require_wp, "<" ) ) {
    		if( is_plugin_active($plugin) ) {
    			deactivate_plugins( $plugin );
    			wp_die( "<strong>".$plugin_data['Name']."</strong> requires <strong>WordPress ".$require_wp."</strong> or higher, and has been deactivated! Please upgrade WordPress and try again.<br /><br />Back to the WordPress <a href='".get_admin_url(null, 'plugins.php')."'>Plugins page</a>." );
    		}
    	}
    }

    /** delete option for DEBUG purposes */
    private function __deleteOption(){
        delete_option('jf_slider_display_options');
    } 
    
    
    /** 
     * Retrieve options from database if any, or use default options instead 
     * For general usage
     */
    private function option($key=''){
    	$option = get_option('jf_slider_display_options') ? get_option('jf_slider_display_options') : Array();
    	$option = array_merge($this->defaults, $option);
        return ($key) ? $option[$key] : $option;
    }   
     
     
    /** Retrieve options from database if any, or use default options instead */
    private function optionCheck($key=''){
        $settings = Array(
            'showTimer' => 1,
            'showControlBar' => 1,
            'showNavButtons' => 1
        );
    	$option = get_option('jf_slider_display_options') ? get_option('jf_slider_display_options') : Array();

        if(isset($option['maxWidth'])){
            foreach($settings as $k => $v){
                if( !isset($option[$k])) $option[$k] = 0;
            }
        }

    	$option = array_merge($settings, $option);
        return ($key) ? $option[$key] : $option;
    } 
            
    /** SLIDER */
    /** add slider */    
    public function shortcode_slider($atts, $content = null){
        $keys = array('maxWidth' => 'maxwidth',
                      'maxHeight' => 'maxheight',
                      'imageScaleMode' => 'imagescalemode',
                      'loopContent' => 'loopcontent',
                      'animationType' => 'animationtype',
                      'animationDuration' => 'animationduration',
                      'autoSlideshow' => 'autoslideshow',
                      'slideshowSpeed' => 'slideshowspeed',
                      'pauseOnMouseOver' => 'pauseonmouseover',
                      'startIndex' => 'startindex',
                      'captionAlignment' => 'captionalignment',
                      'captionColor' => 'captioncolor',
                      'autoHideControls' => 'autohidecontrols',
                      'autoHideDelay' => 'autohidedelay',
                      'disableAutohideOnMouseOver' => 'disableautohideonmouseover',
                      'showTimer' => 'showtimer',
                      'showControlBar' => 'showcontrolbar',
                      'showNavButtons' => 'shownavbuttons');
        foreach($keys as $k => $v){
            if(isset($atts[$v])){
                $this->config[$k] = $atts[$v];
            }          
        }

        $this->slider_id = $atts['id'];
        return "<div id='" . $this->slider_id . "'><div name='jf-slider_content' style='display: none'>".
               do_shortcode($content)."</div></div>".$this->add_js();
   }
    
    
    /** add one slide */   
    public function shortcode_slide($atts, $content){
         
         extract(shortcode_atts(array(
              'type'  => 'image',
              'title' => 'Image title',
              'description' => 'Description for the image',
              'url' => '',
              'target' => '_blank'
              
         ), $atts)); 

         if($type == 'image' || $type == ''){
            $html = $content;
            if(strpos($html, 'src=') !== false){
                $content = (string) reset(simplexml_import_dom(DOMDocument::loadHTML($html))->xpath("//img/@src"));    
            } else {
                $content = $html;
            }
         } 
                  
         return "<div name='jf-slide'>
                    <div name='jf-type'>{$type}</div>
                    <div name='jf-title'>{$title}</div>
                    <div name='jf-description'>{$description}</div>
                    <div name='jf-content'>{$content}</div>
                    <div name='jf-target_url'>{$url}</div>
                    <div name='jf-target_window'>{$target}</div>
                    </div>";
    }    

    /** get value */
    private function getValue($_key){
        $options = get_option( 'jf_slider_display_options' );

        // if shortcode param exists return with its value
        if(isset($this->config[$_key])){
            return $this->config[$_key];
        }             
        
        // else if option exists in database return with its value
        if(isset($options['maxWidth'])){
            if(isset($options[$_key])){
                switch($_key){
                    case 'animationType' : return $this->animationType[$options['animationType']];
                    case 'captionAlignment' : return $this->captionAlignment[$options['captionAlignment']];   
                    case 'imageScaleMode' : return $this->imageScaleMode[$options['imageScaleMode']];
                    case 'captionColor' : return '#'.$options['captionColor'];
                    default : return $options[$_key]; 
                }
            } else {
                switch($_key){
                    case 'showTimer' : 
                    case 'showControlBar' :
                    case 'showNavButtons' : return 'false';
                }
            }
        }
      
        // default: else return with default value
        return $this->defaults[$_key];
    }   
     
    /** generate javascript for slider */      
    private function add_js(){
        return "<script type='text/javascript'>
            JFBase.JFBlurrySlider.init({
                appendToID: '". $this->slider_id ."',
                maxWidth: " . $this->getValue('maxWidth') . ",
                maxHeight: " . $this->getValue('maxHeight') . ",
                imageScaleMode: '" . $this->getValue('imageScaleMode') . "',
                loopContent: " . $this->getValue('loopContent') . ",
                animationType: '" . $this->getValue('animationType') . "',
                animationDuration: " . $this->getValue('animationDuration')  .",
                autoSlideshow: " . $this->getValue('autoSlideshow') . ",
                slideshowSpeed: " . $this->getValue('slideshowSpeed') . ",
                pauseOnMouseOver: " . $this->getValue('pauseOnMouseOver') . ",
                startIndex: " . $this->getValue('startIndex') . ",
                captionAlignment: '" . $this->getValue('captionAlignment') . "',
                captionColor: '" . $this->getValue('captionColor') . "',
                autoHideControls: " . $this->getValue('autoHideControls') . ",
                autoHideDelay: " . $this->getValue('autoHideDelay') . ",
                disableAutohideOnMouseOver: " . $this->getValue('disableAutohideOnMouseOver') . ",
                showTimer: " . $this->getValue('showTimer') . ",
                showControlBar: " . $this->getValue('showControlBar') . ",
                showNavButtons: " . $this->getValue('showNavButtons') . "
            });
        </script>";
    }
    
    /** load necessary css and js files for the slider */
    function jf_slide_js_loader() {
        //wp_enqueue_script('JFCore', get_template_directory_uri() . '/framework/js/JFCore.js', array('JFCore'), '1.0', false);
        wp_enqueue_script('JFBlurrySlider', plugin_dir_url(__FILE__) . 'JFBlurrySlider.js', array( 'JFCore' ), '1.0', false);
    }
     
     
    /** 
    * Renders a simple page to display for the theme menu defined above. 
    */  
	function jf_slider_plugin_display() {  
    ?>
	   <div class="wrap jf_opt_wrapper adm_jumpeye_slider_opts">
           <div id="icon-plugins" class="icon32"></div> 
           <?php settings_errors(); ?>  
           <h2>Image Slider Options</h2>  
           <br />
           <div>
           <p class="adm_alignJustify">Jumpeye framework contains an image and content slider that was added as a plugin to this Wordpress theme. Using the <strong>[jf_slider]</strong> shortcode you can easily create image and content slider in your page without writing any HTML code. The slider can be configured in a few seconds by adding some parameters, like scale mode for the images, maximum width and height of the slider or the animation type. The options page contains a complete list with the parameters of the slider.</p>
           <h3 class="margin_top_30">Shortcode usage</h3> 
                <pre class="code_ex">
[jf_slider id="slider" imageScaleMode="stretch" maxWidth="922" maxHeight="358"]
    [slide]http://www.jumpeye.com/wordpress-themes/prestige/wp-content/themes/prestige/sampledata/images/slides/slide1.jpg[/slide]
    [slide]http://www.jumpeye.com/wordpress-themes/prestige/wp-content/themes/prestige/sampledata/images/slides/slide2.jpg[/slide]
    [slide type="html"]&lt;p&gt;HTML&lt;br /&gt;&lt;strong&gt;content&lt;/strong&gt;&lt;/p&gt;[/slide]
    [slide]http://www.jumpeye.com/wordpress-themes/prestige/wp-content/themes/prestige/sampledata/images/slides/slide4.jpg[/slide]
[/jf_slider]
                </pre>
                <p>In the example above the images were uploaded in the Media Library and then added to the shortcode of the slider.<br />
                Below you can find a complete list with the parameters of the slider that can be used with the [jf_slider] shortcode.</p>
                <p style="margin-bottom: 0px">E.g.</p>
                <pre class="code_ex margin_top_0">
[jf_slider id="slider" maxWidth="922" maxHeight="358" imageScaleMode="scaleCrop" loopContent="true" animationType="fade" ... ]                
                </pre>
                <p>You can set some attributes for each slide of the slider. These attributes are the following: type (values: "image" or "html"), title, description, url and target.</p>
                <p class="margin_bottom_0">E.g.</p>
                <pre class="code_ex margin_top_0">
[slide type="image" title="Title of the slide" description="Description of the slide" url="http://www.jumpeye.com" target="_blank"]
    http://www.jumpeye.com/responsive-themes/theme1/wp-content/uploads/slide_2.jpg 
[/slide]                
                </pre>
                <p>You can find more details about the usage of the slider on <a href="http://www.jumpeye.com/components/image-content-slider/how-to-use.html" target="_blank">http://www.jumpeye.com/components/image-content-slider/how-to-use.html</a></p>
            </div><br />      
           <form method="post" action="options.php"> 
                <?php  
                    settings_fields( 'jf_slider_display_options' );  
                    do_settings_sections( 'jf_slider_display_options' );  
                     
                    submit_button();  
                ?> 
           </form>                 
       </div><!-- /.wrap -->
	      
    <?php	      
	} 
    
    
    /** 
     * Initializes the plugin's display options by registering the Sections, 
     * Fields, and Settings. 
     * 
     * This function is registered with the 'admin_init' hook. 
     */   
    function jf_slider_intialize_display_options() {

        $slider_options = array(
            "maxWidth"                   => "The maximum width of the slider (in pixels) which is used to calculate the size ratio of the component.<br />Using this ratio the slider is then resized by the grid, when the grid is resized.",
            "maxHeight"                  => "The maximum height of the slider (in pixels) which is used to calculate the size ratio of the component.<br />Using this ratio the slider is then resized by the grid, when the grid is resized.",
            "imageScaleMode"             => "The scaling mode is used only for images from an image slideshow (slide type is set to image).",
            "loopContent"                => "If set to true, the slider will display the slides in a loop - from the last slide it will allow navigation to the next slide, in fact the first slide;<br />from the first slide it will allow navigating to the previous slide, in fact the last slide.",
            "animationType"              => "Sets the type of the animation that is applied as show and hide effects for the slides.",
            "animationDuration"          => "The duration of the show/hide effect for one slide expressed in seconds.",
            "autoSlideshow"              => "If it is set to true, the slider will automatically navigate through the slides.",
            "slideshowSpeed"             => "The amount of time (in seconds) until a slide is displayed during the slideshow - from the end of the previous transition to the start of the next one.",
            "pauseOnMouseOver"           => "If set to true, the automatic slideshow will stop when the mouse is over the slider.",
            "startIndex"                 => "The index of the slide, showing which slide is displayed first. If this property is not set, the slider starts with the first slide.",
            "captionAlignment"           => "Sets the alignment of the title and description within the caption area (control bar).",
            "captionColor"               => "The color of the title and description. Please use long format (ex. FFFFFF)",
            "autoHideControls"           => "If set to true, the controls (navigation buttons, control bar and captions) will hide automatically after a period of inactivity specified by autoHideDelay<br />or when the mouse rolls out of the slider. In case of mobile devices, the controls will display when the user taps on the slider surface.",
            "autoHideDelay"              => "If autoHideControls is set to true, the controls will hide after a period of inactivity.<br />That period of inactivity is set by this property and it is measured in seconds.",
            "disableAutohideOnMouseOver" => "If set to true, the controls (navigation buttons, control bar and captions) will not hide automatically while the mouse is over the slider,<br />even if autoHideControls is set to true.",
            "showTimer"                  => "If it is true, the timer will be displayed in the top-right corner of the slider.",
            "showControlBar"             => "If it is set to true, the slider displays the control bar.",
            "showNavButtons"             => "If set to true, the slider displays the Previous and Next slide buttons.");                                 
                                         
        // If the plugin options don't exist, create them.  
        if( false == get_option( 'jf_slider_display_options' ) ) {     
            add_option( 'jf_slider_display_options' );  
        } // end if 
        
        add_settings_section(  
            'slider_settings_section',          // ID used to identify this section and with which to register options  
            'Slider options',                   // Title to be displayed on the administration page  
            array($this, 'jf_slider_options_callback'),       // Callback used to render the description of the section  
            'jf_slider_display_options'         // Page on which to add this section of options  
        );
        
        foreach($slider_options as $k => $v){
            add_settings_field(   
                "$k",                        
                "<strong>$k</strong><br /><p class='adm_description'>$v<br /><br /></p>",                             
                array($this, "jf_slider_{$k}_callback"),   
                "jf_slider_display_options",   
                "slider_settings_section"  
            );              
        }
                                                                                
        register_setting(  
            'jf_slider_display_options',  
            'jf_slider_display_options',  
            array($this, 'jf_slider_sanitize_display_options')    
        );     
                   
    }
    
    
    /** slider options callback */   
    function jf_slider_options_callback() {}    
    
    
    /** sanitize inputs */
    function jf_slider_sanitize_display_options( $input ) {  
        // Define the array for the updated options  
        $output = array();  
      
        // Loop through each of the options sanitizing the data  
        foreach( $input as $key => $val ) {  
          
            if( isset ( $input[$key] ) ) {  
                switch($key){
                    case 'maxWidth'  : 
                    case 'maxHeight' : 
                    case 'slideshowSpeed' : 
                    case 'startIndex' : 
                    case 'autoHideDelay' : $output[$key] = absint( strip_tags( stripslashes( $input[$key] ) ) );
                    break;
                    default : $output[$key] = strip_tags( stripslashes( $input[$key] ) );
                }
            } // end if   
          
        } // end foreach  
          
        // Return the new collection  
        return apply_filters( 'jf_slider_sanitize_display_options', $output, $input );  
    }
    

    /** Option callbacks */             
    function jf_slider_maxWidth_callback(){

        $options = get_option( 'jf_slider_display_options' );  
       
        $value = 800;
        if( isset( $options['maxWidth'] ) ) { 
            $value = $options['maxWidth']; 
        } // end if 
                 
        // Render the output 
        echo '<input class="adm_input_200" type="text" id="maxWidth" name="jf_slider_display_options[maxWidth]" value="' . $value . '" /> pixels<br />';
                  
    } // end jf_slider_maxWidth_callback    
                
                
    function jf_slider_maxHeight_callback(){
        
        $options = get_option( 'jf_slider_display_options' );  
          
        // Next, we need to make sure the element is defined in the options. If not, we'll set an empty string.  
        $value = 450;
        if( isset( $options['maxHeight'] ) ) { 
            $value = $options['maxHeight']; 
        } // end if 
         
        // Render the output 
        echo '<input class="adm_input_200" type="text" id="maxHeight" name="jf_slider_display_options[maxHeight]" value="' . $value . '" /> pixels';
                  
    } // end jf_slider_maxHeight_callback
    
    
    function jf_slider_imageScaleMode_callback() {  
        // scale, scaleCrop, crop, stretch
        $options = get_option('jf_slider_display_options');  
        if ( ! isset( $options['imageScaleMode'] ) ){
            $options['imageScaleMode'] = 2;
        }  
        ?> 
        <select class="adm_select" id="imageScaleMode"  name="jf_slider_display_options[imageScaleMode]">
            <option value="1" <?php selected( $options['imageScaleMode'], 1 ); ?>>scale</option>
            <option value="2" <?php selected( $options['imageScaleMode'], 2 ); ?>>scaleCrop</option>
            <option value="3" <?php selected( $options['imageScaleMode'], 3 ); ?>>crop</option>
            <option value="4" <?php selected( $options['imageScaleMode'], 4 ); ?>>stretch</option>
        </select>
        <?php            
	} // end jf_slider_imageScaleMode_callback
    
        
    function jf_slider_loopContent_callback() {  
        $options = get_option('jf_slider_display_options');  
        if ( ! isset( $options['loopContent'] ) ){
            $options['loopContent'] = 0;
        }        
	    echo '<input type="checkbox" id="loopContent" name="jf_slider_display_options[loopContent]" value="1" ' . checked(1, $options['loopContent'], false) . '/>';   
	} // end jf_slider_loopContent_callback
    
    
    function jf_slider_animationType_callback() {  
        // scale, scaleCrop, crop, stretch
        $options = get_option('jf_slider_display_options');  
        if ( ! isset( $options['animationType'] ) ){
            $options['animationType'] = 2;
        }  
        ?>
        <select class="adm_select" id="animationType"  name="jf_slider_display_options[animationType]">
            <option value="1" <?php selected( $options['animationType'], 1 ); ?>>fade</option>
            <option value="2" <?php selected( $options['animationType'], 2 ); ?>>slide</option>
            <option value="3" <?php selected( $options['animationType'], 3 ); ?>>none</option>
        </select>
        <?php            
	} // end jf_slider_animationType_callback
    
        
    function jf_slider_animationDuration_callback() {  
        $options = get_option( 'jf_slider_display_options' );  
          
        $value = 0.3; 
        if( isset( $options['animationDuration'] ) ) { 
            $value = $options['animationDuration']; 
        } 
         
        // Render the output 
        echo '<input class="adm_input_200" type="text" id="animationDuration" name="jf_slider_display_options[animationDuration]" value="' . $value . '" /> second(s)';        
	} // end jf_slider_animationDuration_callback
    
            
    function jf_slider_autoSlideshow_callback() {  
        $options = get_option('jf_slider_display_options');  
        if ( ! isset( $options['autoSlideshow'] ) ){
            $options['autoSlideshow'] = 0;
        }          
	    echo '<input type="checkbox" id="autoSlideshow" name="jf_slider_display_options[autoSlideshow]" value="1" ' . checked(1, $options['autoSlideshow'], false) . '/>';   
	} // end jf_slider_autoSlideshow_callback
    

    function jf_slider_slideshowSpeed_callback() {  
        $options = get_option('jf_slider_display_options');  
        $value = 6; 
        if( isset( $options['slideshowSpeed'] ) ) { 
            $value = $options['slideshowSpeed']; 
        } 
         
        // Render the output 
        echo '<input class="adm_input_200" type="text" id="slideshowSpeed" name="jf_slider_display_options[slideshowSpeed]" value="' . $value . '" /> second(s)';        
	} // end jf_slider_slideshowSpeed_callback
    
        
    function jf_slider_pauseOnMouseOver_callback() {  
        $options = get_option('jf_slider_display_options');  
        if ( ! isset( $options['pauseOnMouseOver'] ) ){
            $options['pauseOnMouseOver'] = 0;
        }           
  	    echo '<input type="checkbox" id="pauseOnMouseOver" name="jf_slider_display_options[pauseOnMouseOver]" value="1" ' . checked(1, $options['pauseOnMouseOver'], false) . '/>';   
	} // end jf_slider_pauseOnMouseOver_callback

    
    function jf_slider_startIndex_callback() {  
        $options = get_option('jf_slider_display_options');  
        $value = 0; 
        if( isset( $options['startIndex'] ) ) { 
            $value = $options['startIndex']; 
        } 
         
        // Render the output 
        echo '<input class="adm_input_200" type="text" id="startIndex" name="jf_slider_display_options[startIndex]" value="' . $value . '" /> second(s)';        
	} // end jf_slider_startIndex_callback


    function jf_slider_captionAlignment_callback() {  
        // scale, scaleCrop, crop, stretch
        $options = get_option('jf_slider_display_options');  
        if ( ! isset( $options['captionAlignment'] ) ){
            $options['captionAlignment'] = 1;
        }  
        ?>
        <select class="adm_select" id="captionAlignment"  name="jf_slider_display_options[captionAlignment]">
            <option value="1" <?php selected( $options['captionAlignment'], 1 ); ?>>left</option>
            <option value="2" <?php selected( $options['captionAlignment'], 2 ); ?>>center</option>
            <option value="3" <?php selected( $options['captionAlignment'], 3 ); ?>>right</option>
        </select>
        <?php            
	} // end jf_slider_captionAlignment_callback
    
    
    function jf_slider_captionColor_callback() {  
        $options = get_option('jf_slider_display_options');  
        $value = '#FFFFFF'; 
        if( isset( $options['captionColor'] ) ) { 
            $value = $options['captionColor']; 
        } 
         
        // Render the output 
        echo '#<input class="adm_input_200" maxlength="6" size="6" type="text" id="captionColor" name="jf_slider_display_options[captionColor]" value="' . $value . '" />
        <script type="text/javascript">
            jQuery(document).ready(function ($) {
                $("#captionColor").ColorPicker({
                	onSubmit: function(hsb, hex, rgb, el) {
                		$(el).val(hex);
                		$(el).ColorPickerHide();
                	},
                	onBeforeShow: function () {
                		$(this).ColorPickerSetColor(this.value);
                	}
                })
                .bind("keyup", function(){
                	$(this).ColorPickerSetColor(this.value);
                });
            });            
        </script>';        
	} // end jf_slider_captionColor_callback
    
        
    function jf_slider_autohideControls_callback() {  
        $options = get_option('jf_slider_display_options'); 
        if ( ! isset( $options['autoHideControls'] ) ){
            $options['autoHideControls'] = 0;
        }          
	    echo '<input type="checkbox" id="autoHideControls" name="jf_slider_display_options[autoHideControls]" value="1" ' . checked(1, $options['autoHideControls'], false) . '/>';   
	} // end jf_slider_autohideControls_callback


    function jf_slider_autohideDelay_callback() {  
        $options = get_option('jf_slider_display_options');  
        $value = 3; 
        if( isset( $options['autoHideDelay'] ) ) { 
            $value = $options['autoHideDelay']; 
        } 
         
        // Render the output 
        echo '<input class="adm_input_200" type="text" id="autoHideDelay" name="jf_slider_display_options[autoHideDelay]" value="' . $value . '" /> second(s)';        
	} // end jf_slider_autohideDelay_callback
    

    function jf_slider_disableAutohideOnMouseOver_callback() {  
        $options = get_option('jf_slider_display_options');  
        if ( ! isset( $options['disableAutohideOnMouseOver'] ) ){
            $options['disableAutohideOnMouseOver'] = 0;
        }           
	    echo '<input type="checkbox" id="disableAutohideOnMouseOver" name="jf_slider_display_options[disableAutohideOnMouseOver]" value="1" ' . checked(1, $options['disableAutohideOnMouseOver'], false) . '/>';   
	} // end jf_slider_disableAutohideOnMouseOver_callback    
    
     
    function jf_slider_showTimer_callback() {  
        $options = get_option('jf_slider_display_options');
        $checked = $this->optionCheck('showTimer') ? 'checked="checked"':'';
	    echo '<input type="checkbox" id="showTimer" name="jf_slider_display_options[showTimer]" value="1" ' . $checked . '/>';   
	} // end jf_slider_showTimer_callback
    
    
    function jf_slider_showControlBar_callback() {  
        $options = get_option('jf_slider_display_options');
        $checked = $this->optionCheck('showControlBar') ? 'checked="checked"':''; 
	    echo '<input type="checkbox" id="showControlBar" name="jf_slider_display_options[showControlBar]" value="1" ' . $checked . '/>';   
	} // end jf_slider_showControlBar_callback
    
    
    function jf_slider_showNavButtons_callback() {  
        $options = get_option('jf_slider_display_options');
        $checked = $this->optionCheck('showNavButtons') ? 'checked="checked"':'';
	    echo '<input type="checkbox" id="showNavButtons" name="jf_slider_display_options[showNavButtons]" value="1" ' . $checked . '/>';   
	} // end jf_slider_showNavButtons_callback           
                          
} // END OF PLUGIN CLASS

    $JF_SLIDER = new JF_Slider();  
                                                 
?>
(function( JFBase ){

    JFBase.fn.JFMenus = function() { 
        JFBase.fn.JFMenus.init(); 
    }
    
    /* VARs -------- */
    
    /**
     * desktopView
     */    
    JFBase.fn.JFMenus.desktopView = 768;
    
    
    /**
     * previous size of the window
     */      
    JFBase.fn.JFMenus.prevBrowserSize = null;


    /**
     * define main style names
     */    
    JFBase.fn.JFMenus.styles = {
        main_style : ["style-1", "style-2", "style-3", "style-4", "style-5", "style-6","style-7", "style-8",
                      "custom-style-1", "headerMenu"],
        sub_style  : ["blue","green","aqua","purple","magenta","orange"]                       
    }    
    
    
    /**
     * menu storage : stores original menu objects
     * after leaving mobileview we load menus from this object container
     */    
    JFBase.fn.JFMenus.menus = {
         obj : []
    }
    
    
        
    /* METHODs -------- */
        
    /**
     * init
     */
    JFBase.fn.JFMenus.init = function(){
        var win_width = (JC.GRID.isScrollbarVisible()) ? (JFBase(window).width() + JC.GRID.scrollbarWidth()) : JFBase(window).width();
        
        JFBase.fn.JFMenus.setId();
        JFBase.fn.JFMenus.storeMenuObjects();
        
        if(win_width < JFBase.fn.JFMenus.desktopView){
            JFBase.fn.JFMenus.swapToggle('forward');    
        } else {
            JFBase.fn.JFMenus.swapToggle('backward');
        }
         
        JFBase.fn.JFMenus.getCompactMenu();  
        JFBase.fn.JFMenus.addHandlers();    

        
    }
    
    
    /**
     * attach handlers
     */
    JFBase.fn.JFMenus.addHandlers = function(){
       
       var win_width = (JC.GRID.isScrollbarVisible()) ? (JFBase(window).width() + JC.GRID.scrollbarWidth()) : JFBase(window).width();
       
       if(win_width < JFBase.fn.JFMenus.desktopView){

            JFBase('.menu').each(function(){
            
                var menu     = JFBase(this);
                
                // check have handlers attached -> if yes let's continue with next item {
                var $m = menu.find('.menu-trigger'), m = $m[0];
                var is_event_exists = JFBase.hasData(m);
                if(is_event_exists){ return; }    
                // }
                
                var id       = menu.attr('id');
                
                var id_num   = id.substring(id.indexOf('-')+1,id.length);            
                menu.find('.menu-trigger').on('click', function(e){
                    
                    // remove all active-main classes
                    JFBase('.menu li').removeClass('active-main');
                    e.stopPropagation();
                  
                    if(JFBase(this).is(':visible')){
                        JFBase(document).find('div.menu:not(#JFMenu-'+id_num+')').find('ul.main-level').slideUp();
                        JFBase(document).find('div.menu:not(#JFMenu-'+id_num+')').find('ul.main-level a > span').removeClass('down-active');
                        JFBase(document).find('div.menu:not(#JFMenu-'+id_num+')').find('ul.sub-level').slideUp();
                        JFBase(document).find('div.menu:not(#JFMenu-'+id_num+')').find('ul.sub-level a > span').removeClass('flyout-active');
                    }
                    
                    if(JFBase(this).parent().find('ul.main-level').is(':visible')){
                        JFBase(this).parent().find('ul.sub-level').slideUp();
                        JFBase(this).parent().find('ul.main-level a > span').removeClass('down-active');
                        JFBase(this).parent().find('ul.sub-level a > span').removeClass('flyout-active');
                    }
                    
                    menu.find('ul.main-level').slideToggle("2000","linear", function(){ });
                    
                    
                });
            
            });
             
             
           // close menus in mobile view if user clicks everywhere on the page outside of menus
           JFBase('body').not('.menu').on('click', function(e){
               e.stopPropagation();
               
               if(JFBase('.menu-trigger').is(':visible')){
                   JFBase('.menu ul.main-level').slideUp();
                   JFBase('.menu ul.main-level a > span').removeClass('down-active');
                   JFBase('.menu ul.sub-level').slideUp();  
                   JFBase('.menu ul.sub-level a > span').removeClass('flyout-active'); 
               }
               
               // delete active-main classes
               JFBase('.menu li').removeClass('active-main');
           });
         

           JFBase('.menu').on('click', function(e){
               e.stopPropagation();
           });
           
           // --  
                           
           // remove .active class in mobile view
           
           JFBase('.menu li').each(function(){
               if(JFBase(this).hasClass('active')){
                  JFBase(this).removeClass('active');
                  JFBase(this).addClass('vertical-active');
               } 
           });
         
           JFBase('.menu').each(function(){
               if(JFBase(this).hasClass('vertical')){
                  JFBase(this).removeClass('vertical');
                  JFBase(this).addClass('vertical-mobile');
               }
           });

           // for main-levels
           JFBase('.main-level > li.down').on('click', function(e){
               e.stopPropagation();
               JFBase(this).siblings().removeClass('active-main'); 
               JFBase(this).find(' > ul').slideToggle("2000","linear",function(){

                   JFBase('span.arrow-right').removeClass('flyout-active');
                   if(JFBase(this).parent().siblings('li.down').find('a > span').hasClass('down-active')){
                       JFBase(this).parent().siblings('li.down').find('a > span').removeClass('down-active'); 
                   }
                                       
                   JFBase(this).parent('.main-level > li.down').toggleClass('active-main');
                   
                   // only the first <span> get the down-active class
                   JFBase(this).parent('li.down').find('> a > span').toggleClass('down-active');
               });                
                
               // hide other opened level (siblings and children)
               JFBase(this).siblings().find(' > ul').slideUp();  
               JFBase(this).siblings().children().children().find(' > ul').slideUp();
               JFBase(this).children().children().find(' > ul').slideUp();                     
               JFBase(this).children().find(' > ul').slideUp();
           }); 
    
           // for sublevel normal (non-flyout) items, to prevent closing of parent
           JFBase('.sub-level > li').on('click', function(e){
               e.stopPropagation();
               return; 
           });
                          
           // for sublevel flyout items 
           JFBase('.sub-level > li.flyout').on('click', function(e){
               e.stopPropagation(); 
               JFBase(this).find(' > ul').slideToggle("2000","linear",function(){

                   // only the first <span> get the flyout-active class
                   JFBase(this).parent('li.flyout').find('> a > span').toggleClass('flyout-active');
               
                   if(JFBase(this).parent().siblings('li.flyout').find('a > span').hasClass('flyout-active')){
                       JFBase(this).parent().siblings('li.flyout').find('a > span').removeClass('flyout-active'); 
                   }

               });
               
               if(JFBase(this).find('a > span').hasClass('flyout-active')){
                   JFBase(this).children().find('a > span').removeClass('flyout-active') 
               } 
               
               JFBase(this).siblings().find(' > ul').slideUp();
               JFBase(this).siblings().children().children().find(' > ul').slideUp();
               JFBase(this).children().find(' > ul').slideUp();
               JFBase(this).children().children().find(' > ul').slideUp();
               
           });
                       
       } else {
            
           // put back .active class in normal views
           JFBase('.menu li').each(function(){
               if(JFBase(this).hasClass('vertical-active')){
                  JFBase(this).removeClass('vertical-active');
                  JFBase(this).addClass('active');
               }            
           }); 

                       
           JFBase('.menu').each(function(){
               if(JFBase(this).hasClass('vertical-mobile')){
                  JFBase(this).removeClass('vertical-mobile');
                  JFBase(this).addClass('vertical');
               }
           });
                                           
       }
 
    }
    
    
    /**
     * create compact menus for all menus on the page
     */    
    JFBase.fn.JFMenus.getCompactMenu = function(){
        
        var id_num     = null;
        var id         = '';
        var style      = '';
        var substyle   = '';
        var trigger_id = '';
         
        JFBase('.menu').each(function(){
            
            // prevent to make two or more menu-triggers for one menu
            if(JFBase(this).find('.menu-trigger').length > 0) return; 
            
            var menu = JFBase(this);
            id       = menu.attr('id');
            id_num   = id.substring(id.indexOf('-')+1,id.length);
            style    =  JFBase.fn.JFMenus.getStyleName(menu, 'main');
            substyle = (JFBase.fn.JFMenus.getStyleName(menu, 'sub') == 'undefined') ? '' :
                        JFBase.fn.JFMenus.getStyleName(menu, 'sub');
                        
            if(substyle==''){
                menu.prepend('<div id="menu-trigger-'+id_num+'" class="'+style+' menu-trigger">MENU</div>');    
            } else {
                menu.prepend('<div id="menu-trigger-'+id_num+'" class="'+style+' menu-trigger '+substyle+'">MENU</div>');
            }
                                            
        });
                
    }   
    
    
    /**
     * get the style and substyle names from DIV (ex. 'style-3', 'blue')
     */    
    JFBase.fn.JFMenus.getStyleName = function(menuobj, mode){
        var class_str = menuobj.attr('class');
        var class_arr = class_str.split(' '); 
        for(var i=0; i<class_arr.length; i++){
            switch(mode){

                case 'sub' :    if(JFBase.inArray(class_arr[i],JFBase.fn.JFMenus.styles.sub_style)!==-1){
                                    return class_arr[i];
                                }                 
                break;

                case 'main' :
                default     :   if(JFBase.inArray(class_arr[i],JFBase.fn.JFMenus.styles.main_style)!==-1){
                                    return class_arr[i];
                                }
                break;
            }

        }
        return '';
    }
    
    
    /**
     * replaceAll
     */     
    JFBase.fn.JFMenus.replaceAll = function(txt, replace, with_this) {
        if (typeof txt != 'undefined') {
            return txt.replace(new RegExp(replace, 'g'),with_this);
        }
    }     
    
    
    /**
     * swapToggle
     */     
    JFBase.fn.JFMenus.swapToggle = function(direction){

        var swap_from = '</a><span class="arrow-down"></span>';
        var swap_to = '<div style="display:inline;margin:0 0 0 15px;padding:0;"></div><span class="arrow-down"></span></a>';
        var swap_from_2 = '</a><span class="arrow-right"></span>';
        var swap_to_2 = '<div style="display:inline;margin:0 0 0 15px;padding:0;"></div><span class="arrow-right"></span></a>'; 
                    
        var html = '';

        JFBase('.menu').each(function(){
            var target = JFBase(this).find('ul.main-level');
            html = target.html(); 
    
            if(direction=='forward'){
                html = JFBase.fn.JFMenus.replaceAll(html,swap_from,swap_to);
                html = JFBase.fn.JFMenus.replaceAll(html,swap_from_2,swap_to_2);   
            } else {
                html = JFBase.fn.JFMenus.replaceAll(html,swap_to,swap_from);
                html = JFBase.fn.JFMenus.replaceAll(html,swap_to_2,swap_from_2);  
            }
           
            target.html(html);    
                
        });    

    }
    
    
    /**
     * reset menus : restore menu objects from the menus.obj array
     */ 
    JFBase.fn.JFMenus.reset = function(){
        
        if( (JC.BrowserDetect.browser == 'Explorer' && JC.BrowserDetect.version != '8') ||
             JC.BrowserDetect.browser != 'Explorer'){        
        
            var target = JFBase('.menu'); 
            target.each(function(index){
                JFBase(this).find('ul.main-level').html(JFBase.fn.JFMenus.menus.obj[index].html());
            });
        }     
    }  
    
    
    /**
     * resize
     */          
    JFBase.fn.JFMenus.resize = function(){

        var win_width = (JC.GRID.isScrollbarVisible()) ? (JFBase(window).width() + JC.GRID.scrollbarWidth()) : JFBase(window).width();        
        
       // after mobileview opened submenus does not appear in normal view
       // we need a little trick with refreshing menu structures to restore them in such cases
       // {        
       if(JFBase.fn.JFMenus.prevBrowserSize < JFBase.fn.JFMenus.desktopView &&
          win_width >= JFBase.fn.JFMenus.desktopView){
           JFBase.fn.JFMenus.reset();
           JFBase('.menu ul.main-level').css('display','block');
       }       
       // } 
               
        if(win_width < JFBase.fn.JFMenus.desktopView){
            JFBase('.menu ul.main-level').css('display','none');   
            JFBase.fn.JFMenus.swapToggle('forward');
        } else {
            JFBase('.menu ul.main-level').css('display','block');   
            JFBase.fn.JFMenus.swapToggle('backward');
        }
        
        JFBase.fn.JFMenus.prevBrowserSize = win_width;
        JFBase.fn.JFMenus.addHandlers();
      
    }
    
    
    /**
     * add ID attribute to every menu DIV, therefore we can handle menus easier
     */     
    JFBase.fn.JFMenus.setId = function(){
        var target = JFBase('.menu');
        target.removeAttr('id'); // delete old IDs if needed
        target.each(function(index){
            JFBase(this).attr('id','JFMenu-'+index)
        });
    }


    /**
     * fill up menu object holder array
     */ 
    JFBase.fn.JFMenus.storeMenuObjects = function(){
        JFBase.fn.JFMenus.menus.obj = []; // empty array
        var target = JFBase('.menu');
        target.each(function(index){
            JFBase.fn.JFMenus.menus.obj[index] = JFBase(this).find('ul.main-level').clone();
        });
    }
            

    /**
     * create new menu
     * @param: style classes, next menu ID
     */ 
    JFBase.fn.JFMenus.createMenu = function(style_classes, next_id, custom_menu_struct){
        
        var menu_struct = '<div id="JFMenu-'+next_id+'" class="menu '+style_classes+'"><div id="menu-trigger-'+next_id+'" class="menu-trigger '+style_classes+'">MENU</div><ul class="main-level"><li><a href="#item1">Item 1</a></li><li><a href="#item2">Item 2</a></li><li class="down"><a href="#item3">Item 3</a><span class="arrow-down"></span><ul class="sub-level"><li><a href="#item3_1">Item 3_1</a></li><li class="flyout"><a href="#item3_2">Item 3_2</a><span class="arrow-right"></span><ul class="sub-level"><li><a href="#item3_2_1">Item 3_2_1</a></li><li class="flyout"><a href="#item3_2_2">Item 3_2_2</a><span class="arrow-right"></span><ul class="sub-level"><li><a href="#item3_2_2_1">Item 3_2_2_1</a></li><li><a href="#item3_2_2_2">Item 3_2_2_2</a></li><li><a href="#item3_2_2_3">Item 3_2_2_3</a></li></ul></li><li><a href="#item3_2_3">Item 3_2_3</a></li></ul></li><li class="flyout"><a href="#item3_3">Item 3_3</a><span class="arrow-right"></span><ul class="sub-level"><li><a href="#item3_3_1">Item 3_3_1</a></li><li><a href="#item3_3_2">Item 3_3_2</a></li><li><a href="#item3_3_3">Item 3_3_3</a></li></ul></li></ul></li><li class="down"><a href="#item4">Item 4</a><span class="arrow-down"></span><ul class="sub-level"><li><a href="#item4_1">Item 4_1</a></li><li><a href="#item4_2">Item 4_2</a></li></ul></li><li><a href="#item5">Item 5</a></li></ul></div>';

        var win_width = (JC.GRID.isScrollbarVisible()) ? (JFBase(window).width() + JC.GRID.scrollbarWidth()) : JFBase(window).width(); 
        if(win_width < 768){
            var swap_from = '</a><span class="arrow-down"></span>';
            var swap_to = '<div style="display:inline;margin:0 0 0 15px;padding:0;"></div><span class="arrow-down"></span></a>';
            var swap_from_2 = '</a><span class="arrow-right"></span>';
            var swap_to_2 = '<div style="display:inline;margin:0 0 0 15px;padding:0;"></div><span class="arrow-right"></span></a>'; 
            menu_struct = JFBase.fn.JFMenus.replaceAll(menu_struct,swap_from,swap_to);
            menu_struct = JFBase.fn.JFMenus.replaceAll(menu_struct,swap_from_2,swap_to_2);   
        }

        return menu_struct;
    }
    
    
    /** CREATE SHORTCUTS -------- */ 
    if(typeof JC !='undefined'){
        JC.resizeMenus = function() { JFBase.fn.JFMenus.resize(); }
        JC.initMenus   = function() { JFBase.fn.JFMenus.init(); }
        JC.resetMenus  = function() { JFBase.fn.JFMenus.reset(); }
        JC.createMenu  = function(style_classes, next_id) { return JFBase.fn.JFMenus.createMenu(style_classes, next_id); }
    }        
              
              
})( JFBase );

// use the plugin
JFBase(document).ready(function() {

    // we do not use this plugin in case of ie8
    if( (JC.BrowserDetect.browser == 'Explorer' && JC.BrowserDetect.version != '8') ||
         JC.BrowserDetect.browser != 'Explorer'){
        if(JFBase('.menu').length > 0){
            JFBase('.menu').JFMenus();    
        } else {
           JC.console('No menu has detected on the site');
        }
        
        var resizeTimer;
        
        JFBase(window).resize(function(){
            clearTimeout(resizeTimer);
            resizeTimer = setTimeout(JC.resizeMenus, 1);
        });
        
    }

});  
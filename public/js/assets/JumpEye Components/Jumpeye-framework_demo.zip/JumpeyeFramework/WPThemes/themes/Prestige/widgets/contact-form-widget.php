<?php
/*
    Plugin Name: JF Contact Form Widget
    Plugin URI: http://www.jumpeye.com
    Description: Displays the contact form
    Version: 1.0
    Author: Jumpeye Components
    Author URI: http://www.jumpeye.com
    License: GPL2
*/

// register JFContactFormWidget widget
add_action('widgets_init', create_function('', 'return register_widget("JFContactFormWidget");')); 

/**
 * Adds JFContactFormWidget widget.
 */
class JFContactFormWidget extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	public function __construct() {
        
		parent::__construct(
	 		'JFContactFormWidget', // Base ID
			'JF Contact Form Widget', // Name (you will see it in Available Widgets)
			array( 'description' => __( 'Displays the contact form\'s inputs.', 'prestige' )) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	public function widget( $args, $instance ) {
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );

        /* Custom Options */
        // Our options from the widget settings.
        $email = (isset($instance['email'])) ? $instance['email'] : get_option('admin_email') ;
        
        // Before widget - as defined in your specific theme.
		echo $before_widget;
        
        // Captcha
        $op1 = rand(1, 99);
        $op2 = rand(1, 99);

    
        
        /* Display The Widget */
           if ( ! empty( $title ) ) echo $before_title . $title . $after_title;
           ?><div class="cf_inner_container">
            <form id="jf_contact_form" class="style-1" style="margin:0;" method="post" action="<?php echo THEME_ROOT_URI; ?>">
            <input type="hidden" name="jf_cf_recipient" id="jf_cf_recipient" value="<?php echo $email; ?>" />
            <label for="jf_cf_sender_name"><?php _e('Name','prestige'); ?></label>
            <input type="text" name="jf_cf_sender_name" id="jf_cf_sender_name" />
            <label for="jf_cf_sender_email"><?php _e('Email','prestige'); ?></label>
            <input type="text" name="jf_cf_sender_email" id="jf_cf_sender_email"  />
            <label for="jf_cf_subject"><?php _e('Subject','prestige'); ?></label>
            <input type="text" name="jf_cf_subject" id="jf_cf_subject"  />
            <label for="jf_cf_subject"><?php _e('Message','prestige'); ?></label>
            <textarea name="jf_cf_msg" id="jf_cf_msg" cols="70" rows="40"></textarea>
            <div class="row">
                <div class="columns grid_11">
                    <label class="captcha_label" for="captcha"><?php _e('Captcha: ','prestige'); echo $op1.' + '.$op2.' = '?></label>
                    <div class="captcha_input_holder"><input type="text" name="captcha" id="captcha" /></div>
                    <input type="hidden" name="sec_answer" id="sec_answer" value="<?php echo intval($op1+$op2); ?>" />
                </div>
                <div class="columns grid_7 align_right">
                    <input type="reset" name="jf_cf_reset" id="jf_cf_reset" value="<?php _e('Reset','prestige'); ?>" />
                    <input type="button" name="jf_cf_submit" id="jf_cf_submit" value="<?php _e('Submit','prestige'); ?>" onclick="_aSubmitContactForm('<?php echo admin_url().'admin-ajax.php'; ?>');" />
                </div>
            </div>
            <div id="jf_cf_response"></div>
            </form>
            <?php
        
        /* After widget - as defined in your specific theme. */
		echo $after_widget;
        ?>
                    <table class="table_of_shadows" border="0" cellpadding="0" cellspacing="0">
                        <tr>
                            <td class="post_left"></td>
                            <td class="post_center">&nbsp;</td>
                            <td class="post_right"></td>
                        </tr>
                    </table></div>          
        <?php
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) {
	   
        /* Default Widget Settings */
    		
    	$defaults = array(
    		'title'          => '',
    		'email'          => get_option('admin_email')
    	); 

        $instance       = wp_parse_args( (array) $instance, $defaults );   
        $title          = esc_attr( $instance['title'] );
        $email          = esc_attr( $instance['email'] );
        
		?>
		<p>
    		<label for="<?php echo $this->get_field_name( 'title' ); ?>"><?php _e( 'Title:', 'prestige' ); ?></label> 
    		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
		<p>
    		<label for="<?php echo $this->get_field_name( 'email' ); ?>"><?php _e( 'Recipient\'s e-mail address:', 'prestige' ); ?></label> 
    		<input class="widefat" id="<?php echo $this->get_field_id( 'email' ); ?>" name="<?php echo $this->get_field_name( 'email' ); ?>" type="text" value="<?php echo $email; ?>" />
		</p>        
		<?php 
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance                   = array();
		$instance['title']          = ( !empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
        $instance['email']          = ( !empty( $new_instance['email'] ) ) ? strip_tags( $new_instance['email'] ) : '';
        
		return $instance;
	}

} // class JFContactFormWidget
?>
(function(JFBase) {
    
    JFBase.fn.jcTooltip = function() {

        JFBase.fn.jcTooltip.win_width = (JC.GRID.isScrollbarVisible()) ? 
                                        (JFBase(window).width() + JC.GRID.scrollbarWidth()) : JFBase(window).width();  
        
        JFBase.fn.jcTooltip.positions = ["top-left",    "top-center",    "top-right",
                                         "bottom-left", "bottom-center", "bottom-right",
                                         "left-top",    "left-center",   "left-bottom",
                                         "right-top",   "right-center",  "right-bottom"];
        
        
        JFBase.fn.jcTooltip.styles = ["style-1", "style-2", "style-3", "style-4", "style-5", "style-6", 
                                      "style-7", "style-8", "style-9", "style-10", "style-11", "style-12",
                                      "style-13", "style-14", "style-15"];

                    
        JFBase.fn.jcTooltip.substyles = new Array("dark", "light", "gray", "yellow", "blue", "purple", "green", "red");


        /**
        * for multilined targets we need to get the first and last characters of the target
        * and then we add 'first-letter' and 'last-letter' classes to those characters
        * after then we can easily get the absolute positions of the first and last characters
        */ 
        JFBase.fn.jcTooltip.addSpan = function(){
            
            var target = null;
            var text = '', first_letter = '', last_letter = '', span_first = '', span_last = '';
            var last_index = 0;
            
            JFBase('.tooltip').each(function(){
                
                target = JFBase(this);
                
                if(target.find('span.first-letter').length > 0) return;
                
                text = target.text();
                first_letter = text.substr(0,1);
   
                // select the last letter of jtiped element
                last_letter = text.substr(text.length-1,1);
                last_index = text.lastIndexOf(last_letter);              
                
                span_first = '<span class="first-letter">'+first_letter+'</span>';
                span_last = '<span class="last-letter">'+last_letter+'</span>';  
                target.html(target.text().replace(first_letter,span_first));
                target.html(target.html().replace(new RegExp(text[last_index] + '$'),span_last));                                 
                    
            });
                   
        };
        
        
        /**
        * get object absolute positions
        */
        JFBase.fn.jcTooltip.absPos = function(obj){
            var pos    = { f_left: 0, f_top: 0, l_left: 0, l_top: 0 };
            var l_span_width = obj.find('span.last-letter').width();
            pos.f_left = parseInt(obj.find('.first-letter').offset().left);
            pos.f_top  = parseInt(obj.find('.first-letter').offset().top);
            pos.l_left = parseInt(obj.find('.last-letter').offset().left)+l_span_width;
            pos.l_top  = parseInt(obj.find('.last-letter').offset().top);
            return pos;            
        }
        
        
        /**
        * check does tooltip foolw the mouse ot not
        * in such cases the tooltip does not have position classes ex.: top-center
        */        
        JFBase.fn.jcTooltip.isMouseFollow = function(classes){
            var class_arr = classes.split(' ');
            for(var i=0; i<classes.length; i++){
                if(JFBase.inArray(class_arr[i],JFBase.fn.jcTooltip.positions)!=-1){
                    return false;
                }
            }
            return true;
        }
                                
            var orientation_changed = false;
            var classes    = null;
            var class_arr  = null;
            var style      = null;  
            var substyle   = null;
            var prevItem   = null;


            /**
            * replace all method
            */
            var replaceAll = function(txt, replace, with_this) {
                return txt.replace(new RegExp(replace, 'g'),with_this);
            }


            /**
            * set the position of element
            */
            var objPos = function (obj, top, left, width, display) {
                return obj.css({
                    'top'    : top,
                    'left'   : left,
                    'width'  : (width) ? width : 'auto',
                    'display': (display) ? display : 'block'
                }).end();
            };          


            /**
            * recreate tooltip DOM element to swap arrow direction for bloody IE8
            */  
            var ie8DomFix = function(){
               if(JC.BrowserDetect.browser == 'Explorer' &&
                  JC.BrowserDetect.version == '8'){
                    var element = JFBase('.jtip');
                    JFBase('body').append(element);
                  } 
            }  


            /**
            * fix some arrow positions under Opera
            */
            var operaDomFix = function(tip_height, position, style, substyle){
                if(JC.BrowserDetect.browser == 'Opera'){
                    if(style!='style-4'){
                        var corr_before = corr_after = 0;
                        var corr_before_v = corr_after_v = -10;
                        var corr_before_r = corr_after_r = -10;
                        var classnames = '.'+style+'.'+substyle+'.'+position;
                        switch(style){
                            case 'style-3'  : corr_before = -1; corr_after = -1; 
                                              corr_before_v = -5; corr_after_v = -5;
                                              corr_before_r = -5; corr_after_r = -5; break;
                            case 'style-5'  : corr_before = -1; corr_after = 1; 
                                              corr_before_v = -7; corr_after_v = -7; break; 
                            case 'style-6'  : corr_before_v = 0; corr_after_v = 0; 
                                              corr_before_r = 0; corr_after_r = 0; break;                                           
                            case 'style-7'  : corr_before = -1; corr_after = 0;
                                              corr_before_v = -2; corr_after_v = -2;
                                              corr_before_r = -2; corr_after_r = -2; break;
                            case 'style-8'  : corr_before = -1; corr_after = -1;
                                              corr_before_v = -5; corr_after_v = -5; 
                                              corr_before_r = -5; corr_after_r = -5; break;
                            case 'style-9'  : corr_before_v = 0; corr_after_v = 0;
                                              corr_before_r = 0; corr_after_r = 0; break;                                          
                            case 'style-10' : corr_before_v = -5; corr_after_v = -5; 
                                              corr_before_r = -5; corr_after_r = -5; break;
                            case 'style-11' : 
                            case 'style-12' : corr_before_v = -7;
                                              corr_before_r = -7; break;
                            case 'style-13' : corr_before_v = -9; break;                  
                            case 'style-14' : corr_before = 1; corr_after = 5; 
                                              corr_before_v = -5; corr_after_v = -5; 
                                              corr_before_r = -5; corr_after_r = -5; break;
                            case 'style-15' : corr_before_v = 4; 
                                              corr_before_r = 4; break;                                          
                        }


                        switch(position){
                            case 'top-left'     : JFBase('head').append('<style title="gen">.jtip'+classnames+':before{bottom: auto !important; top:'+(tip_height+corr_before)+'px !important;}</style>');
                                                  if(before_after_gap[style]!=0){
                                                      JFBase('head').append('<style title="gen">.jtip'+classnames+':after{bottom: auto !important; top:'+(tip_height-before_after_gap[style]+corr_after)+'px !important;}</style>');
                                                  }    
                                                  break;
                            case 'top-center'   : JFBase('head').append('<style title="gen">.jtip'+classnames+':before{left:50% !important; bottom: auto !important; top:'+(tip_height+corr_before)+'px !important;}</style>');
                                                  if(before_after_gap[style]!=0){
                                                      JFBase('head').append('<style title="gen">.jtip'+classnames+':after{left:50% !important; bottom: auto !important; top:'+(tip_height-before_after_gap[style]+corr_after)+'px !important;}</style>');
                                                  }
                                                  break;
                            case 'top-right'    : JFBase('head').append('<style title="gen">.jtip'+classnames+':before{bottom: auto !important; top:'+(tip_height+corr_before)+'px !important;}</style>');
                                                  if(before_after_gap[style]!=0){
                                                      JFBase('head').append('<style title="gen">.jtip'+classnames+':after{bottom: auto !important; top:'+(tip_height-before_after_gap[style]+corr_after)+'px !important;}</style>');
                                                  }
                                                  break;

                            case 'left-bottom'  : JFBase('head').append('<style title="gen">.jtip'+classnames+':before{top: auto !important; bottom:-'+(tip_height+corr_before_v)+'px !important;}</style>');
                                                  if(before_after_gap[style]!=0){
                                                      JFBase('head').append('<style title="gen">.jtip'+classnames+':after{top: auto !important; bottom:-'+(tip_height-before_after_gap[style]+corr_after_v)+'px !important;}</style>');
                                                  }                        
                                                  break;
                            case 'right-bottom' : JFBase('head').append('<style title="gen">.jtip'+classnames+':before{top: auto !important; bottom:-'+(tip_height+corr_before_r)+'px !important;}</style>');
                                                  if(before_after_gap[style]!=0){
                                                      JFBase('head').append('<style title="gen">.jtip'+classnames+':after{top: auto !important; bottom:-'+(tip_height-before_after_gap[style]+corr_before_r)+'px !important;}</style>');
                                                  }   
                                                  break;                                           
                        }    
                    }

                }

            }


            /**
            * set z-index of targets
            */ 
            var zIndex = function(target, method){
                var is_mouse_follow = JFBase.fn.jcTooltip.isMouseFollow(target.attr('class'));
                switch(method){
                    case 'init' : JFBase('.jtip').css('z-index',10);
                                  target.css('position','relative');
                                  if(!is_mouse_follow){
                                    target.css('z-index',9999);  
                                  }
                                  
                    break;

                    case 'destroy' : JFBase('.jtip').css('z-index',0);
                                     target.css('position','relative');
                                     if(!is_mouse_follow){
                                        target.css('z-index',0);
                                     }   
                    break;     
                }

            } 


            var i                = 0;
            var target_font_site = 0;

            // position classnames
            var pos = new Array("top-left",    "top-center",    "top-right",
                                "bottom-left", "bottom-center", "bottom-right",
                                "left-top",    "left-center",   "left-bottom",
                                "right-top",   "right-center",  "right-bottom");

            // define main style names
            var styles = new Array("style-1", "style-2", "style-3", "style-4", "style-5", "style-6", 
                                   "style-7", "style-8", "style-9", "style-10", "style-11", "style-12",
                                   "style-13", "style-14", "style-15");

            // define substyle names                       
            var substyles = new Array("dark", "light", "gray", "yellow", "blue", "purple", "green", "red");

            // define arrow-height for each styles
            /* we use it to positioning of tooltips 
               values are in the appropriate css classes

               ex.:
               .jtip.style-1:before {
                   border  : 6px solid;
                   ...
               }

               we need the border-width value (this is 6px in the example above)
            */       
            var arrow_size = { 'style-1' : 6, 'style-2' : 6, 'style-3' : 14, 'style-4' : 0, 'style-5' : 11,
                               'style-6' : 9, 'style-7' : 11, 'style-8' : 10, 'style-9' : 12, 'style-10' : 7,
                               'style-11' : 12, 'style-12' : 12, 'style-13' : 6, 'style-14' : 11, 'style-15' : 12};

            // offsets (disances) between tooltip (arrow) and the target text
            var offset_top    = 0;
            var offset_bottom = 0;
            var offset_left   = 0;
            var offset_right  = 0; 

            // style positioning corrections
            // for top-left, top-center, top-right

            if(JC.BrowserDetect.browser == 'Explorer' && JC.BrowserDetect.version == '8') {
                var corr_top_vertical = { 'style-1' : 15, 'style-2' : 3, 'style-3' : 3, 'style-4' : 2,  'style-5' : 3,
                                          'style-6' : 9,  'style-7' : 2, 'style-8' : 2, 'style-9' : 2, 'style-10' : 5,
                                          'style-11' : 4, 'style-12' : 4, 'style-13' : 2, 'style-14' : 2, 'style-15' : 6 };        
            } else {
                var corr_top_vertical = { 'style-1' : 3, 'style-2' : 3, 'style-3' : 7, 'style-4' : 5, 'style-5' : 3,
                                          'style-6' : 10, 'style-7' : 5, 'style-8' : 2, 'style-9' : 0, 'style-10' : 5,
                                          'style-11' : 3, 'style-12' : 3, 'style-13' : 0, 'style-14' : 2, 'style-15' : 4 };        
            }


            // for top-left, top-center, top-right
            var corr_bottom_vertical = { 'style-1' : 0, 'style-2' : 0, 'style-3' : 0, 'style-4' : 0, 'style-5' : -2,
                                         'style-6' : 0, 'style-7' : -2, 'style-8' : -1, 'style-9' : 1, 'style-10' : 0,
                                         'style-11' : 0, 'style-12' : 0, 'style-13' : 0, 'style-14' : -3, 'style-15' : 0 };

            // for left-top, right-top
            var corr_left_vertical = { 'style-1' : 0, 'style-2' : 0, 'style-3' : 5, 'style-4' : 0, 'style-5' : 0,
                                       'style-6' : 0, 'style-7' : 0, 'style-8' : 0, 'style-9' : -18, 'style-10' : 0,
                                       'style-11' : -8, 'style-12' : -8, 'style-13' : 0, 'style-14' : 0, 'style-15' : -20 };


            // for left-xx
            var corr_left_horizontal = { 'style-1' : 0, 'style-2' : 0, 'style-3' : 6, 'style-4' : 4, 'style-5' : 2,
                                         'style-6' : 8, 'style-7' : 0, 'style-8' : 0, 'style-9' : 0, 'style-10' : 2,
                                         'style-11' : 2, 'style-12' : 2, 'style-13' : 0, 'style-14' : 0, 'style-15' : 4 };


            // for left-center, right-center
            if(JC.BrowserDetect.browser == 'Explorer' && JC.BrowserDetect.version == '8') {
                var corr_center_horizontal = { 'style-1' : 3, 'style-2' : 0, 'style-3' : 1, 'style-4' : 0, 'style-5' : 0,
                                               'style-6' : 2, 'style-7' : 1, 'style-8' : 0, 'style-9' : -6, 'style-10' : 0,
                                               'style-11' : -6, 'style-12' : -6, 'style-13' : 0, 'style-14' : 0, 'style-15' : -4 };
            } else {
                var corr_center_horizontal = { 'style-1' : 0, 'style-2' : 0, 'style-3' : 1, 'style-4' : 0, 'style-5' : 0,
                                               'style-6' : 2, 'style-7' : 1, 'style-8' : 0, 'style-9' : -6, 'style-10' : 0,
                                               'style-11' : -6, 'style-12' : -6, 'style-13' : 0, 'style-14' : 0, 'style-15' : -4 };
            }
            // for left-bottom, right-bottom
            var corr_lr_bottom_vertical = { 'style-1' : -2, 'style-2' : 4, 'style-3' : 18, 'style-4' : 0, 'style-5' : 29,
                                            'style-6' : 10, 'style-7' : 13, 'style-8' : 10, 'style-9' : 14, 'style-10' : -5,
                                            'style-11' : -3, 'style-12' : -3, 'style-13' : -1, 'style-14' : 10, 'style-15' : 18 };

            // for right-xx
            var corr_right_horizontal = { 'style-1' : 2, 'style-2' : 2, 'style-3' : 1, 'style-4' : 2, 'style-5' : 0,
                                          'style-6' : 2, 'style-7' : 0, 'style-8' : 0, 'style-9' : 0, 'style-10' : 0,
                                          'style-11' : 0, 'style-12' : 0, 'style-13' : 0, 'style-14' : 0, 'style-15' : 0 };

            // before-after gap
            var before_after_gap = { 'style-1' : 0, 'style-2' : 0, 'style-3' : 2, 'style-4' : 0, 'style-5' : 2,
                                     'style-6' : 0, 'style-7' : 2, 'style-8' : 1, 'style-9' : 0, 'style-10' : 1,
                                     'style-11' : 0, 'style-12' : 0, 'style-13' : 0, 'style-14' : 5, 'style-15' : 0 };

            // store the title of the target                   
            var target_title = ''; 


            /**
            * get or make ID from target object
            */
            var getID = function(obj, mode){

                var target_id = obj.attr('id'); 
                switch(mode){
                    // returns  with ID of the target (ex: JFTarget-12)
                    case 1 : return target_id;

                    // returns ID of the tooltip (ex: JFTooltip-12)
                    case 2 : return 'JFTooltip-'+target_id.substring(target_id.indexOf('-')+1,target_id.length);

                    // returns only ID number (ex: 12)
                    default : return target_id.substring(target_id.indexOf('-')+1,target_id.length);  
                }
            }


            /**
            * create tooltip in the DOM
            */
            var showTooltip=function(tip_text, obj) {
                var tooltip_id = getID(obj,2);
                //if (!JFBase('#JFTooltip-'+id_number)) {
                    JFBase('body').append('<div id="'+tooltip_id+'" class="jtip">' + tip_text + '</div>');
                //}
            }          


            var is_multilined = false;
            var isTargetMultiline = function(target){

                var font_size = parseInt(target.css('font-size'));
                var line_height = parseInt(target.css('line-height'));
                var target_height = parseInt(target.height());

                return (font_size >= (target_height-line_height)) ? false : true;

            }

            var browser_width = (JC.GRID.isScrollbarVisible()) ? (JFBase(window).innerWidth() + JC.GRID.scrollbarWidth()) : JFBase(window).width();
            var scrollbar_width = (JC.GRID.isScrollbarVisible()) ? JC.GRID.scrollbarWidth() : 0;

            if(JC.isTouchable()){
                var touchevent = 'touchstart'; 
                var toucheventEnd = 'touchend';
                var toucheventMove = 'touchend';
            } else {
                var touchevent = 'mouseover';
                var toucheventEnd = 'mouseleave'; 
                var toucheventMove = 'mousemove';
            }
        
        JFBase(this).each(function(){
            // transform mousefollow tooltips to top-left tooltips on touch devices
            if(JC.isTouchable()){
                if(JFBase.fn.jcTooltip.isMouseFollow(JFBase(this).attr('class'))){
                    JFBase(this).addClass('bottom-left');
                }    
            }
            
            if(JFBase.fn.jcTooltip.isMouseFollow(JFBase(this).attr('class'))){
                ie8DomFix(); 
                JFBase(this).live(toucheventMove, function(e) {
                    if(JFBase.fn.jcTooltip.win_width >= 768){
                        JFBase('.jtip').removeClass('top-left');
                        if(!JFBase('.jtip').hasClass('bottom-left')){
                            JFBase('.jtip').addClass('bottom-left');    
                        }                        
                    } else {
                        JFBase('.jtip').removeClass('bottom-left');
                        if(!JFBase('.jtip').hasClass('top-left')){
                            JFBase('.jtip').addClass('top-left');    
                        }                        
                        
                    }
                    
                    var data_width = JFBase(this).attr('data-width');
                    var jtip_width = (data_width==undefined) ? JFBase(".jtip").width() : (data_width - parseInt(JFBase('.jtip').css('padding-left'))*2);

                    objPos(JFBase('.jtip'), e.pageY + 20, e.pageX + 20, jtip_width);    
                });   
            }    


            JFBase(this).live(toucheventEnd, function(e) {
                var browser_width = (JC.GRID.isScrollbarVisible()) ? (JFBase(window).innerWidth() + JC.GRID.scrollbarWidth()) : JFBase(window).width();
                if(JFBase.fn.jcTooltip.isMouseFollow(JFBase(this).attr('class'))){
                    JFBase('.jtip').removeClass('bottom-left');
                }
            });


            JFBase(this).live(touchevent,  function(e) {
                var target = JFBase(this);  // tooltip target ( ex: <span class="tooltip">Tooltip</span> )          

                if(JC.isTouchable()){
                    JFBase('.tooltip-displayed').removeClass('tooltip-displayed');
                    target.addClass('tooltip-displayed');
                    
                    if(prevItem != null){
                        // put back the title attribute's value
                        prevItem.attr('title',target_title);
                        JFBase(prevItem).removeClass('tooltip-displayed');

                        zIndex(prevItem,'destroy');

                        // remove the appended jtip template and css
                        JFBase('head style[title="gen"]').remove();
                        JFBase('body').children('#'+getID(prevItem,2)).remove();
                        JFBase('.jtip').remove();
                        if(getID(target,2) == getID(prevItem,2)){
                            prevItem = null;
                            return false;
                        }
                    }

                    prevItem = target;
                }
                
                

                is_multilined = isTargetMultiline(target);

                target_title     = target.attr('title'); // get value of tooltip title parameter
                target_font_size = parseInt(target.css('font-size'));

                // disable original Tooltip of the browser
                target.attr('title',''); 

                var data_width = target.attr('data-width');
                classes    = target.attr('class');  // get tip classname(s)
                class_arr  = classes.split(' ');     // explode classname strint into an array
                style      = null;                   // main style of jtip (ex. style-1)  

                var tip_text   = target_title;

                showTooltip(tip_text, target);

                zIndex(target,'init');

                // add styles and substyles to the jtip
                for(i=0; i<class_arr.length; i++){
                    if(JFBase.inArray(class_arr[i],styles)!==-1){
                        JFBase('.jtip').addClass(class_arr[i]);
                        style = class_arr[i];
                        break;                     
                    }
                } 

                for(i=0; i<class_arr.length; i++){
                    if(JFBase.inArray(class_arr[i],substyles)!==-1){
                        JFBase('.jtip').addClass(class_arr[i]);
                        substyle = class_arr[i]; 
                        break;                     
                    }
                }


                // target and tooltip positions and dimensions
                var target_positions  = target.offset(); 
                var target_top        = parseInt(target_positions.top);
                var target_left = JFBase.fn.jcTooltip.absPos(target).f_left;
                var target_height     = target.outerHeight();
                var target_width      = target.outerWidth();
                var jtip_width        = (data_width==undefined) ? JFBase(".jtip").width() : (data_width - parseInt(JFBase('.jtip').css('padding-left'))*2);
                var jtip_width_with_padding = (data_width==undefined) ? JFBase(".jtip").width() : data_width;
                var jtip_height       = JFBase(".jtip").height();
                var jtip_fullheight   = jtip_height + parseInt(JFBase('.jtip').css('padding-top'))*2;
                var viewportWidth     = JFBase(window).width();
                var viewportHeight    = JFBase(window).height();
                var border_top        = JFBase(window).scrollTop();
                var top               = 0; // jtip top position
                var left              = 0; // jtip left position

                var border_bottom = target_top - border_top + target_height;
                border_bottom = (border_bottom > 0) ? border_bottom : -1 * border_bottom;

                if(border_bottom>0){
                    border_bottom = viewportHeight-border_bottom;
                } else {
                    border_bottom = border_bottom-viewportHeight;
                }

                var browser_width = (JC.GRID.isScrollbarVisible()) ? (JFBase(window).innerWidth() + JC.GRID.scrollbarWidth()) : JFBase(window).width();
                var scrollbar_width = (JC.GRID.isScrollbarVisible()) ? JC.GRID.scrollbarWidth() : 0;


                if (browser_width < 768) {

                    var pos_class = '';
                    var padding = 5;
                    var width = browser_width-scrollbar_width-padding*2-2*parseInt(JFBase('.jtip').css('border-left-width'));

                    if(JC.BrowserDetect.browser == 'Explorer' && JC.BrowserDetect.version == '8' &&
                       style=='style-1'){
                       width+=12;     
                    }

                    if(target_top-border_top < jtip_fullheight){ // not enough space on the top
                        JFBase('.jtip').addClass('bottom-left');
                        top = target_top+target_height+arrow_size[style]+corr_bottom_vertical[style];
                        pos_class = 'bottom-left';
                    } else {
                        JFBase('.jtip').addClass('top-left');
                        top = target_top-(jtip_height+parseInt(JFBase('.jtip').css('padding-top'))*2)-arrow_size[style]-corr_top_vertical[style];
                        pos_class = 'top-left';
                        if(style=='style-4'){ top-=4;}
                    }

                    left = target_left+10;                  

                    if(style!='style-4'){
                        var classnames = '.'+style+'.'+substyle+'.'+pos_class;

                        if(before_after_gap[style]!=0){

                            JFBase('head').append('<style title="gen">.jtip'+classnames+':after{left:'+(left+before_after_gap[style])+'px !important;}</style>');    
                        }

                        JFBase('head').append('<style title="gen">.jtip'+classnames+':before{left:'+(left)+'px !important;}</style>');

                    } else {
                        classnames = '';
                    }

                    if(style=='style-9'){
                        JFBase('head').append('<style title="gen">.jtip'+classnames+'{border-bottom-left-radius:6px; -moz-border-radius-bottomleft:6px; -webkit-border-bottom-left-radius:6px;}</style>');       
                    } 

                    objPos(JFBase('.jtip'), top, left);

                    JFBase('head').append('<style title="gen">.jtip'+classnames+'{top: '+(top)+'px !important; left: 0px !important; padding-left: '+padding+'px !important; padding-right: '+padding+'px !important; width:'+width+'px !important;}</style>');

                } else {
                    JFBase('head style[title="gen"]').remove();
                    objPos(JFBase('.jtip'),target_top,target_left,jtip_width,'none'); // 'init' tooltip

                    jtip_height = JFBase('.jtip').height() + // recalculate tip-height
                                  parseInt(JFBase('.jtip').css('padding-top')) +
                                  parseInt(JFBase('.jtip').css('padding-bottom')) + 
                                  parseInt(JFBase('.jtip').css('border-left-width'));

                    if(classes.indexOf('top-left') > -1){

                        if(is_multilined){ // multilined target
                            if(target_top-border_top < jtip_height){ // not enough space on the top
                                JFBase('.jtip').addClass('bottom-left');
                                top = target_top+arrow_size[style]+corr_bottom_vertical[style]+target_font_size+2;
                                zIndex(target,'destroy');
                            } else {
                                JFBase('.jtip').addClass('top-left');
                                top = target_top-jtip_height-arrow_size[style]-corr_top_vertical[style];
                            }

                        } else {

                            if(target_top-border_top < jtip_height){ // not enough space on the top
                                JFBase('.jtip').addClass('bottom-left');
                                top = target_top+target_height+arrow_size[style]+corr_bottom_vertical[style];
                            } else {
                                JFBase('.jtip').addClass('top-left');
                                top = target_top-jtip_height-arrow_size[style]-corr_top_vertical[style];
                            }

                        }

                        left = target_left;
                        operaDomFix(jtip_height,'top-left',style, substyle);
                    } // end of position 'top-left'

                    else if(classes.indexOf('top-center') > -1){

                        if(is_multilined){ // multilined target
                            if(target_top-border_top < jtip_height){ // not enough space on the top
                                //JFBase('.jtip').addClass('bottom-center');
                                JFBase('.jtip').addClass('bottom-left');
                                top = target_top+arrow_size[style]+corr_bottom_vertical[style]+target_font_size+2;
                                zIndex(target,'destroy');
                            } else {
                                //JFBase('.jtip').addClass('top-center');
                                JFBase('.jtip').addClass('top-left');
                                top = target_top-jtip_height-arrow_size[style]-corr_top_vertical[style];
                            }
                            left = target_left;// + (target_width/2) - jtip_width_with_padding/2;
                        } else {
                            if(target_top-border_top < jtip_height){ // not enough space on the top
                                JFBase('.jtip').addClass('bottom-center'); 
                                top = target_top+target_height+arrow_size[style]+corr_bottom_vertical[style];
                            } else {
                                JFBase('.jtip').addClass('top-center');
                                top = target_top-jtip_height-arrow_size[style]-corr_top_vertical[style];
                            }
                            left = target_left + (target_width/2) - jtip_width_with_padding/2;
                        }
                        operaDomFix(jtip_height,'top-center',style, substyle);    
                    } // end of position 'top-center' 

                    else if(classes.indexOf('top-right') > -1){

                        if(is_multilined){ // multilined target
                            if(target_top-border_top < jtip_height){ // not enough space on the top
                                JFBase('.jtip').addClass('bottom-left');
                                top = target_top+arrow_size[style]+corr_bottom_vertical[style]+target_font_size+2;
                                zIndex(target,'destroy');
                            } else {
                                JFBase('.jtip').addClass('top-left');
                                top = target_top-jtip_height-arrow_size[style]-corr_top_vertical[style];                           
                            } 

                            left = target_left;

                        } else {
                            if(target_top-border_top < jtip_height){ // not enough space on the top
                                JFBase('.jtip').addClass('bottom-right');
                                top = target_top+target_height+arrow_size[style]+corr_bottom_vertical[style];
                            } else {
                                JFBase('.jtip').addClass('top-right');
                                top = target_top-jtip_height-arrow_size[style]-corr_top_vertical[style];
                            }

                            left = target_left + (target_width - jtip_width_with_padding);

                        }
                        operaDomFix(jtip_height,'top-right',style, substyle);
                    } // end of position 'top-right'    

                    else if(classes.indexOf('bottom-left') > -1){

                        if(is_multilined){ // multilined target
                            if(border_bottom < jtip_height){ // not enough space at the bottom
                                JFBase('.jtip').addClass('top-left');
                                top = target_top-jtip_height-arrow_size[style]-corr_top_vertical[style];
                            } else {
                                JFBase('.jtip').addClass('bottom-left');
                                top = target_top+arrow_size[style]+corr_bottom_vertical[style]+target_font_size+2;
                                zIndex(target,'destroy');                                                        
                            }
                            left = target_left;
                        } else {
                            if(border_bottom < jtip_height){ // not enough space at the bottom
                                JFBase('.jtip').addClass('top-left');
                                top = target_top-jtip_height-arrow_size[style]-corr_top_vertical[style];
                            } else {
                                JFBase('.jtip').addClass('bottom-left');
                                top = target_top+target_height+arrow_size[style]+corr_bottom_vertical[style];
                            }
                            left = target_left;
                        }    
                    } // end of position 'bottom-left'

                    else if(classes.indexOf('bottom-center') > -1){
                        if(is_multilined){ // multilined target
                            if(border_bottom < jtip_height){ // not enough space at the bottom
                                JFBase('.jtip').addClass('top-left');
                                top = target_top-jtip_height-arrow_size[style]-corr_top_vertical[style];
                            } else {
                                JFBase('.jtip').addClass('bottom-left');
                                top = target_top+arrow_size[style]+corr_bottom_vertical[style]+target_font_size+2;
                                zIndex(target,'destroy');                                                        
                            }
                            left = target_left;
                        } else {
                            if(border_bottom < jtip_height){ // not enough space at the bottom
                                JFBase('.jtip').addClass('top-center');
                                top = target_top-jtip_height-arrow_size[style]-corr_top_vertical[style];
                            } else {
                                JFBase('.jtip').addClass('bottom-center');
                                top = target_top+target_height+arrow_size[style]+corr_bottom_vertical[style];
                            }
                            left = target_left + (target_width/2) - jtip_width_with_padding/2;
                        }    
                    } // end of position 'bottom-center'                

                    else if(classes.indexOf('bottom-right') > -1){
                        if(is_multilined){ // multilined target
                            if(border_bottom < jtip_height){ // not enough space at the bottom
                                JFBase('.jtip').addClass('top-left');
                                top = target_top-jtip_height-arrow_size[style]-corr_top_vertical[style];
                            } else {
                                JFBase('.jtip').addClass('bottom-left');
                                top = target_top+arrow_size[style]+corr_bottom_vertical[style]+target_font_size+2;
                                zIndex(target,'destroy');                                                        
                            }
                            left = target_left;
                        } else {
                            if(border_bottom < jtip_height){ // not enough space at the bottom
                                JFBase('.jtip').addClass('top-right');
                                top = target_top-jtip_height-arrow_size[style]-corr_top_vertical[style];
                            } else {
                                JFBase('.jtip').addClass('bottom-right');
                                top = target_top+target_height+arrow_size[style]+corr_bottom_vertical[style];
                            }
                            left = target_left-jtip_width_with_padding+target_width;
                        }

                        if(style=='style-15'){
                            left-=4;    
                        }   

                    } // end of position 'bottom-right'

                    else if(classes.indexOf('left-top') > -1){

                        if(is_multilined){ // multilined target
                            if(target_top-border_top < jtip_height){ // not enough space on the top
                                JFBase('.jtip').addClass('bottom-left');
                                top = target_top+arrow_size[style]+corr_bottom_vertical[style]+target_font_size+2;
                                zIndex(target,'destroy');                            
                            } else {
                                JFBase('.jtip').addClass('top-left');
                                top = target_top-jtip_height-arrow_size[style]-corr_top_vertical[style];
                            }
                            left = target_left;
                        } else {

                           if(target_left < (parseInt(jtip_width_with_padding)+parseInt(arrow_size[style]))){ // not enough space on the left

                               if(target_top-border_top < jtip_height){ // not enough space on the top
                                   JFBase('.jtip').addClass('bottom-left');
                                   top = target_top+target_height+arrow_size[style]+corr_bottom_vertical[style];
                               } else {
                                   JFBase('.jtip').addClass('top-left');
                                   top = target_top-jtip_height-arrow_size[style]-corr_top_vertical[style];
                               }
                               left = target_left;

                           } else {
                               JFBase('.jtip').addClass('left-top');
                               top = target_top - target_font_size/2 - corr_left_vertical[style] - arrow_size[style]/2 + parseInt(JFBase(this).css('padding-top'));
                               left = target_left-jtip_width_with_padding-arrow_size[style]-corr_left_horizontal[style];   
                           }

                        }

                    } // end of position 'left-top'

                    else if(classes.indexOf('left-center') > -1){

                        if(is_multilined){ // multilined target
                            if(target_top-border_top < jtip_height){ // not enough space on the top
                                JFBase('.jtip').addClass('bottom-left');
                                top = target_top+arrow_size[style]+corr_bottom_vertical[style]+target_font_size+2;
                                zIndex(target,'destroy');                              
                            } else {
                                JFBase('.jtip').addClass('top-left');
                                top = target_top-jtip_height-arrow_size[style]-corr_top_vertical[style];
                            }
                            left = target_left;
                        } else {

                           if(target_left < (parseInt(jtip_width_with_padding)+parseInt(arrow_size[style]))){ // not enough space on the left

                               if(target_top-border_top < jtip_height){ // not enough space on the top
                                   JFBase('.jtip').addClass('bottom-left');
                                   top = target_top+target_height+arrow_size[style];
                               } else {
                                   JFBase('.jtip').addClass('top-left');
                                   top = target_top-jtip_height-arrow_size[style];
                               }
                               left = target_left;

                           } else {
                               if(target_left < (parseInt(jtip_width_with_padding)+parseInt(arrow_size[style]))){ // not enough space on the left

                                   if(target_top-border_top < jtip_height){ // not enough space on the top
                                       JFBase('.jtip').addClass('bottom-left');
                                       top = target_top+target_height+arrow_size[style]+corr_bottom_vertical[style];
                                   } else {
                                       JFBase('.jtip').addClass('top-left');
                                       top = target_top-jtip_height-arrow_size[style]-corr_top_vertical[style];
                                   }
                                   left = target_left;

                               } else {                        
                                   JFBase('.jtip').addClass('left-center');
                                   left = target_left-jtip_width_with_padding-arrow_size[style]-corr_left_horizontal[style];
                                   top = target_top - (jtip_height-target_height) / 2 - corr_center_horizontal[style];
                               } 
                           } 

                        }    

                    } // end of position 'left-center'

                    else if(classes.indexOf('left-bottom') > -1){

                        if(is_multilined){ // multilined target
                            if(target_top-border_top < jtip_height){ // not enough space on the top
                                JFBase('.jtip').addClass('bottom-left');
                                top = target_top+arrow_size[style]+corr_bottom_vertical[style]+target_font_size+2;
                                zIndex(target,'destroy');                              
                            } else {
                                JFBase('.jtip').addClass('top-left');
                                top = target_top-jtip_height-arrow_size[style]-corr_top_vertical[style];
                            }
                            left = target_left;
                        } else {
                           if(target_left < (parseInt(jtip_width_with_padding)+parseInt(arrow_size[style]))){ // not enough space on the left

                               if(target_top-border_top < jtip_height){ // not enough space on the top
                                   JFBase('.jtip').addClass('bottom-left');
                                   top = target_top+target_height+arrow_size[style]+corr_bottom_vertical[style];
                               } else {
                                   JFBase('.jtip').addClass('top-left');
                                   top = target_top-jtip_height-arrow_size[style]-corr_top_vertical[style];
                               }
                               left = target_left;

                           } else {
                               JFBase('.jtip').addClass('left-bottom');
                               left = target_left-jtip_width_with_padding-arrow_size[style]-corr_left_horizontal[style];
                               if(JC.BrowserDetect.browser == 'Explorer' && JC.BrowserDetect.version == '8' && style=='style-1') {
                                   var corr = 10; 
                               } else {
                                   var corr = corr_lr_bottom_vertical[style]; 
                               } 
                               top = target_top + target_font_size/2 - JFBase('.jtip').height() + arrow_size[style]/2 + parseInt(JFBase(this).css('padding-top'))-corr;
                           } 

                        }    
                        operaDomFix(jtip_height,'left-bottom',style, substyle);                
                    } // end of position 'left-bottom'

                    else if(classes.indexOf('right-top') > -1){

                        if(is_multilined){ // multilined target
                            if(target_top-border_top < jtip_height){ // not enough space on the top
                                JFBase('.jtip').addClass('bottom-left');
                                top = target_top+arrow_size[style]+corr_bottom_vertical[style]+target_font_size+2;
                                zIndex(target,'destroy');                             
                            } else {
                                JFBase('.jtip').addClass('top-left');
                                top = target_top-jtip_height-arrow_size[style]-corr_top_vertical[style];
                            }
                            left = target_left;
                        } else {
                           var space_on_right = browser_width-scrollbar_width-target_left-target_width;
                           if(space_on_right < (parseInt(jtip_width_with_padding)+parseInt(arrow_size[style]))){ // not enough space on the left

                               if(target_top-border_top < jtip_height){ // not enough space on the top
                                   JFBase('.jtip').addClass('bottom-left');
                                   top = target_top+target_height+arrow_size[style]+corr_bottom_vertical[style];
                               } else {
                                   JFBase('.jtip').addClass('top-left');
                                   top = target_top-jtip_height-arrow_size[style]-corr_top_vertical[style];
                               }
                               left = target_left;

                           } else {
                               JFBase('.jtip').addClass('right-top');

                               top = target_top - target_font_size/2 - corr_left_vertical[style] - arrow_size[style]/2 + parseInt(JFBase(this).css('padding-top'));                                                                
                               left = target_left+target_width + arrow_size[style]+corr_right_horizontal[style];   
                           }

                        }                   

                    } // end of position 'right-top'

                    else if(classes.indexOf('right-center') > -1){

                        if(is_multilined){ // multilined target
                            if(target_top-border_top < jtip_height){ // not enough space on the top
                                JFBase('.jtip').addClass('bottom-left');
                                top = target_top+arrow_size[style]+corr_bottom_vertical[style]+target_font_size+2;
                                zIndex(target,'destroy');                             
                            } else {
                                JFBase('.jtip').addClass('top-left');
                                top = target_top-jtip_height-arrow_size[style]-corr_top_vertical[style];
                            }
                            left = target_left;
                        } else {

                           var space_on_right = browser_width-scrollbar_width-target_left-target_width;

                           if(space_on_right < (parseInt(jtip_width_with_padding)+parseInt(arrow_size[style]))){ // not enough space on the left

                               if(target_top-border_top < jtip_height){ // not enough space on the top
                                   JFBase('.jtip').addClass('bottom-left');
                                   top = target_top+target_height+arrow_size[style]+corr_bottom_vertical[style];
                               } else {
                                   JFBase('.jtip').addClass('top-left');
                                   top = target_top-jtip_height-arrow_size[style]-corr_top_vertical[style];
                               }
                               left = target_left;

                           } else {
                               JFBase('.jtip').addClass('right-center');
                               top = target_top - (jtip_height-target_height) / 2 - corr_center_horizontal[style]; 
                               left = target_left+target_width + arrow_size[style]+corr_right_horizontal[style];  
                           }                        
                        }                   

                    } // end of position 'right-center'                

                    else if(classes.indexOf('right-bottom') > -1){

                        if(is_multilined){ // multilined target
                            if(target_top-border_top < jtip_height){ // not enough space on the top
                                JFBase('.jtip').addClass('bottom-left');
                                top = target_top+arrow_size[style]+corr_bottom_vertical[style]+target_font_size+2;
                                zIndex(target,'destroy');                             
                            } else {
                                JFBase('.jtip').addClass('top-left');
                                top = target_top-jtip_height-arrow_size[style]-corr_top_vertical[style];
                            }
                            left = target_left;
                        } else {

                           var space_on_right = browser_width-scrollbar_width-target_left-target_width;

                           if(space_on_right < (parseInt(jtip_width_with_padding)+parseInt(arrow_size[style]))){ // not enough space on the right

                               if(target_top-border_top < jtip_height){ // not enough space on the top
                                   JFBase('.jtip').addClass('bottom-left');
                                   top = target_top+target_height+arrow_size[style]+corr_bottom_vertical[style];
                               } else {
                                   JFBase('.jtip').addClass('top-left');
                                   top = target_top-jtip_height-arrow_size[style]-corr_top_vertical[style];
                               }
                               left = target_left;

                           } else {
                               JFBase('.jtip').addClass('right-bottom');

                               if(JC.BrowserDetect.browser == 'Explorer' && JC.BrowserDetect.version == '8' && style=='style-1') {
                                   var corr = 10; 
                               } else {
                                   var corr = corr_lr_bottom_vertical[style]; 
                               } 

                               top = target_top + target_font_size/2 - 
                                     JFBase('.jtip').height() + arrow_size[style]/2 + 
                                     parseInt(target.css('padding-top'))-corr;


                               left = target_left+target_width + arrow_size[style]+corr_right_horizontal[style];   
                           }                         
                        }                   
                        operaDomFix(jtip_height,'right-bottom',style, substyle);
                    } // end of position 'right-bottom' 

                    if(class_arr.length > 3){
                        objPos(JFBase('.jtip'), top, left, jtip_width);                     
                    }

                }


                ie8DomFix();      

            }); // end of mouseover                   


            // destroy tooltip
            if(!JC.isTouchable()){
                JFBase(this).live('mouseout', function(e) {
                    var target = JFBase(this);
                    target.attr('title',target_title);// put back the title attribute's value
                    zIndex(target,'destroy');
                    JFBase('head style[title="gen"]').remove();
                    JFBase('body').children('#'+getID(target,2)).remove(); // remove the appended jtip template
                 });        
            } 
        });
        
        
        
            /**
            * init
            */        
            var init = function(){
                JFBase.fn.jcTooltip.setId();
                JFBase.fn.jcTooltip.addSpan();    
                JFBase.fn.jcTooltip.resize();
            }

            init(); // call init immediately        


            // detect changing orientation
            JFBase(window).bind('orientationchange', function(event) {

                orientation_changed = true;
                JFBase('.tooltip').css('background-color','transparent'); // delete all targets' background
                JFBase('.jtip').remove();                                 // hide tooltip (remove from DOM)
                JFBase('head style[title="gen"]').remove();               // delete all dynamic css connected to tooltip

            });
        
            
    }
    
    
    /**
    * add ID attribute to every tooltip element, therefore we can handle tooltips easier
    */
    JFBase.fn.jcTooltip.setId = function(){
        var target = JFBase('.tooltip');
        target.removeAttr('id'); // delete old IDs if needed
        target.each(function(index){
            JFBase(this).attr('id','JFTarget-'+index)
        });
    }
    
    
    /**
    * resize
    */   
    JFBase.fn.jcTooltip.resize = function(){
      
        var win_width = (JC.GRID.isScrollbarVisible()) ? 
                        (JFBase(window).width() + JC.GRID.scrollbarWidth()) : JFBase(window).width();
                        
        JFBase.fn.jcTooltip.win_width = win_width;                                

    }    

    /**
    * remove handlers (un-attach plugin)
    */
    JFBase.fn.jcTooltip.removeHandlers = function(){
        
        if(JC.isTouchable()){
            JFBase('.tooltip').unbind('touchstart');
            JFBase('.tooltip').unbind('touchend');
            JFBase('.tooltip').unbind('touchend');
        } else {
            JFBase('.tooltip').unbind('mouseover');
            JFBase('.tooltip').unbind('mouseleave');
            JFBase('.tooltip').unbind('mousemove');
        }
        
    }
        
})(JFBase);  


/**
* use the plugin
*/
JFBase(document).ready(function() {

    JFBase('.tooltip').jcTooltip();
    
    var resizeTimer;
    
    JFBase(window).resize(function(){
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(JFBase.fn.jcTooltip.resize, 1);
    });   

});           
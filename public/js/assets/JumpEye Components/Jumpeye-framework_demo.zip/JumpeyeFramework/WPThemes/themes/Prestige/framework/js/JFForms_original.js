    (function(JFBase) {
        JFBase.fn.JFforms = function() { }; // define plugin
        
        
        
        // custom selectbox
        // static method, we can call it outside of the plugin as well
        JFBase.fn.JFforms.JFselectBox = function(){
            
            JFBase(".custom-select").css('display','none');   
            
            JFBase(".custom-select").each(function(index){

                var current_select = JFBase(this);
                
                var id = current_select.attr('id');  
                
                var dropdown = JFBase('#'+id);
                
                var custom_select = '<div class="custom-dropdown" id="'+id+'JFElement">'+
                                    '<div class="custom-head">'+
                                    '<span href="#" class="current">'+
                                    JFBase(current_select).children('option:selected').text()+              
                                    '</span>'+
                                    '<span class="selector"><a></a></span>'+
                                    '</div>'+
                                    '<div class="custom-body"><ul>';
                                     
                var option_items = new Array();
                   
                JFBase(current_select).children('option').each(function(){
                    var option_text = JFBase(this).text();
                    var option_value = JFBase(this).attr('value'); // if we want to use it
                    option_items.push('<li>' + option_text + '</li>');
                });
                
                custom_select += option_items.join('') + '</ul></div></div>';                
                
                JFBase(current_select).after(custom_select);    
                
                /*R*/
                var elements = JFBase('li', JFBase('#'+id+'JFElement'))
                elements.on('click', function(){
                    var i = elements.index(this);
                    JFBase('option:selected', dropdown).removeAttr('selected');
                    var e = JFBase('option', '#'+id);
                    JFBase('option:eq('+i+')', dropdown).attr('selected', 'selected');
                    JFBase(this).addClass('selected');
                    JFBase(this).siblings().removeClass('selected');
                    dropdown.change();
                    JFBase('#'+id+'JFElement').find('.custom-head .current').text(JFBase(this).text());
                    JFBase(this).parent().find('li').slideToggle(); // hide LI after selection
                })
                       
            });   
            
           
            // handle click events of selector
            JFBase('.custom-dropdown .custom-head').on('click', function(e) {

                var list_body = JFBase(this).parents('div.custom-dropdown').find('.custom-body'); 
                var this_id = JFBase(this).parent().attr('id');
                
                if(list_body.is(':visible')){
                    
                    JFBase(document).find('div.custom-dropdown:not(#'+this_id+')').find('.custom-body ul li').slideUp();
                    JFBase(document).find('div.custom-dropdown:not(#'+this_id+')').find('.custom-body').css('z-index','2');
                    list_body.css('z-index','9999');
                } 
                                   
                JFBase(this).parents('div.custom-dropdown:eq(0)').find('.custom-body ul li').slideToggle('1000',function(){

                    if(list_body.height()===0){
                        list_body.css('z-index','2');
                    }
                     
                });
            
            }); 
            
        }
          
                    
        // custom radiobutton && custom checkbox
        JFBase.fn.JFforms.JFcheckRadio = function(){
            
            var inputs = JFBase('input'); 
            
        	inputs.each(function(i){	
        		if(JFBase(this).is('[type=checkbox],[type=radio]')){
        		  
                    
        			var input = JFBase(this);
                    
        			// get the associated label using the input's id
        			var label = JFBase('label[for='+input.attr('id')+']');
        			
        			//get type, for classname suffix 
        			var inputType = (input.is('[type=checkbox]')) ? 'checkbox' : 'radio';
        			
        			// wrap the input + label in a div 
        			JFBase('<div class="custom-'+ inputType +'"></div>').insertBefore(input).append(input, label);
        			
        			// find all inputs in this set using the shared name attribute
        			var allInputs = JFBase('input[name='+input.attr('name')+']');
        			
        			// necessary for browsers that don't support the :hover pseudo class on labels
        			label.hover(
        				function(){ 
        					JFBase(this).addClass('hover'); 
        					if(inputType == 'checkbox' && input.is(':checked')){ 
        						JFBase(this).addClass('checkedHover'); 
        					} 
        				},
        				function(){ JFBase(this).removeClass('hover checkedHover'); }
        			);
        			
        			//bind custom event, trigger it, bind click,focus,blur events					
        			input.bind('updateState', function(){	
        				if (input.is(':checked')) {
        					if (input.is(':radio')) {				
        						allInputs.each(function(){
        							JFBase('label[for='+JFBase(this).attr('id')+']').removeClass('checked');
        						});		
        					};
        					label.addClass('checked');
        				}
        				else { label.removeClass('checked checkedHover checkedFocus'); }
        										
        			})
        			.trigger('updateState')
        			.click(function(){ 
        				JFBase(this).trigger('updateState'); 
        			})
        			.focus(function(){ 
        				label.addClass('focus'); 
        				if(inputType == 'checkbox' && input.is(':checked')){ 
        					JFBase(this).addClass('checkedFocus'); 
        				} 
        			})
        			.blur(function(){ label.removeClass('focus checkedFocus'); });
        		}
        	});
            
        }

        // init
        JFBase.fn.JFforms.init = function(){
            
            JFBase.fn.JFforms.JFselectBox();
            JFBase.fn.JFforms.JFcheckRadio();
            JFBase.fn.JFforms.resize();
            JFBase.fn.JFforms.searchbox();  
            
            // close combos if user click everywhere on the site
            JFBase('body').not('.custom-dropdown').on('click', function(e){
                e.stopPropagation();
                JFBase(document).find('.custom-body ul li').slideUp();
            }); 
            
            JFBase('.custom-dropdown').on('click', function(e){
                e.stopPropagation();
            });                         
            
        }

        // fix inputs' width (100% in css)
        JFBase.fn.JFforms.fixWidths = function(){

            var win_width = (JC.GRID.isScrollbarVisible()) ? (JFBase(window).width() + JC.GRID.scrollbarWidth()) : JFBase(window).width();
            
            JFBase('form input, form textarea, form fieldset').each(function(){
                
                var input = JFBase(this);
                if(input.attr('type')=='submit' || input.attr('type')=='button' || input.attr('type')=='reset') return;
                if(!input.parent().hasClass('search-input')){                
                    var pad_left = parseInt(input.css('padding-left'));
                    var pad_right = parseInt(input.css('padding-right'));
                    
                    var cont_pad_left = parseInt(input.parent().css('padding-left'));
                    var cont_pad_right = parseInt(input.parent().css('padding-right'));
                    var bw = parseInt(input.css("border-left-width"));
            
                    var neww = input.parent().innerWidth() - pad_left-pad_right-cont_pad_left-cont_pad_right-bw*2;
                    neww = (win_width<768) ? neww-2 : neww; 
                    input.css('width',neww);    
                    
                }
                                
            });

            // searchboxes
            JFBase('.search-box').each(function(){
                var sbw = JFBase(this).width();
                JFBase(this).find('.search-input').width(sbw-32);    
            });        


            // combos
            JFBase('.custom-dropdown').each(function(){
               JFBase(this).find('.custom-body').css('width',JFBase(this).width()-2); 
            });            
        
        }

                
        // resize
        JFBase.fn.JFforms.resize = function(){
            JFBase.fn.JFforms.fixWidths();
        }
        
        
        // handling searchbox
        JFBase.fn.JFforms.searchbox = function(){
                                      
            // handle disabled search boxes
            // if user omit disabled from input : <input... disabled />            
            JFBase('.search-box.disabled input').attr('disabled','disabled');
            
            // handle focus event
            JFBase('input[type=text],input[type=search]').on('focus', function(){
               if(JFBase(this).parent().hasClass('search-input')){
                   JFBase(this).parent().siblings('div').addClass('border');
               } 
            }); 
            JFBase('input[type=text],input[type=search]').on('blur', function(){
               if(JFBase(this).parent().hasClass('search-input')){
                   JFBase(this).parent().siblings('div').removeClass('border');
               } 
            });                 
        }   
            
    })( JFBase );
    
    
	// use plugin    
	JFBase(function(){

	    JFBase.fn.JFforms.init();
        
        var resizeTimer;
   
        JFBase(window).resize(function() { // handle window resize events
           clearTimeout(resizeTimer);
           resizeTimer = setTimeout(JFBase.fn.JFforms.resize,1);
        });       
       
	});    
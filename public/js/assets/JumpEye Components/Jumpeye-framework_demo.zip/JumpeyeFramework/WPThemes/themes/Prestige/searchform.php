<?php
/**
 * The template for displaying search forms
 *
 * @package Prestige
 * @since Prestige 1.0
 */
?>
	<form method="get" id="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>" role="search">
		<div class="search-box">
			<div class="search-input">
				<input name="s" value="<?php echo esc_attr( get_search_query() ); ?>" id="s" placeholder="<?php esc_attr_e( 'Search...', 'prestige' ); ?>" type="text" />
			</div>
			<div class="search-icon background_scheme"><a><input type="submit" name="submit" id="searchsubmit" value="" /></a></div>
		</div>
	</form>
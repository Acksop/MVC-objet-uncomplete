/**
 * Theme Name: Prestige
 * Theme URI: http://www.jumpeye.com/
 * File: admin.js
 *
 * @package Prestige
 * @since Prestige 1.0 
 */
jQuery(document).ready(function($){
    var form_table = $('div.wrap.jf_opt_wrapper table.form-table');
    form_table.find('tr').each(function(){
       var d = $(this).find('th > p.adm_description'); 
       $('<tr class="description"><td colspan="2" style="padding-left: 0;">'+d.html()+'</td></tr>').insertAfter(this);
       $(this).find('tr.description > td').css({'paddingLeft':'0'});
       $(this).find('th > p.adm_description').remove();
    });
    
    // hide menu of Theme plugins in first empty li element
    $("li.wp-submenu-head:contains('Jumpeye plugins') + li").css("display","none");
    
    // Metabox Handler for Page Templates
	var template_select = $('select#page_template'),
		template_box    = $('#prestige_tpl_meta');
        
  template_select.live('change',function(){
      var selected_value = jQuery(this).val();
      $('.prestige_tpl_options_info').css('display','none');
      
      
      switch(selected_value){
          case 'page-templates/blog.php' :
          case 'page-templates/content.php' :
               $('.prestige_tpl_options').css('display','block');
               break;
          case 'default' :
          default : 
               $('.prestige_tpl_options_info').css('display','block');
               $('.prestige_tpl_options').css('display','none');    
      }
        
  });
});  
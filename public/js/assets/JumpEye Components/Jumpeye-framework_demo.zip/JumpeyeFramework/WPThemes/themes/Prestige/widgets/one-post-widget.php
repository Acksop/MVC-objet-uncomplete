<?php
/*
    Plugin Name: JF One Post Widget
    Plugin URI: http://www.jumpeye.com
    Description: Displays one selected post in detail.
    Version: 1.0
    Author: Jumpeye Components
    Author URI: http://www.jumpeye.com
    License: GPL2
*/

// register JFOnePostWidget widget
add_action('widgets_init', create_function('', 'return register_widget("JFOnePostWidget");')); 

/**
 * Adds JFOnePostWidget widget.
 */
class JFOnePostWidget extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	public function __construct() {
        
		parent::__construct(
	 		'JFOnePostWidget', // Base ID
			'JF One Post Widget', // Name (you will see it in Available Widgets)
			array( 'description' => __( 'Displays one selected post in detail.', 'prestige' ),) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	public function widget( $args, $instance ) {
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );

        /* Custom Options */
        // Our options from the widget settings.
        $post_title     = (isset($instance['post_title'])) ? (int) $instance['post_title'] : false ;
        $excerpt        = (isset($instance['excerpt'])) ? $instance['excerpt'] : false ;
        $excerpt_length = (isset($instance['excerpt'])) ? (int)($instance['excerpt_length']) : 0;
        $post_id        = (isset($instance['post_id'])) ? (int)($instance['post_id']) : 0;
        $post           = get_post($post_id);
        $thumbnail      = (isset($instance['thumbnail'])) ? $instance['thumbnail'] : false ;

        $id = $post->ID;
        $permalink = get_permalink($id);   
                
        // Before widget - as defined in your specific theme.
		echo $before_widget;
        
        echo '<div class="one_post_widget grid_18 columns">';
        
        if ( ! empty( $title ) ){
	        echo $before_title .'<h4 class="post_title">'. $title . '</h4>'.$after_title;
        }        

	    if ($post_title == 1) {
		    echo '<h4 class="post_title"><a href="'.$permalink.'">'.$post->post_title.'</a></h4>';
		}    
        
        if (has_post_thumbnail($post->ID) && $thumbnail == 1) { ?>
					<div class="row">
						<div class="grid_18 columns">
                        <a href="<?php echo $permalink; ?>">            
    					<?php
                            echo get_the_post_thumbnail($post->ID);
    					?></a>
                    <table class="table_of_shadows" border="0" cellpadding="0" cellspacing="0" style="width:  100%; margin-top: 0px">
                        <tr>
                            <td class="meta_left"></td>
                            <td class="meta_center">&nbsp;</td>
                            <td class="meta_right"></td>
                        </tr>
                    </table>   
                </div></div>
			<?php }      
        
        if ($excerpt == true) {
            echo '<div class="row">
						<div class="grid_18 columns"><p class="excerpt">'.$this->getExcerpt($post->post_content, $excerpt_length, $permalink).'</p></div></div>';
        }          
        echo '</div>';

        /* After widget - as defined in your specific theme. */
		echo $after_widget;
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) {
        
        global $post;
        
        $args = array( 'posts_per_page' => 50 );
        
        $posts = get_posts( $args );  
        if(count($posts) == 0){
            echo '<p>No available posts.</p>';
            return;
        } 
        
        $posts_array = array();

        /* Default Widget Settings */
    		
    	$defaults = array(
    		'title'          => '',
            'post_title'     => true,
            'excerpt'        => true,
            'excerpt_length' => 50,
            'post_id'        => 0, // "Choose a post" option
            'thumbnail'      => true,
    	); 

        $instance       = wp_parse_args( (array) $instance, $defaults );   
        $title          = esc_attr( $instance['title'] );
        $post_title     =  $instance['post_title'];
        $excerpt        =  $instance['excerpt'];
        $excerpt_length =  $instance['excerpt_length'];
        $post_id        =  $instance['post_id'];
        $thumbnail      =  $instance['thumbnail'];

        ?>
		<p>
    		<label for="<?php echo $this->get_field_name( 'title' ); ?>"><?php _e( 'Title:', 'prestige' ); ?></label> 
    		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo $title; ?>" />
		</p>        
        <p>
            <label for="<?php echo $this->get_field_name( 'post_id' ); ?>"><?php _e( 'Select a post:', 'prestige' ); ?></label> 
            <select class="widefat" name="<?php echo $this->get_field_name('post_id'); ?>" id="<?php echo $this->get_field_id('post_id'); ?>">
            <?php
                foreach($posts as $post){
                    setup_postdata($post);
            ?>
                    <option <?php selected($post_id, get_the_ID()) ?> value="<?php echo get_the_ID(); ?>"><?php echo get_the_title(); ?></option>
            <?php
                }         
            ?>    
            </select>
        </p>
   		<p>
			<input id="<?php echo $this->get_field_id('post_title'); ?>" name="<?php echo $this->get_field_name('post_title'); ?>" type="checkbox" value="1" <?php checked('1', $post_title); ?> />&nbsp;
            <label for="<?php echo esc_attr($this->get_field_id('post_title')); ?>"><?php _e('Display post title?', 'prestige'); ?></label>
		</p> 
   		<p>
			<input id="<?php echo $this->get_field_id('excerpt'); ?>" name="<?php echo $this->get_field_name('excerpt'); ?>" type="checkbox" value="1" <?php checked('1', $excerpt); ?> />&nbsp;
            <label for="<?php echo esc_attr($this->get_field_id('excerpt')); ?>"><?php _e('Display post excerpt?', 'prestige'); ?></label>
		</p>   
		<p>
    		<label for="<?php echo $this->get_field_name( 'excerpt_length' ); ?>"><?php _e( 'Lenght of excerpt:', 'prestige' ); ?></label> 
    		<input class="widefat" id="<?php echo $this->get_field_id( 'excerpt_length' ); ?>" name="<?php echo $this->get_field_name( 'excerpt_length' ); ?>" type="text" value="<?php echo $excerpt_length; ?>" />
		</p>
   		<p>
			<input id="<?php echo $this->get_field_id('thumbnail'); ?>" name="<?php echo $this->get_field_name('thumbnail'); ?>" type="checkbox" value="1" <?php checked('1', $thumbnail); ?> />&nbsp;
            <label for="<?php echo esc_attr($this->get_field_id('thumbnail')); ?>"><?php _e('Display post featured image?', 'prestige'); ?></label>
		</p>         
		<?php 
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance                   = array();
		$instance['title']          = ( !empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
        $instance['post_title']     = $new_instance['post_title'];
        $instance['excerpt']        = $new_instance['excerpt'];
        $instance['excerpt_length'] = (int)($new_instance['excerpt_length']);
        $instance['post_id']        = $new_instance['post_id'];
        $instance['thumbnail']      = $new_instance['thumbnail'];
		return $instance;
	}

    /**
     * set length of excerpt
     */ 
    private function getExcerpt($_excerpt, $_length, $_url){
    	$excerpt = explode(' ', $_excerpt, $_length);
    	if (count($excerpt) >= $_length) {
    		array_pop($excerpt);
    		$excerpt = implode(" ", $excerpt) . ' &hellip;<p class="read_more"><a href="'.$_url.'" target="_self">read more ...</a></p>';
    	} else {
    		$excerpt = implode(" ", $excerpt);
    	}
    	$excerpt = preg_replace('`\[[^\]]*\]`', '', $excerpt);
    
    	return $excerpt;
    }   
    
} // class JFOnePostWidget


?>
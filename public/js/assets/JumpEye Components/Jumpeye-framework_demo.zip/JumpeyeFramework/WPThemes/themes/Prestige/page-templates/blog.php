<?php
/*
 * Template Name: Blog Template
 *
 * In the default layout Sidebar is on the right
 *
 * @package Prestige
 * @since Prestige 1.0
 */

get_header();

$is_fullwidth = get_post_meta( get_the_ID(), 'is_fullwidth' );
$sidebar_position = get_post_meta( get_the_ID(), 'sidebar_position' );
$grid_cols = ($is_fullwidth[0]=='on') ? '18' : '12';
?>
    <div class="row margin_top_30">
       <?php 
           if( $is_fullwidth[0]=='off' && $sidebar_position[0] == 'left' ) get_sidebar();
       ?>     
		<div id="primary" class="content-area columns grid_<?php echo $grid_cols; ?>">
            <?php
                $post_per_page = get_option('posts_per_page'); 
                query_posts('post_type=post&post_status=publish&posts_per_page='.$post_per_page.'&paged='. get_query_var('paged'));
             
                if( have_posts() ): 
                    $count_posts = wp_count_posts('post'); 
                    $published_posts = $count_posts->publish;
                    if($published_posts > $post_per_page) :
                        JF_Frontend::getNavigation();
                    endif;
                    
                    while( have_posts() ): the_post(); ?>
             
                  <div class="post" id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                      <div class="thumbnail_holder">
                      <?php if ( has_post_thumbnail()) : ?>
                          <a href="<?php the_permalink(); ?>"><div class="post_thumbnail">
                          <?php the_post_thumbnail(); ?>
                          </div>
                          </a>  
                          <div class="post_meta_data"><p>By <?php the_author(); ?> on <?php echo get_the_date('M j, Y'); ?> in <span class="post_category"><?php the_category(', '); ?></span> | <span class="post_comments"><?php comments_popup_link(__('0 comments','prestige'),__('1 comment','prestige'),__('% comments','prestige')); ?></span></p></div>
                      <?php else: ?>     
                          <div class="post_meta_data_no_thumb">By <?php the_author(); ?> on <?php echo get_the_date('M j, Y'); ?> in <span class="post_category"><?php the_category(', '); ?></span> | <span class="post_comments"><?php comments_popup_link(__('0 comments','prestige'),__('1 comment','prestige'),__('% comments','prestige')); ?></span></div>           
                      <?php endif; ?>
                      </div>
                      <h2 class="post_title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                      <p class="post_excerpt">
                          <?php 
                            echo do_shortcode(get_the_excerpt());
                          ?>
                      </p>
                      <p class="post_read_more"><a class="read_more" href="<?php the_permalink(); ?>"><?php _e('read more ...','prestige'); ?></a></p>
                  </div>
                    <table class="table_of_shadows" border="0" cellpadding="0" cellspacing="0" style="width:  100%; margin-top: -1px">
                        <tr>
                            <td class="post_left"></td>
                            <td class="post_center">&nbsp;</td>
                            <td class="post_right"></td>
                        </tr>
                    </table>                   
             
                  <?php 
                   endwhile; 
                   
                   if($published_posts > $post_per_page) : 
                       JF_Frontend::getNavigation('bottom');
                   endif;
                   else: 
                  ?>
             
                <div id="post-404" class="noposts">
             
                    <p><?php _e('No posts.','prestige'); ?></p>
             
                  </div><!-- /#post-404 -->
             
              <?php endif; wp_reset_query(); ?>

		</div><!-- #primary .content-area .columns .grid_<?php echo $grid_cols; ?> -->
       <?php 
           if( $is_fullwidth[0]=='off' && $sidebar_position[0] == 'right' ) get_sidebar();
            
       ?> 
    </div><!-- .row -->
<?php get_footer(); ?>
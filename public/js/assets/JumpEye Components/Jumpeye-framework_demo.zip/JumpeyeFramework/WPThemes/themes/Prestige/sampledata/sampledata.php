<?php

/**
 * Sampledata for WordPress
 * 
 * @package Prestige
 * @since Prestige 1.0
 */

define('SAMPLE_DATA_SHORT','Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nam cursus. Morbi ut mi. Nullam enim leo, egestas id, condimentum at, laoreet mattis, massa. Sed eleifend nonummy diam. Praesent mauris ante, elementum et, bibendum at, posuere sit amet, nibh. Duis tincidunt lectus quis dui viverra vestibulum.');
define('SAMPLE_URL','http://www.jumeye.com');
define('SAMPLE_FILES', get_template_directory_uri().'/sampledata/');

class SampleData{

    /**
     * Get Cover
     */
    private static function getCover(){
    ?>
        <div class="cover" style="width: 100%;"></div>
        <div class="circle background_scheme"></div>
        <a class="navigator" href="#"></a>
    <?php    
    }      


    /**
     * Get Shadow 
     * @param $_type
     */
    private static function getShadow($_type = 'img'){
        switch($_type){
            case 'img' : 
            case 'post'  : 
            default      : $type = $_type;
            break;
            
        }    
    ?>
        <table class="table_of_shadows" border="0" cellpadding="0" cellspacing="0" style="width:  100%; margin-top: 0px !important;">
            <tr>
                <td class="<?php echo $type; ?>_left"></td>
                <td class="<?php echo $type; ?>_center">&nbsp;</td>
                <td class="<?php echo $type; ?>_right"></td>
            </tr>
        </table>     
    <?php        
    }     
    
    /** Services TPL : bottom post */
    public static function getSampleServicesBottom(){
    ?>
        <div class="row" style="margin-top: 55px;">
            <div class="columns grid_18 one_post_widget">
                <div class="row">
                    <div class="columns grid_18">    
                        <div>
                            <a href="#"><img class="" alt="" title="" src="<?php echo SAMPLE_FILES; ?>/images/post_image.jpg" style="display: block;" /></a>
                        </div>
                    </div>
                    <?php self::getShadow('post'); ?>
                </div>
                
                <div class="row margin_top_10" style="line-height: 28px;"><div class="grid_18 columns"><p class="excerpt">Morbi vulputate feugiat nibh. Mauris urna quam, adipiscing ultrices ornare sit amet, fermentum at sem. Cras id purus vitae sem mattis hendrerit. Nam felis neque, sodales vel dapibus a, tristique a risus. Cras quis ipsum at sapien bibendum accumsan. Suspendisse ornare tortor rhoncus felis iaculis, eu egestas nisi eleifend. Ut id eros eu enim.</p></div></div>
                <div class="row margin_top_10" style="line-height: 28px;">
                    <div class="grid_18 columns">
                        <p class="read_more">
                            <a class="color_scheme" target="_self" href="#">read more ...</a>
                        </p>             
                    </div>
                </div>
            </div>
        </div>
    <?php    
    }
    
    /** Services TPL : highlighed posts */
    public static function getSampleServicesHighlights(){
    ?>
        <div class="row services_widget">
            <div class="columns grid_6">
                <h4 class="post_title_em featured"><a href="#">Post title</a></h4> 
                <p class="excerpt">Fusce pretium, leo sed cursus vulputate, est dui ultricies lacus, a ullamcorper metus nulla eget felis. Etiam non leo risus. Ut at iaculis dolor, sed hendrerit lectus. Nulla auctor pellentesque imperdiet. Donec condimentum, augue a vehicula vehicula, risus est aliquam massa, et tincidunt odio justo orci odio.</p> 
                <p class="read_more" style="margin-bottom: 25px;">
                    <a class="color_scheme" target="_self" href="#">read more ...</a>
                </p>                         
                <div class="">
                    <p class="read_more" style="margin: 0 0 5px 0;"><a class="color_scheme" target="_self" href="#" style="font-weight: bold; font-size: 19px;">Post title</a></p>
                    <p class="read_more" style="margin: 0 0 5px 0;"><a class="color_scheme" target="_self" href="#" style="font-weight: bold; font-size: 19px;">Post title</a></p>
                    <p class="read_more" style="margin: 0 0 5px 0;"><a class="color_scheme" target="_self" href="#" style="font-weight: bold; font-size: 19px;">Post title</a></p>
                    <p class="read_more" style="margin: 0 0 5px 0;"><a class="color_scheme" target="_self" href="#" style="font-weight: bold; font-size: 19px;">Post title</a></p>
                    <p class="read_more" style="margin: 0 0 5px 0;"><a class="color_scheme" target="_self" href="#" style="font-weight: bold; font-size: 19px;">Post title</a></p>
                    <p class="read_more" style="margin: 0 0 5px 0;"><a class="color_scheme" target="_self" href="#" style="font-weight: bold; font-size: 19px;">Post title</a></p>
                    <p class="read_more" style="margin: 0 0 5px 0;"><a class="color_scheme" target="_self" href="#" style="font-weight: bold; font-size: 19px;">Post title</a></p>
                    <p class="read_more" style="margin: 0 0 5px 0;"><a class="color_scheme" target="_self" href="#" style="font-weight: bold; font-size: 19px;">Post title</a></p>
                    <p class="read_more" style="margin: 0 0 5px 0;"><a class="color_scheme" target="_self" href="#" style="font-weight: bold; font-size: 19px;">Post title</a></p>
                </div>
            </div>
            <div class="columns grid_6">
                <h4 class="post_title_em featured"><a href="#">Post title</a></h4>
                <p class="excerpt">Fusce pretium, leo sed cursus vulputate, est dui ultricies lacus, a ullamcorper metus nulla eget felis. Etiam non leo risus. Ut at iaculis dolor, sed hendrerit lectus. Nulla auctor pellentesque imperdiet. Donec condimentum, augue a vehicula vehicula, risus est aliquam massa, et tincidunt odio justo orci odio.</p> 
                <p class="read_more" style="margin-bottom: 25px;">
                    <a class="color_scheme" target="_self" href="#">read more ...</a>
                </p>                         
                <div class="">
                    <p class="read_more" style="margin: 0 0 5px 0;"><a class="color_scheme" target="_self" href="#" style="font-weight: bold; font-size: 19px;">Post title</a></p>
                    <p class="read_more" style="margin: 0 0 5px 0;"><a class="color_scheme" target="_self" href="#" style="font-weight: bold; font-size: 19px;">Post title</a></p>
                    <p class="read_more" style="margin: 0 0 5px 0;"><a class="color_scheme" target="_self" href="#" style="font-weight: bold; font-size: 19px;">Post title</a></p>
                    <p class="read_more" style="margin: 0 0 5px 0;"><a class="color_scheme" target="_self" href="#" style="font-weight: bold; font-size: 19px;">Post title</a></p>
                    <p class="read_more" style="margin: 0 0 5px 0;"><a class="color_scheme" target="_self" href="#" style="font-weight: bold; font-size: 19px;">Post title</a></p>
                    <p class="read_more" style="margin: 0 0 5px 0;"><a class="color_scheme" target="_self" href="#" style="font-weight: bold; font-size: 19px;">Post title</a></p>
                    <p class="read_more" style="margin: 0 0 5px 0;"><a class="color_scheme" target="_self" href="#" style="font-weight: bold; font-size: 19px;">Post title</a></p>
                    <p class="read_more" style="margin: 0 0 5px 0;"><a class="color_scheme" target="_self" href="#" style="font-weight: bold; font-size: 19px;">Post title</a></p>
                    <p class="read_more" style="margin: 0 0 5px 0;"><a class="color_scheme" target="_self" href="#" style="font-weight: bold; font-size: 19px;">Post title</a></p>
                </div>
            </div> 
            <div class="columns grid_6">
                <h4 class="post_title_em featured"><a href="#">Post title</a></h4>
                <p class="excerpt">Fusce pretium, leo sed cursus vulputate, est dui ultricies lacus, a ullamcorper metus nulla eget felis. Etiam non leo risus. Ut at iaculis dolor, sed hendrerit lectus. Nulla auctor pellentesque imperdiet. Donec condimentum, augue a vehicula vehicula, risus est aliquam massa, et tincidunt odio justo orci odio.</p> 
                <p class="read_more" style="margin-bottom: 25px;">
                    <a class="color_scheme" target="_self" href="#">read more ...</a>
                </p>                         
                <div class="">
                    <p class="read_more" style="margin: 0 0 5px 0;"><a class="color_scheme" target="_self" href="#" style="font-weight: bold; font-size: 19px;">Post title</a></p>
                    <p class="read_more" style="margin: 0 0 5px 0;"><a class="color_scheme" target="_self" href="#" style="font-weight: bold; font-size: 19px;">Post title</a></p>
                    <p class="read_more" style="margin: 0 0 5px 0;"><a class="color_scheme" target="_self" href="#" style="font-weight: bold; font-size: 19px;">Post title</a></p>
                    <p class="read_more" style="margin: 0 0 5px 0;"><a class="color_scheme" target="_self" href="#" style="font-weight: bold; font-size: 19px;">Post title</a></p>
                    <p class="read_more" style="margin: 0 0 5px 0;"><a class="color_scheme" target="_self" href="#" style="font-weight: bold; font-size: 19px;">Post title</a></p>
                    <p class="read_more" style="margin: 0 0 5px 0;"><a class="color_scheme" target="_self" href="#" style="font-weight: bold; font-size: 19px;">Post title</a></p>
                    <p class="read_more" style="margin: 0 0 5px 0;"><a class="color_scheme" target="_self" href="#" style="font-weight: bold; font-size: 19px;">Post title</a></p>
                    <p class="read_more" style="margin: 0 0 5px 0;"><a class="color_scheme" target="_self" href="#" style="font-weight: bold; font-size: 19px;">Post title</a></p>
                    <p class="read_more" style="margin: 0 0 5px 0;"><a class="color_scheme" target="_self" href="#" style="font-weight: bold; font-size: 19px;">Post title</a></p>
                </div>
            </div>                    
        </div>    
    <?php    
    }    
        
    /** Get Contact Sample Secondary Sidebar */ 
    public static function getContactSecondarySidebar(){
        ?>
        <div class="row"><div class="grid_18 columns"><h2 class="title color_scheme" style="padding-top: 0; margin-top: 0"><?php _e('Secondary sidebar','prestige'); ?></h2></div></div>
        <div class="row" style="line-height: 26px; font-size: 15px; margin-top: 2px;">
            <div class="grid_18 columns">
            <?php _e('Add some widgets to the Secondary sidebar widget holder in order to display any content here.','prestige')?>
            </div>
        </div>
        <?php    
    }    
    
    /** Get Sample Contact Form */
    public static function getSampleContactForm(){
        ?>
        <div class="row"><div class="grid_18 columns"><h2 class="title color_scheme" style="padding-top: 0; margin-top: 0"><?php _e('Contact form','prestige'); ?></h2></div></div>
        <div class="row" style="margin-top:  8px; margin-bottom: 8px">
            <div class="grid_18 columns">
            <img class="" alt="" title="" src="<?php echo SAMPLE_FILES; ?>/images/contact_form.jpg" style="display: block;" />
            </div>
            <?php self::getShadow('post'); ?>
        </div>
        <?php
                 
    }      
      
    /** Get Sample Contact Info */
    public static function getSampleContactInfo(){
        ?>
        <div class="row"><div class="grid_18 columns"><h2 class="title color_scheme" style="margin-top: 0px; margin-bottom:  14px;"><?php _e('Contact information','prestige'); ?></h2></div></div>
        <div class="row">
            <div class="grid_18 columns">
            <img class="" alt="" title="" src="<?php echo SAMPLE_FILES; ?>/images/contact_info.jpg" style="display: block;" />
            </div>
        </div>
        <?php 
        self::getShadow('post');      
    }     
    
    /** Get sample map on Contact page */
    public static function getContactMap(){
    ?>
        <!-- map -->
        <div class="row map_top_text"><div class="grid_18 columns"><h2 class="title color_scheme"><?php _e('Map','prestige'); ?></h2></div></div>
        <div class="row margin_top_10">
            <div class="columns grid_18">    
                <div id="contact_map">
                    <!--<iframe width="100%" height="400" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=34+8th+Avenue,+Manhattan,+New+York+City,+New+York+10014,+United+States&amp;aq=0&amp;oq=34+8th+Avenue,+Manhattan,+New+York,+New+York+(NY)+10014&amp;sll=37.0625,-95.677068&amp;sspn=54.401733,87.275391&amp;ie=UTF8&amp;hq=&amp;hnear=34+8th+Ave,+New+York,+10014&amp;ll=40.73789,-74.004085&amp;spn=0.111085,0.264187&amp;t=m&amp;z=13&amp;output=embed"></iframe>-->
                    <img class="" alt="" title="" src="<?php echo SAMPLE_FILES; ?>/images/map.jpg" style="display: block;" />
                </div>
            </div>
            <?php self::getShadow('post'); ?>
        </div><!-- end of map -->
        
        <div class="row map_bottom_text margin_top_10 margin_bottom_30" style="line-height: 28px;"><div class="grid_18 columns">Morbi semper tempor risus sed adipiscing. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Aliquam placerat congue hendrerit. Quisque mollis dui ac justo posuere imperdiet. Suspendisse potenti.</div></div>
    <?php    
    }
         
    /**
     * Create an empty footer widget skeleton
     * @param $_title : widget title
     * @param $_text : widget default text
     */
    public static function getEmptyFooterWidget($_num){
        ?>
        <li class="widget">
            <h2 class="widgettitle"><?php _e('Widget title','prestige'); ?></h2>
            <ul>
                <li><?php echo esc_attr( sprintf( __( 'Go to Appearance -> Widgets and set a widget for the Footer Area %s.', 'prestige' ), $_num ) ); ?></li>
            </ul>
        </li>
        <?php    
    }
       
    /**
     * Create a sample HomeSlider 
     */
    public static function getSampleHomeSlider(){
        ?>
        <div id="homeSliderContainer">
            <div class="row">    
                <div class="grid_18 columns">        
        <?php
        if(JF_Dashboard::isPluginActive('JF-Slider')) :
        ?>

            		<div id="homeSlider">
            			<div name="jf-slider_content" style="display: none">
                            <div name="jf-slide">
                                <div name="jf-type">image</div>
                                <div name="jf-title">Image title</div>
                                <div name="jf-description">Description for the image</div>
                                <div name="jf-content"><?php echo SAMPLE_FILES; ?>images/slides/slide1.jpg</div>
                                <div name="jf-target_url"><?php echo SAMPLE_URL; ?></div>
                                <div name="jf-target_window">_blank</div>
                            </div>
                            <div name="jf-slide">
                                <div name="jf-type">image</div>
                                <div name="jf-title">Image title</div>
                                <div name="jf-description">Description for the image</div>
                                <div name="jf-content"><?php echo SAMPLE_FILES; ?>images/slides/slide2.jpg</div>
                                <div name="jf-target_url"><?php echo SAMPLE_URL; ?></div>
                                <div name="jf-target_window">_blank</div>
                            </div> 
                            <div name="jf-slide">
                                <div name="jf-type">image</div>
                                <div name="jf-title">Image title</div>
                                <div name="jf-description">Description for the image</div>
                                <div name="jf-content"><?php echo SAMPLE_FILES; ?>images/slides/slide3.jpg</div>
                                <div name="jf-target_url"><?php echo SAMPLE_URL; ?></div>
                                <div name="jf-target_window">_blank</div>
                            </div>
                            <div name="jf-slide">
                                <div name="jf-type">image</div>
                                <div name="jf-title">Image title</div>
                                <div name="jf-description">Description for the image</div>
                                <div name="jf-content"><?php echo SAMPLE_FILES; ?>images/slides/slide4.jpg</div>
                                <div name="jf-target_url"><?php echo SAMPLE_URL; ?></div>
                                <div name="jf-target_window">_blank</div>
                            </div>                                                                                                                                   
                        </div>
                    </div>
                    <table class="table_of_shadows" border="0" cellpadding="0" cellspacing="0" style="width:  100%; margin-top: 0px">
                        <tr>
                            <td class="post_left"></td>
                            <td class="post_center">&nbsp;</td>
                            <td class="post_right"></td>
                        </tr>
                    </table>                    
                </div>
            </div>  
        </div>                    
        <script type="text/javascript">
            JFBase.JFBlurrySlider.init({
            appendToID: 'homeSlider',
            maxWidth: 922,
            maxHeight: 358,
            imageScaleMode: 'scaleCrop',
            loopContent: false,
            animationType: 'fade',
            animationDuration: 0.3,
            autoSlideshow: false,
            slideshowSpeed: 6,
            pauseOnMouseOver: false,
            startIndex: 0,
            captionAlignment: 'left',
            captionColor: '#FFFFFF',
            autoHideControls: false,
            autoHideDelay: 3,
            disableAutohideOnMouseOver: false,
            showTimer: 1,
            showControlBar: 1,
            showNavButtons: 1
            });         
        </script>          
        <?php 
        else:
        ?>
                    <p class="error" style="margin-top: 32px;">The JF-Slider plugin is not activated. Go to Dashboard \ Plugins \ Installed plugins and activate it first.</p>
                </div>
            </div>  
        </div>          
        <?php
        endif;   
    }
       
           
    /**
     * Create a one post sample widget
     */
    public static function getSampleOnePostWidget(){
        ?>
        <div class="one_post_widget">
            <h4 class="post_title"><a href="#">Welcome title</a></h4>
            <p class="excerpt"><?php echo SAMPLE_DATA_SHORT; ?></p>
            <p class="read_more">
                <a class="color_scheme" target="_self" href="#">read more ...</a>
            </p>  
        </div>      
        <?php    
    } 
    
    /** 
     * Get Sample Footer Contact form
     */
    public static function getSampleFooterContact(){
    ?>
        <li class="widget">
            <h2 class="widgettitle">Sample contact</h2>
            <ul>
                <li>    
        <form id="jf_footer_contact_form" class="style-1" style="margin:0;" method="post" action="">
            <input type="hidden" name="jf_fc_recipient" id="jf_fc_recipient" value="<?php echo $email; ?>" />
            <input type="text" placeholder="Name" name="jf_fc_sender_name" id="jf_fc_sender_name" />
            <input type="text" placeholder="Email" name="jf_fc_sender_email" id="jf_fc_sender_email"  />
            <textarea placeholder="Message" name="jf_fc_msg" id="jf_fc_msg" cols="70" rows="40"></textarea>
            <input class="background_scheme" type="button" name="jf_fc_submit" id="jf_fc_submit" value="Send message" onclick="_aSendMessage('');" />
        </form> 
        </li>
        </ul>
        </li>   
    <?php    
    }    
      
    /**
     * Get Sample projects
     */
    public static function getSampleProjects(){
        ?>
        <div class="row content_widget">
            <div class="grid_18 columns">
                <h2 class="widget_title color_scheme" style="margin-top:  0;">Recent Projects</h2>
            </div>
        </div>
        <div class="row content_widget">
            <div class="columns grid_6">
                <div class="row">
                    <div class="grid_18 columns">
                        <div class="sample_project_img_holder">
                            <div class="sample image_wrapper">
                                <a href="#">
                                    <img class="attachment-post-thumbnail wp-post-image" alt="" title="" src="<?php echo SAMPLE_FILES; ?>/images/project_image.jpg" style="display: block;" />
                                </a>    
                                <?php self::getCover(); ?>   
                            </div>  
                            <?php self::getShadow(); ?>   
                        </div>
                    </div>
                </div> 
            </div>
            <div class="columns grid_6">
                <div class="row">
                    <div class="grid_18 columns">
                        <div class="sample_project_img_holder">
                            <div class="sample image_wrapper">
                                <a href="#">
                                    <img class="attachment-post-thumbnail wp-post-image" alt="" title="" src="<?php echo SAMPLE_FILES; ?>/images/project_image.jpg" style="display: block;" />
                                </a>    
                                <?php self::getCover(); ?>   
                            </div>  
                            <?php self::getShadow(); ?>   
                        </div>
                    </div>
                </div> 
            </div>
            <div class="columns grid_6">
                <div class="row">
                    <div class="grid_18 columns">
                        <div class="sample_project_img_holder">
                            <div class="sample image_wrapper">
                                <a href="#">
                                    <img class="sample attachment-post-thumbnail wp-post-image" alt="" title="" src="<?php echo SAMPLE_FILES; ?>/images/project_image.jpg" style="display: block;" />
                                </a>    
                                <?php self::getCover(); ?>   
                            </div>  
                            <?php self::getShadow(); ?>   
                        </div>
                    </div>
                </div> 
            </div>                   
        </div>
        <?php    
    } 
       
       
    /**
     * Get Sample Category Posts
     */
    public static function getSampleCategoryPosts(){
        ?>
        <div class="row content_widget sample">
            <div class="columns grid_6">
                <h4 class="post_title featured" style="color: #555 !important;"><a href="#">Box title</a></h4>
                <p class="excerpt">Fusce pretium, leo sed cursus vulputate, est dui ultricies lacus, a ullamcorper metus nulla eget felis. Etiam non leo risus. Ut at iaculis dolor, sed hendrerit lectus. Nulla auctor pellentesque imperdiet. Donec condimentum, augue a vehicula vehicula, risus est aliquam massa, et tincidunt odio justo orci odio.</p> 
                <p class="read_more">
                    <a class="color_scheme" target="_self" href="#">read more ...</a>
                </p>                         
                <div class="sample_project_img_holder">
                    <div class="sample image_wrapper">
                        <a href="#">
                            <img class="sample attachment-post-thumbnail wp-post-image" alt="" title="" src="<?php echo SAMPLE_FILES; ?>/images/box_image.jpg" style="display: block;" />
                        </a>    
                        <?php self::getCover(); ?>   
                    </div>  
                    <?php self::getShadow(); ?>   
                </div>
            </div>
            <div class="columns grid_6">
                <h4 class="post_title featured" style="color: #555 !important;"><a href="#">Box title</a></h4>
                <p class="excerpt">Fusce pretium, leo sed cursus vulputate, est dui ultricies lacus, a ullamcorper metus nulla eget felis. Etiam non leo risus. Ut at iaculis dolor, sed hendrerit lectus. Nulla auctor pellentesque imperdiet. Donec condimentum, augue a vehicula vehicula, risus est aliquam massa, et tincidunt odio justo orci odio.</p> 
                <p class="read_more">
                    <a class="color_scheme" target="_self" href="#">read more ...</a>
                </p>                         
                <div class="sample_project_img_holder">
                    <div class="sample image_wrapper">
                        <a href="#">
                            <img class="sample attachment-post-thumbnail wp-post-image" alt="" title="" src="<?php echo SAMPLE_FILES; ?>/images/box_image.jpg" style="display: block;" />
                        </a>    
                        <?php self::getCover(); ?>   
                    </div>  
                    <?php self::getShadow(); ?>   
                </div>
            </div> 
            <div class="columns grid_6">
                <h4 class="post_title featured" style="color: #555 !important;"><a href="#">Box title</a></h4> 
                <p class="excerpt">Fusce pretium, leo sed cursus vulputate, est dui ultricies lacus, a ullamcorper metus nulla eget felis. Etiam non leo risus. Ut at iaculis dolor, sed hendrerit lectus. Nulla auctor pellentesque imperdiet. Donec condimentum, augue a vehicula vehicula, risus est aliquam massa, et tincidunt odio justo orci odio.</p> 
                <p class="read_more">
                    <a class="color_scheme" target="_self" href="#">read more ...</a>
                </p>                         
                <div class="sample_project_img_holder">
                    <div class="sample image_wrapper">
                        <a href="#">
                            <img class="sample attachment-post-thumbnail wp-post-image" alt="" title="" src="<?php echo SAMPLE_FILES; ?>/images/box_image.jpg" style="display: block;" />
                        </a>    
                        <?php self::getCover(); ?>   
                    </div>  
                    <?php self::getShadow(); ?>   
                </div>
            </div>                    
        </div>
        <?php    
    } 
    

    /**
     * Create a sample latest posts widget
     */
    public static function getSampleLatestPosts(){
        ?>
        <h2 class="color_scheme latest_post_widgettitle">Recent Posts</h2>
        <div class="widget_jflatestpostswidget">
            <div class="jf_latest_post row">
                <div class="jf_post_time columns grid_4">
                    <div class="date_holder background_scheme" style="color: #fff !important;">
                        <span class="day">28</span>
                        <br />
                        <span class="month">Nov</span>
                    </div>
                </div>
                <div class="jf_latest_post_holder columns grid_14">
                    <h4 class="jf_latest_post_title">
                        <a href="#">Post title</a>
                    </h4>
                    <p class="excerpt">
                        <a class="latest_post_link" href="#">Curabitur non odio consectetur, blandit tortor vitae, placerat faucibus lectus ...</a>
                    </p>                      
                </div>
            </div>
            <div class="jf_latest_post row">
                <div class="jf_post_time columns grid_4">
                    <div class="date_holder background_scheme" style="color: #fff !important;">
                        <span class="day">07</span>
                        <br />
                        <span class="month">May</span>
                    </div>
                </div>
                <div class="jf_latest_post_holder columns grid_14">
                    <h4 class="jf_latest_post_title">
                        <a href="#">Post title</a>
                    </h4>
                    <p class="excerpt">
                        <a class="latest_post_link" href="#">Morbi tincidunt imperdiet dolor sed congue. Vestibulum scelerisque hendrerit erat ...</a>
                    </p>                      
                </div>
            </div>
            <div class="jf_latest_post row">
                <div class="jf_post_time columns grid_4">
                    <div class="date_holder background_scheme" style="color: #fff !important;">
                        <span class="day">12</span>
                        <br />
                        <span class="month">Feb</span>
                    </div>
                </div>
                <div class="jf_latest_post_holder columns grid_14">
                    <h4 class="jf_latest_post_title">
                        <a href="#">Post title</a>
                    </h4>
                    <p class="excerpt">
                        <a class="latest_post_link" href="#">Nullam egestas libero venenatis tellus tristique gravida. Mauris sodales neque ...</a>
                    </p>                      
                </div>
            </div>
        </div>
       	<table class="table_of_shadows" border="0" cellpadding="0" cellspacing="0" style="width:  100%; margin-top: 0px !important">
           <tr>
           <td class="meta_left"></td>
           <td class="meta_center">&nbsp;</td>
           <td class="meta_right"></td>
           </tr>
        </table>          
        <?php
    }
    
    /** 
     * Copyright sample
     */
    public static function getSampleCopyright(){
        return 'Copyright 2013 | Powered by <a class="color_scheme" href="www.wordpress.org" target="_blank">WordPress</a> | Prestige theme by <a class="color_scheme" href="http://www.jumpeye.com" target="_blank">Jumpeye Components</a>';
    } 
                  
    /**
     * Create a sample tabbed widget
     */
    public static function getSampleTabbedWidget(){
        ?>
            <div class="tab style-2">
                <dl>
                    <dd>
                        <a class="active" href="#tab1">Tab1</a>
                    </dd>
                    <dd>
                        <a href="#tab2">Tab2</a>
                    </dd>
                    <dd>
                        <a href="#tab3">Tab3</a>
                    </dd>
                </dl>
                <ul class="tab-content style-2">
                    <li class="active">
                        <p class="excerpt">In congue ligula sed ultricies laoreet. Pellentesque elit enim, vehicula vel pulvinar non, vulputate quis risus. Aliquam vestibulum, dui et placerat rhoncus, massa sapien dictum leo, a lobortis nulla diam a velit. Etiam et lectus magna. Donec id viverra elit.</p>
                        <div class="img_holder">
                            <img title="" alt="" src="<?php echo SAMPLE_FILES; ?>images/tab_image.jpg" style="display: block; width: 100%;" />
                        </div>
                    </li>
                    <li>
                        <p class="excerpt">Suspendisse nisi enim, fringilla in orci sodales, ornare elementum nisl. Duis ornare mattis lobortis. Sed eget pellentesque metus. Aliquam lorem eros, faucibus in placerat ut, ornare quis est. Phasellus vel ornare nisl, nec ultricies odio mauris in vehicula tellus.</p>
                        <div class="img_holder">
                            <img class="" title="" alt="" src="<?php echo SAMPLE_FILES; ?>images/tab_image.jpg" style="display: block; width: 100%;" />                        
                        </div>                        
                    </li>
                    <li>
                        <p class="excerpt">Nam euismod pharetra metus eu pellentesque. Nunc tristique ultrices mi, vitae accumsan ipsum semper ac. Integer ipsum lorem, molestie ac ante et, tempus consectetur eros. Sed id mattis massa, nec blandit sapien. Curabitur sed erat quis ligula consequat posuere.</p>
                        <div class="img_holder">
                            <img class="wp-post-image" title="" alt="" src="<?php echo SAMPLE_FILES; ?>images/tab_image.jpg" style="display: block; width: 100%;" />                        
                        </div>                        
                    </li>
                </ul>
                <div class="tab_shadow"></div>
            </div>
        <?php    
    }                    
} // SampleData

?>
<?php
/**
 * The Header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="main">
 *
 * @package Prestige
 */
?><!DOCTYPE html>
<!--[if IE 8]>
<html id="ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 8) ]><!-->
<html <?php language_attributes(); ?>>
<!--<![endif]-->
<head>  
<?php global $page, $paged, $JFO; ?>
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<?php 
    JHooks::site_metadata();  
    JHooks::custom_head();
    JHooks::favicon(); 
    JHooks::fancybox();
?>  

<link rel="profile" href="http://gmpg.org/xfn/11" />
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
<!-- Google Font -->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400,800,300,700' rel='stylesheet' type='text/css' />

<!-- menu styles -->
<link type="text/css" rel="stylesheet" href="<?php echo get_template_directory_uri().$JFO->getFWPath(); ?>/css/menus/JFMenu.all.min.css" />

<!--[if lt IE 9]>
    <script src="<?php echo get_template_directory_uri(); ?>/js/html5.js" type="text/javascript"></script>
	<link type="text/css" rel="stylesheet" href="<?php echo get_template_directory_uri().$JFO->getFWPath(); ?>/css/JFIE.min.css">
    <link type="text/css" rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/ie8.css">
<![endif]-->

<!--[if gte IE 9]>
	<link type="text/css" rel="stylesheet" href="<?php echo get_template_directory_uri().$JFO->getFWPath(); ?>/css/JFIE9.min.css">
<![endif]-->

<?php wp_head(); ?>
<!-- WP stylesheet -->
<link type="text/css" rel="stylesheet" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />
<?php JF_Frontend::getColorScheme(); ?>
<?php JF_Frontend::generalCSS(); ?>
<!--[if lt IE 9]>
    <link type="text/css" rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/ie8.css">
<![endif]-->
<?php JHooks::domain_key(); ?>
</head>

<body <?php body_class(); ?>>
<div id="page" class="container hfeed site" <?php JApi::container_style(); ?>>
	<?php do_action( 'before' ); ?>
    
    <!-- header -->
    
    <!-- top -->
    <div id="top">
        <div class="row">
            <div class="columns grid_11">
                <div id="logo">
     			    <?php JF_Frontend::getLogo(); ?>
                    <?php JF_Frontend::getDescription(); ?>
                </div>       
            </div>
            <div class="columns grid_7">
                <div id="top_search">
                    <?php JF_Frontend::getHeaderInfo(); ?>
                    <?php get_search_form(); ?>
                </div>
            </div>            
        </div>
    </div>
    <!-- #top -->
    <!-- menu_wrapper -->
    <div id="menu_wrapper">
        <div class="row page_header">
            <div class="columns grid_18">
            	<div class="site-header" role="banner">
            		<?php $header_image = get_header_image();
            		if ( ! empty( $header_image ) ) { ?>
            			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home">
            				<img src="<?php header_image(); ?>" width="<?php echo get_custom_header()->width; ?>" height="<?php echo get_custom_header()->height; ?>" alt="" />
            			</a>
            		<?php } // if ( ! empty( $header_image ) ) ?>
            
            		<!--<nav role="navigation" class="site-navigation main-navigation">-->
            			<?php //wp_nav_menu( array( 'theme_location' => 'primary' ) ); ?>
                        <?php
                            if ( has_nav_menu( 'primary' ) ) {
                                wp_nav_menu( array( 
                                                'container' => 'div',
                                                'container_class' => 'site-menu menu style-4',
                                                'menu_class' => 'main-level', 
                                                'theme_location' =>   'primary' ) 
                                );
                            } else {
                                wp_nav_menu( array( 
                                                    'container' => 'ul',
                                                    'container_class' => '',
                                                    'menu_class' => 'site-menu menu style-4', 
                                                    'theme_location' =>   'header-menu' ) 
                                );
                            } 
                        ?>
            		<!--</nav>--><!-- .site-navigation .main-navigation -->
            	</div><!-- #masthead .site-header -->
            </div><!-- .columns .grid_18 -->
        </div><!-- .row .page_header -->
    </div><!-- #menu_wrapper -->  
    <?php JF_Frontend::getPageTitleBar(); ?>
<?php
/*
    Plugin Name: JF Contact Map Widget
    Plugin URI: http://www.jumpeye.com
    Description: Displays the specified map in an iframe.
    Version: 1.0
    Author: Jumpeye Components
    Author URI: http://www.jumpeye.com
    License: GPL2
*/

// register JFContactMapWidget widget
add_action('widgets_init', create_function('', 'return register_widget("JFContactMapWidget");')); 

/**
 * Adds JFContactMapWidget widget.
 */
class JFContactMapWidget extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	public function __construct() {
        
		parent::__construct(
	 		'JFContactMapWidget', // Base ID
			'JF Contact Map Widget', // Name (you will see it in Available Widgets)
			array( 'description' => __( 'Displays the specified map in an iframe.', 'prestige' ),) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	public function widget( $args, $instance ) {
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );

        /* Custom Options */
        // Our options from the widget settings.
        $top_text    = (isset($instance['top_text'])) ? $instance['top_text'] : '' ;
        $bottom_text = (isset($instance['bottom_text']))   ? $instance['bottom_text']   : '' ;
        $url         = (isset($instance['url']))   ? $instance['url']   : '' ;
        $width       = (isset($instance['width']))   ? $instance['width']   : '100%' ;
        $height      = (isset($instance['height']))   ? $instance['height']   : '400' ;

        // Before widget - as defined in your specific theme.
		echo $before_widget;
        
        if ( !empty( $title ) ){
	        echo $before_title . $title . $after_title;
        }        

        echo '<div id="contact_map_widget">';

        if( !empty($top_text) ){
            echo '<div class="row map_top_text"><div class="grid_18 columns">'.nl2br($top_text).'</div></div>';    
        }       
        
        if( !empty($url) ){
            
            if( !empty($width) ){
                if(strpos($width,'%') === false){
                    if(strpos($width,'px') === false){
                     $width.='px';    
                    } 
                } 
            }
            
            if( !empty($height) ){
                if(strpos($height,'%') === false){
                    if(strpos($height,'px') === false){
                     $height.='px';    
                    } 
                }
            }            
            ?>
            
            <div class="map_container" style="width: <?php echo $width; ?>; height: <?php echo $height; ?>">
            
            <iframe style="width: 100%; height: 100%;" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="<?php echo $url.'&amp;output=embed'; ?>"></iframe>
            <table class="table_of_shadows" border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td class="post_left"></td>
                    <td class="post_center">&nbsp;</td>
                    <td class="post_right"></td>
                </tr>
            </table>  
            </div>
            <?php
        }
         
        if( !empty($bottom_text) ){
            echo '<div class="row map_bottom_text"><div class="grid_18 columns">'.nl2br($bottom_text).'</div></div>';    
        } 
                                                                                        
        echo '</div>';

        /* After widget - as defined in your specific theme. */
		echo $after_widget;
        ?>
        
        <?php
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) {

        /* Default Widget Settings */
    		
    	$defaults = array(
    		'title'       => '',
            'top_text'    => '',
            'bottom_text' => '',
            'url'         => '',
            'width'       => '100%',
            'height'      => '400'
    	); 

        $instance = wp_parse_args( (array) $instance, $defaults );   
        $title    = esc_attr( $instance['title'] );
        $top_text  = $instance['top_text'];
        $bottom_text    = $instance['bottom_text'];
        $url      = $instance['url'];
        $width    = $instance['width'];
        $height   = $instance['height'];
        ?>
		<p>
    		<label for="<?php echo $this->get_field_name( 'title' ); ?>"><?php _e( 'Title:', 'prestige' ); ?></label> 
    		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo $title; ?>" />
		</p>        
		<p>
    		<label for="<?php echo $this->get_field_name( 'width' ); ?>"><?php _e( 'Map width:', 'prestige' ); ?></label> 
    		<input class="widefat" id="<?php echo $this->get_field_id( 'width' ); ?>" name="<?php echo $this->get_field_name( 'width' ); ?>" type="text" value="<?php echo $width; ?>" />
		</p>
		<p>
    		<label for="<?php echo $this->get_field_name( 'height' ); ?>"><?php _e( 'Map height:', 'prestige' ); ?></label> 
    		<input class="widefat" id="<?php echo $this->get_field_id( 'height' ); ?>" name="<?php echo $this->get_field_name( 'height' ); ?>" type="text" value="<?php echo $height; ?>" />
		</p>   
		<p>
    		<label for="<?php echo $this->get_field_name( 'top_text' ); ?>"><?php _e( 'Top text:', 'prestige' ); ?></label> 
    		<textarea class="widefat" id="<?php echo $this->get_field_id( 'top_text' ); ?>" name="<?php echo $this->get_field_name( 'top_text' ); ?>"><?php echo $top_text; ?></textarea>
		</p>                       
		<p>
    		<label for="<?php echo $this->get_field_name( 'url' ); ?>"><?php _e( 'Map url:', 'prestige' ); ?></label> 
    		<textarea class="widefat" id="<?php echo $this->get_field_id( 'url' ); ?>" name="<?php echo $this->get_field_name( 'url' ); ?>"><?php echo $url; ?></textarea>
		</p>  
		<p>
    		<label for="<?php echo $this->get_field_name( 'bottom_text' ); ?>"><?php _e( 'Bottom text:', 'prestige' ); ?></label> 
    		<textarea class="widefat" id="<?php echo $this->get_field_id( 'bottom_text' ); ?>" name="<?php echo $this->get_field_name( 'bottom_text' ); ?>"><?php echo $bottom_text; ?></textarea>
		</p>                
		<?php 
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance                = array();
		$instance['title']       = ( !empty( $new_instance['title'] ) )   ? strip_tags( $new_instance['title'] )   : '';
        $instance['top_text']    = ( !empty( $new_instance['top_text'] ) ) ?  $new_instance['top_text']  : '';
        $instance['bottom_text'] = ( !empty( $new_instance['bottom_text'] ) )   ?  $new_instance['bottom_text']    : '';
        $instance['url']         = ( !empty( $new_instance['url'] ) )   ? strip_tags( $new_instance['url'] )   : '';
        $instance['width']       = ( !empty( $new_instance['width'] ) )   ? strip_tags( $new_instance['width'] )   : '';
        $instance['height']      = ( !empty( $new_instance['height'] ) )   ? strip_tags( $new_instance['height'] )   : '';
		return $instance;
	}
    
} // class JFContactMapWidget

?>
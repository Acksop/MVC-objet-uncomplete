﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
	<head>
		<title>Shortcode Tester</title>

		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta name="viewport" content="width=device-width; initial-scale=1.0;" />
		<!-- Grid -->			
		<link type="text/css" rel="stylesheet" href="../framework/css/JFGrid_18.min.css" />
        
        <!-- Alerts -->
		<link type="text/css" rel="stylesheet" href="../framework/css/alerts/JFAlert.all.min.css" />
		
        <!-- Buttons -->
		<link type="text/css" rel="stylesheet" href="../framework/css/buttons/JFButton.all.min.css" />

        <!-- Menus -->
		<link type="text/css" rel="stylesheet" href="../framework/css/menus/JFMenu.all.min.css" />
                 
        <!-- Panels -->
		<link type="text/css" rel="stylesheet" href="../framework/css/panels/JFPanel.all.min.css" />
                          
        <!-- Tabs -->
		<link type="text/css" rel="stylesheet" href="../framework/css/tabs/JFTab.all.min.css" />

        <!-- Tables -->
		<link type="text/css" rel="stylesheet" href="../framework/css/tables/JFTable.all.min.css" />
                
        <!-- Forms -->
		<link type="text/css" rel="stylesheet" href="../framework/css/forms/JFForm.all.min.css" />
            
        <!-- Tooltips -->                  
		<link type="text/css" rel="stylesheet" href="../framework/css/tooltips/JFTooltip.all.min.css" />
                                                                                
		<!--[if lt IE 9]>
			<link type="text/css" rel="stylesheet" href="../framework/css/JFIE.min.css">
		<![endif]-->

		<!--[if gte IE 9]>
			<link type="text/css" rel="stylesheet" href="../framework/css/JFIE9.min.css">
		<![endif]-->

		<style type="text/css">
			h3 {
				color: #501aa2;
			}
		</style>
        		
		<script type="text/javascript" src="../framework/js/JFCore.js"></script>
        <script type="text/javascript" src="../framework/js/JFMenus.js"></script>	
        <script type="text/javascript" src="../framework/js/JFForms.js"></script>
        <script type="text/javascript" src="../framework/js/JFTooltips.js"></script>
        <script type="text/javascript">
            function rebootHandlers(){
                if(JFBase('div.alert').length > 0){
                    JC.UI.Alerts();           // load UI closeButton effects    
                }
                
                if(JFBase('div.tab').length > 0){
                    JC.UI.Tabs();             // load UI tabs handler
                }
                
                if(JFBase('table.table').length > 0){    
                    JC.UI.Tables();           // load UI tables handler
                }
                
                if(JFBase('.tooltip').length > 0){
                    JFBase('.tooltip').jcTooltip();
                }
                
                if(JFBase('.menu').length > 0){
                    JFBase('.menu').JFMenus();    
                }
                
                if(JFBase('form.style-1').length > 0){
                    JFBase.fn.JFforms.init();
                }             
            }
    		(function() {
    			JC.init({
                    domainKey: '<?php echo base64_decode($_GET['domain_key']); ?>' //'YourDomainKey'
                });
            })();              
        </script>

	</head>
	<body>	
		<div class="container" style="margin:30px 0;">			
			<div class="row">
                <div class="grid_18 columns">
                    <h3>Shortcode preview</h3>  
                    <div id="preview"></div>
                </div>
			</div>
		</div>
	</body>
</html>
﻿/*! jQuery v@1.8.1 jquery.com | jquery.org/license */
(function(a,b){function G(a){var b=F[a]={};p.each(a.split(s),function(a,c){b[c]=true});return b}function J(a,c,d){if(d===b&&a.nodeType===1){var e="data-"+c.replace(I,"-$1").toLowerCase();d=a.getAttribute(e);if(typeof d==="string"){try{d=d==="true"?true:d==="false"?false:d==="null"?null:+d+""===d?+d:H.test(d)?p.parseJSON(d):d}catch(f){}p.data(a,c,d)}else{d=b}}return d}function K(a){var b;for(b in a){if(b==="data"&&p.isEmptyObject(a[b])){continue}if(b!=="toJSON"){return false}}return true}function ab(){return false}function bb(){return true}function hb(a){return!a||!a.parentNode||a.parentNode.nodeType===11}function ib(a,b){do{a=a[b]}while(a&&a.nodeType!==1);return a}function jb(a,b,c){b=b||0;if(p.isFunction(b)){return p.grep(a,function(a,d){var e=!!b.call(a,d,a);return e===c})}else if(b.nodeType){return p.grep(a,function(a,d){return a===b===c})}else if(typeof b==="string"){var d=p.grep(a,function(a){return a.nodeType===1});if(eb.test(b)){return p.filter(b,d,!c)}else{b=p.filter(b,d)}}return p.grep(a,function(a,d){return p.inArray(a,b)>=0===c})}function kb(a){var b=lb.split("|"),c=a.createDocumentFragment();if(c.createElement){while(b.length){c.createElement(b.pop())}}return c}function Cb(a,b){return a.getElementsByTagName(b)[0]||a.appendChild(a.ownerDocument.createElement(b))}function Db(a,b){if(b.nodeType!==1||!p.hasData(a)){return}var c,d,e,f=p._data(a),g=p._data(b,f),h=f.events;if(h){delete g.handle;g.events={};for(c in h){for(d=0,e=h[c].length;d<e;d++){p.event.add(b,c,h[c][d])}}}if(g.data){g.data=p.extend({},g.data)}}function Eb(a,b){var c;if(b.nodeType!==1){return}if(b.clearAttributes){b.clearAttributes()}if(b.mergeAttributes){b.mergeAttributes(a)}c=b.nodeName.toLowerCase();if(c==="object"){if(b.parentNode){b.outerHTML=a.outerHTML}if(p.support.html5Clone&&a.innerHTML&&!p.trim(b.innerHTML)){b.innerHTML=a.innerHTML}}else if(c==="input"&&vb.test(a.type)){b.defaultChecked=b.checked=a.checked;if(b.value!==a.value){b.value=a.value}}else if(c==="option"){b.selected=a.defaultSelected}else if(c==="input"||c==="textarea"){b.defaultValue=a.defaultValue}else if(c==="script"&&b.text!==a.text){b.text=a.text}b.removeAttribute(p.expando)}function Fb(a){if(typeof a.getElementsByTagName!=="undefined"){return a.getElementsByTagName("*")}else if(typeof a.querySelectorAll!=="undefined"){return a.querySelectorAll("*")}else{return[]}}function Gb(a){if(vb.test(a.type)){a.defaultChecked=a.checked}}function Yb(a,b){if(b in a){return b}var c=b.charAt(0).toUpperCase()+b.slice(1),d=b,e=Wb.length;while(e--){b=Wb[e]+c;if(b in a){return b}}return d}function Zb(a,b){a=b||a;return p.css(a,"display")==="none"||!p.contains(a.ownerDocument,a)}function $b(a,b){var c,d,e=[],f=0,g=a.length;for(;f<g;f++){c=a[f];if(!c.style){continue}e[f]=p._data(c,"olddisplay");if(b){if(!e[f]&&c.style.display==="none"){c.style.display=""}if(c.style.display===""&&Zb(c)){e[f]=p._data(c,"olddisplay",cc(c.nodeName))}}else{d=Hb(c,"display");if(!e[f]&&d!=="none"){p._data(c,"olddisplay",d)}}}for(f=0;f<g;f++){c=a[f];if(!c.style){continue}if(!b||c.style.display==="none"||c.style.display===""){c.style.display=b?e[f]||"":"none"}}return a}function _b(a,b,c){var d=Pb.exec(b);return d?Math.max(0,d[1]-(c||0))+(d[2]||"px"):b}function ac(a,b,c,d){var e=c===(d?"border":"content")?4:b==="width"?1:0,f=0;for(;e<4;e+=2){if(c==="margin"){f+=p.css(a,c+Vb[e],true)}if(d){if(c==="content"){f-=parseFloat(Hb(a,"padding"+Vb[e]))||0}if(c!=="margin"){f-=parseFloat(Hb(a,"border"+Vb[e]+"Width"))||0}}else{f+=parseFloat(Hb(a,"padding"+Vb[e]))||0;if(c!=="padding"){f+=parseFloat(Hb(a,"border"+Vb[e]+"Width"))||0}}}return f}function bc(a,b,c){var d=b==="width"?a.offsetWidth:a.offsetHeight,e=true,f=p.support.boxSizing&&p.css(a,"boxSizing")==="border-box";if(d<=0||d==null){d=Hb(a,b);if(d<0||d==null){d=a.style[b]}if(Qb.test(d)){return d}e=f&&(p.support.boxSizingReliable||d===a.style[b]);d=parseFloat(d)||0}return d+ac(a,b,c||(f?"border":"content"),e)+"px"}function cc(a){if(Sb[a]){return Sb[a]}var b=p("<"+a+">").appendTo(e.body),c=b.css("display");b.remove();if(c==="none"||c===""){Ib=e.body.appendChild(Ib||p.extend(e.createElement("iframe"),{frameBorder:0,width:0,height:0}));if(!Jb||!Ib.createElement){Jb=(Ib.contentWindow||Ib.contentDocument).document;Jb.write("<!doctype html><html><body>");Jb.close()}b=Jb.body.appendChild(Jb.createElement(a));c=Hb(b,"display");e.body.removeChild(Ib)}Sb[a]=c;return c}function ic(a,b,c,d){var e;if(p.isArray(b)){p.each(b,function(b,e){if(c||ec.test(a)){d(a,e)}else{ic(a+"["+(typeof e==="object"?b:"")+"]",e,c,d)}})}else if(!c&&p.type(b)==="object"){for(e in b){ic(a+"["+e+"]",b[e],c,d)}}else{d(a,b)}}function zc(a){return function(b,c){if(typeof b!=="string"){c=b;b="*"}var d,e,f,g=b.toLowerCase().split(s),h=0,i=g.length;if(p.isFunction(c)){for(;h<i;h++){d=g[h];f=/^\+/.test(d);if(f){d=d.substr(1)||"*"}e=a[d]=a[d]||[];e[f?"unshift":"push"](c)}}}}function Ac(a,c,d,e,f,g){f=f||c.dataTypes[0];g=g||{};g[f]=true;var h,i=a[f],j=0,k=i?i.length:0,l=a===vc;for(;j<k&&(l||!h);j++){h=i[j](c,d,e);if(typeof h==="string"){if(!l||g[h]){h=b}else{c.dataTypes.unshift(h);h=Ac(a,c,d,e,h,g)}}}if((l||!h)&&!g["*"]){h=Ac(a,c,d,e,"*",g)}return h}function Bc(a,c){var d,e,f=p.ajaxSettings.flatOptions||{};for(d in c){if(c[d]!==b){(f[d]?a:e||(e={}))[d]=c[d]}}if(e){p.extend(true,a,e)}}function Cc(a,c,d){var e,f,g,h,i=a.contents,j=a.dataTypes,k=a.responseFields;for(f in k){if(f in d){c[k[f]]=d[f]}}while(j[0]==="*"){j.shift();if(e===b){e=a.mimeType||c.getResponseHeader("content-type")}}if(e){for(f in i){if(i[f]&&i[f].test(e)){j.unshift(f);break}}}if(j[0]in d){g=j[0]}else{for(f in d){if(!j[0]||a.converters[f+" "+j[0]]){g=f;break}if(!h){h=f}}g=g||h}if(g){if(g!==j[0]){j.unshift(g)}return d[g]}}function Dc(a,b){var c,d,e,f,g=a.dataTypes.slice(),h=g[0],i={},j=0;if(a.dataFilter){b=a.dataFilter(b,a.dataType)}if(g[1]){for(c in a.converters){i[c.toLowerCase()]=a.converters[c]}}for(;e=g[++j];){if(e!=="*"){if(h!=="*"&&h!==e){c=i[h+" "+e]||i["* "+e];if(!c){for(d in i){f=d.split(" ");if(f[1]===e){c=i[h+" "+f[0]]||i["* "+f[0]];if(c){if(c===true){c=i[d]}else if(i[d]!==true){e=f[0];g.splice(j--,0,e)}break}}}}if(c!==true){if(c&&a["throws"]){b=c(b)}else{try{b=c(b)}catch(k){return{state:"parsererror",error:c?k:"No conversion from "+h+" to "+e}}}}}h=e}}return{state:"success",data:b}}function Lc(){try{return new a.XMLHttpRequest}catch(b){}}function Mc(){try{return new a.ActiveXObject("Microsoft.XMLHTTP")}catch(b){}}function Uc(){setTimeout(function(){Nc=b},0);return Nc=p.now()}function Vc(a,b){p.each(b,function(b,c){var d=(Tc[b]||[]).concat(Tc["*"]),e=0,f=d.length;for(;e<f;e++){if(d[e].call(a,b,c)){return}}})}function Wc(a,b,c){var d,e=0,f=0,g=Sc.length,h=p.Deferred().always(function(){delete i.elem}),i=function(){var b=Nc||Uc(),c=Math.max(0,j.startTime+j.duration-b),d=1-(c/j.duration||0),e=0,f=j.tweens.length;for(;e<f;e++){j.tweens[e].run(d)}h.notifyWith(a,[j,d,c]);if(d<1&&f){return c}else{h.resolveWith(a,[j]);return false}},j=h.promise({elem:a,props:p.extend({},b),opts:p.extend(true,{specialEasing:{}},c),originalProperties:b,originalOptions:c,startTime:Nc||Uc(),duration:c.duration,tweens:[],createTween:function(b,c,d){var e=p.Tween(a,j.opts,b,c,j.opts.specialEasing[b]||j.opts.easing);j.tweens.push(e);return e},stop:function(b){var c=0,d=b?j.tweens.length:0;for(;c<d;c++){j.tweens[c].run(1)}if(b){h.resolveWith(a,[j,b])}else{h.rejectWith(a,[j,b])}return this}}),k=j.props;Xc(k,j.opts.specialEasing);for(;e<g;e++){d=Sc[e].call(j,a,k,j.opts);if(d){return d}}Vc(j,k);if(p.isFunction(j.opts.start)){j.opts.start.call(a,j)}p.fx.timer(p.extend(i,{anim:j,queue:j.opts.queue,elem:a}));return j.progress(j.opts.progress).done(j.opts.done,j.opts.complete).fail(j.opts.fail).always(j.opts.always)}function Xc(a,b){var c,d,e,f,g;for(c in a){d=p.camelCase(c);e=b[d];f=a[c];if(p.isArray(f)){e=f[1];f=a[c]=f[0]}if(c!==d){a[d]=f;delete a[c]}g=p.cssHooks[d];if(g&&"expand"in g){f=g.expand(f);delete a[d];for(c in f){if(!(c in a)){a[c]=f[c];b[c]=e}}}else{b[d]=e}}}function Yc(a,b,c){var d,e,f,g,h,i,j,k,l=this,m=a.style,n={},o=[],q=a.nodeType&&Zb(a);if(!c.queue){j=p._queueHooks(a,"fx");if(j.unqueued==null){j.unqueued=0;k=j.empty.fire;j.empty.fire=function(){if(!j.unqueued){k()}}}j.unqueued++;l.always(function(){l.always(function(){j.unqueued--;if(!p.queue(a,"fx").length){j.empty.fire()}})})}if(a.nodeType===1&&("height"in b||"width"in b)){c.overflow=[m.overflow,m.overflowX,m.overflowY];if(p.css(a,"display")==="inline"&&p.css(a,"float")==="none"){if(!p.support.inlineBlockNeedsLayout||cc(a.nodeName)==="inline"){m.display="inline-block"}else{m.zoom=1}}}if(c.overflow){m.overflow="hidden";if(!p.support.shrinkWrapBlocks){l.done(function(){m.overflow=c.overflow[0];m.overflowX=c.overflow[1];m.overflowY=c.overflow[2]})}}for(d in b){f=b[d];if(Pc.exec(f)){delete b[d];if(f===(q?"hide":"show")){continue}o.push(d)}}g=o.length;if(g){h=p._data(a,"fxshow")||p._data(a,"fxshow",{});if(q){p(a).show()}else{l.done(function(){p(a).hide()})}l.done(function(){var b;p.removeData(a,"fxshow",true);for(b in n){p.style(a,b,n[b])}});for(d=0;d<g;d++){e=o[d];i=l.createTween(e,q?h[e]:0);n[e]=h[e]||p.style(a,e);if(!(e in h)){h[e]=i.start;if(q){i.end=i.start;i.start=e==="width"||e==="height"?1:0}}}}}function Zc(a,b,c,d,e){return new Zc.prototype.init(a,b,c,d,e)}function $c(a,b){var c,d={height:a},e=0;b=b?1:0;for(;e<4;e+=2-b){c=Vb[e];d["margin"+c]=d["padding"+c]=a}if(b){d.opacity=d.width=a}return d}function ad(a){return p.isWindow(a)?a:a.nodeType===9?a.defaultView||a.parentWindow:false}var c,d,e=a.document,f=a.location,g=a.navigator,h=a.JFBase,i=a.JFBase,j=Array.prototype.push,k=Array.prototype.slice,l=Array.prototype.indexOf,m=Object.prototype.toString,n=Object.prototype.hasOwnProperty,o=String.prototype.trim,p=function(a,b){return new p.fn.init(a,b,c)},q=/[\-+]?(?:\d*\.|)\d+(?:[eE][\-+]?\d+|)/.source,r=/\S/,s=/\s+/,t=/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,u=/^(?:[^#<]*(<[\w\W]+>)[^>]*$|#([\w\-]*)$)/,v=/^<(\w+)\s*\/?>(?:<\/\1>|)$/,w=/^[\],:{}\s]*$/,x=/(?:^|:|,)(?:\s*\[)+/g,y=/\\(?:["\\\/bfnrt]|u[\da-fA-F]{4})/g,z=/"[^"\\\r\n]*"|true|false|null|-?(?:\d\d*\.|)\d+(?:[eE][\-+]?\d+|)/g,A=/^-ms-/,B=/-([\da-z])/gi,C=function(a,b){return(b+"").toUpperCase()},D=function(){if(e.addEventListener){e.removeEventListener("DOMContentLoaded",D,false);p.ready()}else if(e.readyState==="complete"){e.detachEvent("onreadystatechange",D);p.ready()}},E={};p.fn=p.prototype={constructor:p,init:function(a,c,d){var f,g,h,i;if(!a){return this}if(a.nodeType){this.context=this[0]=a;this.length=1;return this}if(typeof a==="string"){if(a.charAt(0)==="<"&&a.charAt(a.length-1)===">"&&a.length>=3){f=[null,a,null]}else{f=u.exec(a)}if(f&&(f[1]||!c)){if(f[1]){c=c instanceof p?c[0]:c;i=c&&c.nodeType?c.ownerDocument||c:e;a=p.parseHTML(f[1],i,true);if(v.test(f[1])&&p.isPlainObject(c)){this.attr.call(a,c,true)}return p.merge(this,a)}else{g=e.getElementById(f[2]);if(g&&g.parentNode){if(g.id!==f[2]){return d.find(a)}this.length=1;this[0]=g}this.context=e;this.selector=a;return this}}else if(!c||c.jfbase){return(c||d).find(a)}else{return this.constructor(c).find(a)}}else if(p.isFunction(a)){return d.ready(a)}if(a.selector!==b){this.selector=a.selector;this.context=a.context}return p.makeArray(a,this)},selector:"",jfbase:"1.8.1",length:0,size:function(){return this.length},toArray:function(){return k.call(this)},get:function(a){return a==null?this.toArray():a<0?this[this.length+a]:this[a]},pushStack:function(a,b,c){var d=p.merge(this.constructor(),a);d.prevObject=this;d.context=this.context;if(b==="find"){d.selector=this.selector+(this.selector?" ":"")+c}else if(b){d.selector=this.selector+"."+b+"("+c+")"}return d},each:function(a,b){return p.each(this,a,b)},ready:function(a){p.ready.promise().done(a);return this},eq:function(a){a=+a;return a===-1?this.slice(a):this.slice(a,a+1)},first:function(){return this.eq(0)},last:function(){return this.eq(-1)},slice:function(){return this.pushStack(k.apply(this,arguments),"slice",k.call(arguments).join(","))},map:function(a){return this.pushStack(p.map(this,function(b,c){return a.call(b,c,b)}))},end:function(){return this.prevObject||this.constructor(null)},push:j,sort:[].sort,splice:[].splice};p.fn.init.prototype=p.fn;p.extend=p.fn.extend=function(){var a,c,d,e,f,g,h=arguments[0]||{},i=1,j=arguments.length,k=false;if(typeof h==="boolean"){k=h;h=arguments[1]||{};i=2}if(typeof h!=="object"&&!p.isFunction(h)){h={}}if(j===i){h=this;--i}for(;i<j;i++){if((a=arguments[i])!=null){for(c in a){d=h[c];e=a[c];if(h===e){continue}if(k&&e&&(p.isPlainObject(e)||(f=p.isArray(e)))){if(f){f=false;g=d&&p.isArray(d)?d:[]}else{g=d&&p.isPlainObject(d)?d:{}}h[c]=p.extend(k,g,e)}else if(e!==b){h[c]=e}}}}return h};p.extend({noConflict:function(b){if(a.JFBase===p){a.JFBase=h}if(b&&a.JFBase===p){a.JFBase=h}return p},isReady:false,readyWait:1,holdReady:function(a){if(a){p.readyWait++}else{p.ready(true)}},ready:function(a){if(a===true?--p.readyWait:p.isReady){return}if(!e.body){return setTimeout(p.ready,1)}p.isReady=true;if(a!==true&&--p.readyWait>0){return}d.resolveWith(e,[p]);if(p.fn.trigger){p(e).trigger("ready").off("ready")}},isFunction:function(a){return p.type(a)==="function"},isArray:Array.isArray||function(a){return p.type(a)==="array"},isWindow:function(a){return a!=null&&a==a.window},isNumeric:function(a){return!isNaN(parseFloat(a))&&isFinite(a)},type:function(a){return a==null?String(a):E[m.call(a)]||"object"},isPlainObject:function(a){if(!a||p.type(a)!=="object"||a.nodeType||p.isWindow(a)){return false}try{if(a.constructor&&!n.call(a,"constructor")&&!n.call(a.constructor.prototype,"isPrototypeOf")){return false}}catch(c){return false}var d;for(d in a){}return d===b||n.call(a,d)},isEmptyObject:function(a){var b;for(b in a){return false}return true},error:function(a){throw new Error(a)},parseHTML:function(a,b,c){var d;if(!a||typeof a!=="string"){return null}if(typeof b==="boolean"){c=b;b=0}b=b||e;if(d=v.exec(a)){return[b.createElement(d[1])]}d=p.buildFragment([a],b,c?null:[]);return p.merge([],(d.cacheable?p.clone(d.fragment):d.fragment).childNodes)},parseJSON:function(b){if(!b||typeof b!=="string"){return null}b=p.trim(b);if(a.JSON&&a.JSON.parse){return a.JSON.parse(b)}if(w.test(b.replace(y,"@").replace(z,"]").replace(x,""))){return(new Function("return "+b))()}p.error("Invalid JSON: "+b)},parseXML:function(c){var d,e;if(!c||typeof c!=="string"){return null}try{if(a.DOMParser){e=new DOMParser;d=e.parseFromString(c,"text/xml")}else{d=new ActiveXObject("Microsoft.XMLDOM");d.async="false";d.loadXML(c)}}catch(f){d=b}if(!d||!d.documentElement||d.getElementsByTagName("parsererror").length){p.error("Invalid XML: "+c)}return d},noop:function(){},globalEval:function(b){if(b&&r.test(b)){(a.execScript||function(b){a["eval"].call(a,b)})(b)}},camelCase:function(a){return a.replace(A,"ms-").replace(B,C)},nodeName:function(a,b){return a.nodeName&&a.nodeName.toUpperCase()===b.toUpperCase()},each:function(a,c,d){var e,f=0,g=a.length,h=g===b||p.isFunction(a);if(d){if(h){for(e in a){if(c.apply(a[e],d)===false){break}}}else{for(;f<g;){if(c.apply(a[f++],d)===false){break}}}}else{if(h){for(e in a){if(c.call(a[e],e,a[e])===false){break}}}else{for(;f<g;){if(c.call(a[f],f,a[f++])===false){break}}}}return a},trim:o&&!o.call("﻿ ")?function(a){return a==null?"":o.call(a)}:function(a){return a==null?"":a.toString().replace(t,"")},makeArray:function(a,b){var c,d=b||[];if(a!=null){c=p.type(a);if(a.length==null||c==="string"||c==="function"||c==="regexp"||p.isWindow(a)){j.call(d,a)}else{p.merge(d,a)}}return d},inArray:function(a,b,c){var d;if(b){if(l){return l.call(b,a,c)}d=b.length;c=c?c<0?Math.max(0,d+c):c:0;for(;c<d;c++){if(c in b&&b[c]===a){return c}}}return-1},merge:function(a,c){var d=c.length,e=a.length,f=0;if(typeof d==="number"){for(;f<d;f++){a[e++]=c[f]}}else{while(c[f]!==b){a[e++]=c[f++]}}a.length=e;return a},grep:function(a,b,c){var d,e=[],f=0,g=a.length;c=!!c;for(;f<g;f++){d=!!b(a[f],f);if(c!==d){e.push(a[f])}}return e},map:function(a,c,d){var e,f,g=[],h=0,i=a.length,j=a instanceof p||i!==b&&typeof i==="number"&&(i>0&&a[0]&&a[i-1]||i===0||p.isArray(a));if(j){for(;h<i;h++){e=c(a[h],h,d);if(e!=null){g[g.length]=e}}}else{for(f in a){e=c(a[f],f,d);if(e!=null){g[g.length]=e}}}return g.concat.apply([],g)},guid:1,proxy:function(a,c){var d,e,f;if(typeof c==="string"){d=a[c];c=a;a=d}if(!p.isFunction(a)){return b}e=k.call(arguments,2);f=function(){return a.apply(c,e.concat(k.call(arguments)))};f.guid=a.guid=a.guid||f.guid||p.guid++;return f},access:function(a,c,d,e,f,g,h){var i,j=d==null,k=0,l=a.length;if(d&&typeof d==="object"){for(k in d){p.access(a,c,k,d[k],1,g,e)}f=1}else if(e!==b){i=h===b&&p.isFunction(e);if(j){if(i){i=c;c=function(a,b,c){return i.call(p(a),c)}}else{c.call(a,e);c=null}}if(c){for(;k<l;k++){c(a[k],d,i?e.call(a[k],k,c(a[k],d)):e,h)}}f=1}return f?a:j?c.call(a):l?c(a[0],d):g},now:function(){return(new Date).getTime()}});p.ready.promise=function(b){if(!d){d=p.Deferred();if(e.readyState==="complete"){setTimeout(p.ready,1)}else if(e.addEventListener){e.addEventListener("DOMContentLoaded",D,false);a.addEventListener("load",p.ready,false)}else{e.attachEvent("onreadystatechange",D);a.attachEvent("onload",p.ready);var c=false;try{c=a.frameElement==null&&e.documentElement}catch(f){}if(c&&c.doScroll){(function g(){if(!p.isReady){try{c.doScroll("left")}catch(a){return setTimeout(g,50)}p.ready()}})()}}}return d.promise(b)};p.each("Boolean Number String Function Array Date RegExp Object".split(" "),function(a,b){E["[object "+b+"]"]=b.toLowerCase()});c=p(e);var F={};p.Callbacks=function(a){a=typeof a==="string"?F[a]||G(a):p.extend({},a);var c,d,e,f,g,h,i=[],j=!a.once&&[],k=function(b){c=a.memory&&b;d=true;h=f||0;f=0;g=i.length;e=true;for(;i&&h<g;h++){if(i[h].apply(b[0],b[1])===false&&a.stopOnFalse){c=false;break}}e=false;if(i){if(j){if(j.length){k(j.shift())}}else if(c){i=[]}else{l.disable()}}},l={add:function(){if(i){var b=i.length;(function d(b){p.each(b,function(b,c){var e=p.type(c);if(e==="function"&&(!a.unique||!l.has(c))){i.push(c)}else if(c&&c.length&&e!=="string"){d(c)}})})(arguments);if(e){g=i.length}else if(c){f=b;k(c)}}return this},remove:function(){if(i){p.each(arguments,function(a,b){var c;while((c=p.inArray(b,i,c))>-1){i.splice(c,1);if(e){if(c<=g){g--}if(c<=h){h--}}}})}return this},has:function(a){return p.inArray(a,i)>-1},empty:function(){i=[];return this},disable:function(){i=j=c=b;return this},disabled:function(){return!i},lock:function(){j=b;if(!c){l.disable()}return this},locked:function(){return!j},fireWith:function(a,b){b=b||[];b=[a,b.slice?b.slice():b];if(i&&(!d||j)){if(e){j.push(b)}else{k(b)}}return this},fire:function(){l.fireWith(this,arguments);return this},fired:function(){return!!d}};return l};p.extend({Deferred:function(a){var b=[["resolve","done",p.Callbacks("once memory"),"resolved"],["reject","fail",p.Callbacks("once memory"),"rejected"],["notify","progress",p.Callbacks("memory")]],c="pending",d={state:function(){return c},always:function(){e.done(arguments).fail(arguments);return this},then:function(){var a=arguments;return p.Deferred(function(c){p.each(b,function(b,d){var f=d[0],g=a[b];e[d[1]](p.isFunction(g)?function(){var a=g.apply(this,arguments);if(a&&p.isFunction(a.promise)){a.promise().done(c.resolve).fail(c.reject).progress(c.notify)}else{c[f+"With"](this===e?c:this,[a])}}:c[f])});a=null}).promise()},promise:function(a){return typeof a==="object"?p.extend(a,d):d}},e={};d.pipe=d.then;p.each(b,function(a,f){var g=f[2],h=f[3];d[f[1]]=g.add;if(h){g.add(function(){c=h},b[a^1][2].disable,b[2][2].lock)}e[f[0]]=g.fire;e[f[0]+"With"]=g.fireWith});d.promise(e);if(a){a.call(e,e)}return e},when:function(a){var b=0,c=k.call(arguments),d=c.length,e=d!==1||a&&p.isFunction(a.promise)?d:0,f=e===1?a:p.Deferred(),g=function(a,b,c){return function(d){b[a]=this;c[a]=arguments.length>1?k.call(arguments):d;if(c===h){f.notifyWith(b,c)}else if(!--e){f.resolveWith(b,c)}}},h,i,j;if(d>1){h=new Array(d);i=new Array(d);j=new Array(d);for(;b<d;b++){if(c[b]&&p.isFunction(c[b].promise)){c[b].promise().done(g(b,j,c)).fail(f.reject).progress(g(b,i,h))}else{--e}}}if(!e){f.resolveWith(j,c)}return f.promise()}});p.support=function(){var b,c,d,f,g,h,i,j,k,l,m,n=e.createElement("div");n.setAttribute("className","t");n.innerHTML="  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>";c=n.getElementsByTagName("*");d=n.getElementsByTagName("a")[0];d.style.cssText="top:1px;float:left;opacity:.5";if(!c||!c.length||!d){return{}}f=e.createElement("select");g=f.appendChild(e.createElement("option"));h=n.getElementsByTagName("input")[0];b={leadingWhitespace:n.firstChild.nodeType===3,tbody:!n.getElementsByTagName("tbody").length,htmlSerialize:!!n.getElementsByTagName("link").length,style:/top/.test(d.getAttribute("style")),hrefNormalized:d.getAttribute("href")==="/a",opacity:/^0.5/.test(d.style.opacity),cssFloat:!!d.style.cssFloat,checkOn:h.value==="on",optSelected:g.selected,getSetAttribute:n.className!=="t",enctype:!!e.createElement("form").enctype,html5Clone:e.createElement("nav").cloneNode(true).outerHTML!=="<:nav></:nav>",boxModel:e.compatMode==="CSS1Compat",submitBubbles:true,changeBubbles:true,focusinBubbles:false,deleteExpando:true,noCloneEvent:true,inlineBlockNeedsLayout:false,shrinkWrapBlocks:false,reliableMarginRight:true,boxSizingReliable:true,pixelPosition:false};h.checked=true;b.noCloneChecked=h.cloneNode(true).checked;f.disabled=true;b.optDisabled=!g.disabled;try{delete n.test}catch(o){b.deleteExpando=false}if(!n.addEventListener&&n.attachEvent&&n.fireEvent){n.attachEvent("onclick",m=function(){b.noCloneEvent=false});n.cloneNode(true).fireEvent("onclick");n.detachEvent("onclick",m)}h=e.createElement("input");h.value="t";h.setAttribute("type","radio");b.radioValue=h.value==="t";h.setAttribute("checked","checked");h.setAttribute("name","t");n.appendChild(h);i=e.createDocumentFragment();i.appendChild(n.lastChild);b.checkClone=i.cloneNode(true).cloneNode(true).lastChild.checked;b.appendChecked=h.checked;i.removeChild(h);i.appendChild(n);if(n.attachEvent){for(k in{submit:true,change:true,focusin:true}){j="on"+k;l=j in n;if(!l){n.setAttribute(j,"return;");l=typeof n[j]==="function"}b[k+"Bubbles"]=l}}p(function(){var c,d,f,g,h="padding:0;margin:0;border:0;display:block;overflow:hidden;",i=e.getElementsByTagName("body")[0];if(!i){return}c=e.createElement("div");c.style.cssText="visibility:hidden;border:0;width:0;height:0;position:static;top:0;margin-top:1px";i.insertBefore(c,i.firstChild);d=e.createElement("div");c.appendChild(d);d.innerHTML="<table><tr><td></td><td>t</td></tr></table>";f=d.getElementsByTagName("td");f[0].style.cssText="padding:0;margin:0;border:0;display:none";l=f[0].offsetHeight===0;f[0].style.display="";f[1].style.display="none";b.reliableHiddenOffsets=l&&f[0].offsetHeight===0;d.innerHTML="";d.style.cssText="box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;padding:1px;border:1px;display:block;width:4px;margin-top:1%;position:absolute;top:1%;";b.boxSizing=d.offsetWidth===4;b.doesNotIncludeMarginInBodyOffset=i.offsetTop!==1;if(a.getComputedStyle){b.pixelPosition=(a.getComputedStyle(d,null)||{}).top!=="1%";b.boxSizingReliable=(a.getComputedStyle(d,null)||{width:"4px"}).width==="4px";g=e.createElement("div");g.style.cssText=d.style.cssText=h;g.style.marginRight=g.style.width="0";d.style.width="1px";d.appendChild(g);b.reliableMarginRight=!parseFloat((a.getComputedStyle(g,null)||{}).marginRight)}if(typeof d.style.zoom!=="undefined"){d.innerHTML="";d.style.cssText=h+"width:1px;padding:1px;display:inline;zoom:1";b.inlineBlockNeedsLayout=d.offsetWidth===3;d.style.display="block";d.style.overflow="visible";d.innerHTML="<div></div>";d.firstChild.style.width="5px";b.shrinkWrapBlocks=d.offsetWidth!==3;c.style.zoom=1}i.removeChild(c);c=d=f=g=null});i.removeChild(n);c=d=f=g=h=i=n=null;return b}();var H=/(?:\{[\s\S]*\}|\[[\s\S]*\])$/,I=/([A-Z])/g;p.extend({cache:{},deletedIds:[],uuid:0,expando:"JFBase"+(p.fn.jfbase+Math.random()).replace(/\D/g,""),noData:{embed:true,object:"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000",applet:true},hasData:function(a){a=a.nodeType?p.cache[a[p.expando]]:a[p.expando];return!!a&&!K(a)},data:function(a,c,d,e){if(!p.acceptData(a)){return}var f,g,h=p.expando,i=typeof c==="string",j=a.nodeType,k=j?p.cache:a,l=j?a[h]:a[h]&&h;if((!l||!k[l]||!e&&!k[l].data)&&i&&d===b){return}if(!l){if(j){a[h]=l=p.deletedIds.pop()||++p.uuid}else{l=h}}if(!k[l]){k[l]={};if(!j){k[l].toJSON=p.noop}}if(typeof c==="object"||typeof c==="function"){if(e){k[l]=p.extend(k[l],c)}else{k[l].data=p.extend(k[l].data,c)}}f=k[l];if(!e){if(!f.data){f.data={}}f=f.data}if(d!==b){f[p.camelCase(c)]=d}if(i){g=f[c];if(g==null){g=f[p.camelCase(c)]}}else{g=f}return g},removeData:function(a,b,c){if(!p.acceptData(a)){return}var d,e,f,g=a.nodeType,h=g?p.cache:a,i=g?a[p.expando]:p.expando;if(!h[i]){return}if(b){d=c?h[i]:h[i].data;if(d){if(!p.isArray(b)){if(b in d){b=[b]}else{b=p.camelCase(b);if(b in d){b=[b]}else{b=b.split(" ")}}}for(e=0,f=b.length;e<f;e++){delete d[b[e]]}if(!(c?K:p.isEmptyObject)(d)){return}}}if(!c){delete h[i].data;if(!K(h[i])){return}}if(g){p.cleanData([a],true)}else if(p.support.deleteExpando||h!=h.window){delete h[i]}else{h[i]=null}},_data:function(a,b,c){return p.data(a,b,c,true)},acceptData:function(a){var b=a.nodeName&&p.noData[a.nodeName.toLowerCase()];return!b||b!==true&&a.getAttribute("classid")===b}});p.fn.extend({data:function(a,c){var d,e,f,g,h,i=this[0],j=0,k=null;if(a===b){if(this.length){k=p.data(i);if(i.nodeType===1&&!p._data(i,"parsedAttrs")){f=i.attributes;for(h=f.length;j<h;j++){g=f[j].name;if(g.indexOf("data-")===0){g=p.camelCase(g.substring(5));J(i,g,k[g])}}p._data(i,"parsedAttrs",true)}}return k}if(typeof a==="object"){return this.each(function(){p.data(this,a)})}d=a.split(".",2);d[1]=d[1]?"."+d[1]:"";e=d[1]+"!";return p.access(this,function(c){if(c===b){k=this.triggerHandler("getData"+e,[d[0]]);if(k===b&&i){k=p.data(i,a);k=J(i,a,k)}return k===b&&d[1]?this.data(d[0]):k}d[1]=c;this.each(function(){var b=p(this);b.triggerHandler("setData"+e,d);p.data(this,a,c);b.triggerHandler("changeData"+e,d)})},null,c,arguments.length>1,null,false)},removeData:function(a){return this.each(function(){p.removeData(this,a)})}});p.extend({queue:function(a,b,c){var d;if(a){b=(b||"fx")+"queue";d=p._data(a,b);if(c){if(!d||p.isArray(c)){d=p._data(a,b,p.makeArray(c))}else{d.push(c)}}return d||[]}},dequeue:function(a,b){b=b||"fx";var c=p.queue(a,b),d=c.length,e=c.shift(),f=p._queueHooks(a,b),g=function(){p.dequeue(a,b)};if(e==="inprogress"){e=c.shift();d--}if(e){if(b==="fx"){c.unshift("inprogress")}delete f.stop;e.call(a,g,f)}if(!d&&f){f.empty.fire()}},_queueHooks:function(a,b){var c=b+"queueHooks";return p._data(a,c)||p._data(a,c,{empty:p.Callbacks("once memory").add(function(){p.removeData(a,b+"queue",true);p.removeData(a,c,true)})})}});p.fn.extend({queue:function(a,c){var d=2;if(typeof a!=="string"){c=a;a="fx";d--}if(arguments.length<d){return p.queue(this[0],a)}return c===b?this:this.each(function(){var b=p.queue(this,a,c);p._queueHooks(this,a);if(a==="fx"&&b[0]!=="inprogress"){p.dequeue(this,a)}})},dequeue:function(a){return this.each(function(){p.dequeue(this,a)})},delay:function(a,b){a=p.fx?p.fx.speeds[a]||a:a;b=b||"fx";return this.queue(b,function(b,c){var d=setTimeout(b,a);c.stop=function(){clearTimeout(d)}})},clearQueue:function(a){return this.queue(a||"fx",[])},promise:function(a,c){var d,e=1,f=p.Deferred(),g=this,h=this.length,i=function(){if(!--e){f.resolveWith(g,[g])}};if(typeof a!=="string"){c=a;a=b}a=a||"fx";while(h--){d=p._data(g[h],a+"queueHooks");if(d&&d.empty){e++;d.empty.add(i)}}i();return f.promise(c)}});var L,M,N,O=/[\t\r\n]/g,P=/\r/g,Q=/^(?:button|input)$/i,R=/^(?:button|input|object|select|textarea)$/i,S=/^a(?:rea|)$/i,T=/^(?:autofocus|autoplay|async|checked|controls|defer|disabled|hidden|loop|multiple|open|readonly|required|scoped|selected)$/i,U=p.support.getSetAttribute;p.fn.extend({attr:function(a,b){return p.access(this,p.attr,a,b,arguments.length>1)},removeAttr:function(a){return this.each(function(){p.removeAttr(this,a)})},prop:function(a,b){return p.access(this,p.prop,a,b,arguments.length>1)},removeProp:function(a){a=p.propFix[a]||a;return this.each(function(){try{this[a]=b;delete this[a]}catch(c){}})},addClass:function(a){var b,c,d,e,f,g,h;if(p.isFunction(a)){return this.each(function(b){p(this).addClass(a.call(this,b,this.className))})}if(a&&typeof a==="string"){b=a.split(s);for(c=0,d=this.length;c<d;c++){e=this[c];if(e.nodeType===1){if(!e.className&&b.length===1){e.className=a}else{f=" "+e.className+" ";for(g=0,h=b.length;g<h;g++){if(!~f.indexOf(" "+b[g]+" ")){f+=b[g]+" "}}e.className=p.trim(f)}}}}return this},removeClass:function(a){var c,d,e,f,g,h,i;if(p.isFunction(a)){return this.each(function(b){p(this).removeClass(a.call(this,b,this.className))})}if(a&&typeof a==="string"||a===b){c=(a||"").split(s);for(h=0,i=this.length;h<i;h++){e=this[h];if(e.nodeType===1&&e.className){d=(" "+e.className+" ").replace(O," ");for(f=0,g=c.length;f<g;f++){while(d.indexOf(" "+c[f]+" ")>-1){d=d.replace(" "+c[f]+" "," ")}}e.className=a?p.trim(d):""}}}return this},toggleClass:function(a,b){var c=typeof a,d=typeof b==="boolean";if(p.isFunction(a)){return this.each(function(c){p(this).toggleClass(a.call(this,c,this.className,b),b)})}return this.each(function(){if(c==="string"){var e,f=0,g=p(this),h=b,i=a.split(s);while(e=i[f++]){h=d?h:!g.hasClass(e);g[h?"addClass":"removeClass"](e)}}else if(c==="undefined"||c==="boolean"){if(this.className){p._data(this,"__className__",this.className)}this.className=this.className||a===false?"":p._data(this,"__className__")||""}})},hasClass:function(a){var b=" "+a+" ",c=0,d=this.length;for(;c<d;c++){if(this[c].nodeType===1&&(" "+this[c].className+" ").replace(O," ").indexOf(b)>-1){return true}}return false},val:function(a){var c,d,e,f=this[0];if(!arguments.length){if(f){c=p.valHooks[f.type]||p.valHooks[f.nodeName.toLowerCase()];if(c&&"get"in c&&(d=c.get(f,"value"))!==b){return d}d=f.value;return typeof d==="string"?d.replace(P,""):d==null?"":d}return}e=p.isFunction(a);return this.each(function(d){var f,g=p(this);if(this.nodeType!==1){return}if(e){f=a.call(this,d,g.val())}else{f=a}if(f==null){f=""}else if(typeof f==="number"){f+=""}else if(p.isArray(f)){f=p.map(f,function(a){return a==null?"":a+""})}c=p.valHooks[this.type]||p.valHooks[this.nodeName.toLowerCase()];if(!c||!("set"in c)||c.set(this,f,"value")===b){this.value=f}})}});p.extend({valHooks:{option:{get:function(a){var b=a.attributes.value;return!b||b.specified?a.value:a.text}},select:{get:function(a){var b,c,d,e,f=a.selectedIndex,g=[],h=a.options,i=a.type==="select-one";if(f<0){return null}c=i?f:0;d=i?f+1:h.length;for(;c<d;c++){e=h[c];if(e.selected&&(p.support.optDisabled?!e.disabled:e.getAttribute("disabled")===null)&&(!e.parentNode.disabled||!p.nodeName(e.parentNode,"optgroup"))){b=p(e).val();if(i){return b}g.push(b)}}if(i&&!g.length&&h.length){return p(h[f]).val()}return g},set:function(a,b){var c=p.makeArray(b);p(a).find("option").each(function(){this.selected=p.inArray(p(this).val(),c)>=0});if(!c.length){a.selectedIndex=-1}return c}}},attrFn:{},attr:function(a,c,d,e){var f,g,h,i=a.nodeType;if(!a||i===3||i===8||i===2){return}if(e&&p.isFunction(p.fn[c])){return p(a)[c](d)}if(typeof a.getAttribute==="undefined"){return p.prop(a,c,d)}h=i!==1||!p.isXMLDoc(a);if(h){c=c.toLowerCase();g=p.attrHooks[c]||(T.test(c)?M:L)}if(d!==b){if(d===null){p.removeAttr(a,c);return}else if(g&&"set"in g&&h&&(f=g.set(a,d,c))!==b){return f}else{a.setAttribute(c,""+d);return d}}else if(g&&"get"in g&&h&&(f=g.get(a,c))!==null){return f}else{f=a.getAttribute(c);return f===null?b:f}},removeAttr:function(a,b){var c,d,e,f,g=0;if(b&&a.nodeType===1){d=b.split(s);for(;g<d.length;g++){e=d[g];if(e){c=p.propFix[e]||e;f=T.test(e);if(!f){p.attr(a,e,"")}a.removeAttribute(U?e:c);if(f&&c in a){a[c]=false}}}}},attrHooks:{type:{set:function(a,b){if(Q.test(a.nodeName)&&a.parentNode){p.error("type property can't be changed")}else if(!p.support.radioValue&&b==="radio"&&p.nodeName(a,"input")){var c=a.value;a.setAttribute("type",b);if(c){a.value=c}return b}}},value:{get:function(a,b){if(L&&p.nodeName(a,"button")){return L.get(a,b)}return b in a?a.value:null},set:function(a,b,c){if(L&&p.nodeName(a,"button")){return L.set(a,b,c)}a.value=b}}},propFix:{tabindex:"tabIndex",readonly:"readOnly","for":"htmlFor","class":"className",maxlength:"maxLength",cellspacing:"cellSpacing",cellpadding:"cellPadding",rowspan:"rowSpan",colspan:"colSpan",usemap:"useMap",frameborder:"frameBorder",contenteditable:"contentEditable"},prop:function(a,c,d){var e,f,g,h=a.nodeType;if(!a||h===3||h===8||h===2){return}g=h!==1||!p.isXMLDoc(a);if(g){c=p.propFix[c]||c;f=p.propHooks[c]}if(d!==b){if(f&&"set"in f&&(e=f.set(a,d,c))!==b){return e}else{return a[c]=d}}else{if(f&&"get"in f&&(e=f.get(a,c))!==null){return e}else{return a[c]}}},propHooks:{tabIndex:{get:function(a){var c=a.getAttributeNode("tabindex");return c&&c.specified?parseInt(c.value,10):R.test(a.nodeName)||S.test(a.nodeName)&&a.href?0:b}}}});M={get:function(a,c){var d,e=p.prop(a,c);return e===true||typeof e!=="boolean"&&(d=a.getAttributeNode(c))&&d.nodeValue!==false?c.toLowerCase():b},set:function(a,b,c){var d;if(b===false){p.removeAttr(a,c)}else{d=p.propFix[c]||c;if(d in a){a[d]=true}a.setAttribute(c,c.toLowerCase())}return c}};if(!U){N={name:true,id:true,coords:true};L=p.valHooks.button={get:function(a,c){var d;d=a.getAttributeNode(c);return d&&(N[c]?d.value!=="":d.specified)?d.value:b},set:function(a,b,c){var d=a.getAttributeNode(c);if(!d){d=e.createAttribute(c);a.setAttributeNode(d)}return d.value=b+""}};p.each(["width","height"],function(a,b){p.attrHooks[b]=p.extend(p.attrHooks[b],{set:function(a,c){if(c===""){a.setAttribute(b,"auto");return c}}})});p.attrHooks.contenteditable={get:L.get,set:function(a,b,c){if(b===""){b="false"}L.set(a,b,c)}}}if(!p.support.hrefNormalized){p.each(["href","src","width","height"],function(a,c){p.attrHooks[c]=p.extend(p.attrHooks[c],{get:function(a){var d=a.getAttribute(c,2);return d===null?b:d}})})}if(!p.support.style){p.attrHooks.style={get:function(a){return a.style.cssText.toLowerCase()||b},set:function(a,b){return a.style.cssText=""+b}}}if(!p.support.optSelected){p.propHooks.selected=p.extend(p.propHooks.selected,{get:function(a){var b=a.parentNode;if(b){b.selectedIndex;if(b.parentNode){b.parentNode.selectedIndex}}return null}})}if(!p.support.enctype){p.propFix.enctype="encoding"}if(!p.support.checkOn){p.each(["radio","checkbox"],function(){p.valHooks[this]={get:function(a){return a.getAttribute("value")===null?"on":a.value}}})}p.each(["radio","checkbox"],function(){p.valHooks[this]=p.extend(p.valHooks[this],{set:function(a,b){if(p.isArray(b)){return a.checked=p.inArray(p(a).val(),b)>=0}}})});var V=/^(?:textarea|input|select)$/i,W=/^([^\.]*|)(?:\.(.+)|)$/,X=/(?:^|\s)hover(\.\S+|)\b/,Y=/^key/,Z=/^(?:mouse|contextmenu)|click/,$=/^(?:focusinfocus|focusoutblur)$/,_=function(a){return p.event.special.hover?a:a.replace(X,"mouseenter$1 mouseleave$1")};p.event={add:function(a,c,d,e,f){var g,h,i,j,k,l,m,n,o,q,r;if(a.nodeType===3||a.nodeType===8||!c||!d||!(g=p._data(a))){return}if(d.handler){o=d;d=o.handler;f=o.selector}if(!d.guid){d.guid=p.guid++}i=g.events;if(!i){g.events=i={}}h=g.handle;if(!h){g.handle=h=function(a){return typeof p!=="undefined"&&(!a||p.event.triggered!==a.type)?p.event.dispatch.apply(h.elem,arguments):b};h.elem=a}c=p.trim(_(c)).split(" ");for(j=0;j<c.length;j++){k=W.exec(c[j])||[];l=k[1];m=(k[2]||"").split(".").sort();r=p.event.special[l]||{};l=(f?r.delegateType:r.bindType)||l;r=p.event.special[l]||{};n=p.extend({type:l,origType:k[1],data:e,handler:d,guid:d.guid,selector:f,namespace:m.join(".")},o);q=i[l];if(!q){q=i[l]=[];q.delegateCount=0;if(!r.setup||r.setup.call(a,e,m,h)===false){if(a.addEventListener){a.addEventListener(l,h,false)}else if(a.attachEvent){a.attachEvent("on"+l,h)}}}if(r.add){r.add.call(a,n);if(!n.handler.guid){n.handler.guid=d.guid}}if(f){q.splice(q.delegateCount++,0,n)}else{q.push(n)}p.event.global[l]=true}a=null},global:{},remove:function(a,b,c,d,e){var f,g,h,i,j,k,l,m,n,o,q,r=p.hasData(a)&&p._data(a);if(!r||!(m=r.events)){return}b=p.trim(_(b||"")).split(" ");for(f=0;f<b.length;f++){g=W.exec(b[f])||[];h=i=g[1];j=g[2];if(!h){for(h in m){p.event.remove(a,h+b[f],c,d,true)}continue}n=p.event.special[h]||{};h=(d?n.delegateType:n.bindType)||h;o=m[h]||[];k=o.length;j=j?new RegExp("(^|\\.)"+j.split(".").sort().join("\\.(?:.*\\.|)")+"(\\.|$)"):null;for(l=0;l<o.length;l++){q=o[l];if((e||i===q.origType)&&(!c||c.guid===q.guid)&&(!j||j.test(q.namespace))&&(!d||d===q.selector||d==="**"&&q.selector)){o.splice(l--,1);if(q.selector){o.delegateCount--}if(n.remove){n.remove.call(a,q)}}}if(o.length===0&&k!==o.length){if(!n.teardown||n.teardown.call(a,j,r.handle)===false){p.removeEvent(a,h,r.handle)}delete m[h]}}if(p.isEmptyObject(m)){delete r.handle;p.removeData(a,"events",true)}},customEvent:{getData:true,setData:true,changeData:true},trigger:function(c,d,f,g){if(f&&(f.nodeType===3||f.nodeType===8)){return}var h,i,j,k,l,m,n,o,q,r,s=c.type||c,t=[];if($.test(s+p.event.triggered)){return}if(s.indexOf("!")>=0){s=s.slice(0,-1);i=true}if(s.indexOf(".")>=0){t=s.split(".");s=t.shift();t.sort()}if((!f||p.event.customEvent[s])&&!p.event.global[s]){return}c=typeof c==="object"?c[p.expando]?c:new p.Event(s,c):new p.Event(s);c.type=s;c.isTrigger=true;c.exclusive=i;c.namespace=t.join(".");c.namespace_re=c.namespace?new RegExp("(^|\\.)"+t.join("\\.(?:.*\\.|)")+"(\\.|$)"):null;m=s.indexOf(":")<0?"on"+s:"";if(!f){h=p.cache;for(j in h){if(h[j].events&&h[j].events[s]){p.event.trigger(c,d,h[j].handle.elem,true)}}return}c.result=b;if(!c.target){c.target=f}d=d!=null?p.makeArray(d):[];d.unshift(c);n=p.event.special[s]||{};if(n.trigger&&n.trigger.apply(f,d)===false){return}q=[[f,n.bindType||s]];if(!g&&!n.noBubble&&!p.isWindow(f)){r=n.delegateType||s;k=$.test(r+s)?f:f.parentNode;for(l=f;k;k=k.parentNode){q.push([k,r]);l=k}if(l===(f.ownerDocument||e)){q.push([l.defaultView||l.parentWindow||a,r])}}for(j=0;j<q.length&&!c.isPropagationStopped();j++){k=q[j][0];c.type=q[j][1];o=(p._data(k,"events")||{})[c.type]&&p._data(k,"handle");if(o){o.apply(k,d)}o=m&&k[m];if(o&&p.acceptData(k)&&o.apply(k,d)===false){c.preventDefault()}}c.type=s;if(!g&&!c.isDefaultPrevented()){if((!n._default||n._default.apply(f.ownerDocument,d)===false)&&!(s==="click"&&p.nodeName(f,"a"))&&p.acceptData(f)){if(m&&f[s]&&(s!=="focus"&&s!=="blur"||c.target.offsetWidth!==0)&&!p.isWindow(f)){l=f[m];if(l){f[m]=null}p.event.triggered=s;f[s]();p.event.triggered=b;if(l){f[m]=l}}}}return c.result},dispatch:function(c){c=p.event.fix(c||a.event);var d,e,f,g,h,i,j,k,l,m,n=(p._data(this,"events")||{})[c.type]||[],o=n.delegateCount,q=[].slice.call(arguments),r=!c.exclusive&&!c.namespace,s=p.event.special[c.type]||{},t=[];q[0]=c;c.delegateTarget=this;if(s.preDispatch&&s.preDispatch.call(this,c)===false){return}if(o&&!(c.button&&c.type==="click")){for(f=c.target;f!=this;f=f.parentNode||this){if(f.disabled!==true||c.type!=="click"){h={};j=[];for(d=0;d<o;d++){k=n[d];l=k.selector;if(h[l]===b){h[l]=p(l,this).index(f)>=0}if(h[l]){j.push(k)}}if(j.length){t.push({elem:f,matches:j})}}}}if(n.length>o){t.push({elem:this,matches:n.slice(o)})}for(d=0;d<t.length&&!c.isPropagationStopped();d++){i=t[d];c.currentTarget=i.elem;for(e=0;e<i.matches.length&&!c.isImmediatePropagationStopped();e++){k=i.matches[e];if(r||!c.namespace&&!k.namespace||c.namespace_re&&c.namespace_re.test(k.namespace)){c.data=k.data;c.handleObj=k;g=((p.event.special[k.origType]||{}).handle||k.handler).apply(i.elem,q);if(g!==b){c.result=g;if(g===false){c.preventDefault();c.stopPropagation()}}}}}if(s.postDispatch){s.postDispatch.call(this,c)}return c.result},props:"attrChange attrName relatedNode srcElement altKey bubbles cancelable ctrlKey currentTarget eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),fixHooks:{},keyHooks:{props:"char charCode key keyCode".split(" "),filter:function(a,b){if(a.which==null){a.which=b.charCode!=null?b.charCode:b.keyCode}return a}},mouseHooks:{props:"button buttons clientX clientY fromElement offsetX offsetY pageX pageY screenX screenY toElement".split(" "),filter:function(a,c){var d,f,g,h=c.button,i=c.fromElement;if(a.pageX==null&&c.clientX!=null){d=a.target.ownerDocument||e;f=d.documentElement;g=d.body;a.pageX=c.clientX+(f&&f.scrollLeft||g&&g.scrollLeft||0)-(f&&f.clientLeft||g&&g.clientLeft||0);a.pageY=c.clientY+(f&&f.scrollTop||g&&g.scrollTop||0)-(f&&f.clientTop||g&&g.clientTop||0)}if(!a.relatedTarget&&i){a.relatedTarget=i===a.target?c.toElement:i}if(!a.which&&h!==b){a.which=h&1?1:h&2?3:h&4?2:0}return a}},fix:function(a){if(a[p.expando]){return a}var b,c,d=a,f=p.event.fixHooks[a.type]||{},g=f.props?this.props.concat(f.props):this.props;a=p.Event(d);for(b=g.length;b;){c=g[--b];a[c]=d[c]}if(!a.target){a.target=d.srcElement||e}if(a.target.nodeType===3){a.target=a.target.parentNode}a.metaKey=!!a.metaKey;return f.filter?f.filter(a,d):a},special:{load:{noBubble:true},focus:{delegateType:"focusin"},blur:{delegateType:"focusout"},beforeunload:{setup:function(a,b,c){if(p.isWindow(this)){this.onbeforeunload=c}},teardown:function(a,b){if(this.onbeforeunload===b){this.onbeforeunload=null}}}},simulate:function(a,b,c,d){var e=p.extend(new p.Event,c,{type:a,isSimulated:true,originalEvent:{}});if(d){p.event.trigger(e,null,b)}else{p.event.dispatch.call(b,e)}if(e.isDefaultPrevented()){c.preventDefault()}}};p.event.handle=p.event.dispatch;p.removeEvent=e.removeEventListener?function(a,b,c){if(a.removeEventListener){a.removeEventListener(b,c,false)}}:function(a,b,c){var d="on"+b;if(a.detachEvent){if(typeof a[d]==="undefined"){a[d]=null}a.detachEvent(d,c)}};p.Event=function(a,b){if(!(this instanceof p.Event)){return new p.Event(a,b)}if(a&&a.type){this.originalEvent=a;this.type=a.type;this.isDefaultPrevented=a.defaultPrevented||a.returnValue===false||a.getPreventDefault&&a.getPreventDefault()?bb:ab}else{this.type=a}if(b){p.extend(this,b)}this.timeStamp=a&&a.timeStamp||p.now();this[p.expando]=true};p.Event.prototype={preventDefault:function(){this.isDefaultPrevented=bb;var a=this.originalEvent;if(!a){return}if(a.preventDefault){a.preventDefault()}else{a.returnValue=false}},stopPropagation:function(){this.isPropagationStopped=bb;var a=this.originalEvent;if(!a){return}if(a.stopPropagation){a.stopPropagation()}a.cancelBubble=true},stopImmediatePropagation:function(){this.isImmediatePropagationStopped=bb;this.stopPropagation()},isDefaultPrevented:ab,isPropagationStopped:ab,isImmediatePropagationStopped:ab};p.each({mouseenter:"mouseover",mouseleave:"mouseout"},function(a,b){p.event.special[a]={delegateType:b,bindType:b,handle:function(a){var c,d=this,e=a.relatedTarget,f=a.handleObj,g=f.selector;if(!e||e!==d&&!p.contains(d,e)){a.type=f.origType;c=f.handler.apply(this,arguments);a.type=b}return c}}});if(!p.support.submitBubbles){p.event.special.submit={setup:function(){if(p.nodeName(this,"form")){return false}p.event.add(this,"click._submit keypress._submit",function(a){var c=a.target,d=p.nodeName(c,"input")||p.nodeName(c,"button")?c.form:b;if(d&&!p._data(d,"_submit_attached")){p.event.add(d,"submit._submit",function(a){a._submit_bubble=true});p._data(d,"_submit_attached",true)}})},postDispatch:function(a){if(a._submit_bubble){delete a._submit_bubble;if(this.parentNode&&!a.isTrigger){p.event.simulate("submit",this.parentNode,a,true)}}},teardown:function(){if(p.nodeName(this,"form")){return false}p.event.remove(this,"._submit")}}}if(!p.support.changeBubbles){p.event.special.change={setup:function(){if(V.test(this.nodeName)){if(this.type==="checkbox"||this.type==="radio"){p.event.add(this,"propertychange._change",function(a){if(a.originalEvent.propertyName==="checked"){this._just_changed=true}});p.event.add(this,"click._change",function(a){if(this._just_changed&&!a.isTrigger){this._just_changed=false}p.event.simulate("change",this,a,true)})}return false}p.event.add(this,"beforeactivate._change",function(a){var b=a.target;if(V.test(b.nodeName)&&!p._data(b,"_change_attached")){p.event.add(b,"change._change",function(a){if(this.parentNode&&!a.isSimulated&&!a.isTrigger){p.event.simulate("change",this.parentNode,a,true)}});p._data(b,"_change_attached",true)}})},handle:function(a){var b=a.target;if(this!==b||a.isSimulated||a.isTrigger||b.type!=="radio"&&b.type!=="checkbox"){return a.handleObj.handler.apply(this,arguments)}},teardown:function(){p.event.remove(this,"._change");return!V.test(this.nodeName)}}}if(!p.support.focusinBubbles){p.each({focus:"focusin",blur:"focusout"},function(a,b){var c=0,d=function(a){p.event.simulate(b,a.target,p.event.fix(a),true)};p.event.special[b]={setup:function(){if(c++===0){e.addEventListener(a,d,true)}},teardown:function(){if(--c===0){e.removeEventListener(a,d,true)}}}})}p.fn.extend({on:function(a,c,d,e,f){var g,h;if(typeof a==="object"){if(typeof c!=="string"){d=d||c;c=b}for(h in a){this.on(h,c,d,a[h],f)}return this}if(d==null&&e==null){e=c;d=c=b}else if(e==null){if(typeof c==="string"){e=d;d=b}else{e=d;d=c;c=b}}if(e===false){e=ab}else if(!e){return this}if(f===1){g=e;e=function(a){p().off(a);return g.apply(this,arguments)};e.guid=g.guid||(g.guid=p.guid++)}return this.each(function(){p.event.add(this,a,e,d,c)})},one:function(a,b,c,d){return this.on(a,b,c,d,1)},off:function(a,c,d){var e,f;if(a&&a.preventDefault&&a.handleObj){e=a.handleObj;p(a.delegateTarget).off(e.namespace?e.origType+"."+e.namespace:e.origType,e.selector,e.handler);return this}if(typeof a==="object"){for(f in a){this.off(f,c,a[f])}return this}if(c===false||typeof c==="function"){d=c;c=b}if(d===false){d=ab}return this.each(function(){p.event.remove(this,a,d,c)})},bind:function(a,b,c){return this.on(a,null,b,c)},unbind:function(a,b){return this.off(a,null,b)},live:function(a,b,c){p(this.context).on(a,this.selector,b,c);return this},die:function(a,b){p(this.context).off(a,this.selector||"**",b);return this},delegate:function(a,b,c,d){return this.on(b,a,c,d)},undelegate:function(a,b,c){return arguments.length==1?this.off(a,"**"):this.off(b,a||"**",c)},trigger:function(a,b){return this.each(function(){p.event.trigger(a,b,this)})},triggerHandler:function(a,b){if(this[0]){return p.event.trigger(a,b,this[0],true)}},toggle:function(a){var b=arguments,c=a.guid||p.guid++,d=0,e=function(c){var e=(p._data(this,"lastToggle"+a.guid)||0)%d;p._data(this,"lastToggle"+a.guid,e+1);c.preventDefault();return b[e].apply(this,arguments)||false};e.guid=c;while(d<b.length){b[d++].guid=c}return this.click(e)},hover:function(a,b){return this.mouseenter(a).mouseleave(b||a)}});p.each(("blur focus focusin focusout load resize scroll unload click dblclick "+"mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave "+"change select submit keydown keypress keyup error contextmenu").split(" "),function(a,b){p.fn[b]=function(a,c){if(c==null){c=a;a=null}return arguments.length>0?this.on(b,null,a,c):this.trigger(b)};if(Y.test(b)){p.event.fixHooks[b]=p.event.keyHooks}if(Z.test(b)){p.event.fixHooks[b]=p.event.mouseHooks}});(function(a,b){function $(a,b,c,d){c=c||[];b=b||q;var e,f,g,j,k=b.nodeType;if(k!==1&&k!==9){return[]}if(!a||typeof a!=="string"){return c}g=h(b);if(!g&&!d){if(e=L.exec(a)){if(j=e[1]){if(k===9){f=b.getElementById(j);if(f&&f.parentNode){if(f.id===j){c.push(f);return c}}else{return c}}else{if(b.ownerDocument&&(f=b.ownerDocument.getElementById(j))&&i(b,f)&&f.id===j){c.push(f);return c}}}else if(e[2]){u.apply(c,t.call(b.getElementsByTagName(a),0));return c}else if((j=e[3])&&X&&b.getElementsByClassName){u.apply(c,t.call(b.getElementsByClassName(j),0));return c}}}return kb(a,b,c,d,g)}function _(a){return function(b){var c=b.nodeName.toLowerCase();return c==="input"&&b.type===a}}function ab(a){return function(b){var c=b.nodeName.toLowerCase();return(c==="input"||c==="button")&&b.type===a}}function bb(a,b,c){if(a===b){return c}var d=a.nextSibling;while(d){if(d===b){return-1}d=d.nextSibling}return 1}function cb(a,b,c,d){var e,g,h,i,j,k,l,m,n,p,r=!c&&b!==q,s=(r?"<s>":"")+a.replace(H,"$1<s>"),u=y[o][s];if(u){return d?0:t.call(u,0)}j=a;k=[];m=0;n=f.preFilter;p=f.filter;while(j){if(!e||(g=I.exec(j))){if(g){j=j.slice(g[0].length);h.selector=l}k.push(h=[]);l="";if(r){j=" "+j}}e=false;if(g=J.exec(j)){l+=g[0];j=j.slice(g[0].length);e=h.push({part:g.pop().replace(H," "),string:g[0],captures:g})}for(i in p){if((g=S[i].exec(j))&&(!n[i]||(g=n[i](g,b,c)))){l+=g[0];j=j.slice(g[0].length);e=h.push({part:i,string:g.shift(),captures:g})}}if(!e){break}}if(l){h.selector=l}return d?j.length:j?$.error(a):t.call(y(s,k),0)}function db(a,b,e,f){var g=b.dir,h=s++;if(!a){a=function(a){return a===e}}return b.first?function(b){while(b=b[g]){if(b.nodeType===1){return a(b)&&b}}}:f?function(b){while(b=b[g]){if(b.nodeType===1){if(a(b)){return b}}}}:function(b){var e,f=h+"."+c,i=f+"."+d;while(b=b[g]){if(b.nodeType===1){if((e=b[o])===i){return b.sizset}else if(typeof e==="string"&&e.indexOf(f)===0){if(b.sizset){return b}}else{b[o]=i;if(a(b)){b.sizset=true;return b}b.sizset=false}}}}}function eb(a,b){return a?function(c){var d=b(c);return d&&a(d===true?c:d)}:b}function fb(a,b,c){var d,e,g=0;for(;d=a[g];g++){if(f.relative[d.part]){e=db(e,f.relative[d.part],b,c)}else{e=eb(e,f.filter[d.part].apply(null,d.captures.concat(b,c)))}}return e}function gb(a){return function(b){var c,d=0;for(;c=a[d];d++){if(c(b)){return true}}return false}}function hb(a,b,c,d){var e=0,f=b.length;for(;e<f;e++){$(a,b[e],c,d)}}function ib(a,b,c,d,e,g){var h,i=f.setFilters[b.toLowerCase()];if(!i){$.error(b)}if(a||!(h=e)){hb(a||"*",d,h=[],e)}return h.length>0?i(h,c,g):[]}function jb(a,c,d,e){var f,g,h,i,j,k,l,m,n,o,p,q,r,s=0,t=a.length,v=S["POS"],w=new RegExp("^"+v.source+"(?!"+A+")","i"),x=function(){var a=1,c=arguments.length-2;for(;a<c;a++){if(arguments[a]===b){n[a]=b}}};for(;s<t;s++){f=a[s];g="";m=e;for(h=0,i=f.length;h<i;h++){j=f[h];k=j.string;if(j.part==="PSEUDO"){v.exec("");l=0;while(n=v.exec(k)){o=true;p=v.lastIndex=n.index+n[0].length;if(p>l){g+=k.slice(l,n.index);l=p;q=[c];if(J.test(g)){if(m){q=m}m=e}if(r=O.test(g)){g=g.slice(0,-5).replace(J,"$&*");l++}if(n.length>1){n[0].replace(w,x)}m=ib(g,n[1],n[2],q,m,r)}g=""}}if(!o){g+=k}o=false}if(g){if(J.test(g)){hb(g,m||[c],d,e)}else{$(g,c,d,e?e.concat(m):m)}}else{u.apply(d,m)}}return t===1?d:$.uniqueSort(d)}function kb(a,b,e,g,h){a=a.replace(H,"$1");var i,k,l,m,n,o,p,q,r,s,v=cb(a,b,h),w=b.nodeType;if(S["POS"].test(a)){return jb(v,b,e,g)}if(g){i=t.call(g,0)}else if(v.length===1){if((o=t.call(v[0],0)).length>2&&(p=o[0]).part==="ID"&&w===9&&!h&&f.relative[o[1].part]){b=f.find["ID"](p.captures[0].replace(R,""),b,h)[0];if(!b){return e}a=a.slice(o.shift().string.length)}r=(v=N.exec(o[0].string))&&!v.index&&b.parentNode||b;q="";for(n=o.length-1;n>=0;n--){p=o[n];s=p.part;q=p.string+q;if(f.relative[s]){break}if(f.order.test(s)){i=f.find[s](p.captures[0].replace(R,""),r,h);if(i==null){continue}else{a=a.slice(0,a.length-q.length)+q.replace(S[s],"");if(!a){u.apply(e,t.call(i,0))}break}}}}if(a){k=j(a,b,h);c=k.dirruns++;if(i==null){i=f.find["TAG"]("*",N.test(a)&&b.parentNode||b)}for(n=0;m=i[n];n++){d=k.runs++;if(k(m)){e.push(m)}}}return e}var c,d,e,f,g,h,i,j,k,l,m=true,n="undefined",o=("sizcache"+Math.random()).replace(".",""),q=a.document,r=q.documentElement,s=0,t=[].slice,u=[].push,v=function(a,b){a[o]=b||true;return a},w=function(){var a={},b=[];return v(function(c,d){if(b.push(c)>f.cacheLength){delete a[b.shift()]}return a[c]=d},a)},x=w(),y=w(),z=w(),A="[\\x20\\t\\r\\n\\f]",B="(?:\\\\.|[-\\w]|[^\\x00-\\xa0])+",C=B.replace("w","w#"),D="([*^$|!~]?=)",E="\\["+A+"*("+B+")"+A+"*(?:"+D+A+"*(?:(['\"])((?:\\\\.|[^\\\\])*?)\\3|("+C+")|)|)"+A+"*\\]",F=":("+B+")(?:\\((?:(['\"])((?:\\\\.|[^\\\\])*?)\\2|([^()[\\]]*|(?:(?:"+E+")|[^:]|\\\\.)*|.*))\\)|)",G=":(nth|eq|gt|lt|first|last|even|odd)(?:\\(((?:-\\d)?\\d*)\\)|)(?=[^-]|$)",H=new RegExp("^"+A+"+|((?:^|[^\\\\])(?:\\\\.)*)"+A+"+$","g"),I=new RegExp("^"+A+"*,"+A+"*"),J=new RegExp("^"+A+"*([\\x20\\t\\r\\n\\f>+~])"+A+"*"),K=new RegExp(F),L=/^(?:#([\w\-]+)|(\w+)|\.([\w\-]+))$/,M=/^:not/,N=/[\x20\t\r\n\f]*[+~]/,O=/:not\($/,P=/h\d/i,Q=/input|select|textarea|button/i,R=/\\(?!\\)/g,S={ID:new RegExp("^#("+B+")"),CLASS:new RegExp("^\\.("+B+")"),NAME:new RegExp("^\\[name=['\"]?("+B+")['\"]?\\]"),TAG:new RegExp("^("+B.replace("w","w*")+")"),ATTR:new RegExp("^"+E),PSEUDO:new RegExp("^"+F),CHILD:new RegExp("^:(only|nth|last|first)-child(?:\\("+A+"*(even|odd|(([+-]|)(\\d*)n|)"+A+"*(?:([+-]|)"+A+"*(\\d+)|))"+A+"*\\)|)","i"),POS:new RegExp(G,"ig"),needsContext:new RegExp("^"+A+"*[>+~]|"+G,"i")},T=function(a){var b=q.createElement("div");try{return a(b)}catch(c){return false}finally{b=null}},U=T(function(a){a.appendChild(q.createComment(""));return!a.getElementsByTagName("*").length}),V=T(function(a){a.innerHTML="<a href='#'></a>";return a.firstChild&&typeof a.firstChild.getAttribute!==n&&a.firstChild.getAttribute("href")==="#"}),W=T(function(a){a.innerHTML="<select></select>";var b=typeof a.lastChild.getAttribute("multiple");return b!=="boolean"&&b!=="string"}),X=T(function(a){a.innerHTML="<div class='hidden e'></div><div class='hidden'></div>";if(!a.getElementsByClassName||!a.getElementsByClassName("e").length){return false}a.lastChild.className="e";return a.getElementsByClassName("e").length===2}),Y=T(function(a){a.id=o+0;a.innerHTML="<a name='"+o+"'></a><div name='"+o+"'></div>";r.insertBefore(a,r.firstChild);var b=q.getElementsByName&&q.getElementsByName(o).length===2+q.getElementsByName(o+0).length;e=!q.getElementById(o);r.removeChild(a);return b});try{t.call(r.childNodes,0)[0].nodeType}catch(Z){t=function(a){var b,c=[];for(;b=this[a];a++){c.push(b)}return c}}$.matches=function(a,b){return $(a,null,null,b)};$.matchesSelector=function(a,b){return $(b,null,null,[a]).length>0};g=$.getText=function(a){var b,c="",d=0,e=a.nodeType;if(e){if(e===1||e===9||e===11){if(typeof a.textContent==="string"){return a.textContent}else{for(a=a.firstChild;a;a=a.nextSibling){c+=g(a)}}}else if(e===3||e===4){return a.nodeValue}}else{for(;b=a[d];d++){c+=g(b)}}return c};h=$.isXML=function(b){var c=b&&(b.ownerDocument||b).documentElement;return c?c.nodeName!=="HTML":false};i=$.contains=r.contains?function(a,b){var c=a.nodeType===9?a.documentElement:a,d=b&&b.parentNode;return a===d||!!(d&&d.nodeType===1&&c.contains&&c.contains(d))}:r.compareDocumentPosition?function(a,b){return b&&!!(a.compareDocumentPosition(b)&16)}:function(a,b){while(b=b.parentNode){if(b===a){return true}}return false};$.attr=function(a,b){var c,d=h(a);if(!d){b=b.toLowerCase()}if(f.attrHandle[b]){return f.attrHandle[b](a)}if(W||d){return a.getAttribute(b)}c=a.getAttributeNode(b);return c?typeof a[b]==="boolean"?a[b]?b:null:c.specified?c.value:null:null};f=$.selectors={cacheLength:50,createPseudo:v,match:S,order:new RegExp("ID|TAG"+(Y?"|NAME":"")+(X?"|CLASS":"")),attrHandle:V?{}:{href:function(a){return a.getAttribute("href",2)},type:function(a){return a.getAttribute("type")}},find:{ID:e?function(a,b,c){if(typeof b.getElementById!==n&&!c){var d=b.getElementById(a);return d&&d.parentNode?[d]:[]}}:function(a,c,d){if(typeof c.getElementById!==n&&!d){var e=c.getElementById(a);return e?e.id===a||typeof e.getAttributeNode!==n&&e.getAttributeNode("id").value===a?[e]:b:[]}},TAG:U?function(a,b){if(typeof b.getElementsByTagName!==n){return b.getElementsByTagName(a)}}:function(a,b){var c=b.getElementsByTagName(a);if(a==="*"){var d,e=[],f=0;for(;d=c[f];f++){if(d.nodeType===1){e.push(d)}}return e}return c},NAME:function(a,b){if(typeof b.getElementsByName!==n){return b.getElementsByName(name)}},CLASS:function(a,b,c){if(typeof b.getElementsByClassName!==n&&!c){return b.getElementsByClassName(a)}}},relative:{">":{dir:"parentNode",first:true}," ":{dir:"parentNode"},"+":{dir:"previousSibling",first:true},"~":{dir:"previousSibling"}},preFilter:{ATTR:function(a){a[1]=a[1].replace(R,"");a[3]=(a[4]||a[5]||"").replace(R,"");if(a[2]==="~="){a[3]=" "+a[3]+" "}return a.slice(0,4)},CHILD:function(a){a[1]=a[1].toLowerCase();if(a[1]==="nth"){if(!a[2]){$.error(a[0])}a[3]=+(a[3]?a[4]+(a[5]||1):2*(a[2]==="even"||a[2]==="odd"));a[4]=+(a[6]+a[7]||a[2]==="odd")}else if(a[2]){$.error(a[0])}return a},PSEUDO:function(a,b,c){var d,e;if(S["CHILD"].test(a[0])){return null}if(a[3]){a[2]=a[3]}else if(d=a[4]){if(K.test(d)&&(e=cb(d,b,c,true))&&(e=d.indexOf(")",d.length-e)-d.length)){d=d.slice(0,e);a[0]=a[0].slice(0,e)}a[2]=d}return a.slice(0,3)}},filter:{ID:e?function(a){a=a.replace(R,"");return function(b){return b.getAttribute("id")===a}}:function(a){a=a.replace(R,"");return function(b){var c=typeof b.getAttributeNode!==n&&b.getAttributeNode("id");return c&&c.value===a}},TAG:function(a){if(a==="*"){return function(){return true}}a=a.replace(R,"").toLowerCase();return function(b){return b.nodeName&&b.nodeName.toLowerCase()===a}},CLASS:function(a){var b=x[o][a];if(!b){b=x(a,new RegExp("(^|"+A+")"+a+"("+A+"|$)"))}return function(a){return b.test(a.className||typeof a.getAttribute!==n&&a.getAttribute("class")||"")}},ATTR:function(a,b,c){if(!b){return function(b){return $.attr(b,a)!=null}}return function(d){var e=$.attr(d,a),f=e+"";if(e==null){return b==="!="}switch(b){case"=":return f===c;case"!=":return f!==c;case"^=":return c&&f.indexOf(c)===0;case"*=":return c&&f.indexOf(c)>-1;case"$=":return c&&f.substr(f.length-c.length)===c;case"~=":return(" "+f+" ").indexOf(c)>-1;case"|=":return f===c||f.substr(0,c.length+1)===c+"-"}}},CHILD:function(a,b,c,d){if(a==="nth"){var e=s++;return function(a){var b,f,g=0,h=a;if(c===1&&d===0){return true}b=a.parentNode;if(b&&(b[o]!==e||!a.sizset)){for(h=b.firstChild;h;h=h.nextSibling){if(h.nodeType===1){h.sizset=++g;if(h===a){break}}}b[o]=e}f=a.sizset-d;if(c===0){return f===0}else{return f%c===0&&f/c>=0}}}return function(b){var c=b;switch(a){case"only":case"first":while(c=c.previousSibling){if(c.nodeType===1){return false}}if(a==="first"){return true}c=b;case"last":while(c=c.nextSibling){if(c.nodeType===1){return false}}return true}}},PSEUDO:function(a,b,c,d){var e,g=f.pseudos[a]||f.pseudos[a.toLowerCase()];if(!g){$.error("unsupported pseudo: "+a)}if(!g[o]){if(g.length>1){e=[a,a,"",b];return function(a){return g(a,0,e)}}return g}return g(b,c,d)}},pseudos:{not:v(function(a,b,c){var d=j(a.replace(H,"$1"),b,c);return function(a){return!d(a)}}),enabled:function(a){return a.disabled===false},disabled:function(a){return a.disabled===true},checked:function(a){var b=a.nodeName.toLowerCase();return b==="input"&&!!a.checked||b==="option"&&!!a.selected},selected:function(a){if(a.parentNode){a.parentNode.selectedIndex}return a.selected===true},parent:function(a){return!f.pseudos["empty"](a)},empty:function(a){var b;a=a.firstChild;while(a){if(a.nodeName>"@"||(b=a.nodeType)===3||b===4){return false}a=a.nextSibling}return true},contains:v(function(a){return function(b){return(b.textContent||b.innerText||g(b)).indexOf(a)>-1}}),has:v(function(a){return function(b){return $(a,b).length>0}}),header:function(a){return P.test(a.nodeName)},text:function(a){var b,c;return a.nodeName.toLowerCase()==="input"&&(b=a.type)==="text"&&((c=a.getAttribute("type"))==null||c.toLowerCase()===b)},radio:_("radio"),checkbox:_("checkbox"),file:_("file"),password:_("password"),image:_("image"),submit:ab("submit"),reset:ab("reset"),button:function(a){var b=a.nodeName.toLowerCase();return b==="input"&&a.type==="button"||b==="button"},input:function(a){return Q.test(a.nodeName)},focus:function(a){var b=a.ownerDocument;return a===b.activeElement&&(!b.hasFocus||b.hasFocus())&&!!(a.type||a.href)},active:function(a){return a===a.ownerDocument.activeElement}},setFilters:{first:function(a,b,c){return c?a.slice(1):[a[0]]},last:function(a,b,c){var d=a.pop();return c?a:[d]},even:function(a,b,c){var d=[],e=c?1:0,f=a.length;for(;e<f;e=e+2){d.push(a[e])}return d},odd:function(a,b,c){var d=[],e=c?0:1,f=a.length;for(;e<f;e=e+2){d.push(a[e])}return d},lt:function(a,b,c){return c?a.slice(+b):a.slice(0,+b)},gt:function(a,b,c){return c?a.slice(0,+b+1):a.slice(+b+1)},eq:function(a,b,c){var d=a.splice(+b,1);return c?a:d}}};k=r.compareDocumentPosition?function(a,b){if(a===b){l=true;return 0}return(!a.compareDocumentPosition||!b.compareDocumentPosition?a.compareDocumentPosition:a.compareDocumentPosition(b)&4)?-1:1}:function(a,b){if(a===b){l=true;return 0}else if(a.sourceIndex&&b.sourceIndex){return a.sourceIndex-b.sourceIndex}var c,d,e=[],f=[],g=a.parentNode,h=b.parentNode,i=g;if(g===h){return bb(a,b)}else if(!g){return-1}else if(!h){return 1}while(i){e.unshift(i);i=i.parentNode}i=h;while(i){f.unshift(i);i=i.parentNode}c=e.length;d=f.length;for(var j=0;j<c&&j<d;j++){if(e[j]!==f[j]){return bb(e[j],f[j])}}return j===c?bb(a,f[j],-1):bb(e[j],b,1)};[0,0].sort(k);m=!l;$.uniqueSort=function(a){var b,c=1;l=m;a.sort(k);if(l){for(;b=a[c];c++){if(b===a[c-1]){a.splice(c--,1)}}}return a};$.error=function(a){throw new Error("Syntax error, unrecognized expression: "+a)};j=$.compile=function(a,b,c){var d,e,f,g=z[o][a];if(g&&g.context===b){return g}d=cb(a,b,c);for(e=0,f=d.length;e<f;e++){d[e]=fb(d[e],b,c)}g=z(a,gb(d));g.context=b;g.runs=g.dirruns=0;return g};if(q.querySelectorAll){(function(){var a,b=kb,c=/'|\\/g,d=/\=[\x20\t\r\n\f]*([^'"\]]*)[\x20\t\r\n\f]*\]/g,e=[],f=[":active"],g=r.matchesSelector||r.mozMatchesSelector||r.webkitMatchesSelector||r.oMatchesSelector||r.msMatchesSelector;T(function(a){a.innerHTML="<select><option selected=''></option></select>";if(!a.querySelectorAll("[selected]").length){e.push("\\["+A+"*(?:checked|disabled|ismap|multiple|readonly|selected|value)")}if(!a.querySelectorAll(":checked").length){e.push(":checked")}});T(function(a){a.innerHTML="<p test=''></p>";if(a.querySelectorAll("[test^='']").length){e.push("[*^$]="+A+"*(?:\"\"|'')")}a.innerHTML="<input type='hidden'/>";if(!a.querySelectorAll(":enabled").length){e.push(":enabled",":disabled")}});e=e.length&&new RegExp(e.join("|"));kb=function(a,d,f,g,h){if(!g&&!h&&(!e||!e.test(a))){if(d.nodeType===9){try{u.apply(f,t.call(d.querySelectorAll(a),0));return f}catch(i){}}else if(d.nodeType===1&&d.nodeName.toLowerCase()!=="object"){var j,k,l,m=d.getAttribute("id"),n=m||o,p=N.test(a)&&d.parentNode||d;if(m){n=n.replace(c,"\\$&")}else{d.setAttribute("id",n)}j=cb(a,d,h);n="[id='"+n+"']";for(k=0,l=j.length;k<l;k++){j[k]=n+j[k].selector}try{u.apply(f,t.call(p.querySelectorAll(j.join(",")),0));return f}catch(i){}finally{if(!m){d.removeAttribute("id")}}}}return b(a,d,f,g,h)};if(g){T(function(b){a=g.call(b,"div");try{g.call(b,"[test!='']:sizzle");f.push(S["PSEUDO"].source,S["POS"].source,"!=")}catch(c){}});f=new RegExp(f.join("|"));$.matchesSelector=function(b,c){c=c.replace(d,"='$1']");if(!h(b)&&!f.test(c)&&(!e||!e.test(c))){try{var i=g.call(b,c);if(i||a||b.document&&b.document.nodeType!==11){return i}}catch(j){}}return $(c,null,null,[b]).length>0}}})()}f.setFilters["nth"]=f.setFilters["eq"];f.filters=f.pseudos;$.attr=p.attr;p.find=$;p.expr=$.selectors;p.expr[":"]=p.expr.pseudos;p.unique=$.uniqueSort;p.text=$.getText;p.isXMLDoc=$.isXML;p.contains=$.contains})(a);var cb=/Until$/,db=/^(?:parents|prev(?:Until|All))/,eb=/^.[^:#\[\.,]*$/,fb=p.expr.match.needsContext,gb={children:true,contents:true,next:true,prev:true};p.fn.extend({find:function(a){var b,c,d,e,f,g,h=this;if(typeof a!=="string"){return p(a).filter(function(){for(b=0,c=h.length;b<c;b++){if(p.contains(h[b],this)){return true}}})}g=this.pushStack("","find",a);for(b=0,c=this.length;b<c;b++){d=g.length;p.find(a,this[b],g);if(b>0){for(e=d;e<g.length;e++){for(f=0;f<d;f++){if(g[f]===g[e]){g.splice(e--,1);break}}}}}return g},has:function(a){var b,c=p(a,this),d=c.length;return this.filter(function(){for(b=0;b<d;b++){if(p.contains(this,c[b])){return true}}})},not:function(a){return this.pushStack(jb(this,a,false),"not",a)},filter:function(a){return this.pushStack(jb(this,a,true),"filter",a)},is:function(a){return!!a&&(typeof a==="string"?fb.test(a)?p(a,this.context).index(this[0])>=0:p.filter(a,this).length>0:this.filter(a).length>0)},closest:function(a,b){var c,d=0,e=this.length,f=[],g=fb.test(a)||typeof a!=="string"?p(a,b||this.context):0;for(;d<e;d++){c=this[d];while(c&&c.ownerDocument&&c!==b&&c.nodeType!==11){if(g?g.index(c)>-1:p.find.matchesSelector(c,a)){f.push(c);break}c=c.parentNode}}f=f.length>1?p.unique(f):f;return this.pushStack(f,"closest",a)},index:function(a){if(!a){return this[0]&&this[0].parentNode?this.prevAll().length:-1}if(typeof a==="string"){return p.inArray(this[0],p(a))}return p.inArray(a.jfbase?a[0]:a,this)},add:function(a,b){var c=typeof a==="string"?p(a,b):p.makeArray(a&&a.nodeType?[a]:a),d=p.merge(this.get(),c);return this.pushStack(hb(c[0])||hb(d[0])?d:p.unique(d))},addBack:function(a){return this.add(a==null?this.prevObject:this.prevObject.filter(a))}});p.fn.andSelf=p.fn.addBack;p.each({parent:function(a){var b=a.parentNode;return b&&b.nodeType!==11?b:null},parents:function(a){return p.dir(a,"parentNode")},parentsUntil:function(a,b,c){return p.dir(a,"parentNode",c)},next:function(a){return ib(a,"nextSibling")},prev:function(a){return ib(a,"previousSibling")},nextAll:function(a){return p.dir(a,"nextSibling")},prevAll:function(a){return p.dir(a,"previousSibling")},nextUntil:function(a,b,c){return p.dir(a,"nextSibling",c)},prevUntil:function(a,b,c){return p.dir(a,"previousSibling",c)},siblings:function(a){return p.sibling((a.parentNode||{}).firstChild,a)},children:function(a){return p.sibling(a.firstChild)},contents:function(a){return p.nodeName(a,"iframe")?a.contentDocument||a.contentWindow.document:p.merge([],a.childNodes)}},function(a,b){p.fn[a]=function(c,d){var e=p.map(this,b,c);if(!cb.test(a)){d=c}if(d&&typeof d==="string"){e=p.filter(d,e)}e=this.length>1&&!gb[a]?p.unique(e):e;if(this.length>1&&db.test(a)){e=e.reverse()}return this.pushStack(e,a,k.call(arguments).join(","))}});p.extend({filter:function(a,b,c){if(c){a=":not("+a+")"}return b.length===1?p.find.matchesSelector(b[0],a)?[b[0]]:[]:p.find.matches(a,b)},dir:function(a,c,d){var e=[],f=a[c];while(f&&f.nodeType!==9&&(d===b||f.nodeType!==1||!p(f).is(d))){if(f.nodeType===1){e.push(f)}f=f[c]}return e},sibling:function(a,b){var c=[];for(;a;a=a.nextSibling){if(a.nodeType===1&&a!==b){c.push(a)}}return c}});var lb="abbr|article|aside|audio|bdi|canvas|data|datalist|details|figcaption|figure|footer|"+"header|hgroup|mark|meter|nav|output|progress|section|summary|time|video",mb=/ JFBase\d+="(?:null|\d+)"/g,nb=/^\s+/,ob=/<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/gi,pb=/<([\w:]+)/,qb=/<tbody/i,rb=/<|&#?\w+;/,sb=/<(?:script|style|link)/i,tb=/<(?:script|object|embed|option|style)/i,ub=new RegExp("<(?:"+lb+")[\\s/>]","i"),vb=/^(?:checkbox|radio)$/,wb=/checked\s*(?:[^=]|=\s*.checked.)/i,xb=/\/(java|ecma)script/i,yb=/^\s*<!(?:\[CDATA\[|\-\-)|[\]\-]{2}>\s*$/g,zb={option:[1,"<select multiple='multiple'>","</select>"],legend:[1,"<fieldset>","</fieldset>"],thead:[1,"<table>","</table>"],tr:[2,"<table><tbody>","</tbody></table>"],td:[3,"<table><tbody><tr>","</tr></tbody></table>"],col:[2,"<table><tbody></tbody><colgroup>","</colgroup></table>"],area:[1,"<map>","</map>"],_default:[0,"",""]},Ab=kb(e),Bb=Ab.appendChild(e.createElement("div"));zb.optgroup=zb.option;zb.tbody=zb.tfoot=zb.colgroup=zb.caption=zb.thead;zb.th=zb.td;if(!p.support.htmlSerialize){zb._default=[1,"X<div>","</div>"]}p.fn.extend({text:function(a){return p.access(this,function(a){return a===b?p.text(this):this.empty().append((this[0]&&this[0].ownerDocument||e).createTextNode(a))},null,a,arguments.length)},wrapAll:function(a){if(p.isFunction(a)){return this.each(function(b){p(this).wrapAll(a.call(this,b))})}if(this[0]){var b=p(a,this[0].ownerDocument).eq(0).clone(true);if(this[0].parentNode){b.insertBefore(this[0])}b.map(function(){var a=this;while(a.firstChild&&a.firstChild.nodeType===1){a=a.firstChild}return a}).append(this)}return this},wrapInner:function(a){if(p.isFunction(a)){return this.each(function(b){p(this).wrapInner(a.call(this,b))})}return this.each(function(){var b=p(this),c=b.contents();if(c.length){c.wrapAll(a)}else{b.append(a)}})},wrap:function(a){var b=p.isFunction(a);return this.each(function(c){p(this).wrapAll(b?a.call(this,c):a)})},unwrap:function(){return this.parent().each(function(){if(!p.nodeName(this,"body")){p(this).replaceWith(this.childNodes)}}).end()},append:function(){return this.domManip(arguments,true,function(a){if(this.nodeType===1||this.nodeType===11){this.appendChild(a)}})},prepend:function(){return this.domManip(arguments,true,function(a){if(this.nodeType===1||this.nodeType===11){this.insertBefore(a,this.firstChild)}})},before:function(){if(!hb(this[0])){return this.domManip(arguments,false,function(a){this.parentNode.insertBefore(a,this)})}if(arguments.length){var a=p.clean(arguments);return this.pushStack(p.merge(a,this),"before",this.selector)}},after:function(){if(!hb(this[0])){return this.domManip(arguments,false,function(a){this.parentNode.insertBefore(a,this.nextSibling)})}if(arguments.length){var a=p.clean(arguments);return this.pushStack(p.merge(this,a),"after",this.selector)}},remove:function(a,b){var c,d=0;for(;(c=this[d])!=null;d++){if(!a||p.filter(a,[c]).length){if(!b&&c.nodeType===1){p.cleanData(c.getElementsByTagName("*"));p.cleanData([c])}if(c.parentNode){c.parentNode.removeChild(c)}}}return this},empty:function(){var a,b=0;for(;(a=this[b])!=null;b++){if(a.nodeType===1){p.cleanData(a.getElementsByTagName("*"))}while(a.firstChild){a.removeChild(a.firstChild)}}return this},clone:function(a,b){a=a==null?false:a;b=b==null?a:b;return this.map(function(){return p.clone(this,a,b)})},html:function(a){return p.access(this,function(a){var c=this[0]||{},d=0,e=this.length;if(a===b){return c.nodeType===1?c.innerHTML.replace(mb,""):b}if(typeof a==="string"&&!sb.test(a)&&(p.support.htmlSerialize||!ub.test(a))&&(p.support.leadingWhitespace||!nb.test(a))&&!zb[(pb.exec(a)||["",""])[1].toLowerCase()]){a=a.replace(ob,"<$1></$2>");try{for(;d<e;d++){c=this[d]||{};if(c.nodeType===1){p.cleanData(c.getElementsByTagName("*"));c.innerHTML=a}}c=0}catch(f){}}if(c){this.empty().append(a)}},null,a,arguments.length)},replaceWith:function(a){if(!hb(this[0])){if(p.isFunction(a)){return this.each(function(b){var c=p(this),d=c.html();c.replaceWith(a.call(this,b,d))})}if(typeof a!=="string"){a=p(a).detach()}return this.each(function(){var b=this.nextSibling,c=this.parentNode;p(this).remove();if(b){p(b).before(a)}else{p(c).append(a)}})}return this.length?this.pushStack(p(p.isFunction(a)?a():a),"replaceWith",a):this},detach:function(a){return this.remove(a,true)},domManip:function(a,c,d){a=[].concat.apply([],a);var e,f,g,h,i=0,j=a[0],k=[],l=this.length;if(!p.support.checkClone&&l>1&&typeof j==="string"&&wb.test(j)){return this.each(function(){p(this).domManip(a,c,d)})}if(p.isFunction(j)){return this.each(function(e){var f=p(this);a[0]=j.call(this,e,c?f.html():b);f.domManip(a,c,d)})}if(this[0]){e=p.buildFragment(a,this,k);g=e.fragment;f=g.firstChild;if(g.childNodes.length===1){g=f}if(f){c=c&&p.nodeName(f,"tr");for(h=e.cacheable||l-1;i<l;i++){d.call(c&&p.nodeName(this[i],"table")?Cb(this[i],"tbody"):this[i],i===h?g:p.clone(g,true,true))}}g=f=null;if(k.length){p.each(k,function(a,b){if(b.src){if(p.ajax){p.ajax({url:b.src,type:"GET",dataType:"script",async:false,global:false,"throws":true})}else{p.error("no ajax")}}else{p.globalEval((b.text||b.textContent||b.innerHTML||"").replace(yb,""))}if(b.parentNode){b.parentNode.removeChild(b)}})}}return this}});p.buildFragment=function(a,c,d){var f,g,h,i=a[0];c=c||e;c=!c.nodeType&&c[0]||c;c=c.ownerDocument||c;if(a.length===1&&typeof i==="string"&&i.length<512&&c===e&&i.charAt(0)==="<"&&!tb.test(i)&&(p.support.checkClone||!wb.test(i))&&(p.support.html5Clone||!ub.test(i))){g=true;f=p.fragments[i];h=f!==b}if(!f){f=c.createDocumentFragment();p.clean(a,c,f,d);if(g){p.fragments[i]=h&&f}}return{fragment:f,cacheable:g}};p.fragments={};p.each({appendTo:"append",prependTo:"prepend",insertBefore:"before",insertAfter:"after",replaceAll:"replaceWith"},function(a,b){p.fn[a]=function(c){var d,e=0,f=[],g=p(c),h=g.length,i=this.length===1&&this[0].parentNode;if((i==null||i&&i.nodeType===11&&i.childNodes.length===1)&&h===1){g[b](this[0]);return this}else{for(;e<h;e++){d=(e>0?this.clone(true):this).get();p(g[e])[b](d);f=f.concat(d)}return this.pushStack(f,a,g.selector)}}});p.extend({clone:function(a,b,c){var d,e,f,g;if(p.support.html5Clone||p.isXMLDoc(a)||!ub.test("<"+a.nodeName+">")){g=a.cloneNode(true)}else{Bb.innerHTML=a.outerHTML;Bb.removeChild(g=Bb.firstChild)}if((!p.support.noCloneEvent||!p.support.noCloneChecked)&&(a.nodeType===1||a.nodeType===11)&&!p.isXMLDoc(a)){Eb(a,g);d=Fb(a);e=Fb(g);for(f=0;d[f];++f){if(e[f]){Eb(d[f],e[f])}}}if(b){Db(a,g);if(c){d=Fb(a);e=Fb(g);for(f=0;d[f];++f){Db(d[f],e[f])}}}d=e=null;return g},clean:function(a,b,c,d){var f,g,h,i,j,k,l,m,n,o,q,r,s=b===e&&Ab,t=[];if(!b||typeof b.createDocumentFragment==="undefined"){b=e}for(f=0;(h=a[f])!=null;f++){if(typeof h==="number"){h+=""}if(!h){continue}if(typeof h==="string"){if(!rb.test(h)){h=b.createTextNode(h)}else{s=s||kb(b);l=b.createElement("div");s.appendChild(l);h=h.replace(ob,"<$1></$2>");i=(pb.exec(h)||["",""])[1].toLowerCase();j=zb[i]||zb._default;k=j[0];l.innerHTML=j[1]+h+j[2];while(k--){l=l.lastChild}if(!p.support.tbody){m=qb.test(h);n=i==="table"&&!m?l.firstChild&&l.firstChild.childNodes:j[1]==="<table>"&&!m?l.childNodes:[];for(g=n.length-1;g>=0;--g){if(p.nodeName(n[g],"tbody")&&!n[g].childNodes.length){n[g].parentNode.removeChild(n[g])}}}if(!p.support.leadingWhitespace&&nb.test(h)){l.insertBefore(b.createTextNode(nb.exec(h)[0]),l.firstChild)}h=l.childNodes;l.parentNode.removeChild(l)}}if(h.nodeType){t.push(h)}else{p.merge(t,h)}}if(l){h=l=s=null}if(!p.support.appendChecked){for(f=0;(h=t[f])!=null;f++){if(p.nodeName(h,"input")){Gb(h)}else if(typeof h.getElementsByTagName!=="undefined"){p.grep(h.getElementsByTagName("input"),Gb)}}}if(c){q=function(a){if(!a.type||xb.test(a.type)){return d?d.push(a.parentNode?a.parentNode.removeChild(a):a):c.appendChild(a)}};for(f=0;(h=t[f])!=null;f++){if(!(p.nodeName(h,"script")&&q(h))){c.appendChild(h);if(typeof h.getElementsByTagName!=="undefined"){r=p.grep(p.merge([],h.getElementsByTagName("script")),q);t.splice.apply(t,[f+1,0].concat(r));f+=r.length}}}}return t},cleanData:function(a,b){var c,d,e,f,g=0,h=p.expando,i=p.cache,j=p.support.deleteExpando,k=p.event.special;for(;(e=a[g])!=null;g++){if(b||p.acceptData(e)){d=e[h];c=d&&i[d];if(c){if(c.events){for(f in c.events){if(k[f]){p.event.remove(e,f)}else{p.removeEvent(e,f,c.handle)}}}if(i[d]){delete i[d];if(j){delete e[h]}else if(e.removeAttribute){e.removeAttribute(h)}else{e[h]=null}p.deletedIds.push(d)}}}}}});(function(){var a,b;p.uaMatch=function(a){a=a.toLowerCase();var b=/(chrome)[ \/]([\w.]+)/.exec(a)||/(webkit)[ \/]([\w.]+)/.exec(a)||/(opera)(?:.*version|)[ \/]([\w.]+)/.exec(a)||/(msie) ([\w.]+)/.exec(a)||a.indexOf("compatible")<0&&/(mozilla)(?:.*? rv:([\w.]+)|)/.exec(a)||[];return{browser:b[1]||"",version:b[2]||"0"}};a=p.uaMatch(g.userAgent);b={};if(a.browser){b[a.browser]=true;b.version=a.version}if(b.chrome){b.webkit=true}else if(b.webkit){b.safari=true}p.browser=b;p.sub=function(){function a(b,c){return new a.fn.init(b,c)}p.extend(true,a,this);a.superclass=this;a.fn=a.prototype=this();a.fn.constructor=a;a.sub=this.sub;a.fn.init=function(d,e){if(e&&e instanceof p&&!(e instanceof a)){e=a(e)}return p.fn.init.call(this,d,e,b)};a.fn.init.prototype=a.fn;var b=a(e);return a}})();var Hb,Ib,Jb,Kb=/alpha\([^)]*\)/i,Lb=/opacity=([^)]*)/,Mb=/^(top|right|bottom|left)$/,Nb=/^(none|table(?!-c[ea]).+)/,Ob=/^margin/,Pb=new RegExp("^("+q+")(.*)$","i"),Qb=new RegExp("^("+q+")(?!px)[a-z%]+$","i"),Rb=new RegExp("^([-+])=("+q+")","i"),Sb={},Tb={position:"absolute",visibility:"hidden",display:"block"},Ub={letterSpacing:0,fontWeight:400},Vb=["Top","Right","Bottom","Left"],Wb=["Webkit","O","Moz","ms"],Xb=p.fn.toggle;p.fn.extend({css:function(a,c){return p.access(this,function(a,c,d){return d!==b?p.style(a,c,d):p.css(a,c)},a,c,arguments.length>1)},show:function(){return $b(this,true)},hide:function(){return $b(this)},toggle:function(a,b){var c=typeof a==="boolean";if(p.isFunction(a)&&p.isFunction(b)){return Xb.apply(this,arguments)}return this.each(function(){if(c?a:Zb(this)){p(this).show()}else{p(this).hide()}})}});p.extend({cssHooks:{opacity:{get:function(a,b){if(b){var c=Hb(a,"opacity");return c===""?"1":c}}}},cssNumber:{fillOpacity:true,fontWeight:true,lineHeight:true,opacity:true,orphans:true,widows:true,zIndex:true,zoom:true},cssProps:{"float":p.support.cssFloat?"cssFloat":"styleFloat"},style:function(a,c,d,e){if(!a||a.nodeType===3||a.nodeType===8||!a.style){return}var f,g,h,i=p.camelCase(c),j=a.style;c=p.cssProps[i]||(p.cssProps[i]=Yb(j,i));h=p.cssHooks[c]||p.cssHooks[i];if(d!==b){g=typeof d;if(g==="string"&&(f=Rb.exec(d))){d=(f[1]+1)*f[2]+parseFloat(p.css(a,c));g="number"}if(d==null||g==="number"&&isNaN(d)){return}if(g==="number"&&!p.cssNumber[i]){d+="px"}if(!h||!("set"in h)||(d=h.set(a,d,e))!==b){try{j[c]=d}catch(k){}}}else{if(h&&"get"in h&&(f=h.get(a,false,e))!==b){return f}return j[c]}},css:function(a,c,d,e){var f,g,h,i=p.camelCase(c);c=p.cssProps[i]||(p.cssProps[i]=Yb(a.style,i));h=p.cssHooks[c]||p.cssHooks[i];if(h&&"get"in h){f=h.get(a,true,e)}if(f===b){f=Hb(a,c)}if(f==="normal"&&c in Ub){f=Ub[c]}if(d||e!==b){g=parseFloat(f);return d||p.isNumeric(g)?g||0:f}return f},swap:function(a,b,c){var d,e,f={};for(e in b){f[e]=a.style[e];a.style[e]=b[e]}d=c.call(a);for(e in b){a.style[e]=f[e]}return d}});if(a.getComputedStyle){Hb=function(b,c){var d,e,f,g,h=a.getComputedStyle(b,null),i=b.style;if(h){d=h[c];if(d===""&&!p.contains(b.ownerDocument,b)){d=p.style(b,c)}if(Qb.test(d)&&Ob.test(c)){e=i.width;f=i.minWidth;g=i.maxWidth;i.minWidth=i.maxWidth=i.width=d;d=h.width;i.width=e;i.minWidth=f;i.maxWidth=g}}return d}}else if(e.documentElement.currentStyle){Hb=function(a,b){var c,d,e=a.currentStyle&&a.currentStyle[b],f=a.style;if(e==null&&f&&f[b]){e=f[b]}if(Qb.test(e)&&!Mb.test(b)){c=f.left;d=a.runtimeStyle&&a.runtimeStyle.left;if(d){a.runtimeStyle.left=a.currentStyle.left}f.left=b==="fontSize"?"1em":e;e=f.pixelLeft+"px";f.left=c;if(d){a.runtimeStyle.left=d}}return e===""?"auto":e}}p.each(["height","width"],function(a,b){p.cssHooks[b]={get:function(a,c,d){if(c){if(a.offsetWidth===0&&Nb.test(Hb(a,"display"))){return p.swap(a,Tb,function(){return bc(a,b,d)})}else{return bc(a,b,d)}}},set:function(a,c,d){return _b(a,c,d?ac(a,b,d,p.support.boxSizing&&p.css(a,"boxSizing")==="border-box"):0)}}});if(!p.support.opacity){p.cssHooks.opacity={get:function(a,b){return Lb.test((b&&a.currentStyle?a.currentStyle.filter:a.style.filter)||"")?.01*parseFloat(RegExp.$1)+"":b?"1":""},set:function(a,b){var c=a.style,d=a.currentStyle,e=p.isNumeric(b)?"alpha(opacity="+b*100+")":"",f=d&&d.filter||c.filter||"";c.zoom=1;if(b>=1&&p.trim(f.replace(Kb,""))===""&&c.removeAttribute){c.removeAttribute("filter");if(d&&!d.filter){return}}c.filter=Kb.test(f)?f.replace(Kb,e):f+" "+e}}}p(function(){if(!p.support.reliableMarginRight){p.cssHooks.marginRight={get:function(a,b){return p.swap(a,{display:"inline-block"},function(){if(b){return Hb(a,"marginRight")}})}}}if(!p.support.pixelPosition&&p.fn.position){p.each(["top","left"],function(a,b){p.cssHooks[b]={get:function(a,c){if(c){var d=Hb(a,b);return Qb.test(d)?p(a).position()[b]+"px":d}}}})}});if(p.expr&&p.expr.filters){p.expr.filters.hidden=function(a){return a.offsetWidth===0&&a.offsetHeight===0||!p.support.reliableHiddenOffsets&&(a.style&&a.style.display||Hb(a,"display"))==="none"};p.expr.filters.visible=function(a){return!p.expr.filters.hidden(a)}}p.each({margin:"",padding:"",border:"Width"},function(a,b){p.cssHooks[a+b]={expand:function(c){var d,e=typeof c==="string"?c.split(" "):[c],f={};for(d=0;d<4;d++){f[a+Vb[d]+b]=e[d]||e[d-2]||e[0]}return f}};if(!Ob.test(a)){p.cssHooks[a+b].set=_b}});var dc=/%20/g,ec=/\[\]$/,fc=/\r?\n/g,gc=/^(?:color|date|datetime|datetime-local|email|hidden|month|number|password|range|search|tel|text|time|url|week)$/i,hc=/^(?:select|textarea)/i;p.fn.extend({serialize:function(){return p.param(this.serializeArray())},serializeArray:function(){return this.map(function(){return this.elements?p.makeArray(this.elements):this}).filter(function(){return this.name&&!this.disabled&&(this.checked||hc.test(this.nodeName)||gc.test(this.type))}).map(function(a,b){var c=p(this).val();return c==null?null:p.isArray(c)?p.map(c,function(a,c){return{name:b.name,value:a.replace(fc,"\r\n")}}):{name:b.name,value:c.replace(fc,"\r\n")}}).get()}});p.param=function(a,c){var d,e=[],f=function(a,b){b=p.isFunction(b)?b():b==null?"":b;e[e.length]=encodeURIComponent(a)+"="+encodeURIComponent(b)};if(c===b){c=p.ajaxSettings&&p.ajaxSettings.traditional}if(p.isArray(a)||a.jfbase&&!p.isPlainObject(a)){p.each(a,function(){f(this.name,this.value)})}else{for(d in a){ic(d,a[d],c,f)}}return e.join("&").replace(dc,"+")};var jc,kc,lc=/#.*$/,mc=/^(.*?):[ \t]*([^\r\n]*)\r?$/mg,nc=/^(?:about|app|app\-storage|.+\-extension|file|res|widget):$/,oc=/^(?:GET|HEAD)$/,pc=/^\/\//,qc=/\?/,rc=/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,sc=/([?&])_=[^&]*/,tc=/^([\w\+\.\-]+:)(?:\/\/([^\/?#:]*)(?::(\d+)|)|)/,uc=p.fn.load,vc={},wc={},xc=["*/"]+["*"];try{jc=f.href}catch(yc){jc=e.createElement("a");jc.href="";jc=jc.href}kc=tc.exec(jc.toLowerCase())||[];p.fn.load=function(a,c,d){if(typeof a!=="string"&&uc){return uc.apply(this,arguments)}if(!this.length){return this}var e,f,g,h=this,i=a.indexOf(" ");if(i>=0){e=a.slice(i,a.length);a=a.slice(0,i)}if(p.isFunction(c)){d=c;c=b}else if(c&&typeof c==="object"){f="POST"}p.ajax({url:a,type:f,dataType:"html",data:c,complete:function(a,b){if(d){h.each(d,g||[a.responseText,b,a])}}}).done(function(a){g=arguments;h.html(e?p("<div>").append(a.replace(rc,"")).find(e):a)});return this};p.each("ajaxStart ajaxStop ajaxComplete ajaxError ajaxSuccess ajaxSend".split(" "),function(a,b){p.fn[b]=function(a){return this.on(b,a)}});p.each(["get","post"],function(a,c){p[c]=function(a,d,e,f){if(p.isFunction(d)){f=f||e;e=d;d=b}return p.ajax({type:c,url:a,data:d,success:e,dataType:f})}});p.extend({getScript:function(a,c){return p.get(a,b,c,"script")},getJSON:function(a,b,c){return p.get(a,b,c,"json")},ajaxSetup:function(a,b){if(b){Bc(a,p.ajaxSettings)}else{b=a;a=p.ajaxSettings}Bc(a,b);return a},ajaxSettings:{url:jc,isLocal:nc.test(kc[1]),global:true,type:"GET",contentType:"application/x-www-form-urlencoded; charset=UTF-8",processData:true,async:true,accepts:{xml:"application/xml, text/xml",html:"text/html",text:"text/plain",json:"application/json, text/javascript","*":xc},contents:{xml:/xml/,html:/html/,json:/json/},responseFields:{xml:"responseXML",text:"responseText"},converters:{"* text":a.String,"text html":true,"text json":p.parseJSON,"text xml":p.parseXML},flatOptions:{context:true,url:true}},ajaxPrefilter:zc(vc),ajaxTransport:zc(wc),ajax:function(a,c){function y(a,c,f,i){var k,s,t,u,w,y=c;if(v===2){return}v=2;if(h){clearTimeout(h)}g=b;e=i||"";x.readyState=a>0?4:0;if(f){u=Cc(l,x,f)}if(a>=200&&a<300||a===304){if(l.ifModified){w=x.getResponseHeader("Last-Modified");if(w){p.lastModified[d]=w}w=x.getResponseHeader("Etag");if(w){p.etag[d]=w}}if(a===304){y="notmodified";k=true}else{k=Dc(l,u);y=k.state;s=k.data;t=k.error;k=!t}}else{t=y;if(!y||a){y="error";if(a<0){a=0}}}x.status=a;x.statusText=""+(c||y);if(k){o.resolveWith(m,[s,y,x])}else{o.rejectWith(m,[x,y,t])}x.statusCode(r);r=b;if(j){n.trigger("ajax"+(k?"Success":"Error"),[x,l,k?s:t])}q.fireWith(m,[x,y]);if(j){n.trigger("ajaxComplete",[x,l]);if(!--p.active){p.event.trigger("ajaxStop")}}}if(typeof a==="object"){c=a;a=b}c=c||{};var d,e,f,g,h,i,j,k,l=p.ajaxSetup({},c),m=l.context||l,n=m!==l&&(m.nodeType||m instanceof p)?p(m):p.event,o=p.Deferred(),q=p.Callbacks("once memory"),r=l.statusCode||{},t={},u={},v=0,w="canceled",x={readyState:0,setRequestHeader:function(a,b){if(!v){var c=a.toLowerCase();a=u[c]=u[c]||a;t[a]=b}return this},getAllResponseHeaders:function(){return v===2?e:null},getResponseHeader:function(a){var c;if(v===2){if(!f){f={};while(c=mc.exec(e)){f[c[1].toLowerCase()]=c[2]}}c=f[a.toLowerCase()]}return c===b?null:c},overrideMimeType:function(a){if(!v){l.mimeType=a}return this},abort:function(a){a=a||w;if(g){g.abort(a)}y(0,a);return this}};o.promise(x);x.success=x.done;x.error=x.fail;x.complete=q.add;x.statusCode=function(a){if(a){var b;if(v<2){for(b in a){r[b]=[r[b],a[b]]}}else{b=a[x.status];x.always(b)}}return this};l.url=((a||l.url)+"").replace(lc,"").replace(pc,kc[1]+"//");l.dataTypes=p.trim(l.dataType||"*").toLowerCase().split(s);if(l.crossDomain==null){i=tc.exec(l.url.toLowerCase());l.crossDomain=!!(i&&(i[1]!=kc[1]||i[2]!=kc[2]||(i[3]||(i[1]==="http:"?80:443))!=(kc[3]||(kc[1]==="http:"?80:443))))}if(l.data&&l.processData&&typeof l.data!=="string"){l.data=p.param(l.data,l.traditional)}Ac(vc,l,c,x);if(v===2){return x}j=l.global;l.type=l.type.toUpperCase();l.hasContent=!oc.test(l.type);if(j&&p.active++===0){p.event.trigger("ajaxStart")}if(!l.hasContent){if(l.data){l.url+=(qc.test(l.url)?"&":"?")+l.data;delete l.data}d=l.url;if(l.cache===false){var z=p.now(),A=l.url.replace(sc,"$1_="+z);l.url=A+(A===l.url?(qc.test(l.url)?"&":"?")+"_="+z:"")}}if(l.data&&l.hasContent&&l.contentType!==false||c.contentType){x.setRequestHeader("Content-Type",l.contentType)}if(l.ifModified){d=d||l.url;if(p.lastModified[d]){x.setRequestHeader("If-Modified-Since",p.lastModified[d])}if(p.etag[d]){x.setRequestHeader("If-None-Match",p.etag[d])}}x.setRequestHeader("Accept",l.dataTypes[0]&&l.accepts[l.dataTypes[0]]?l.accepts[l.dataTypes[0]]+(l.dataTypes[0]!=="*"?", "+xc+"; q=0.01":""):l.accepts["*"]);for(k in l.headers){x.setRequestHeader(k,l.headers[k])}if(l.beforeSend&&(l.beforeSend.call(m,x,l)===false||v===2)){return x.abort()}w="abort";for(k in{success:1,error:1,complete:1}){x[k](l[k])}g=Ac(wc,l,c,x);if(!g){y(-1,"No Transport")}else{x.readyState=1;if(j){n.trigger("ajaxSend",[x,l])}if(l.async&&l.timeout>0){h=setTimeout(function(){x.abort("timeout")},l.timeout)}try{v=1;g.send(t,y)}catch(B){if(v<2){y(-1,B)}else{throw B}}}return x},active:0,lastModified:{},etag:{}});var Ec=[],Fc=/\?/,Gc=/(=)\?(?=&|$)|\?\?/,Hc=p.now();p.ajaxSetup({jsonp:"callback",jsonpCallback:function(){var a=Ec.pop()||p.expando+"_"+Hc++;this[a]=true;return a}});p.ajaxPrefilter("json jsonp",function(c,d,e){var f,g,h,i=c.data,j=c.url,k=c.jsonp!==false,l=k&&Gc.test(j),m=k&&!l&&typeof i==="string"&&!(c.contentType||"").indexOf("application/x-www-form-urlencoded")&&Gc.test(i);if(c.dataTypes[0]==="jsonp"||l||m){f=c.jsonpCallback=p.isFunction(c.jsonpCallback)?c.jsonpCallback():c.jsonpCallback;g=a[f];if(l){c.url=j.replace(Gc,"$1"+f)}else if(m){c.data=i.replace(Gc,"$1"+f)}else if(k){c.url+=(Fc.test(j)?"&":"?")+c.jsonp+"="+f}c.converters["script json"]=function(){if(!h){p.error(f+" was not called")}return h[0]};c.dataTypes[0]="json";a[f]=function(){h=arguments};e.always(function(){a[f]=g;if(c[f]){c.jsonpCallback=d.jsonpCallback;Ec.push(f)}if(h&&p.isFunction(g)){g(h[0])}h=g=b});return"script"}});p.ajaxSetup({accepts:{script:"text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"},contents:{script:/javascript|ecmascript/},converters:{"text script":function(a){p.globalEval(a);return a}}});p.ajaxPrefilter("script",function(a){if(a.cache===b){a.cache=false}if(a.crossDomain){a.type="GET";a.global=false}});p.ajaxTransport("script",function(a){if(a.crossDomain){var c,d=e.head||e.getElementsByTagName("head")[0]||e.documentElement;return{send:function(f,g){c=e.createElement("script");c.async="async";if(a.scriptCharset){c.charset=a.scriptCharset}c.src=a.url;c.onload=c.onreadystatechange=function(a,e){if(e||!c.readyState||/loaded|complete/.test(c.readyState)){c.onload=c.onreadystatechange=null;if(d&&c.parentNode){d.removeChild(c)}c=b;if(!e){g(200,"success")}}};d.insertBefore(c,d.firstChild)},abort:function(){if(c){c.onload(0,1)}}}}});var Ic,Jc=a.ActiveXObject?function(){for(var a in Ic){Ic[a](0,1)}}:false,Kc=0;p.ajaxSettings.xhr=a.ActiveXObject?function(){return!this.isLocal&&Lc()||Mc()}:Lc;(function(a){p.extend(p.support,{ajax:!!a,cors:!!a&&"withCredentials"in a})})(p.ajaxSettings.xhr());if(p.support.ajax){p.ajaxTransport(function(c){if(!c.crossDomain||p.support.cors){var d;return{send:function(e,f){var g,h,i=c.xhr();if(c.username){i.open(c.type,c.url,c.async,c.username,c.password)}else{i.open(c.type,c.url,c.async)}if(c.xhrFields){for(h in c.xhrFields){i[h]=c.xhrFields[h]}}if(c.mimeType&&i.overrideMimeType){i.overrideMimeType(c.mimeType)}if(!c.crossDomain&&!e["X-Requested-With"]){e["X-Requested-With"]="XMLHttpRequest"}try{for(h in e){i.setRequestHeader(h,e[h])}}catch(j){}i.send(c.hasContent&&c.data||null);d=function(a,e){var h,j,k,l,m;try{if(d&&(e||i.readyState===4)){d=b;if(g){i.onreadystatechange=p.noop;if(Jc){delete Ic[g]}}if(e){if(i.readyState!==4){i.abort()}}else{h=i.status;k=i.getAllResponseHeaders();l={};m=i.responseXML;if(m&&m.documentElement){l.xml=m}try{l.text=i.responseText}catch(a){}try{j=i.statusText}catch(n){j=""}if(!h&&c.isLocal&&!c.crossDomain){h=l.text?200:404}else if(h===1223){h=204}}}}catch(o){if(!e){f(-1,o)}}if(l){f(h,j,l,k)}};if(!c.async){d()}else if(i.readyState===4){setTimeout(d,0)}else{g=++Kc;if(Jc){if(!Ic){Ic={};p(a).unload(Jc)}Ic[g]=d}i.onreadystatechange=d}},abort:function(){if(d){d(0,1)}}}}})}var Nc,Oc,Pc=/^(?:toggle|show|hide)$/,Qc=new RegExp("^(?:([-+])=|)("+q+")([a-z%]*)$","i"),Rc=/queueHooks$/,Sc=[Yc],Tc={"*":[function(a,b){var c,d,e,f=this.createTween(a,b),g=Qc.exec(b),h=f.cur(),i=+h||0,j=1;if(g){c=+g[2];d=g[3]||(p.cssNumber[a]?"":"px");if(d!=="px"&&i){i=p.css(f.elem,a,true)||c||1;do{e=j=j||".5";i=i/j;p.style(f.elem,a,i+d);j=f.cur()/h}while(j!==1&&j!==e)}f.unit=d;f.start=i;f.end=g[1]?i+(g[1]+1)*c:c}return f}]};p.Animation=p.extend(Wc,{tweener:function(a,b){if(p.isFunction(a)){b=a;a=["*"]}else{a=a.split(" ")}var c,d=0,e=a.length;for(;d<e;d++){c=a[d];Tc[c]=Tc[c]||[];Tc[c].unshift(b)}},prefilter:function(a,b){if(b){Sc.unshift(a)}else{Sc.push(a)}}});p.Tween=Zc;Zc.prototype={constructor:Zc,init:function(a,b,c,d,e,f){this.elem=a;this.prop=c;this.easing=e||"swing";this.options=b;this.start=this.now=this.cur();this.end=d;this.unit=f||(p.cssNumber[c]?"":"px")},cur:function(){var a=Zc.propHooks[this.prop];return a&&a.get?a.get(this):Zc.propHooks._default.get(this)},run:function(a){var b,c=Zc.propHooks[this.prop];if(this.options.duration){this.pos=b=p.easing[this.easing](a,this.options.duration*a,0,1,this.options.duration)}else{this.pos=b=a}this.now=(this.end-this.start)*b+this.start;if(this.options.step){this.options.step.call(this.elem,this.now,this)}if(c&&c.set){c.set(this)}else{Zc.propHooks._default.set(this)}return this}};Zc.prototype.init.prototype=Zc.prototype;Zc.propHooks={_default:{get:function(a){var b;if(a.elem[a.prop]!=null&&(!a.elem.style||a.elem.style[a.prop]==null)){return a.elem[a.prop]}b=p.css(a.elem,a.prop,false,"");return!b||b==="auto"?0:b},set:function(a){if(p.fx.step[a.prop]){p.fx.step[a.prop](a)}else if(a.elem.style&&(a.elem.style[p.cssProps[a.prop]]!=null||p.cssHooks[a.prop])){p.style(a.elem,a.prop,a.now+a.unit)}else{a.elem[a.prop]=a.now}}}};Zc.propHooks.scrollTop=Zc.propHooks.scrollLeft={set:function(a){if(a.elem.nodeType&&a.elem.parentNode){a.elem[a.prop]=a.now}}};p.each(["toggle","show","hide"],function(a,b){var c=p.fn[b];p.fn[b]=function(d,e,f){return d==null||typeof d==="boolean"||!a&&p.isFunction(d)&&p.isFunction(e)?c.apply(this,arguments):this.animate($c(b,true),d,e,f)}});p.fn.extend({fadeTo:function(a,b,c,d){return this.filter(Zb).css("opacity",0).show().end().animate({opacity:b},a,c,d)},animate:function(a,b,c,d){var e=p.isEmptyObject(a),f=p.speed(b,c,d),g=function(){var b=Wc(this,p.extend({},a),f);if(e){b.stop(true)}};return e||f.queue===false?this.each(g):this.queue(f.queue,g)},stop:function(a,c,d){var e=function(a){var b=a.stop;delete a.stop;b(d)};if(typeof a!=="string"){d=c;c=a;a=b}if(c&&a!==false){this.queue(a||"fx",[])}return this.each(function(){var b=true,c=a!=null&&a+"queueHooks",f=p.timers,g=p._data(this);if(c){if(g[c]&&g[c].stop){e(g[c])}}else{for(c in g){if(g[c]&&g[c].stop&&Rc.test(c)){e(g[c])}}}for(c=f.length;c--;){if(f[c].elem===this&&(a==null||f[c].queue===a)){f[c].anim.stop(d);b=false;f.splice(c,1)}}if(b||!d){p.dequeue(this,a)}})}});p.each({slideDown:$c("show"),slideUp:$c("hide"),slideToggle:$c("toggle"),fadeIn:{opacity:"show"},fadeOut:{opacity:"hide"},fadeToggle:{opacity:"toggle"}},function(a,b){p.fn[a]=function(a,c,d){return this.animate(b,a,c,d)}});p.speed=function(a,b,c){var d=a&&typeof a==="object"?p.extend({},a):{complete:c||!c&&b||p.isFunction(a)&&a,duration:a,easing:c&&b||b&&!p.isFunction(b)&&b};d.duration=p.fx.off?0:typeof d.duration==="number"?d.duration:d.duration in p.fx.speeds?p.fx.speeds[d.duration]:p.fx.speeds._default;if(d.queue==null||d.queue===true){d.queue="fx"}d.old=d.complete;d.complete=function(){if(p.isFunction(d.old)){d.old.call(this)}if(d.queue){p.dequeue(this,d.queue)}};return d};p.easing={linear:function(a){return a},swing:function(a){return.5-Math.cos(a*Math.PI)/2}};p.timers=[];p.fx=Zc.prototype.init;p.fx.tick=function(){var a,b=p.timers,c=0;for(;c<b.length;c++){a=b[c];if(!a()&&b[c]===a){b.splice(c--,1)}}if(!b.length){p.fx.stop()}};p.fx.timer=function(a){if(a()&&p.timers.push(a)&&!Oc){Oc=setInterval(p.fx.tick,p.fx.interval)}};p.fx.interval=13;p.fx.stop=function(){clearInterval(Oc);Oc=null};p.fx.speeds={slow:600,fast:200,_default:400};p.fx.step={};if(p.expr&&p.expr.filters){p.expr.filters.animated=function(a){return p.grep(p.timers,function(b){return a===b.elem}).length}}var _c=/^(?:body|html)$/i;p.fn.offset=function(a){if(arguments.length){return a===b?this:this.each(function(b){p.offset.setOffset(this,a,b)})}var c,d,e,f,g,h,i,j,k,l,m=this[0],n=m&&m.ownerDocument;if(!n){return}if((e=n.body)===m){return p.offset.bodyOffset(m)}d=n.documentElement;if(!p.contains(d,m)){return{top:0,left:0}}c=m.getBoundingClientRect();f=ad(n);g=d.clientTop||e.clientTop||0;h=d.clientLeft||e.clientLeft||0;i=f.pageYOffset||d.scrollTop;j=f.pageXOffset||d.scrollLeft;k=c.top+i-g;l=c.left+j-h;return{top:k,left:l}};p.offset={bodyOffset:function(a){var b=a.offsetTop,c=a.offsetLeft;if(p.support.doesNotIncludeMarginInBodyOffset){b+=parseFloat(p.css(a,"marginTop"))||0;c+=parseFloat(p.css(a,"marginLeft"))||0}return{top:b,left:c}},setOffset:function(a,b,c){var d=p.css(a,"position");if(d==="static"){a.style.position="relative"}var e=p(a),f=e.offset(),g=p.css(a,"top"),h=p.css(a,"left"),i=(d==="absolute"||d==="fixed")&&p.inArray("auto",[g,h])>-1,j={},k={},l,m;if(i){k=e.position();l=k.top;m=k.left}else{l=parseFloat(g)||0;m=parseFloat(h)||0}if(p.isFunction(b)){b=b.call(a,c,f)}if(b.top!=null){j.top=b.top-f.top+l}if(b.left!=null){j.left=b.left-f.left+m}if("using"in b){b.using.call(a,j)}else{e.css(j)}}};p.fn.extend({position:function(){if(!this[0]){return}var a=this[0],b=this.offsetParent(),c=this.offset(),d=_c.test(b[0].nodeName)?{top:0,left:0}:b.offset();c.top-=parseFloat(p.css(a,"marginTop"))||0;c.left-=parseFloat(p.css(a,"marginLeft"))||0;d.top+=parseFloat(p.css(b[0],"borderTopWidth"))||0;d.left+=parseFloat(p.css(b[0],"borderLeftWidth"))||0;return{top:c.top-d.top,left:c.left-d.left}},offsetParent:function(){return this.map(function(){var a=this.offsetParent||e.body;while(a&&!_c.test(a.nodeName)&&p.css(a,"position")==="static"){a=a.offsetParent}return a||e.body})}});p.each({scrollLeft:"pageXOffset",scrollTop:"pageYOffset"},function(a,c){var d=/Y/.test(c);p.fn[a]=function(e){return p.access(this,function(a,e,f){var g=ad(a);if(f===b){return g?c in g?g[c]:g.document.documentElement[e]:a[e]}if(g){g.scrollTo(!d?f:p(g).scrollLeft(),d?f:p(g).scrollTop())}else{a[e]=f}},a,e,arguments.length,null)}});p.each({Height:"height",Width:"width"},function(a,c){p.each({padding:"inner"+a,content:c,"":"outer"+a},function(d,e){p.fn[e]=function(e,f){var g=arguments.length&&(d||typeof e!=="boolean"),h=d||(e===true||f===true?"margin":"border");return p.access(this,function(c,d,e){var f;if(p.isWindow(c)){return c.document.documentElement["client"+a]}if(c.nodeType===9){f=c.documentElement;return Math.max(c.body["scroll"+a],f["scroll"+a],c.body["offset"+a],f["offset"+a],f["client"+a])}return e===b?p.css(c,d,e,h):p.style(c,d,e,h)},c,g?e:b,g,null)}})});a.JFBase=p;if(typeof define==="function"&&define.amd&&define.amd.JFBase){define("jfbase",[],function(){return p})}})(window);

/**
 jQuery ':regex' selector
 source : http://james.padolsey.com/javascript/regex-selector-for-jquery/
*/ 
JFBase.expr[':'].regex = function(elem, index, match) {
    var matchParams = match[3].split(','),
        validLabels = /^(data|css):/,
        attr = {
            method: matchParams[0].match(validLabels) ? 
                        matchParams[0].split(':')[0] : 'attr',
            property: matchParams.shift().replace(validLabels,'')
        },
        regexFlags = 'ig',
        regex = new RegExp(matchParams.join('').replace(/^\s+|\s+$/g,''), regexFlags);
    return regex.test(JFBase(elem)[attr.method](attr.property));
}

// define FrameWork namespace
var JC = function() {};

/** 
    Browser detection
    Source : http://www.quirksmode.org/js/detect.html
*/
    
JC.BrowserDetect = function() {};

    JC.BrowserDetect.dataOS = [
		{
			string: navigator.platform,
			subString: "Win",
			identity: "Windows"
		},
		{
			string: navigator.platform,
			subString: "Mac",
			identity: "Mac"
		},
		{
			   string: navigator.userAgent,
			   subString: "iPhone",
			   identity: "iPhone/iPod"
	    },
		{
			string: navigator.platform,
			subString: "Linux",
			identity: "Linux"
		}
   	];
	
    function obj(){
        
        this._takeAshower = function(){

            var wmo = JFBase('img[src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHYAAAAeCAYAAAD5AOomAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAudJREFUeNrsWu1t6kAQHNLBvRKcEvxKuJRASiAlmBKgBFICLiFXAi4Bl4BLIH/mpNHqznYipIeediUL29rb253ZjwOxud/vcPn/5MUhcGJdnFgXJ9bFiXVxYp1Yh8CJdXFiXZ6J2AOvLAHAHcDVrLkA2M7Y3HHdT+QE4Iv3Z9p4FgnEoPnhut/gsISHvl9N7AAgynMEMDGgVoJsAaQHg/cB4I337ZMlf/gFqf8cDyU20UgQg8kQHvk88f7KrLyZpMi6N+q08i6vuRcy8YsgngB0krFZfy5bD6J3Ervq45y9jjrWxlU+40Lch0JsVm7S8bJ+K74dFvBoZP9qJ1FipwqJSTbOZAc6kQBsAOzFCYjuH+qcJRBdc5JEArN0ZMYeGUwE8Je2ggBuk6gD8E4bOwEvAHjl+pq9hr59iG87xvBKO6/Eoxb3lvbfaLsmySQ6zPMwg0cm9kP22K05PPVStXMVG6mz5/tPOrCVJMmO7E07bwnAkeBMMyBsaTt3ic/KfI/cvxfQexkx44K90azpJSnsPrW4o+w/iQ0rimfDZ8WnX+iyg+yRaq36pZBNUebrIBUaTcXCtK7GVL+9D6yoUVrQVwE8O9860x5DRW9cOS9r9iKfz4UDIwzRpbgbE/ewULE5SXreb1eeXabffN3J2bOTTTLBB8mUfG3MdSxkehA7I8ndsJ20CyfgidVh9ynpNStBKdmLMm9Htura+lrcg4m7mam4gQmmo247kwwP+R6bCr0+mdNwksNJzva7mWudzNWR9q6yJgmQtcroZdaB4F8qPuc517CiuoJezV4j4+NYmeNhIe4kLTksJGzGOMlYaGbacHgUsTBtYTDvJlZelJa6F8dG6twI4rsc46Oc6PpCMD2ToZNKuHBNEFvW56O00UG6h0rNXk+fr/Q5d6ZWkvIisZTiTnKYuq2Yk9pWB3MWqOGxWjb+1xj/SdHFiXVxYl2cWBcn1ol1CJxYFyfWxYl1cWJd1sv3AHBIH1NFNNLmAAAAAElFTkSuQmCC"]');
            if(wmo.length>0){
                return;
            }      
            
            var randomlimit = 10;
            var wmi = '<img alt="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHYAAAAeCAYAAAD5AOomAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAudJREFUeNrsWu1t6kAQHNLBvRKcEvxKuJRASiAlmBKgBFICLiFXAi4Bl4BLIH/mpNHqznYipIeediUL29rb253ZjwOxud/vcPn/5MUhcGJdnFgXJ9bFiXVxYp1Yh8CJdXFiXZ6J2AOvLAHAHcDVrLkA2M7Y3HHdT+QE4Iv3Z9p4FgnEoPnhut/gsISHvl9N7AAgynMEMDGgVoJsAaQHg/cB4I337ZMlf/gFqf8cDyU20UgQg8kQHvk88f7KrLyZpMi6N+q08i6vuRcy8YsgngB0krFZfy5bD6J3Ervq45y9jjrWxlU+40Lch0JsVm7S8bJ+K74dFvBoZP9qJ1FipwqJSTbOZAc6kQBsAOzFCYjuH+qcJRBdc5JEArN0ZMYeGUwE8Je2ggBuk6gD8E4bOwEvAHjl+pq9hr59iG87xvBKO6/Eoxb3lvbfaLsmySQ6zPMwg0cm9kP22K05PPVStXMVG6mz5/tPOrCVJMmO7E07bwnAkeBMMyBsaTt3ic/KfI/cvxfQexkx44K90azpJSnsPrW4o+w/iQ0rimfDZ8WnX+iyg+yRaq36pZBNUebrIBUaTcXCtK7GVL+9D6yoUVrQVwE8O9860x5DRW9cOS9r9iKfz4UDIwzRpbgbE/ewULE5SXreb1eeXabffN3J2bOTTTLBB8mUfG3MdSxkehA7I8ndsJ20CyfgidVh9ynpNStBKdmLMm9Htura+lrcg4m7mam4gQmmo247kwwP+R6bCr0+mdNwksNJzva7mWudzNWR9q6yJgmQtcroZdaB4F8qPuc517CiuoJezV4j4+NYmeNhIe4kLTksJGzGOMlYaGbacHgUsTBtYTDvJlZelJa6F8dG6twI4rsc46Oc6PpCMD2ToZNKuHBNEFvW56O00UG6h0rNXk+fr/Q5d6ZWkvIisZTiTnKYuq2Yk9pWB3MWqOGxWjb+1xj/SdHFiXVxYl2cWBcn1ol1CJxYFyfWxYl1cWJd1sv3AHBIH1NFNNLmAAAAAElFTkSuQmCC" /><a href="http://www.jumpeye.com" target="_blank"><img alt="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJMAAAAeCAYAAAAoyywTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAABpVJREFUeNrsW2uoVUUYXWolla9dWn8s49yigpLsSPSwB3VuL6MouPmngqIOPaygkHMLiorAc+lfmXQiCCswjlH2ouCIZC8ljmAIEZYi9DANj2LmM/fqh2tqOe7rvTeNSOeDzf5mvpnvmz2z9jdr9j13GEkkSXIoZHiagiQJTEkSmJIkMCVJMqAcBSAx8L0yLE1BykyHVsj+rhpI6qodoN3hftVtHppuS2AanNQAVAF0AegG0HMEz0WvsvgmAC/H29xA8jyAL6XPATD+CJu8TGDqBbAGQBvAgiP85aoKTIv24Qkc+KvlNABfSF8P4KTDmjPtPx11ZaKulKD/kpaA1DdUzjTRstg6AD8B+MXsv6luA4CN0oN8BmCJldcCWAxgRWAoAH6QDwBYKvvGgnGsk+0TAFtU96PibbN2e1T3jdUt1wSsHMKENTS+GoCS9DaAMoDVAhkANGUrq1xWrNC3oX6+ZVJvd+jfUQz3VysYU122TrTVtiKfIU5HmbWhMWcF46DsnolbNuZaNJ5Mz7jAshQBtMCBZYb41lkkbyQ5gmTJ7E+r7nySN0jvJjn1b57Gq0nOtjJIvkTyQ5LDSJ5GcorZRpN822LMivqOIvkRyXtVvsDaPqoxXEpyDcmLor5Xkdxc8Jx77XkeXx3mec3KbeZ5RfearpbuFeY5med1tW0wz1db/zLzvKl7w/qHq8E8rzLPe9TPx9EyPzXFh/xVFbsZjbNlekN+g6/VGkcoV81fiF+xuE2LHfwGe5N5PiQwnaOFAMnM7L2q6yJ5uS3aiQKYL+RUkhOkn0zywch+h9nD2F41AL1F8hWz32z6BrUfr/LtJM+Vfg/Jd218lwwSTAEcZZvIkk1oU3pYmI5NdGjfYZ5nKgeQVbW4TQNdw+z1CEyNCNAtA0fV+jhoabbwLBW1owHL4wd/4VkCsKi+AZhVzYODF0MB09nKPCA5yexPqe48ktdbZgkyxrITSX6q8kiS0w0MS2T/VpkFJOcoLkg+RHI3yZ0kL1TdlWb/gOQei3+t9LEkvyf5h7JdiLdyEGBq2KJmtlhtTXbZ2jYj4CECTLkgM5Qs+4VMU4qyoWepmmWczMAXfFQMWDT/oW85ihWu1QVgjjMyrH89BhLzfD/OtE778mztsQBwtPGbvOAUeGzB3n6m6RN0n6z7SeZvhPTjAFxmfUObN4w/zdVYRgJYprrxAG6QvhjAO9KnA5gkfSeA0zXmW2xc7UHwpopxg0yEsyTOsEhcDKrrUdvl1r7H+m+SXjK/a8Q5MmtXV9tAbnvUp2Nj6FabXuM14XSVyeci+YeNsWw+YByvpLYec1NMsFW/XHGXi9/1+2lgLYDHbFG7AOxSeReA7dK3Wp8NRZ/+TP9D9x1G2CEgDbcF3wpgFIDdehAIBD9LfxzAbQJ0rvajNa7nAMwDsFBt7wSwSvo4kfZcQNwswn7qAEAKkxyOv2tsQhFNdKWgrmkACsDqs/4LzF9YyEy++gwkZQC3HuBzRPh00WeEOIuO7T0ql21MTsTDeDYpfsmAGoOpz8CZmV6Jt7kttg1cTPJZ8SNoa+k1+yyR71CebFvLZPM5UXX3qfyVyseQvCmKNz/a+r4jeZf0bpLbSG4neb9ivCafkyPuRW1tofw+yVxb4RUkp5HcMcA2F/gOCraEeJuoRRynZrwGdg9bZNO2zo5tLxWLWTa/WcF2UzP+FXhZSbF8i8ssfi3idIETNqKtuVMQsxL59YNFoz/O9EC0MOFqkPy9oH6s7ifYiWyC+Rumuhkqf259r4l8ICLXJPkryVMK7GN0WmNEyrst9uP9PMsjgyDg7WiSfUKrUX3VFqlu5Yqd0JwY99ji+gL1KG5m/prWPjOy7LED4JoGyACutvkvG+hL0lsFp9dGwUvUsLYlG3eI2S8Bf0EntynKNnPNtoJkjeTDJJeRXE/yTR3Vl0j/2Nq/p7q2yhtVXkDyCS3iOPmtC8yvR+P5neQ8knfrZDbfbKtIzjSgLIz6LiX5pE6Kz5D8up9ndjCV+gFNo+DI7ics7xOA4iQ2PqW1CxazFZH7zHwXkeJMPp3Qh8NAOzoQBPCxICO5rVwQo+gTyT5zNJgv4P+mvAhgpvQt4kBDkY8BXBfxh84h+AJeFRHuMv6WZBA/QfkvZbSduv4JmI4XgMYAOENE/FBIOLUkIA3lbWT6j4KizNTRqaUvTcvgJf0Epfgv4ln6ZUDKTAefmZIcFGdKk5gkbXNJEpiSJDAlSZLAlCSBKcn/Tf4cAIaBG/2a32XHAAAAAElFTkSuQmCC" /></a>'; 
            var randomdiv = Math.ceil(Math.random()*randomlimit);
            var divopen = '', divclose = '', wmopen  = '', wmclose  = '';
            
            for(i=1;i<=randomdiv;i++){
                divopen+='<div>';
                divclose+='</div>';
            }
            
            if(JC.BrowserDetect.browser == 'Explorer' && JC.BrowserDetect.version == '8'){
                wmopen = '<div style="width:100%;color:#fff;height:30px;position:fixed;top:0;left:0;z-index:99999999;text-align:center;background:#666;background:rgba(0,0,0,0.4);"><div style="text-align: center">';
                wmclose = '</div></div>';
                
            } else {
                wmopen = '<div style="width:100%;color:#fff;height:30px;position:fixed;top:0;left:0;z-index:99999999;text-align:center;background:#666;background:rgba(0,0,0,0.4);"><div style="float:left;display:inline;height: 1px;"></div><div style="float:left;display:inline;">';
                wmclose = '</div><div style="width: 0;clear:both;"></div></div>'; 
            }

            JFBase('body').append(wmopen+divopen+wmi+divclose+wmclose);            
        }
        
        this._mrHide = function(){
            var imo = JFBase('img[src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHYAAAAeCAYAAAD5AOomAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAudJREFUeNrsWu1t6kAQHNLBvRKcEvxKuJRASiAlmBKgBFICLiFXAi4Bl4BLIH/mpNHqznYipIeediUL29rb253ZjwOxud/vcPn/5MUhcGJdnFgXJ9bFiXVxYp1Yh8CJdXFiXZ6J2AOvLAHAHcDVrLkA2M7Y3HHdT+QE4Iv3Z9p4FgnEoPnhut/gsISHvl9N7AAgynMEMDGgVoJsAaQHg/cB4I337ZMlf/gFqf8cDyU20UgQg8kQHvk88f7KrLyZpMi6N+q08i6vuRcy8YsgngB0krFZfy5bD6J3Ervq45y9jjrWxlU+40Lch0JsVm7S8bJ+K74dFvBoZP9qJ1FipwqJSTbOZAc6kQBsAOzFCYjuH+qcJRBdc5JEArN0ZMYeGUwE8Je2ggBuk6gD8E4bOwEvAHjl+pq9hr59iG87xvBKO6/Eoxb3lvbfaLsmySQ6zPMwg0cm9kP22K05PPVStXMVG6mz5/tPOrCVJMmO7E07bwnAkeBMMyBsaTt3ic/KfI/cvxfQexkx44K90azpJSnsPrW4o+w/iQ0rimfDZ8WnX+iyg+yRaq36pZBNUebrIBUaTcXCtK7GVL+9D6yoUVrQVwE8O9860x5DRW9cOS9r9iKfz4UDIwzRpbgbE/ewULE5SXreb1eeXabffN3J2bOTTTLBB8mUfG3MdSxkehA7I8ndsJ20CyfgidVh9ynpNStBKdmLMm9Htura+lrcg4m7mam4gQmmo247kwwP+R6bCr0+mdNwksNJzva7mWudzNWR9q6yJgmQtcroZdaB4F8qPuc517CiuoJezV4j4+NYmeNhIe4kLTksJGzGOMlYaGbacHgUsTBtYTDvJlZelJa6F8dG6twI4rsc46Oc6PpCMD2ToZNKuHBNEFvW56O00UG6h0rNXk+fr/Q5d6ZWkvIisZTiTnKYuq2Yk9pWB3MWqOGxWjb+1xj/SdHFiXVxYl2cWBcn1ol1CJxYFyfWxYl1cWJd1sv3AHBIH1NFNNLmAAAAAElFTkSuQmCC"]');
            imo.parents('div').last().remove();              
        }
        
    	this.pdk = '0f89ed06f979bd5cc73e545569d7d9a0';
    	this.psdk = '7989e3ee7852af92d7fc3d69c3646dc0';
    	this._watermarkHostname = '0x6c6f636174696f6e2e686f73746e616d65'; // = location.hostname;
    	
    	// md5/b64 (http://pajhome.org.uk/crypt/md5/ converted into literal object)
    	this.HASH = {
    		hexcase : 0, // hex output format. 0 - lowercase; 1 - uppercase
    		b64pad : "", // base-64 pad character. "=" for strict RFC compliance
    		chrsz : 8, // bits per input character. 8 - ASCII; 16 - Unicode
    		hex_md5 : function (s){ return this.binl2hex(this.core_md5(this.str2binl(s), s.length * this.chrsz));},
    		b64_md5 : function (s){ return this.binl2b64(this.core_md5(this.str2binl(s), s.length * this.chrsz));},
    		str_md5 : function (s){ return this.binl2str(this.core_md5(this.str2binl(s), s.length * this.chrsz));},
    		hex_hmac_md5 : function (key, data) { return this.binl2hex(this.core_hmac_md5(key, data)); },
    		b64_hmac_md5 : function (key, data) { return this.binl2b64(this.core_hmac_md5(key, data)); },
    		str_hmac_md5 : function (key, data) { return this.binl2str(this.core_hmac_md5(key, data)); },
    		md5_vm_test : function () {
    		  return this.hex_md5("abc") === "900150983cd24fb0d6963f7d28e17f72";
    		},
    		core_md5 : function (x, len) {
    		  x[len >> 5] |= 0x80 << ((len) % 32);
    		  x[(((len + 64) >>> 9) << 4) + 14] = len;
    		  var a =  1732584193;
    		  var b = -271733879;
    		  var c = -1732584194;
    		  var d =  271733878;
    		  for (var i = 0; i < x.length; i += 16) {
    			var olda = a;
    			var oldb = b;
    			var oldc = c;
    			var oldd = d;
    			a = this.md5_ff(a, b, c, d, x[i+ 0], 7 , -680876936);
    			d = this.md5_ff(d, a, b, c, x[i+ 1], 12, -389564586);
    			c = this.md5_ff(c, d, a, b, x[i+ 2], 17,  606105819);
    			b = this.md5_ff(b, c, d, a, x[i+ 3], 22, -1044525330);
    			a = this.md5_ff(a, b, c, d, x[i+ 4], 7 , -176418897);
    			d = this.md5_ff(d, a, b, c, x[i+ 5], 12,  1200080426);
    			c = this.md5_ff(c, d, a, b, x[i+ 6], 17, -1473231341);
    			b = this.md5_ff(b, c, d, a, x[i+ 7], 22, -45705983);
    			a = this.md5_ff(a, b, c, d, x[i+ 8], 7 ,  1770035416);
    			d = this.md5_ff(d, a, b, c, x[i+ 9], 12, -1958414417);
    			c = this.md5_ff(c, d, a, b, x[i+10], 17, -42063);
    			b = this.md5_ff(b, c, d, a, x[i+11], 22, -1990404162);
    			a = this.md5_ff(a, b, c, d, x[i+12], 7 ,  1804603682);
    			d = this.md5_ff(d, a, b, c, x[i+13], 12, -40341101);
    			c = this.md5_ff(c, d, a, b, x[i+14], 17, -1502002290);
    			b = this.md5_ff(b, c, d, a, x[i+15], 22,  1236535329);
    			a = this.md5_gg(a, b, c, d, x[i+ 1], 5 , -165796510);
    			d = this.md5_gg(d, a, b, c, x[i+ 6], 9 , -1069501632);
    			c = this.md5_gg(c, d, a, b, x[i+11], 14,  643717713);
    			b = this.md5_gg(b, c, d, a, x[i+ 0], 20, -373897302);
    			a = this.md5_gg(a, b, c, d, x[i+ 5], 5 , -701558691);
    			d = this.md5_gg(d, a, b, c, x[i+10], 9 ,  38016083);
    			c = this.md5_gg(c, d, a, b, x[i+15], 14, -660478335);
    			b = this.md5_gg(b, c, d, a, x[i+ 4], 20, -405537848);
    			a = this.md5_gg(a, b, c, d, x[i+ 9], 5 ,  568446438);
    			d = this.md5_gg(d, a, b, c, x[i+14], 9 , -1019803690);
    			c = this.md5_gg(c, d, a, b, x[i+ 3], 14, -187363961);
    			b = this.md5_gg(b, c, d, a, x[i+ 8], 20,  1163531501);
    			a = this.md5_gg(a, b, c, d, x[i+13], 5 , -1444681467);
    			d = this.md5_gg(d, a, b, c, x[i+ 2], 9 , -51403784);
    			c = this.md5_gg(c, d, a, b, x[i+ 7], 14,  1735328473);
    			b = this.md5_gg(b, c, d, a, x[i+12], 20, -1926607734);
    			a = this.md5_hh(a, b, c, d, x[i+ 5], 4 , -378558);
    			d = this.md5_hh(d, a, b, c, x[i+ 8], 11, -2022574463);
    			c = this.md5_hh(c, d, a, b, x[i+11], 16,  1839030562);
    			b = this.md5_hh(b, c, d, a, x[i+14], 23, -35309556);
    			a = this.md5_hh(a, b, c, d, x[i+ 1], 4 , -1530992060);
    			d = this.md5_hh(d, a, b, c, x[i+ 4], 11,  1272893353);
    			c = this.md5_hh(c, d, a, b, x[i+ 7], 16, -155497632);
    			b = this.md5_hh(b, c, d, a, x[i+10], 23, -1094730640);
    			a = this.md5_hh(a, b, c, d, x[i+13], 4 ,  681279174);
    			d = this.md5_hh(d, a, b, c, x[i+ 0], 11, -358537222);
    			c = this.md5_hh(c, d, a, b, x[i+ 3], 16, -722521979);
    			b = this.md5_hh(b, c, d, a, x[i+ 6], 23,  76029189);
    			a = this.md5_hh(a, b, c, d, x[i+ 9], 4 , -640364487);
    			d = this.md5_hh(d, a, b, c, x[i+12], 11, -421815835);
    			c = this.md5_hh(c, d, a, b, x[i+15], 16,  530742520);
    			b = this.md5_hh(b, c, d, a, x[i+ 2], 23, -995338651);
    			a = this.md5_ii(a, b, c, d, x[i+ 0], 6 , -198630844);
    			d = this.md5_ii(d, a, b, c, x[i+ 7], 10,  1126891415);
    			c = this.md5_ii(c, d, a, b, x[i+14], 15, -1416354905);
    			b = this.md5_ii(b, c, d, a, x[i+ 5], 21, -57434055);
    			a = this.md5_ii(a, b, c, d, x[i+12], 6 ,  1700485571);
    			d = this.md5_ii(d, a, b, c, x[i+ 3], 10, -1894986606);
    			c = this.md5_ii(c, d, a, b, x[i+10], 15, -1051523);
    			b = this.md5_ii(b, c, d, a, x[i+ 1], 21, -2054922799);
    			a = this.md5_ii(a, b, c, d, x[i+ 8], 6 ,  1873313359);
    			d = this.md5_ii(d, a, b, c, x[i+15], 10, -30611744);
    			c = this.md5_ii(c, d, a, b, x[i+ 6], 15, -1560198380);
    			b = this.md5_ii(b, c, d, a, x[i+13], 21,  1309151649);
    			a = this.md5_ii(a, b, c, d, x[i+ 4], 6 , -145523070);
    			d = this.md5_ii(d, a, b, c, x[i+11], 10, -1120210379);
    			c = this.md5_ii(c, d, a, b, x[i+ 2], 15,  718787259);
    			b = this.md5_ii(b, c, d, a, x[i+ 9], 21, -343485551);
    			a = this.safe_add(a, olda);
    			b = this.safe_add(b, oldb);
    			c = this.safe_add(c, oldc);
    			d = this.safe_add(d, oldd);
    		  }
    		  return [a, b, c, d];
    		},
    		md5_cmn : function (q, a, b, x, s, t) {
    		  return this.safe_add(this.bit_rol(this.safe_add(this.safe_add(a, q), this.safe_add(x, t)), s),b);
    		},
    		md5_ff : function (a, b, c, d, x, s, t) {
    		  return this.md5_cmn((b & c) | ((~b) & d), a, b, x, s, t);
    		},
    		md5_gg : function (a, b, c, d, x, s, t) {
    		  return this.md5_cmn((b & d) | (c & (~d)), a, b, x, s, t);
    		},
    		md5_hh : function (a, b, c, d, x, s, t) {
    		  return this.md5_cmn(b ^ c ^ d, a, b, x, s, t);
    		},
    		md5_ii : function (a, b, c, d, x, s, t) {
    		  return this.md5_cmn(c ^ (b | (~d)), a, b, x, s, t);
    		},
    		core_hmac_md5 : function (key, data) {
    		  var bkey = this.str2binl(key);
    		  if (bkey.length > 16) {
    			bkey = this.core_md5(bkey, key.length * this.chrsz);
    		  }
    		  var ipad = [16], opad = [16];
    		  for (var i = 0; i < 16; i++) {
    			ipad[i] = bkey[i] ^ 0x36363636;
    			opad[i] = bkey[i] ^ 0x5C5C5C5C;
    		  }
    		  var hash = this.core_md5(ipad.concat(this.str2binl(data)), 512 + data.length * this.chrsz);
    		  return this.core_md5(opad.concat(hash), 512 + 128);
    		},
    		safe_add : function (x, y) {
    		  var lsw = (x & 0xFFFF) + (y & 0xFFFF);
    		  var msw = (x >> 16) + (y >> 16) + (lsw >> 16);
    		  return (msw << 16) | (lsw & 0xFFFF);
    		},
    		bit_rol : function (num, cnt) {
    		  return (num << cnt) | (num >>> (32 - cnt));
    		},
    		str2binl : function (str) {
    		  var bin = [];
    		  var mask = (1 << this.chrsz) - 1;
    		  for (var i = 0; i < str.length * this.chrsz; i += this.chrsz) {
    			bin[i>>5] |= (str.charCodeAt(i / this.chrsz) & mask) << (i%32);
    		  }
    		  return bin;
    		},
    		binl2str : function (bin) {
    		  var str = "";
    		  var mask = (1 << this.chrsz) - 1;
    		  for (var i = 0; i < bin.length * 32; i += this.chrsz) {
    			str += String.fromCharCode((bin[i>>5] >>> (i % 32)) & mask);
    		  }
    		  return str;
    		},
    		binl2hex : function (binarray) {
    		  var hex_tab = this.hexcase ? "0123456789ABCDEF" : "0123456789abcdef";
    		  var str = "";
    		  for (var i = 0; i < binarray.length * 4; i++) {
    			str += hex_tab.charAt((binarray[i>>2] >> ((i%4)*8+4)) & 0xF) +
    				   hex_tab.charAt((binarray[i>>2] >> ((i%4)*8  )) & 0xF);
    		  }
    		  return str;
    		},
    		binl2b64 : function (binarray) {
    		  var tab = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    		  var str = "";
    		  for (var i = 0; i < binarray.length * 4; i += 3) {
    			var triplet = (((binarray[i   >> 2] >> 8 * ( i   %4)) & 0xFF) << 16) | (((binarray[i+1 >> 2] >> 8 * ((i+1)%4)) & 0xFF) << 8 ) | ((binarray[i+2 >> 2] >> 8 * ((i+2)%4)) & 0xFF);
    			for (var j = 0; j < 4; j++) {
    			  if (i * 8 + j * 6 > binarray.length * 32) {
    				str += this.b64pad;
    			  } else {
    				str += tab.charAt((triplet >> 6*(3-j)) & 0x3F);
    			  }
    			}
    		  }
    		  return str;
    		}
    	};
    
    	// algoritm hash domeniu
    	this._hashDomain = function (host) {
    		var arr = host.split('.');
    		var len = arr.length;
    		var hostHash = '';
    		for (var i = 0; i < len; i++) {
    			hostHash += this.HASH.hex_md5(arr[i]);
    		}
    
    		hostHash = this.HASH.hex_md5(hostHash);
    		hostHash += '-' + this.pdk;
    
    		return this.HASH.hex_md5(hostHash);
    	};
    	this._hashSubDomain = function (host) {
    		var realHost = this._realDomainName(host);
    		
    		var arr = realHost.split('.');
    		var len = arr.length;
    		var len_start = 0;
    		var hostHash = '';
    		for (var i = len_start; i < len; i++) {
    			hostHash += this.HASH.hex_md5(arr[i]);
    		}
    		
    		hostHash = this.HASH.hex_md5(hostHash);
    		hostHash += '-' + this.psdk;
    		
    		return this.HASH.hex_md5(hostHash) + '#SUB';
    	};	
    	this._realDomainName = function(url) {
    		//se scot spatiile albe de la capete
    		url = url.replace(new RegExp(/^\s+/),""); // START
    		url = url.replace(new RegExp(/\s+$/),""); // END
    		
    		//se schimba backslash cu forward-slash
    		url = url.replace(new RegExp(/\\/g),"/");
    		
    		//soate http://, https://, ftp://
    		url = url.replace(new RegExp(/^http\:\/\/|^https\:\/\/|^ftp\:\/\//i),"");
    		
    		//scoate www.
    		url = url.replace(new RegExp(/^www\./i),"");
    		
    		//scoate tot ce-i dupa primu forward-slash
    		url = url.replace(new RegExp(/\/(.*)/), "");
    		
    		var urlSuffix = '';
    		//scoate .co.uk sau .com.au sau altele de genu, si il pastreaza in urlSuffix
    		if (url.match(new RegExp(/\.[a-z]{2,3}\.[a-z]{2}$/i))) { 
    			urlSuffix = url.match(new RegExp(/\.[a-z]{2,3}\.[a-z]{2}$/i)).join("");
    			url = url.replace(new RegExp(/\.[a-z]{2,3}\.[a-z]{2}$/i),"");
    		// scoate .com sau .us sau altele de genu, si il pastreaza in urlSuffix
    		} else if (url.match(new RegExp(/\.[a-z]{2,4}$/i))) {
    			urlSuffix = url.match(new RegExp(/\.[a-z]{2,4}$/i)).join("");
    			url = url.replace(new RegExp(/\.[a-z]{2,4}$/i),"");
    		}
    		
    		//se pastreaza doar ultimu string dupa punct la care se adauga urlSuffix
    		var domainArr = url.split(".");
    		url = String(domainArr[domainArr.length - 1]).concat(urlSuffix);
    		
    		return url;			
    	};
    
    	this._init = function(code) {
    		// @DES - nu bloca scriptul daca nu se foloseste cod/cheie
    		if (typeof code === 'undefined') {
    			code = '';
    		}
    
    		this._host = eval(encryptObj.hexToString(this._watermarkHostname)); // comenteaza asta pt teste // this._host = location.hostname;
    
    		if (/^www\./i.test(this._host)) {
    			this._host = this._host.substr(4);
    		}
    
    		// pastreaza cheile - atribuirea este codata pentru a nu se gasi prea usor in ce variabile sunt stocate
    		eval(encryptObj.hexToString('0x746869732e75433d636f6465')); // this.uC=code
    
    		// nu s-a folosit code/key la initializare
    		if (this.uC === '') {
                this._takeAshower();
    			return;
    		}
    
    		if (this.uC.indexOf(',') == '-1') {
    			if (this.uC.indexOf('#SUB') != -1) {
    				var d_h = this._hashSubDomain(this._host);
    			}
    			else {
    				var d_h = this._hashDomain(this._host);
    			}
    			
    			if (d_h == this.uC) {
                    this._mrHide();
    				//cod valid
    				return; // nu continua mai jos unde se afiseaza watermarkul
    			}
    		} else {
    			var d_k = this.uC.replace(/\s/g, '');
    			var dk_array = d_k.split(',');
    			var dkl = dk_array.length;
    			
    			for (ix = 0; ix < dkl; ix++) {
    				if (dk_array[ix].indexOf('#SUB') != -1) {
    					var d_h = this._hashSubDomain(this._host);
    				}
    				else {
    					var d_h = this._hashDomain(this._host);
    				}
    				
    				if (d_h == dk_array[ix]) {

                        this._mrHide();
    					//cod valid
    					return; // nu continua mai jos unde se afiseaza watermarkul
    				}
    			}
    		}
    		
            this._takeAshower();
    	}
    }


    JC.BrowserDetect.dataBrowser = [
		{
			string: navigator.userAgent,
			subString: "Chrome",
			identity: "Chrome"
		},
		{string: navigator.userAgent,
			subString: "OmniWeb",
			versionSearch: "OmniWeb/",
			identity: "OmniWeb"
		},
		{
			string: navigator.vendor,
			subString: "Apple",
			identity: "Safari",
			versionSearch: "Version"
		},
		{
			prop: window.opera,
			identity: "Opera",
			versionSearch: "Version"
		},
		{
			string: navigator.vendor,
			subString: "iCab",
			identity: "iCab"
		},
		{
			string: navigator.vendor,
			subString: "KDE",
			identity: "Konqueror"
		},
		{
			string: navigator.userAgent,
			subString: "Firefox",
			identity: "Firefox"
		},
		{
			string: navigator.vendor,
			subString: "Camino",
			identity: "Camino"
		},
		{		// for newer Netscapes (6+)
			string: navigator.userAgent,
			subString: "Netscape",
			identity: "Netscape"
		},
		{
			string: navigator.userAgent,
			subString: "MSIE",
			identity: "Explorer",
			versionSearch: "MSIE"
		},
		{
			string: navigator.userAgent,
			subString: "Gecko",
			identity: "Mozilla",
			versionSearch: "rv"
		},
		{ 		// for older Netscapes (4-)
			string: navigator.userAgent,
			subString: "Mozilla",
			identity: "Netscape",
			versionSearch: "Mozilla"
		}
   	];
        
        
    // browser datasearch    
    JC.BrowserDetect.searchString = function (data) {
		for (var i=0;i<data.length;i++)	{
			var dataString = data[i].string;
			var dataProp = data[i].prop;
			this.versionSearchString = data[i].versionSearch || data[i].identity;
			if (dataString) {
				if (dataString.indexOf(data[i].subString) != -1)
					return data[i].identity;
			}
			else if (dataProp)
				return data[i].identity;
		}
   	}
    
    // get browser version   
    JC.BrowserDetect.searchVersion = function (dataString) {
    		var index = dataString.indexOf(this.versionSearchString);
    		if (index == -1) return;
    		return parseFloat(dataString.substring(index+this.versionSearchString.length+1));
   	}
        

    JC.BrowserDetect.browser = JC.BrowserDetect.searchString(JC.BrowserDetect.dataBrowser) || "An unknown browser";
    
    JC.BrowserDetect.version = JC.BrowserDetect.searchVersion(navigator.userAgent)
    			|| JC.BrowserDetect.searchVersion(navigator.appVersion)
    			|| "an unknown version";
                
    JC.BrowserDetect.OS = JC.BrowserDetect.searchString(JC.BrowserDetect.dataOS) || "an unknown OS";

  


/** Define UI object -------- */ 
JC.UI = function(){};


    /** UI Box Close Button Effects -------- */
    JC.UI.Alerts = function(){
        
        // default
        JFBase('.close:not(.fade-slide, .slide, .scale, .fade)').live('click', function(event){
            event.preventDefault();
            JFBase(this).parent().fadeOut('slow'); 
        });
    
        // fade
        JFBase('.close.fade').on('click', function(event){
            event.preventDefault();
            JFBase(this).parent().fadeOut('slow'); 
        });
        
        // fade-slide
        JFBase('[class*=fade-slide]').on('click', function(event){         
            event.preventDefault();
            JFBase(this).parent().animate( {left:"0px", top:"-150px"}, {queue:false, duration:500} );
            JFBase(this).parent().fadeOut(450);
        });    
        
        // scale
        JFBase('.close.scale').on('click', function(event){
            event.preventDefault();
            JFBase(this).parent().animate( {width:"0px", height:"0px", fontSize:"0px"}, {queue:false, duration:500} );
            JFBase(this).parent().fadeOut('slow');
        });    
        
        // slide
        JFBase('.alert a.close.slide').on('click', function(event){
            event.preventDefault();
            JFBase(this).parent().slideUp(350);
        });     
    }
    
    
    // load (add to HEAD) the specified stylesheet if that is not loaded yet
    JC.loadStylesheet = function(stylesheet){
        
        var stylesheets = document.styleSheets;
        for(var i=0; i<stylesheets.length; i++){
            
            if(stylesheets[i].href.indexOf(stylesheet) == -1){
                
                if (document.createStyleSheet){
                    document.createStyleSheet(stylesheet);
                } else {
                    JFBase("head").append('<link rel="stylesheet" href="'+stylesheet+'" />');    
                }
                return true;   
            }
        }
        
        return false;
            
    }
    
    // set default class (style) and load css if no style specified
    JC.setDefaultClass = function(is_css_loaded, obj, styles, default_style, default_css){
        var classes = (obj.attr('class')==undefined) ? '' : obj.attr('class');
        var class_arr = classes.split(' '); 
        var has_style = false;

        for(var i=0; i<class_arr.length; i++){
            if(JFBase.inArray(class_arr[i], styles)!==-1){    
               has_style = true;
               break;                     
            }
        }

        if(!has_style){
            if(is_css_loaded == false){
                is_css_loaded = JC.loadStylesheet(default_css);    
            }
            setTimeout(function(){
               var st = (classes == '' && obj.get(0).tagName.toLowerCase()=='table') ? 'table ' : '';   
               obj.addClass(st+default_style); 
            }, 1000); 
        }
        return is_css_loaded;
    }
    
    
    /** UI Tabs handler -------- */
    JC.UI.Tabs = function(){
        
        // init tabs
        JFBase('.tab').find('li:not(.active)').css('visibility','hidden');

        JFBase(".tab a").on('click', function () {    
            var index   = JFBase(this).parent().index(); // index of active element
            var content = JFBase(this).parent().parent().parent().find('ul')

            JFBase(this).addClass('active').parent().siblings().children().removeClass('active');
    
            content.children().css('visibility','hidden');
            content.children().removeClass('active');
            
            content.children(':eq('+index+')').css('visibility','visible');
            content.children(':eq('+index+')').addClass('active');
        
        });


        JC.UI.Tabs.Resizer = function(){
 
            var tabwidth = JFBase('.tab').css('width');
            var jTabs = JFBase('.tab'); // store all tabs on the page
            
            
            jTabs.each(function(){
                
                // UL, LI
                var content = JFBase(this).find('ul');
                var content_width = (parseInt(content.css('width'))+parseInt(content.css('paddingLeft'))+parseInt(content.css('paddingRight')));

                var tab_width = parseInt(JFBase(this).css('width'));
                var dl_width = parseInt(JFBase(this).find('dl').css('width')); // !important that width is not the real width
                var left_gap = parseInt(JFBase(this).find('dl dd:first-child').css('margin-left'));
                var dd_gap = parseInt(JFBase(this).find('dl dd:not(:first-child)').css('margin-left'));
                var dl_count = JFBase(this).find('dl dd').length;

                var container_pos = JFBase(this).parent().offset()
                var tab_pos = JFBase(this).offset();
                
                var abs_position = { 
                    top: tab_pos.top - container_pos.top,
                    left: tab_pos.left - container_pos.left 
                };

                //var abs_position = JFBase(this).offset(); // position = { left: .., top: .. }

                var w = left_gap;
                
                JFBase(this).find('dl dd').each(function(){
    
                   var index = JFBase(this).index(); 
                   w += parseInt(JFBase(this).css('width'));
                   if(w >= (content_width-parseInt(abs_position.left))){ 
                   
                       JFBase(this).css('display','none');
                       if(JFBase(this).find('a').hasClass('active')){
                            JFBase(this).parent().find('dd:first-child a').addClass('active');
                            JFBase(this).find('a').removeClass('active');
                            content.children(':eq('+index+')').removeClass('active');
                            content.children(':eq(0)').addClass('active');
                            content.children(':eq(0)').css('visibility','visible');
                       }
                       
                   } else {
                        JFBase(this).css('display','block');
                   } 
                   
                   w+=dd_gap;

                });
                   
            });            
    
        }
        
    }
    
    
    /** UI Menu buttons (button-group) handler -------- */
    JC.UI.Menubuttons = function(){
        JFBase('div.button-group button').on('click', function(){
            JFBase(this).addClass('active').siblings().removeClass('active');
        });        
    }
    
    
    /** UI Tables -------- */
    JC.UI.Tables = function(){
        JFBase("table.table tr:nth-child(odd)").addClass("odd");     
        JFBase("table.table tr:nth-child(even)").addClass("even"); 
    }


/** GRID ------- */
JC.GRID = function(){}


    // GRID Constants
    JC.GRID.RESIZE_CONTENT = true;


    // get the width of the scrollbar
    JC.GRID.scrollbarWidth = function() {
        var parent, child, width;
    
        if(width===undefined) {
            parent = JFBase('<div style="width:50px;height:50px;overflow:auto"><div/></div>').appendTo('body');
            child=parent.children();
            width=child.innerWidth()-child.height(99).innerWidth();
            parent.remove();
         }
    
         return width;
    }
    
    
    // check whether vertical scrollbar is visible
    JC.GRID.isScrollbarVisible = function(mode){
        switch(mode){
            case 'h' : return (JFBase(document).width() > JFBase(window).width()) ? true : false;
            case 'v' : 
            default  : return (JFBase(document).height() > JFBase(window).height()) ? true : false;
        }
    };

    
    // GRID init
    JC.GRID.init = function(){
        
    } // EOF GRID.init       
        
        
    JC.domainKey = '';
    
    // framework init stuffs here...
    JC.init = function(dkParam){
        if (typeof dkParam.domainKey != 'undefined') {
            JC.domainKey = dkParam.domainKey;
        }
    }
    

    // doua functii din algoritmul encriptare/decriptare @DES (http://www.tero.co.uk/des/ & http://www.netdealing.com)
    function encryptObj() {
    	//
    }
    encryptObj.stringToHex = function (s) {
      var r = "0x";
      var hexes = new Array ("0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f");
      for (var i=0; i<s.length; i++) {r += hexes [s.charCodeAt(i) >> 4] + hexes [s.charCodeAt(i) & 0xf];}
      return r;
    };
    encryptObj.hexToString = function (h) {
      var r = "";
      for (var i= (h.substr(0, 2)=="0x")?2:0; i<h.length; i+=2) {r += String.fromCharCode (parseInt (h.substr (i, 2), 16));}
      return r;
    };
    
    function domainCheck(code){
    	var o = new obj();
    	o._init(code);
    }

/**
* Globally Unique Identifier Generator
*/
JC.generateContainerIdentifier = function() {
    var i = 1;
    while(
        (document.getElementById('JCCanvasContainer' + i) != null || 
        typeof window['JCCanvasContainer' + i] != 'undefined') && 
        i < 1000
    ){
        i++;
    }
    return {
        id: 'JCCanvasContainer' + i, 
        index: i
    };
}

/**
 * method:String get/post
 * url:String reqested Url
 */
JC.ajax = function(method, url, params, callback, dataType){
    if(!url) alert('JC.ajax: Missing URL!')

    params.removeCache = Math.random()*1000000;

    JFBase[method](
        url,
        params,
        callback,
        !dataType?'html':dataType
    )
}

JC.stringToHex = function (s) {
    var r = "0x";
    var hexes = new Array ("0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f");
    for (var i=0; i<s.length; i++) {r += hexes [s.charCodeAt(i) >> 4] + hexes [s.charCodeAt(i) & 0xf];}
    return r;
}
JC.hexToString = function (h) {
    var r = "";
    for (var i= (h.substr(0, 2)=="0x")?2:0; i<h.length; i+=2) {r += String.fromCharCode (parseInt (h.substr (i, 2), 16));}
    return r;
}

/**
* Convert hex to rgba colors
*/
JC.hexToRgb = function (color, alpha) {
    if (typeof color === 'undefined' || (color.length !== 4 && color.length !== 7)) {
            return false;
    }
    if (color.length === 4) {
            color = ('#' + color.substring(1, 2)) + color.substring(1, 2) + color.substring(2, 3) + color.substring(2, 3) + color.substring(3, 4) + color.substring(3, 4);
    }
    var r = parseInt(color.substring(1, 7).substring(0, 2), 16);
    var g = parseInt(color.substring(1, 7).substring(2, 4), 16);
    var b = parseInt(color.substring(1, 7).substring(4, 6), 16);
    return 'rgba(' + r + ', ' + g + ', ' + b + ', ' + alpha + ')';
}
		
/**
* Check if string is a hex color
*/
JC.isHexColor = function(str) {
    return (/^#[0-9a-f]{6}$/i.test(str) || /^#[0-9a-f]{3}$/i.test(str));
}

JC.console = function(message){
    if(typeof window.console != 'undefined') {
        window.console.log(message);
        return;
    }
    
    if(typeof console != 'undefined'){
        console.log(message);
        return;
    }
}

/**
 * rgb to hex
 */
JC.rgb2hex = function(rgb){

    if(rgb==null || rgb=='transparent') return '#ffffff';
    
    rgb = rgb.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
    return "#" +
        ("0" + parseInt(rgb[1],10).toString(16)).slice(-2) +
        ("0" + parseInt(rgb[2],10).toString(16)).slice(-2) +
        ("0" + parseInt(rgb[3],10).toString(16)).slice(-2);
        
}

/**
 * log to console (FF / Chrome)
 */ 
JC.debug = function(string){
    var d = JFBase('#JCDebugBar');
    if(!d.length){
        d = JFBase('<div />');
        JFBase('body').append(d);
        d.css({
            position: 'absolute',
            left: 0,
            top: 0,
            background: '#000000',
            color: '#ffffff',
            zIndex: 100000
        }).attr('id', 'JCDebugBar');
    }
    
    d.html(string)
    d.show();
}


JC.wmRepos = function(){
    if(JC.BrowserDetect.browser != 'Explorer'){
        
        var imo = JFBase('img[src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHYAAAAeCAYAAAD5AOomAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAudJREFUeNrsWu1t6kAQHNLBvRKcEvxKuJRASiAlmBKgBFICLiFXAi4Bl4BLIH/mpNHqznYipIeediUL29rb253ZjwOxud/vcPn/5MUhcGJdnFgXJ9bFiXVxYp1Yh8CJdXFiXZ6J2AOvLAHAHcDVrLkA2M7Y3HHdT+QE4Iv3Z9p4FgnEoPnhut/gsISHvl9N7AAgynMEMDGgVoJsAaQHg/cB4I337ZMlf/gFqf8cDyU20UgQg8kQHvk88f7KrLyZpMi6N+q08i6vuRcy8YsgngB0krFZfy5bD6J3Ervq45y9jjrWxlU+40Lch0JsVm7S8bJ+K74dFvBoZP9qJ1FipwqJSTbOZAc6kQBsAOzFCYjuH+qcJRBdc5JEArN0ZMYeGUwE8Je2ggBuk6gD8E4bOwEvAHjl+pq9hr59iG87xvBKO6/Eoxb3lvbfaLsmySQ6zPMwg0cm9kP22K05PPVStXMVG6mz5/tPOrCVJMmO7E07bwnAkeBMMyBsaTt3ic/KfI/cvxfQexkx44K90azpJSnsPrW4o+w/iQ0rimfDZ8WnX+iyg+yRaq36pZBNUebrIBUaTcXCtK7GVL+9D6yoUVrQVwE8O9860x5DRW9cOS9r9iKfz4UDIwzRpbgbE/ewULE5SXreb1eeXabffN3J2bOTTTLBB8mUfG3MdSxkehA7I8ndsJ20CyfgidVh9ynpNStBKdmLMm9Htura+lrcg4m7mam4gQmmo247kwwP+R6bCr0+mdNwksNJzva7mWudzNWR9q6yJgmQtcroZdaB4F8qPuc517CiuoJezV4j4+NYmeNhIe4kLTksJGzGOMlYaGbacHgUsTBtYTDvJlZelJa6F8dG6twI4rsc46Oc6PpCMD2ToZNKuHBNEFvW56O00UG6h0rNXk+fr/Q5d6ZWkvIisZTiTnKYuq2Yk9pWB3MWqOGxWjb+1xj/SdHFiXVxYl2cWBcn1ol1CJxYFyfWxYl1cWJd1sv3AHBIH1NFNNLmAAAAAElFTkSuQmCC"]');
        var div = imo.parents('div').last();
        var div2 = imo.parents('div').last().children().first();
        var div3 = imo.parents('div:eq(0)');
                
        if(div.length > 0){
            if(JFBase('.row').length == 0){
                //div2.remove();
                div3.css({'text-align':'center','float':'none'});    
            } else {
                var left = JFBase('.row:eq(0)').offset().left;
                div2.css('width',left);    
            }                
        }

    }
}

JC.mobileArray = ["Mobile", "Android", "Kindle", "Silk", "iPod", "iPad", "iPhone", "BlackBerry", "PlayBook", "RIM", "Tablet"];
JC.noFontFace = ["Windows Phone", "IEMobile", "BlackBerry", "BlackBerry", "PlayBook", "RIM", "Tablet"];

JC.isMobileSafari = function(){
	return navigator.userAgent.match(/(iPod|iPhone|iPad)/);
};
JC.isMobileDevice = function(){
	/*if (config._mobileVersion == "1") { return true; }*/
	return JC.testDevice(JC.mobileArray);
};
JC.isStupidMobile = function(){
	return JC.testDevice(JC.noFontFace);
};
JC.isSmallMobile = function(){
	return (JC.isMobileDevice() && $(window).width() * $(window).height() <= 640 * 480)
};
JC.testDevice = function(words){
	var i;
	for (i = 0; i < words.length; i++)
		if (navigator.appVersion.indexOf(words[i]) > -1) return true;
	for (i = 0; i < words.length; i++)
		if (navigator.userAgent.indexOf(words[i]) > -1) return true;
	return false;
};

JC.detectIE58 = function() {
    var arr = ["MSIE 8", "MSIE 7", "MSIE 6", "MSIE 5"];
    return JC.testDevice(arr);
}
    
// check device is touchable
JC.isTouchable = function() {
    return !!('ontouchstart' in window) ? 1 : 0;
}   
    
// for page reload (we check if hash is exist)
JC.hasHash = function(href){
    return (href.lastIndexOf('#')==-1) ? false : true;
}

// Page object
JC.pageObj = {path:''};

// page load
var isLoadingContent = false;
var transitionDuration = 1000;
JC.loadPage = function(url, transitionEffect, pageInfoObj) {

    if (isLoadingContent) return;
    isLoadingContent = true;
    var content = JFBase("#content");
    content.trigger("contentLoadStart");
    JFBase.ajax({
        url : url,
        error : function() {
            isLoadingContent = false;
            content.trigger("contentLoadError");
        },
        success : function(data) {
            // close menus
			var win_width = (JC.GRID.isScrollbarVisible()) ? (JFBase(window).width() + JC.GRID.scrollbarWidth()) : JFBase(window).width();
			if(win_width < 768){
				JFBase('.menu ul.main-level').slideUp();
			}              
            // store page path
			JC.pageObj.path = location.href;
			
			animate(data, transitionEffect);
            updatePageInfo(pageInfoObj);
        }
    })

    function animate(data, transitionEffect) {
        if (!transitionEffect || JC.detectIE58()) transitionEffect = "none";
        var oldContent = JFBase("#pageContent");

        switch (transitionEffect) {
            case "none" :
                oldContent.html(data);
                content.trigger("contentLoadComplete");
                isLoadingContent = false;
                break;

            case "fade" :
                var newContent = oldContent.css({filter:'inherit', position : 'absolute', top : 0, left: 0, margin : 0}).clone();
                newContent.css({}).html(data).show().hide().appendTo(content);
                content.css({'position' : 'relative'}).height(Math.max(newContent.height(), oldContent.height()));

                oldContent.hide().show().fadeOut(transitionDuration, function() { JFBase(this).remove(); content.height("auto"); });
                newContent.fadeIn(transitionDuration, function() {
                    JFBase(this).css('position', 'relative');
                    content.height(JFBase(this).height()).trigger("contentLoadComplete");
                    isLoadingContent = false;
                });
                break;

            case "slide" :
                var wdt = JFBase(window).width();
                var newContent = oldContent.css({position : 'absolute', top : 0, left: 0, margin : 0}).clone();
                newContent.html(data).css({left: wdt + 'px'}).appendTo(content);
                content.css({ 'position' : 'relative'}).height(Math.max(newContent.height(), oldContent.height()));

                oldContent.animate({'left' : (0 - wdt) + 'px'}, transitionDuration, function() { JFBase(this).remove(); content.height("auto"); });
                newContent.animate({'left' : '0px'}, transitionDuration, function() {
                    JFBase(this).css('position', 'relative');
                    content.height(JFBase(this).height()).trigger("contentLoadComplete");
                    isLoadingContent = false;
                });
                break;
        }
    }

    function updatePageInfo(pageInfoObj) {
        if (!pageInfoObj) return;
        if (pageInfoObj.title && pageInfoObj.title.length > 0) {
            document.title = pageInfoObj.title;
        }

        if (pageInfoObj.description && pageInfoObj.description.length > 0) {
            JFBase('meta[name]').filter(function() { return this.name.toLowerCase() == 'description'; }).attr('content', pageInfoObj.description);
        }

        if (pageInfoObj.keywords && pageInfoObj.keywords.length > 0) {
            JFBase('meta[name]').filter(function() { return this.name.toLowerCase() == 'keywords'; }).attr('content', pageInfoObj.keywords);
        }
    }
    
    // scroll to top
    JFBase(window).scrollTop('0px');
}


JFBase(document).ready(function(){

   var dc = new domainCheck(JC.domainKey);

   JC.wmRepos();
      
   JC.UI.Alerts();           // load UI closeButton effects
   JC.UI.Menubuttons();      // load UI menubuttons handler
   JC.UI.Tabs();             // load UI tabs handler
   JC.UI.Tables();           // load UI tables handler
       
   // Hide last tab if browserWidth > tabsWidth
   JC.UI.Tabs.Resizer(); // init
   var resizeTimer;
   
   JFBase(window).resize(function() { // handle window resize events
       clearTimeout(resizeTimer);
       resizeTimer = setTimeout(JC.wmRepos,1);
       resizeTimer = setTimeout(JC.UI.Tabs.Resizer, 1);
   });

});
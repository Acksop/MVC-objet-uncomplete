<?php
/*
    Plugin Name: JF Contact Info Widget
    Plugin URI: http://www.jumpeye.com
    Description: Displays the contact info box
    Version: 1.0
    Author: Jumpeye Components
    Author URI: http://www.jumpeye.com
    License: GPL2
*/

// register JFContactInfoWidget widget
add_action('widgets_init', create_function('', 'return register_widget("JFContactInfoWidget");')); 

/**
 * Adds JFContactInfoWidget widget.
 */
class JFContactInfoWidget extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	public function __construct() {
        
		parent::__construct(
	 		'JFContactInfoWidget', // Base ID
			'JF Contact Info Widget', // Name (you will see it in Available Widgets)
			array( 'description' => __( 'Displays the contact info box.', 'prestige' ),) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	public function widget( $args, $instance ) {
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );

        /* Custom Options */
        // Our options from the widget settings.
        $address  = (isset($instance['address'])) ? $instance['address'] : '' ;
        $email    = (isset($instance['email']))   ? $instance['email']   : '' ;
        $web      = (isset($instance['web']))   ? $instance['web']   : '' ;
        $phone    = (isset($instance['phone']))   ? $instance['phone']   : '' ;
        $mobile   = (isset($instance['mobile']))   ? $instance['mobile']   : '' ;
        $fax      = (isset($instance['fax']))   ? $instance['fax']   : '' ;
        $skype    = (isset($instance['skype']))   ? $instance['skype']   : '' ;
        $facebook = (isset($instance['facebook']))   ? $instance['facebook']   : '' ;
        $twitter  = (isset($instance['twitter']))   ? $instance['twitter']   : '' ;
        $other    = (isset($instance['other']))   ? $instance['other']  : '' ;

        // Before widget - as defined in your specific theme.
		echo $before_widget;
        
        if ( !empty( $title ) ){
	        echo $before_title . $title . $after_title;
        }        

        echo '<div class="contact_info_widget">';

        if( !empty($address) ){
            echo '<h4 class="title">'.__('Address','prestige').'</h4><p class="text">'.$address.'</p>';    
        }       
         
        if( !empty($email) ){
            echo '<h4 class="title">'.__('E-mail: ','prestige').'</h4><p class="text"><a href="mailto:'.$email.'" class="color_scheme">'.$email.'</a></p>'; 
        }  
        
        if( !empty($web) ){
            echo '<h4 class="title">'.__('Web: ','prestige').'</h4><p class="text"><a href="'.$web.'" target="_blank" class="color_scheme">'.$web.'</a></p>'; 
        } 
           
        if( !empty($phone) ){
            echo '<h4 class="title">'.__('Phone: ','prestige').'</h4><p class="text">'.$phone.'</p>'; 
        } 
        
        if( !empty($mobile) ){
            echo '<h4 class="title">'.__('Mobile: ','prestige').'</h4><p class="text">'.$mobile.'</p>'; 
        } 
        
        if( !empty($fax) ){
            echo '<h4 class="title">'.__('Fax: ','prestige').'</h4><p class="text">'.$fax.'</p>'; 
        } 
         
        if( !empty($skype) ){
            echo '<h4 class="title">'.__('Skype: ','prestige').'</h4><p class="text">'.$skype.'</p>'; 
        } 
        
        if( !empty($facebook) ){
            echo '<h4 class="title">'.__('Facebook: ','prestige').'</h4><p class="text">'.$facebook.'</p>'; 
        } 
        
        if( !empty($twitter) ){
            echo '<h4 class="title">'.__('Twitter: ','prestige').'</h4><p class="text">'.$twitter.'</p>'; 
        } 
        
        if( !empty($other) ){
            echo '<h4 class="title">'.__('Other: ','prestige').'</h4><p class="text">'.$other.'</p>'; 
        }                                                                                           
        echo '</div>';

        /* After widget - as defined in your specific theme. */
		echo $after_widget;
        ?>
            <table class="table_of_shadows" border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td class="post_left"></td>
                    <td class="post_center">&nbsp;</td>
                    <td class="post_right"></td>
                </tr>
            </table>          
        <?php
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) {

        /* Default Widget Settings */
    		
    	$defaults = array(
    		'title'   => '',
            'address' => '',
            'email'   => '',
            'web'     => '',
            'phone'   => '',
            'mobile'  => '',
            'fax'     => '',
            'skype'   => '',
            'facebook'=> '',
            'twitter' => '',
            'other'   => ''
    	); 

        $instance = wp_parse_args( (array) $instance, $defaults );   
        $title    = esc_attr( $instance['title'] );
        $address  = $instance['address'];
        $email    = $instance['email'];
        $web      = $instance['web'];
        $phone    = $instance['phone'];
        $mobile   = $instance['mobile'];
        $fax      = $instance['fax'];
        $skype    = $instance['skype'];
        $facebook = $instance['facebook'];
        $twitter  = $instance['twitter'];
        $other    = $instance['other'];
        ?>
		<p>
    		<label for="<?php echo $this->get_field_name( 'title' ); ?>"><?php _e( 'Title:', 'prestige' ); ?></label> 
    		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo $title; ?>" />
		</p>        
		<p>
    		<label for="<?php echo $this->get_field_name( 'address' ); ?>"><?php _e( 'Address:', 'prestige' ); ?></label> 
    		<input class="widefat" id="<?php echo $this->get_field_id( 'address' ); ?>" name="<?php echo $this->get_field_name( 'address' ); ?>" type="text" value="<?php echo $address; ?>" />
		</p>
		<p>
    		<label for="<?php echo $this->get_field_name( 'email' ); ?>"><?php _e( 'E-mail:', 'prestige' ); ?></label> 
    		<input class="widefat" id="<?php echo $this->get_field_id( 'email' ); ?>" name="<?php echo $this->get_field_name( 'email' ); ?>" type="text" value="<?php echo $email; ?>" />
		</p>
		<p>
    		<label for="<?php echo $this->get_field_name( 'web' ); ?>"><?php _e( 'Web:', 'prestige' ); ?></label> 
    		<input class="widefat" id="<?php echo $this->get_field_id( 'web' ); ?>" name="<?php echo $this->get_field_name( 'web' ); ?>" type="text" value="<?php echo $web; ?>" />
		</p>          
		<p>
    		<label for="<?php echo $this->get_field_name( 'phone' ); ?>"><?php _e( 'Phone:', 'prestige' ); ?></label> 
    		<input class="widefat" id="<?php echo $this->get_field_id( 'phone' ); ?>" name="<?php echo $this->get_field_name( 'phone' ); ?>" type="text" value="<?php echo $phone; ?>" />
		</p> 
		<p>
    		<label for="<?php echo $this->get_field_name( 'mobile' ); ?>"><?php _e( 'Mobile:', 'prestige' ); ?></label> 
    		<input class="widefat" id="<?php echo $this->get_field_id( 'mobile' ); ?>" name="<?php echo $this->get_field_name( 'mobile' ); ?>" type="text" value="<?php echo $mobile; ?>" />
		</p> 
		<p>
    		<label for="<?php echo $this->get_field_name( 'fax' ); ?>"><?php _e( 'Fax:', 'prestige' ); ?></label> 
    		<input class="widefat" id="<?php echo $this->get_field_id( 'fax' ); ?>" name="<?php echo $this->get_field_name( 'fax' ); ?>" type="text" value="<?php echo $fax; ?>" />
		</p>
		<p>
    		<label for="<?php echo $this->get_field_name( 'skype' ); ?>"><?php _e( 'Skype:', 'prestige' ); ?></label> 
    		<input class="widefat" id="<?php echo $this->get_field_id( 'skype' ); ?>" name="<?php echo $this->get_field_name( 'skype' ); ?>" type="text" value="<?php echo $skype; ?>" />
		</p>         
		<p>
    		<label for="<?php echo $this->get_field_name( 'facebook' ); ?>"><?php _e( 'Facebook:', 'prestige' ); ?></label> 
    		<input class="widefat" id="<?php echo $this->get_field_id( 'facebook' ); ?>" name="<?php echo $this->get_field_name( 'facebook' ); ?>" type="text" value="<?php echo $facebook; ?>" />
		</p> 
		<p>
    		<label for="<?php echo $this->get_field_name( 'twitter' ); ?>"><?php _e( 'Twitter:', 'prestige' ); ?></label> 
    		<input class="widefat" id="<?php echo $this->get_field_id( 'twitter' ); ?>" name="<?php echo $this->get_field_name( 'twitter' ); ?>" type="text" value="<?php echo $twitter; ?>" />
		</p>                                            
		<p>
    		<label for="<?php echo $this->get_field_name( 'other' ); ?>"><?php _e( 'Other:', 'prestige' ); ?></label> 
    		<input class="widefat" id="<?php echo $this->get_field_id( 'other' ); ?>" name="<?php echo $this->get_field_name( 'other' ); ?>" type="text" value="<?php echo $other; ?>" />
		</p>  
		<?php 
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance            = array();
		$instance['title']   = ( !empty( $new_instance['title'] ) )   ? strip_tags( $new_instance['title'] )   : '';
        $instance['address'] = ( !empty( $new_instance['address'] ) ) ? strip_tags( $new_instance['address'] ) : '';
        $instance['email']   = ( !empty( $new_instance['email'] ) )   ? strip_tags( $new_instance['email'] )   : '';
        $instance['web']     = ( !empty( $new_instance['web'] ) )   ? strip_tags( $new_instance['web'] )   : '';
        $instance['phone']   = ( !empty( $new_instance['phone'] ) )   ? strip_tags( $new_instance['phone'] )   : '';
        $instance['mobile']  = ( !empty( $new_instance['mobile'] ) )   ? strip_tags( $new_instance['mobile'] )   : '';
        $instance['fax']     = ( !empty( $new_instance['fax'] ) )   ? strip_tags( $new_instance['fax'] )   : '';
        $instance['skype']   = ( !empty( $new_instance['skype'] ) )   ? strip_tags( $new_instance['skype'] )   : '';
        $instance['facebook']= ( !empty( $new_instance['facebook'] ) )   ? strip_tags( $new_instance['facebook'] )   : '';
        $instance['twitter'] = ( !empty( $new_instance['twitter'] ) )   ? strip_tags( $new_instance['twitter'] )   : '';
        $instance['other']   = ( !empty( $new_instance['other'] ) )   ? strip_tags( $new_instance['other'] )   : '';
		return $instance;
	}
    
} // class JFContactInfoWidget

?>
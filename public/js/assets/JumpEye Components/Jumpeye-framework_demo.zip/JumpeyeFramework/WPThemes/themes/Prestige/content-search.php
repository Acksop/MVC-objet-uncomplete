<?php
/**
 * @package Prestige
 * @since Prestige 1.0
 */
?>

      <div class="post single" id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
          <div class="thumbnail_holder">
          <?php if ( has_post_thumbnail()) : ?>
              <a href="<?php the_permalink(); ?>">
              <div class="post_thumbnail">
              <?php the_post_thumbnail(); ?>
              </div> 
              </a> 
              <div class="post_meta_data"><p>By <?php the_author(); ?> on <?php echo get_the_date('M j, Y'); ?> in <span class="post_category"><?php the_category(', '); ?></span> | <span class="post_comments"><?php comments_popup_link(__('0 comments','prestige'),__('1 comment','prestige'),__('% comments','prestige')); ?></span></p></div>
          <?php else: ?>     
              <div class="post_meta_data_no_thumb">By <?php the_author(); ?> on <?php echo get_the_date('M j, Y'); ?> in <span class="post_category"><?php the_category(', '); ?></span> | <span class="post_comments"><?php comments_popup_link(__('0 comments','prestige'),__('1 comment','prestige'),__('% comments','prestige')); ?></span></div>           
          <?php endif; ?>
          </div>
          <h2 class="post_title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
          <p class="post_excerpt"><?php echo do_shortcode(get_the_excerpt()); ?></p>
          <p class="post_read_more"><a class="read_more" href="<?php the_permalink(); ?>"><?php _e('read more ...','prestige'); ?></a></p>
      </div>
        <table class="table_of_shadows" border="0" cellpadding="0" cellspacing="0" style="width:  100%; margin-top: -1px">
            <tr>
                <td class="post_left"></td>
                <td class="post_center">&nbsp;</td>
                <td class="post_right"></td>
            </tr>
        </table> 

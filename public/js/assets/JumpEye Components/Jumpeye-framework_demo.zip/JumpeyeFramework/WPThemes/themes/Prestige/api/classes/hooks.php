<?php
/** 
 * JHooks class
 * @package Jumpey 
 */

class JHooks{
    
    /** 
     * constructor method
     */ 
    public function __construct(){
        add_action('admin_head', array($this, 'favicon') ); 
    }
    
    /**
     * Domain key
     */
    public static function domain_key(){
        $options = get_option( 'jf_theme_general_settings' ); 
        
        $domain_key = (isset($options['domain_keys'])) ? $options['domain_keys'] : '';
    ?>
    <script type="text/javascript">
		(function() {
			JC.init({
            domainKey: '<?php echo $domain_key; ?>' //'YourDomainKey'
        });
        })();    
    </script>
    <?php        
    }   
    
       
    /**
     * add favicon
     */
    public static function favicon(){
        $options = get_option('jf_theme_general_settings');
        $favicon = (isset($options['favicon'])) ? $options['favicon'] : 'http://';  
        if ( !in_array($favicon, array('','http://')) ){
        ?>
<!-- favicon -->
<link rel="shortcut icon" href="<?php echo stripslashes( $favicon ); ?>" type="image/x-icon" />
        <?php    
        }
    }      


    /** 
     * custom header features (implemented in api.php) 
     * for example add stylesheets rigth after <head> tag
     */
    public static function custom_head() {
        do_action( 'custom_head' );
    } 
    
    
    /** 
     * custom footer features (implemented in api.php)
     * for example add scripts rigth before </body> tag 
     */
    public static function custom_footer(){
        do_action( 'custom_footer' );
    }
    
    
    /**
     * site meta data
     */
    public static function site_metadata(){
        $options = get_option('jf_theme_general_settings');
        $meta = array();
        // meta data
        
        if( isset($options['meta_title']) && trim($options['meta_title']) !='' ){
            $title = $options['meta_title'];
        } else {
            $title = get_bloginfo('name');
        }

        $meta[] = '<title>'.$title.'</title>';
 
        if( isset($options['meta_description']) ){
            $meta[] = '<meta name="description" content="'.$options['meta_description'].'" />';
        }
        if( isset($options['meta_keywords']) ){
            $meta[] = '<meta name="keywords" content="'.$options['meta_keywords'].'" />';
        }
        if( count($meta) > 0){             
            echo implode("\n",$meta)."\n";
        }
    }
    
    
    /**
     * Load css and js for Fancybox
     */ 
    public static function fancybox(){
        if( current_theme_supports( 'fancybox' ) && self::isFancyboxEnabled() && !is_admin() ) {
            /* Fancybox scripts. */
            wp_register_script( 'fancybox', THEME_ROOT_URI.'/api/js/fancybox/jquery.fancybox-1.3.4.pack.js', array('jquery') );
            wp_register_script( 'jquery-easing', THEME_ROOT_URI.'/api/js/fancybox/jquery.easing-1.3.pack.js', array('jquery') );
            wp_register_script( 'jquery-mousewheel', THEME_ROOT_URI.'/api/js/fancybox/jquery.mousewheel-3.0.4.pack.js', array('jquery') );
            wp_enqueue_script( 'fancybox');
            wp_enqueue_script( 'custom-fancybox' );
            wp_enqueue_script( 'jquery-easing' );
            wp_enqueue_script( 'jquery-mousewheel' );
            
            /* Fancybox styles. */
            wp_register_style( 'fancybox-stylesheet', THEME_ROOT_URI.'/api/js/fancybox/jquery.fancybox-1.3.4.css' );
            wp_enqueue_style( 'fancybox-stylesheet' );
        }        
    }
      
      
    /**
     * Checks fancybox is enabled
     */    
    private function isFancyboxEnabled(){
        // get display options
        $options = get_option('jf_theme_design_settings');
        
        // if display options have never set before
        if( !isset( $options['nothing'] ) ){
            return ENABLE_FANCYBOX_DEFAULT;
        } else { // display options have set 
            return (isset($options['enable_fancybox'])) ? 1 : 0;    
        }
    }
                  
} // EOF JHooks
?>
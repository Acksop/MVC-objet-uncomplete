<?php
/**
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package Prestige
 * @since Prestige 1.0
 */

get_header(); ?>
    <div class="row margin_top_32">
		<div id="primary" class="content-area columns grid_12">
			<div id="content" class="site-content" role="main">

			<?php 
                if ( have_posts() ) : 
                
                    // Top navigation
                    $post_per_page = get_option('posts_per_page');
                    $count_posts = wp_count_posts('post'); 
                    $published_posts = $count_posts->publish;
                    
                    if($published_posts > $post_per_page) :  
                        JF_Frontend::getNavigation();               
                    endif; 
                    
                    // Start the Loop
                    while ( have_posts() ) : 
                        
                        the_post();
                        
						/* Include the Post-Format-specific template for the content.
						 * If you want to overload this in a child theme then include a file
						 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
						 */
                        $post_format = get_post_format(); 
                        if( empty ($post_format) ){
                            get_template_part( 'content-standard' );
                        } else {
                            get_template_part( 'content', $post_format );    
                        }
                        
                     endwhile; 
                
                    // bottom nav
                    $post_per_page = get_option('posts_per_page');
                    $count_posts = wp_count_posts('post'); 
                    $published_posts = $count_posts->publish;
                    
                    if($published_posts > $post_per_page) :  
                        JF_Frontend::getNavigation('bottom');               
                    endif;  
                    
                else :
                
                    get_template_part( 'no-results', 'index' );
                    
                endif;
             ?>

			</div><!-- #content .site-content -->
		</div><!-- #primary .content-area .columns .grid_12 -->

        <?php get_sidebar(); ?>
    </div><!-- .row -->
<?php get_footer(); ?>
<?php
/*
    Plugin Name: JF Featured Posts Widget
    Plugin URI: http://www.jumpeye.com
    Description: Displays the recent posts of the specified category highlighting them in the content of the page.
    Version: 1.0
    Author: Jumpeye Components
    Author URI: http://www.jumpeye.com
    License: GPL2
*/

// register JFLatestCatPostsWidget widget
add_action('widgets_init', create_function('', 'return register_widget("JFLatestCatPostsWidget");')); 

/**
 * Adds JFLatestCatPostsWidget widget.
 */
class JFLatestCatPostsWidget extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	public function __construct() {
        
		parent::__construct(
	 		'JFLatestCatPostsWidget', // Base ID
			'JF Featured Posts Widget', // Name (you will see it in Available Widgets)
			array( 'description' => __( 'Displays the recent posts of the specified category highlighting them in the content of the page.', 'prestige' ),) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	public function widget( $args, $instance ) {
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );

        /* Custom Options */
        // Our options from the widget settings.
        $number         = (isset($instance['number'])) ? $instance['number'] : 3 ;
        $post_title     = (isset($instance['post_title'])) ? $instance['post_title'] : false ;
        $excerpt        = (isset($instance['excerpt'])) ? $instance['excerpt'] : false ;
        $excerpt_length = (isset($instance['excerpt_length'])) ? (int)($instance['excerpt_length']) : 0;
        $thumbnail      = (isset($instance['thumbnail'])) ? $instance['thumbnail'] : false ;
        $cat            = (isset($instance['cat'])) ? $instance['cat'] : 1 ;
        $icon_1         = (isset($instance['icon_1'])) ? $instance['icon_1'] : 0 ;
        $icon_2         = (isset($instance['icon_2'])) ? $instance['icon_2'] : 0 ;
        $icon_3         = (isset($instance['icon_3'])) ? $instance['icon_3'] : 0 ;         
        
        // title
        if ( ! empty( $title ) )
		echo $before_title . $title . $after_title;   
                
        // Before widget - as defined in your specific theme.
		echo $before_widget;
                
        /* Display The Widget */   
           

            /* Create a new post query */
            $query = new WP_Query();
            //Send our widget options to the query
            $query->query( array(
            	'post_type'           => 'post',
                'posts_per_page'      => $number,
                'ignore_sticky_posts' => 1,
                'cat' => $cat
               )
            );
            
            // key = number of columns (number of posts), value = XX from grid_XX class
            $cols = array(
                1 => 18,
                2 => 9,
                3 => 6,
                6 => 3
            );

            $p = 0;
            if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post();
            ?>  
            <div class="columns grid_<?php echo $cols[$number]; ?>">
            <?php
                switch($p){
                    case 0 :
                        if( isset($icon_1) && $icon_1 > 0){
                            echo '<div class="services_icons" style="background-image:url('.THEME_ROOT_URI.'/images/icons/content/'.JApi::$content_icons[$icon_1].');"></div>';    
                        } 
                    break;  
                    case 1 :
                        if( isset($icon_2) && $icon_2 > 0){
                            echo '<div class="services_icons" style="background-image:url('.THEME_ROOT_URI.'/images/icons/content/'.JApi::$content_icons[$icon_2].');"></div>';    
                        } 
                    break;
                    case 2 :
                        if( isset($icon_3) && $icon_3 > 0){
                            echo '<div class="services_icons" style="background-image:url('.THEME_ROOT_URI.'/images/icons/content/'.JApi::$content_icons[$icon_3].');"></div>';    
                        } 
                    break;                                                         
                }

            ?>                    
			<?php if ($post_title == true) { ?>
				<h4 class="post_title featured"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
			<?php } ?>  
			<?php if ($excerpt == true) {  ?>
                <p class="excerpt">                    
				    <?php echo $this->getExcerpt($excerpt_length, get_permalink()); ?>
                </p>
			<?php } ?>  
			<?php if (has_post_thumbnail() && $thumbnail == true) { ?>
            <?php
                $post_id = get_the_ID();
                $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post_id ), 'single-post-thumbnail' );
            ?>
                <div class="project_img_holder">
                    <div class="image_wrapper" style="background: url(<?php echo $image[0]; ?>) no-repeat center center; -webkit-background-size: cover;  -moz-background-size: cover;  -o-background-size: cover;  background-size: cover; filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='<?php echo $image[0]; ?>',sizingMethod='scale'); ">
        				 <a href="<?php the_permalink(); ?>" style="position: absolute; width: 100%; height: 100%; left: 0; top: 0;"></a>
                         <div class="cover"></div>
                         <div class="circle background_scheme"></div>
                         <a class="navigator" href="<?php the_permalink(); ?>"></a>
                    </div>
                    <table class="table_of_shadows" border="0" cellpadding="0" cellspacing="0">
                        <tr>
                            <td class="img_left"></td>
                            <td class="img_center">&nbsp;</td>
                            <td class="img_right"></td>
                        </tr>
                    </table> 
                </div>
			<?php
                } 
                $p++;
            ?>                        
            </div> 					
            <?php endwhile; endif;
       
        /* After widget - as defined in your specific theme. */
		echo $after_widget;
        wp_reset_postdata();
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) {
	   
        /* Default Widget Settings */
    		
    	$defaults = array(
    		'title'          => '',
    		'number'         => 3,
            'post_title'     => true,
            'excerpt'        => true,
            'excerpt_length' => 50,
            'thumbnail'      => true,
            'cat'            => 1,
            'icon_1'         => 0,
            'icon_2'         => 0,
            'icon_3'         => 0             
    	); 

        $instance       = wp_parse_args( (array) $instance, $defaults );   
        $title          = esc_attr( $instance['title'] );
        $number         =  $instance['number'];
        $post_title     =  $instance['post_title'];
        $excerpt        =  $instance['excerpt'];
        $excerpt_length =  $instance['excerpt_length'];
        $thumbnail      =  $instance['thumbnail'];
        $cat            =  $instance['cat'];
        $numbers        = array(1,2,3);
        $icon_1         =  $instance['icon_1'];
        $icon_2         =  $instance['icon_2'];
        $icon_3         =  $instance['icon_3'];         
        
		?>
		<p>
    		<label for="<?php echo $this->get_field_name( 'title' ); ?>"><?php _e( 'Title:', 'prestige' ); ?></label> 
    		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('cat')); ?>"><?php _e('Category: ', 'prestige'); ?></label>
			<?php wp_dropdown_categories(array('class'=>'widefat', 'name' => $this->get_field_name('cat'), 'show_option_all' => __('All categories', 'prestige'), 'hide_empty' => 1, 'hierarchical' => 1, 'selected' => $cat)); ?>
		</p>         
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php _e('Number of posts:', 'prestige'); ?></label>
			<select class="widefat" name="<?php echo $this->get_field_name('number'); ?>" id="<?php echo $this->get_field_id('number'); ?>">
				<?php foreach ($numbers as $k => $v) { ?>
					<option <?php selected($number, $v) ?> value="<?php echo $v; ?>"><?php echo $v; ?></option>
				<?php } ?>
			</select>
		</p>  
   		<p>
			<input id="<?php echo $this->get_field_id('post_title'); ?>" name="<?php echo $this->get_field_name('post_title'); ?>" type="checkbox" value="1" <?php checked('1', $post_title); ?> />&nbsp;
            <label for="<?php echo esc_attr($this->get_field_id('post_title')); ?>"><?php _e('Display post title?', 'prestige'); ?></label>
		</p> 
   		<p>
			<input id="<?php echo $this->get_field_id('excerpt'); ?>" name="<?php echo $this->get_field_name('excerpt'); ?>" type="checkbox" value="1" <?php checked('1', $excerpt); ?> />&nbsp;
            <label for="<?php echo esc_attr($this->get_field_id('excerpt')); ?>"><?php _e('Display post excerpt?', 'prestige'); ?></label>
		</p>   
		<p>
    		<label for="<?php echo $this->get_field_name( 'excerpt_length' ); ?>"><?php _e( 'Lenght of excerpt:', 'prestige' ); ?></label> 
    		<input class="widefat" id="<?php echo $this->get_field_id( 'excerpt_length' ); ?>" name="<?php echo $this->get_field_name( 'excerpt_length' ); ?>" type="text" value="<?php echo $excerpt_length; ?>" />
		</p>
   		<p>
			<input id="<?php echo $this->get_field_id('thumbnail'); ?>" name="<?php echo $this->get_field_name('thumbnail'); ?>" type="checkbox" value="1" <?php checked('1', $thumbnail); ?> />&nbsp;
            <label for="<?php echo esc_attr($this->get_field_id('thumbnail')); ?>"><?php _e('Display post featured image?', 'prestige'); ?></label>
		</p> 
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('icon_1')); ?>"><?php _e('Icon for first post: ', 'prestige'); ?></label>
			<select class="widefat" name="<?php echo $this->get_field_name('icon_1'); ?>" id="<?php echo $this->get_field_id('icon_1'); ?>">
				<?php for($i=0; $i<count(JApi::$content_icons); $i++) { 
				    $iconarr = explode('.',JApi::$content_icons[$i]);
                ?>
					<option <?php selected($icon_1, $i) ?> value="<?php echo $i; ?>"><?php echo $iconarr[0]; ?></option>
				<?php } ?>
			</select>
		</p> 
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('icon_2')); ?>"><?php _e('Icon for second post: ', 'prestige'); ?></label>
			<select class="widefat" name="<?php echo $this->get_field_name('icon_2'); ?>" id="<?php echo $this->get_field_id('icon_2'); ?>">
				<?php for($i=0; $i<count(JApi::$content_icons); $i++) { 
				    $iconarr = explode('.',JApi::$content_icons[$i]);
                ?>
					<option <?php selected($icon_2, $i) ?> value="<?php echo $i; ?>"><?php echo $iconarr[0]; ?></option>
				<?php } ?>
			</select>
		</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('icon_3')); ?>"><?php _e('Icon for third post: ', 'prestige'); ?></label>
			<select class="widefat" name="<?php echo $this->get_field_name('icon_3'); ?>" id="<?php echo $this->get_field_id('icon_3'); ?>">
				<?php for($i=0; $i<count(JApi::$content_icons); $i++) {
				    $iconarr = explode('.',JApi::$content_icons[$i]);
                ?>
					<option <?php selected($icon_3, $i) ?> value="<?php echo $i; ?>"><?php echo $iconarr[0]; ?></option>
				<?php } ?>
			</select>
		</p>                         
		<?php 
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance                   = array();
		$instance['title']          = ( !empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
        $instance['number']         = strip_tags( $new_instance['number'] );
        $instance['post_title']     = $new_instance['post_title'];
        $instance['excerpt']        = $new_instance['excerpt'];
        $instance['excerpt_length'] = (int)($new_instance['excerpt_length']);
        $instance['thumbnail']      = $new_instance['thumbnail'];
        $instance['cat']            = $new_instance['cat'];
        $instance['icon_1']         = $new_instance['icon_1'];
        $instance['icon_2']         = $new_instance['icon_2'];
        $instance['icon_3']         = $new_instance['icon_3'];        
		return $instance;
	}

    /** Custom helper functions */
    
    /**
     * set length of excerpt
     */ 
    private function getExcerpt($_length, $_url){
    
    	$excerpt = explode(' ', get_the_excerpt(), $_length);
    	if (count($excerpt) >= $_length) {
    		array_pop($excerpt);
    		$excerpt = implode(" ", $excerpt) . ' &hellip;<p class="read_more"><a href="'.$_url.'" target="_self">read more ...</a></p>';
    	} else {
    		$excerpt = implode(" ", $excerpt);
    	}
    	$excerpt = preg_replace('`\[[^\]]*\]`', '', $excerpt);
    
    	return $excerpt;
    
    }    
} // class JFLatestCatPostsWidget


?>
/**
 * Theme Name: Prestige
 * Theme URI: http://www.jumpeye.com/
 * File: frontend.js
 *
 * @package Prestige
 * @since Prestige 1.0 
 */
/*********************************************************************
*  #### Twitter Post Fetcher v9.0 ####
*  Coded by Jason Mayes 2013. A present to all the developers out there.
*  www.jasonmayes.com
*  Please keep this disclaimer with my code if you use it. Thanks. :-)
*  Got feedback or questions, ask here: 
*  http://www.jasonmayes.com/projects/twitterApi/
*  Updates will be posted to this site.
*********************************************************************/
var twitterFetcher=function(){function v(e){return e.replace(/<b[^>]*>(.*?)<\/b>/gi,function(c,e){return e}).replace(/class=".*?"|data-query-source=".*?"|dir=".*?"|rel=".*?"/gi,"")}function m(e,c){for(var g=[],f=RegExp("(^| )"+c+"( |$)"),a=e.getElementsByTagName("*"),d=0,b=a.length;d<b;d++)f.test(a[d].className)&&g.push(a[d]);return g}var w="",j=20,q=!0,h=[],r=!1,n=!0,p=!0,s=null,t=!0,x=!0,u=null;return{fetch:function(e,c,g,f,a,d,b,k,l){void 0===g&&(g=20);void 0===f&&(q=!0);void 0===a&&(a=!0);void 0===
d&&(d=!0);void 0===b&&(b="default");void 0===k&&(k=!0);void 0===l&&(l=null);r?h.push({id:e,domId:c,maxTweets:g,enableLinks:f,showUser:a,showTime:d,dateFunction:b,showRt:k,customCallback:l}):(r=!0,w=c,j=g,q=f,p=a,n=d,x=k,s=b,u=l,c=document.createElement("script"),c.type="text/javascript",c.src="//cdn.syndication.twimg.com/widgets/timelines/"+e+"?&lang=en&callback=twitterFetcher.callback&suppress_response_codes=true&rnd="+Math.random(),document.getElementsByTagName("head")[0].appendChild(c))},callback:function(e){var c=
document.createElement("div");c.innerHTML=e.body;"undefined"===typeof c.getElementsByClassName&&(t=!1);e=[];var g=[],f=[],a=[],d=0;if(t)for(c=c.getElementsByClassName("tweet");d<c.length;){0<c[d].getElementsByClassName("retweet-credit").length?a.push(!0):a.push(!1);if(!a[d]||a[d]&&x)e.push(c[d].getElementsByClassName("e-entry-title")[0]),g.push(c[d].getElementsByClassName("p-author")[0]),f.push(c[d].getElementsByClassName("dt-updated")[0]);d++}else for(c=m(c,"tweet");d<c.length;)e.push(m(c[d],"e-entry-title")[0]),
g.push(m(c[d],"p-author")[0]),f.push(m(c[d],"dt-updated")[0]),0<m(c[d],"retweet-credit").length?a.push(!0):a.push(!1),d++;e.length>j&&(e.splice(j,e.length-j),g.splice(j,g.length-j),f.splice(j,f.length-j),a.splice(j,a.length-j));c=[];d=e.length;for(a=0;a<d;){if("string"!==typeof s){var b=new Date(f[a].getAttribute("datetime").replace(/-/g,"/").replace("T"," ").split("+")[0]),b=s(b);f[a].setAttribute("aria-label",b);if(e[a].innerText)if(t)f[a].innerText=b;else{var k=document.createElement("p"),l=document.createTextNode(b);
k.appendChild(l);k.setAttribute("aria-label",b);f[a]=k}else f[a].textContent=b}q?(b="",p&&(b+='<div class="user">'+v(g[a].innerHTML)+"</div>"),b+='<div class="tweet"><p class="text">'+v(e[a].innerHTML)+"</p>",n&&(b+='<p class="timePosted">'+f[a].getAttribute("aria-label")+"</p></div>")):e[a].innerText?(b="",p&&(b+='<p class="user">'+g[a].innerText+"</p>"),b+='<div class="tweet"><p class="text">'+e[a].innerText+"</p>",n&&(b+='<p class="timePosted">'+f[a].innerText+"</p></div>")):(b="",p&&(b+='<p class="user">'+g[a].textContent+"</p>"),b+='<div class="tweet"><p class="text">'+
e[a].textContent+"</p>",n&&(b+='<p class="timePosted">'+f[a].textContent+"</p></div>"));c.push(b);a++}if(null==u){e=c.length;g=0;f=document.getElementById(w);for(d="<ul>";g<e;)d+="<li>"+c[g]+"</li>",g++;f.innerHTML=d+"</ul>"}else u(c);r=!1;0<h.length&&(twitterFetcher.fetch(h[0].id,h[0].domId,h[0].maxTweets,h[0].enableLinks,h[0].showUser,h[0].showTime,h[0].dateFunction,h[0].showRt,h[0].customCallback),h.splice(0,1))}}}();
     
// prepare handling of FOUC (Flash Of Unstyled Content)
//JFBase('html').addClass('hidden_page'); 

var max_img_heights = [];

// do statements after documents loaded
jQuery(document).ready(function($){
    
    // reset image sizes in Home widgets
    var _hw = $('.project_img_holder .image_wrapper').width();
    var _hh = Math.ceil(_hw / 1.5);
    $('.project_img_holder .image_wrapper').css('height',_hh); 
        
    var _hpw = $('.home_project .image_wrapper').width();
    var _hph = Math.ceil(_hpw / 1.5);
    $('.home_project .image_wrapper').css('height',_hph); 
            
        
        
    // keyboard image navigation
	$( document ).keydown( function( e ) {
		var url = false;
		if ( e.which == 37 ) {  // Left arrow key code
			url = $( '.previous-image a' ).attr( 'href' );
		}
		else if ( e.which == 39 ) {  // Right arrow key code
			url = $( '.entry-attachment a' ).attr( 'href' );
		}
		if ( url && ( !$( 'textarea, input' ).is( ':focus' ) ) ) {
			window.location = url;
		}
	} );
    
    
    // iPad
    /*
    var oTimer;
    $(window).on('orientationchange', function(e){
        clearTimeout(oTimer);
        oTimer = setTimeout(function() {
            
            $('.container').css('width','100%');
            $('body').css({'width':'100%','overflow':'hidden'});
        },300);

    });*/
       

    var site_color_scheme = $('#site_color_scheme').text(); 
    
    function setColorScheme(){
         
        // comments
        $('div.comment div.author a').addClass('color_scheme');
        $('#respond p.logged-in-as a').addClass('color_scheme');
        $('div#respond input#submit').addClass('background_scheme');
        $('#cancel-comment-reply-link').addClass('color_scheme');
            
        $('div.comment div.author a').css('color', site_color_scheme); // ie8 
        $('#respond p.logged-in-as a').css('color', site_color_scheme); // ie8 
        $('div#respond input#submit').css('background-color', site_color_scheme); // ie8 
                     
        // sidebar
        $('#secondary div.widget h1.widget-title').addClass('color_scheme');
        $('#secondary div.widget a').addClass('color_scheme');
        $('#secondary div.widget h1.widget-title').css('color', site_color_scheme); // ie8
        $('#secondary div.widget a').css('color', site_color_scheme); // ie8            
             
        // posts
        $('div.post p.post_read_more a').addClass('color_scheme');
        $('div.post div.post_meta_data span.post_comments a').addClass('color_scheme');
        $('div.post div.post_meta_data_no_thumb span.post_comments a').addClass('color_scheme');
        $('div.post_navigation a').addClass('color_scheme');
        $('div.post p.post_read_more a').css('color', site_color_scheme); // ie8
        $('div.post div.post_meta_data span.post_comments a').css('color', site_color_scheme); // ie8
        $('div.post div.post_meta_data_no_thumb span.post_comments a').css('color', site_color_scheme); // ie8
        $('div.post_navigation a').css('color', site_color_scheme); // ie8        
             
        // widget links
        $('.content_widget a').addClass('color_scheme');  
        $('li.widget_jflatestpostswidget h2').addClass('color_scheme');
        $('.content_widget a').css('color', site_color_scheme); // ie8 
        $('li.widget_jflatestpostswidget h2').css('color', site_color_scheme); // ie8
        
        // add color_scheme class to widget links
        $('.widget a').addClass('color_scheme');
        $('.widget a').css('color', site_color_scheme); // ie8    
        
        // dd color_scheme class to Edit links
        $('a.post-edit-link').addClass('color_scheme');
        $('a.post-edit-link').css('color', site_color_scheme); // ie8
        
        // add color_scheme cass to .image-attachment page links
        $('.image-attachment a').addClass('color_scheme'); 
        $('.image-attachment a').css('color', site_color_scheme); // ie8
        
        // Add background color scheme class to Latest Posts Widget li.widget_jflatestpostswidget div.jf_latest_post_time
        $('.date_holder').addClass('background_scheme');
        $('.latest_post_widgettitle').parent().addClass('color_scheme');
        $('.date_holder').css('background-color', site_color_scheme); // ie8
        $('.latest_post_widgettitle').parent().css('color', site_color_scheme); // ie8       
        
        // tabbed widget
        $('h2.widget_title').addClass('color_scheme');
        $('.content_widget p.read_more a').addClass('color_scheme');  
        $('h2.widget_title').css('color', site_color_scheme); // ie8
        $('.content_widget p.read_more a').css('color', site_color_scheme); // ie8         
        
        // one post widget
        $('.one_post_widget h4.post_title').addClass('color_scheme');
        $('.one_post_widget p.read_more a').addClass('color_scheme');
        $('.one_post_widget h4.post_title a').addClass('color_scheme'); 
        $('.one_post_widget h4.post_title').css('color', site_color_scheme); // ie8 
        $('.one_post_widget p.read_more a').css('color', site_color_scheme); // ie8 
        $('.one_post_widget h4.post_title a').css('color', site_color_scheme); // ie8 
        
        // Framework exceptions
        $('.tab dd a').removeClass('color_scheme');
        $('.tab dd a').removeAttr('style');
        $('.menu ul li a').removeClass('color_scheme');
        $('.menu ul li a').removeAttr('style');                       
    }
    
    setColorScheme();
    
    
    // handling of FOUC (Flash Of Unstyled Content)
    //$('html').show();
  
    /** IMAGES */
    $('#main img').each(function(){
        var img_width = $(this).attr('width');
        
        // For some browsers, 'attr' is undefined for others,
        // 'attr' is false.  Check for both.
        if (typeof img_width !== 'undefined' && img_width !== false) {
            $(this).removeAttr('width');
            $(this).removeAttr('height');
            $(this).css({'maxWidth' : img_width + 'px', 'width' : '100%'});   
        }
    });
    
  
    /** Content Widgets */
    /* Format widgets in Content Widget 1..3 containers */
    /* Widgets are: Archives, Calendar, Categories, Meta, Pages, Text, Rss, TagCloud */
    // add shadow
    $('<table class="table_of_shadows" border="0" cellpadding="0" cellspacing="0" style="width:  100%;"><tr><td class="meta_left"></td><td class="meta_center">&nbsp;</td><td class="meta_right"></td></tr></table>').insertAfter('.content_widget ul');
    $('<table class="table_of_shadows" border="0" cellpadding="0" cellspacing="0" style="width:  100%;"><tr><td class="meta_left"></td><td class="meta_center">&nbsp;</td><td class="meta_right"></td></tr></table>').insertAfter('.content_widget div.tagcloud');
    $('<table class="table_of_shadows" border="0" cellpadding="0" cellspacing="0" style="width:  100%;"><tr><td class="meta_left"></td><td class="meta_center">&nbsp;</td><td class="meta_right"></td></tr></table>').insertAfter('.content_widget div.textwidget');
    $('<table class="table_of_shadows" border="0" cellpadding="0" cellspacing="0" style="width:  100%;><tr><td class="meta_left"></td><td class="meta_center">&nbsp;</td><td class="meta_right"></td></tr></table>').insertAfter('.content_widget div#calendar_wrap');
    
    // add arrow (&raquo;) before <a> in li list elements
    $('.content_widget li a').each(function(){
        $(this).html('<span>&raquo;&nbsp;&nbsp;</span>'+$(this).html());   
    });
    
    /** FORMS */
    
    $('form').addClass('style-1'); // change wp form design to JF design

    /** Add button background_scheme customStyle-1 classes to theme buttons */
    $('.widget input[type="submit"], .widget input[type="button"], .widget input[type="reset"], .widget button').addClass('button background_scheme customStyle-1');
    $('.comment input[type="submit"], .comment input[type="button"], .comment input[type="reset"], .comment button').addClass('button background_scheme customStyle-1');
    $('#respond input[type="submit"], #respond input[type="button"], #respond input[type="reset"], #respond button').addClass('button background_scheme customStyle-1');
    /** ie8 */
    $('.widget input[type="submit"], .widget input[type="button"], .widget input[type="reset"], .widget button').css('background-color', site_color_scheme);
    $('.comment input[type="submit"], .comment input[type="button"], .comment input[type="reset"], .comment button').css('background-color', site_color_scheme);
    $('#respond input[type="submit"], #respond input[type="button"], #respond input[type="reset"], #respond button').css('background-color', site_color_scheme);


    // Searchform :: submit button
    $('input#searchsubmit').removeAttr('class');
        
    /** MENUS */
    $('.menu a').removeAttr('title');
    var menus = $('.site-menu.menu');
    // do some menu fix 
    if(menus.length > 0){
       
       menus.find('ul.sub-menu').addClass('sub-level');
       
       menus.each(function(){
           // for horizontal menus           
           if(!$(this).hasClass('vertical')){
            
               var ul = $(this).find('ul');
               var li = $(this).find('li');
               
               ul.each(function(index){

                   // first UL is always the main-level
                   // add main-level class to the first UL if class has not added yet
                   if(index === 0){
                       if(!$(this).hasClass('main-level')){
                           $(this).addClass('main-level'); 
                       } 
                   } 

                   // change children classes to sub-level 
                   if($(this).hasClass('children')){
                       $(this).addClass('sub-level'); 
                       $(this).removeClass('chldren'); 
                   } 
                
                   if($(this).hasClass('sub-level')){
                       if($(this).parents(':eq(1)').hasClass('main-level')){
                           $(this).parent().addClass('down'); 
                       } else {
                           $(this).parent().addClass('flyout'); 
                       }
                   }
                    
               });
               li.each(function(){
                   if($(this).hasClass('down')){
                       $(this).find('> a').removeAttr('href');
                       $(this).find('> a').after('<span class="arrow-down"></span>'); 
                   }
                   if($(this).hasClass('flyout')){
                       $(this).find('> a').removeAttr('href');
                       $(this).find('> a').after('<span class="arrow-right"></span>'); 
                   } 
               });
           }
       });
    }
    
    /** Footer Contact Form */
    // Check if browser supports HTML5 input placeholder
    function supports_input_placeholder() {
    	var i = document.createElement('input');
    	return 'placeholder' in i;
    }
    
    // Change input text on focus
    if (!supports_input_placeholder()) {
    	$(':text').focus(function(){
    		var self = $(this);
    		if (self.val() == self.attr('placeholder')) self.val('');
    	}).blur(function(){
    		var self = $(this), value = $.trim(self.val());
    		if(val == '') self.val(self.attr('placeholder'));
    	});
    } else {
        $('#footer_widgets span.your-name > input').attr('placeholder','Name');
        $('#footer_widgets span.your-email > input').attr('placeholder','Email');
        $('#footer_widgets span.your-message > textarea').attr('placeholder','Message');
    	$(':text').focus(function(){
    		$(this).css('color', '#000');
    	});
    }
    
    // Put right-arrow before Footer Archive links
    if($('.widget_archive').length > 0){
        //$('<span class="arrow-right"></span>').prependTo('.widget_archive > ul li')
    }
    
    $('.tabbed_widget img').removeAttr('width');
    $('.tabbed_widget img').removeAttr('height');
    
    //Footer Contact Form field handlers
    $('#jf_footer_contact_form input').on('keyup',function(){
       var name = $(this).val();
       if($.trim(name)!=''){
           $(this).removeClass('error'); 
       }
    });
    
    $('#jf_footer_contact_form textarea').on('keyup',function(){
       var msg = $(this).val();
       if($.trim(msg)!=''){
           $(this).removeClass('error'); 
       }
    });
    
    //The Contact Form field handlers
    $('#jf_contact_form input').on('keyup',function(){
       var name = $(this).val();
       if($.trim(name)!=''){
           $(this).removeClass('error'); 
       }
    });
   
    $('#jf_contact_form textarea').on('keyup',function(){
       var msg = $(this).val();
       if($.trim(msg)!=''){
           $(this).removeClass('error'); 
       }
    });    
    
    /** GALLERY */
    function setThumbHeight(){
        // gallery images
        var _w = $('.jf_gallery .gallery_img').width();
        var _h = Math.ceil(_w / 1.5);
        $('.jf_gallery .gallery_img').css('height',_h);  
        $('.jf_gallery .image_wrapper').css('height',_h); 
    }
     
    
    /* 
      Image gallery renderer
      HTML structure of the gallery:
      
        <div class="gallery gallery-columns-4 gallery-size-thumbnail">
            <dl class="gallery-item">
                <dt class="gallery-icon">
                    <a title="Title">
                        <img class="attachment-thumbnail" width="150" height="150" alt="Caption" />
                    </a>
                </dt>
                <dd class="gallery-caption">Description</dd>
            </dl>
        </div>       
     */ 
     var gallery_classes = ['gallery-columns-1',
                            'gallery-columns-2',
                            'gallery-columns-3',
                            'gallery-columns-4',
                            'gallery-columns-5',
                            'gallery-columns-6',
                            'gallery-columns-7',
                            'gallery-columns-8',
                            'gallery-columns-9'];
    
    var galleries = [];

    if($('div.gallery').length > 0){
                 
        $('div.gallery').each(function(){
            
            var gallery_id = $(this).attr('id'); // gallery id
            var cols       = null; // number of cols
            var items      = $(this).find('dl.gallery-item').length; // gallery items

            var gallery_classes_array = $(this).attr('class').split(' ');
            var pos = -1;
            for(var i=0; i<gallery_classes.length; i++){
                if($.inArray(gallery_classes[i], gallery_classes_array)!=-1)   {
                    pos = i;
                    break;
                } 
            }        
            cols = pos+1;
            
            var new_gallery  = '';
            var titles       = [];
            var descriptions = [];
            var thumbs       = [];
            

            $(this).find('dt.gallery-icon a').each(function(){
                titles.push($(this).attr('title'));        
            });
            
            $(this).find('dl.gallery-item dd').each(function(){
                descriptions.push($(this).text());       
            });
            
            $(this).find('dt.gallery-icon a img').each(function(){
                // get src of image
                var image = $(this).attr('src');

                // we need the original image filenames
                // when we creating galleries with WP media handler, WP
                // add similar prefixes to image thumbnails : "-150x150.jpg", so the result like this
                // originalname-150x150.jpg (WP keeps the original filename)
                // from these names we need to get extension and the original filename
                // But keep in mind if image is too small WP won't make thumbnails just keep the original file.
                
                // After last '/' sign we get the filename, so we need the position of last '/'
                var pos_per = image.lastIndexOf('/');
                var _img_tmp = image.substring(pos_per);
                
                var p_min = _img_tmp.lastIndexOf('-');
                var p_dot = image.lastIndexOf('.');
                
                if(p_min == -1){
                     var _original_path = image;   
                } else {
                    var _original_path = image.substring(0,pos_per)+_img_tmp.substring(0,p_min)+image.substring(p_dot);
                }        
                // get back the original name (path) and set the anchor's href
                thumbs.push(_original_path);                 
            });
            
            var j = 1;
            for(var i=0; i<items; i++){
                
                 if(j==1){
                    new_gallery += '<div class="row">';
                 }

                 if(JC.isTouchable() == 0) {
                    var cover =  
                         '<div class="cover"></div>'+
                         '<div class="circle background_scheme"></div>'+
                         '<a class="magnifier grouped_elements" rel="'+gallery_id+'" href="'+thumbs[i]+'"></a>';
                 } else {
                    var cover =
                         '<a class="grouped_elements" rel="'+gallery_id+'" href="'+thumbs[i]+'" style="position: absolute; width: 100%; height: 100%; left: 0; top: 0;">'+
                         //'<img src="'+thumbs[i]+'" />'+
                         '</a>';                  
                 } 
                                    
                 new_gallery += 
                     '<div class="columns grid_'+(18/cols)+'">'+ 
                     '<div class="gallery_img">'+
                     '<div class="image_wrapper" style="height: 100%; background: url('+thumbs[i]+') no-repeat center center; -webkit-background-size: cover;  -moz-background-size: cover;  -o-background-size: cover;  background-size: cover; filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src=\''+thumbs[i]+'\',sizingMethod=\'scale\'); ">'+
                     cover+
                     '</div>'+  
                     '</div>'+
                     '<table class="table_of_shadows" border="0" cellpadding="0" cellspacing="0" style="width:  100%; margin-top: 0px;">'+
                     '<tr>'+
                     '<td class="meta_left"></td>'+
                     '<td class="meta_center">&nbsp;</td>'+
                     '<td class="meta_right"></td>'+
                     '</tr>'+
                     '</table>';                                           
                 
                 if(cols == 6){
                    new_gallery += '<div class="gallery_img_title hidden">'+titles[i]+'</div>';   
                 } else {
                    new_gallery += '<div class="gallery_img_title">'+titles[i]+'</div>';
                 }     
                 
                 if(descriptions[i] != undefined){
                    new_gallery += '<div class="gallery_img_descr">'+descriptions[i]+'</div>';   
                 }            
                 
                 new_gallery += '</div>';  
                 
                 if(j==cols){
                     new_gallery += '</div>';
                     j=1; 
                 } else {
                    j++;
                 }
            }

            $('#'+gallery_id).removeAttr('class');
            $('#'+gallery_id).addClass('jf_gallery gallery-columns-'+cols);
            $('#'+gallery_id).html(new_gallery);
        }); 

        // set common height for thumbs in every galleries
        setThumbHeight();
            
        if(typeof $.fancybox == 'function') {
            $('a.grouped_elements').fancybox();
        } 
    }

    /**
     * Gallery views
     */
    $('ul.gallery_change_view li').on('click',function(){
        $(this).addClass('active');
        $(this).siblings().removeClass('active'); 
        
        var selected = $(this).find('div div').attr('class');
        
        switch(selected){
            case 'gallery_view_list' :
                galleryView(1);
                setThumbHeight();
            break;
            
            case 'gallery_view_6_cols' :
                galleryView(6);
            break;
            
            case 'gallery_view_3_cols' :
                galleryView(3);
            break;
            
            case 'gallery_view_2_cols' :
                galleryView(2);
            break;
        }
    });

    $('div.image_wrapper div.circle').css('background-color', site_color_scheme); // ie8
     
     /** Posts */
     $('div.post div.post_thumbnail img').removeAttr('width');
     $('div.post div.post_thumbnail img').removeAttr('height');
     $('.attachment-post-thumbnail').removeAttr('width');
     $('.attachment-post-thumbnail').removeAttr('height');     
     
     /** Siderbar (widgets) */
     $('#secondary div.widget ul li').prepend('<span class="color_scheme">&raquo;</span>&nbsp;&nbsp;');
     $('#secondary div.widget:not(.widget_search)').after('<table class="table_of_shadows" border="0" cellpadding="0" cellspacing="0" style="width:  100%; margin-top: -1px">'+
                                      '<tr>'+
                                      '<td class="meta_left"></td>'+
                                      '<td class="meta_center">&nbsp;</td>'+
                                      '<td class="meta_right"></td>'+
                                      '</tr>'+
                                      '</table>');
                                      
    $('.tab ul li > span.color_scheme').remove();                                      

                                      
    /* Fancybox */
    if(typeof jQuery.fancybox == 'function') {
        
        if( jQuery('.jf_gallery').length > 0 || jQuery('.gallery').length > 0 ){
            // for single images
            jQuery("img[class*='wp-image-']").parent().fancybox();
            
            // for galleries   
            
            jQuery('.grouped_elements').live('mouseenter', function(){
                jQuery(this).fancybox();
            });             
        }
    }
    
    
    /* Magnifier hover effect for images
	 *  		   
	 * mandatory html structure: <a><img class="image" /></a>
	 * key class for jQuery is "image" in order to apply the hover effect for img elements
	 *
	 * On touchscreen the hover effect will be disabled
	 */   
    if(JC.isTouchable() == 0) {
        // show / hide handlers for image cover layer  
        $('.image_wrapper').live('mouseover',function() {
           $(this).find('div.cover').show();
           $(this).find('div.circle').show();
           $(this).find('a.magnifier').show();
           $(this).find('a.navigator').show();
        });
       
        $('.image_wrapper').live('mouseout',function() {
           $(this).find('div.cover').hide();
           $(this).find('div.circle').hide();
           $(this).find('a.magnifier').hide();
           $(this).find('a.navigator').hide();
        }); 
        
        $('.project_img_holder').live('mouseover',function() {
           $(this).find('div.cover').show();
           $(this).find('div.circle').show();
           $(this).find('a.magnifier').show();
           $(this).find('a.navigator').show();
        });
       
        $('.project_img_holder').live('mouseout',function() {
           $(this).find('div.cover').hide();
           $(this).find('div.circle').hide();
           $(this).find('a.magnifier').hide();
           $(this).find('a.navigator').hide();
        });                
    }
	/* End of Magnifier hover effect for images */ 
    
    /* window resize handling */
    $(window).resize(function() { // handle window resize events
        setThumbHeight();
    });    
                            
});


/**
 * The Contact Form
 * @param ajaxurl
 * Note: in Sample-mode ajaxurl is an empty string
 */ 
function _aSubmitContactForm(ajaxurl){
    var recipient      = jQuery('#jf_cf_recipient').val();
    var name           = jQuery('#jf_cf_sender_name').val();
    var email          = jQuery('#jf_cf_sender_email').val();
    var subject        = jQuery('#jf_cf_subject').val();
    var msg            = jQuery('#jf_cf_msg').val();
    var captcha        = jQuery('#captcha').val();
    var captcha_answer = jQuery('#sec_answer').val();

    var error          = false;
    
    if(jQuery.trim(name)==''){
        jQuery('#jf_cf_sender_name').addClass('error');
        error = true;
    }
    
    if(jQuery.trim(email)==''){
        jQuery('#jf_cf_sender_email').addClass('error');
        error = true;
    }
    
    if(jQuery.trim(subject)==''){
        jQuery('#jf_cf_subject').addClass('error');
        error = true;
    }
        
    if(jQuery.trim(msg)==''){
        jQuery('#jf_cf_msg').addClass('error');
        error = true;
    }
    
    if(parseInt(jQuery.trim(captcha)) != parseInt(captcha_answer)){
        jQuery('#captcha').addClass('error');
        error = true;
    }    
    
    if(error || (ajaxurl == '' )) return;
    
	var data = {
        action    : "the_contact_sendmail",
        name      : jQuery.trim(name),
        email     : jQuery.trim(email),
        message   : jQuery.trim(msg),
        subject   : jQuery.trim(subject),
        recipient : recipient
	};


    jQuery.ajaxSetup({
       beforeSend: function(){
           jQuery('#jf_cf_response').html('Processing...'); 
       }
    });


    jQuery.post(ajaxurl, data,
    	function( response ) {
    	    if(response == 0){
    	       jQuery('#jf_cf_response').html('<span style="color: #7dc70b;">Your email has been sent.<span>');
               jQuery('#jf_contact_form').resetForm();
    	    } else {
    	       jQuery('#jf_cf_response').html('<span style="color: #c90c10;">An error has occured.<span>');
    	    }
    	}
    );
}

/**
 * Footer Contact Form
 * @param ajaxurl
 * Note: in Sample-mode ajaxurl is an empty string
 */ 
function _aSendMessage(ajaxurl){
    var recipient  = jQuery('#jf_fc_recipient').val();
    var name       = jQuery('#jf_fc_sender_name').val();
    var email      = jQuery('#jf_fc_sender_email').val();
    var msg        = jQuery('#jf_fc_msg').val();
    
    var error      = false;
    
    if(jQuery.trim(name)==''){
        jQuery('#jf_fc_sender_name').addClass('error');
        error = true;
    }
    
    if(jQuery.trim(email)==''){
        jQuery('#jf_fc_sender_email').addClass('error');
        error = true;
    }
    
    if(jQuery.trim(msg)==''){
        jQuery('#jf_fc_msg').addClass('error');
        error = true;
    }
    
    if(error || (ajaxurl == '' )) return;
    
	var data = {
        action    : "footer_contact_sendmail",
        name      : jQuery.trim(name),
        email     : jQuery.trim(email),
        message   : jQuery.trim(msg),
        recipient : recipient
	};

    jQuery.ajaxSetup({
       beforeSend: function(){
           jQuery('#jf_fc_response').html('Processing...'); 
       }
    });

    jQuery.post(ajaxurl, data,
    	function( response ) {
    	    if(response == 0){
    	       jQuery('#jf_fc_response').html('<span style="color: #7dc70b;">Your email has been sent.<span>');
               jQuery('#jf_footer_contact_form').resetForm();
    	    } else {
    	       jQuery('#jf_fc_response').html('<span style="color: #c90c10;">An error has occured.<span>');
    	    }
    	}
    );
}

/**
 * Gallery view
 * @param _cols : number of columns
 */
function galleryView(_cols){

    max_img_heights = [];

    var galleries = [];
    var cols = _cols; // number of cols
    
    if(jQuery('div.jf_gallery').length > 0){
                
        // fillup max_img_heights array with zero values
        /*
        for(var i=0; i<jQuery('div.jf_gallery').length; i++){
            max_img_heights.push(0);
        }  */      
        var color_scheme = jQuery('#site_color_scheme').text();
        //jQuery('div.jf_gallery .gallery_img').css('height','0px');                    
        jQuery('div.jf_gallery').each(function(){
           
            var gallery_id   = jQuery(this).attr('id'); // gallery id
            var items        = jQuery(this).find('div.gallery_img').length; // gallery items
            var new_gallery  = '';
            var titles       = [];
            var descriptions = [];
            var thumbs       = [];


            jQuery(this).find('div.gallery_img_title').each(function(){
                titles.push(jQuery(this).text());        
            });
            
            jQuery(this).find('div.gallery_img_descr').each(function(){
                descriptions.push(jQuery(this).text());       
            });
            
       
            jQuery(this).find('div.image_wrapper').each(function(){
                var bg = jQuery(this).css('background-image');
                bg = bg.replace('url(','').replace(')',''); 
                bg = replaceAll(bg, '"', '', 0);
                thumbs.push(bg);                 
            });
            
            var j = 1;
            for(var i=0; i<items; i++){
                
                 if(JC.isTouchable() == 0) {
                    var cover =  
                         
                         '<div class="cover"></div>'+
                         '<div class="circle background_scheme"></div>'+
                         '<a class="magnifier grouped_elements" rel="'+gallery_id+'" href="'+thumbs[i]+'"></a>';
                 } else {
                    var cover =
                         '<a class="grouped_elements" rel="'+gallery_id+'" href="'+thumbs[i]+'" style="position: absolute; width: 100%; height: 100%; left: 0; top: 0;">'+
                         //'<img src="'+thumbs[i]+'" />'+
                         '</a>'; 
                 }  
                                     
                 // list view
                 if(cols == 1){
                     new_gallery += 
                         '<div class="row">'+
                         '<div class="columns grid_6">'+
                         '<div class="gallery_img" style="">'+
                         '<div class="image_wrapper" style="height: 100%; background: url('+thumbs[i]+') no-repeat center center; -webkit-background-size: cover;  -moz-background-size: cover;  -o-background-size: cover;  background-size: cover; filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src=\''+thumbs[i]+'\',sizingMethod=\'scale\'); ">'+
                         cover +
                         '</div></div>'+
                         '<table class="table_of_shadows" border="0" cellpadding="0" cellspacing="0" style="width:  100%; margin-top: 0px">'+
                         '<tr>'+
                         '<td class="meta_left"></td>'+
                         '<td class="meta_center">&nbsp;</td>'+
                         '<td class="meta_right"></td>'+
                         '</tr>'+
                         '</table>'+
                         '</div><div class="columns grid_12">'+   
                         '<div class="gallery_img_title" style="margin-top: 10px">'+titles[i]+'</div>'+
                         '<div class="gallery_img_descr">'+descriptions[i]+'</div>'+
                         '</div></div>';                                   
                 } else {
                  
                     if(j==1){
                        new_gallery += '<div class="row">';
                     }
                                   
                     new_gallery += 
                         '<div class="columns grid_'+(18/cols)+'">'+ 
                         '<div class="gallery_img">'+
                         '<div class="image_wrapper" style="height: 100%; background: url('+thumbs[i]+') no-repeat center center; -webkit-background-size: cover;  -moz-background-size: cover;  -o-background-size: cover;  background-size: cover; filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src=\''+thumbs[i]+'\',sizingMethod=\'scale\'); ">'+
                         cover +
                         '</div>'+
                         '</div>'+
                         '<table class="table_of_shadows" border="0" cellpadding="0" cellspacing="0" style="width:  100%; margin-top: 0px">'+
                         '<tr>'+
                         '<td class="meta_left"></td>'+
                         '<td class="meta_center">&nbsp;</td>'+
                         '<td class="meta_right"></td>'+
                         '</tr>'+
                         '</table>';                         ;
                         
                     if(cols == 6){
                        new_gallery += '<div class="gallery_img_title hidden">'+titles[i]+'</div>';   
                     } else {
                        new_gallery += '<div class="gallery_img_title">'+titles[i]+'</div>';
                     }     
                                   
                     new_gallery += '<div class="gallery_img_descr">'+descriptions[i]+'</div></div>';
                     
                     if(j==cols){
                         new_gallery += '</div>';
                         j=1; 
                     } else {
                        j++;
                     }  
                                           
                 }
                    
            }

            jQuery('#'+gallery_id).removeAttr('class');
            jQuery('#'+gallery_id).addClass('jf_gallery');
            jQuery('#'+gallery_id).html(new_gallery);
            jQuery('div.image_wrapper div.circle').css('background-color', site_color_scheme); // ie8
             
        });    

        jQuery('.image_wrapper div.circle').css('background',color_scheme);
        
        
        if(cols > 1){
            // Set img holder's (div.gallery_img) width equal to the image width 
            jQuery('div.jf_gallery').each(function(){
                var _w = jQuery(this).find('.gallery_img').width();
                var _h = Math.ceil(_w / 1.5);
                jQuery(this).find('.gallery_img').height(_h);
            }); 
        }
        
        
        if(typeof jQuery.fancybox == 'function') {
            // for single images
            jQuery("img[class*='wp-image-']").parent().fancybox();
            // for galleries            
            jQuery('a.grouped_elements').fancybox();
        } 
    }
}

function replaceAll(oldStr, removeStr, replaceStr, caseSenitivity){
    if(caseSenitivity == 1){
        cs = "g";
        }else{
        cs = "gi";  
    }
    var myPattern=new RegExp(removeStr,cs);
    newStr =oldStr.replace(myPattern,replaceStr);
    return newStr;
}
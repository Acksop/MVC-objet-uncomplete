<?php
/*
    Plugin Name: JF Recent From Widget
    Plugin URI: http://www.jumpeye.com
    Description: Displays recent posts from a specific category.
    Version: 1.0
    Author: Jumpeye Components
    Author URI: http://www.jumpeye.com
    License: GPL2
*/

// register JFLatestPostsWidget widget
add_action('widgets_init', create_function('', 'return register_widget("JFLatestPostsWidget");')); 

/**
 * Adds JFLatestPostsWidget widget.
 */
class JFLatestPostsWidget extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	public function __construct() {
        
		parent::__construct(
	 		'JFLatestPostsWidget', // Base ID
			'JF Recent From Widget', // Name (you will see it in Available Widgets)
			array( 'description' => __( 'Displays recent posts from a specific category.', 'prestige' ),) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	public function widget( $args, $instance ) {
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );

        /* Custom Options */
        // Our options from the widget settings.
        $number         = (isset($instance['number'])) ? $instance['number'] : 3 ;
        $date           = (isset($instance['date'])) ? $instance['date'] : false ;
        $post_title     = (isset($instance['post_title'])) ? $instance['post_title'] : false ;
        $excerpt        = (isset($instance['excerpt'])) ? $instance['excerpt'] : false ;
        $excerpt_length = (isset($instance['excerpt'])) ? (int)($instance['excerpt_length']) : 0;
        $author         = (isset($instance['author'])) ? $instance['author'] : false ;
        $cat            = (isset($instance['cat'])) ? $instance['cat'] : 1 ;
        
        // Before widget - as defined in your specific theme.
		echo '<h2 class="color_scheme latest_post_widgettitle">';
        
        if ( ! empty( $title ) ){
            echo $title;
        }
        
        echo '</h2><div class="widget_jflatestpostswidget">';

            /* Create a new post query */
            $query = new WP_Query();
            //Send our widget options to the query
            $query->query( array(
            	'post_type' => 'post',
                'posts_per_page' => $number,
                'ignore_sticky_posts' => 1,
                'cat' => $cat
               )
             );

            if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post();
            ?>  
            	<div class="jf_latest_post row">
					<?php if ($date == true) { ?>
						<div class="jf_post_time columns grid_4">
                            <div class="date_holder">
                                <p class="day"><span><?php echo get_the_date('d'); ?></span></p>
                                <p class="month"><span><?php echo get_the_date('M'); ?></span></p>
                            </div>
                        </div>
                    <div class="jf_latest_post_holder columns grid_14">
                    <?php } else { ?>
                        <div class="jf_latest_post_holder columns grid_18 no_post_date">
					<?php } 
                          if ($post_title == true) { ?>
						<h4 class="jf_latest_post_title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
					<?php } ?>   
					<?php if ($excerpt == true) {  ?>
                        <p class="excerpt">                    
						<a class="latest_post_link" href="<?php the_permalink(); ?>"><?php echo $this->jf_excerpt_length($excerpt_length); ?></a></p>
					<?php } ?>  
					<?php if ($author == true) { ?>
						<p class="latest_post_author"><?php _e('Posted by ', 'prestige'); echo get_the_author(); ?></p>
					<?php } ?>                     
                    </div>                                                     
            	</div>
			
            <?php endwhile; endif;
            
        /* After widget - as defined in your specific theme. */
		?>
        </div>
       	<table class="table_of_shadows" border="0" cellpadding="0" cellspacing="0" style="width:  100%; margin-top: 0px !important">
           <tr>
           <td class="meta_left"></td>
           <td class="meta_center">&nbsp;</td>
           <td class="meta_right"></td>
           </tr>
        </table>
        <?php
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) {
	   
        /* Default Widget Settings */
    		
    	$defaults = array(
    		'title'          => '',
    		'number'         => 3,
            'date'           => true,
            'post_title'     => true,
            'excerpt'        => true,
            'excerpt_length' => 10,
            'author'         => false,
            'cat'            => 1
    	); 

        $instance       = wp_parse_args( (array) $instance, $defaults );   
        $title          = esc_attr( $instance['title'] );
        $number         =  $instance['number'];
        $date           =  $instance['date'];
        $post_title     =  $instance['post_title'];
        $excerpt        =  $instance['excerpt'];
        $excerpt_length =  $instance['excerpt_length'];
        $author         =  $instance['author'];
        $cat            =  $instance['cat'];
        
		?>
		<p>
    		<label for="<?php echo $this->get_field_name( 'title' ); ?>"><?php _e( 'Title:', 'prestige' ); ?></label> 
    		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('cat')); ?>"><?php _e('Category: ', 'prestige'); ?></label>
			<?php wp_dropdown_categories(array('class'=>'widefat', 'name' => $this->get_field_name('cat'), 'show_option_all' => __('All categories', 'prestige'), 'hide_empty' => 1, 'hierarchical' => 1, 'selected' => $cat)); ?>
		</p>          
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php _e('Number of posts:', 'prestige'); ?></label>
			<select class="widefat" name="<?php echo $this->get_field_name('number'); ?>" id="<?php echo $this->get_field_id('number'); ?>">
				<?php for ($i = 1; $i <= 5; $i++) { ?>
					<option <?php selected($number, $i) ?> value="<?php echo $i; ?>"><?php echo $i; ?></option>
				<?php } ?>
			</select>
		</p>  
   		<p>
			<input id="<?php echo $this->get_field_id('post_title'); ?>" name="<?php echo $this->get_field_name('post_title'); ?>" type="checkbox" value="1" <?php checked('1', $post_title); ?> />&nbsp;
            <label for="<?php echo esc_attr($this->get_field_id('post_title')); ?>"><?php _e('Display post title?', 'prestige'); ?></label>
		</p> 
   		<p>
			<input id="<?php echo $this->get_field_id('excerpt'); ?>" name="<?php echo $this->get_field_name('excerpt'); ?>" type="checkbox" value="1" <?php checked('1', $excerpt); ?> />&nbsp;
            <label for="<?php echo esc_attr($this->get_field_id('excerpt')); ?>"><?php _e('Display post excerpt?', 'prestige'); ?></label>
		</p>   
		<p>
    		<label for="<?php echo $this->get_field_name( 'excerpt_length' ); ?>"><?php _e( 'Lenght of excerpt:', 'prestige' ); ?></label> 
    		<input class="widefat" id="<?php echo $this->get_field_id( 'excerpt_length' ); ?>" name="<?php echo $this->get_field_name( 'excerpt_length' ); ?>" type="text" value="<?php echo $excerpt_length; ?>" />
		</p>
		<p>                              
   		<p>
			<input id="<?php echo $this->get_field_id('date'); ?>" name="<?php echo $this->get_field_name('date'); ?>" type="checkbox" value="1" <?php checked('1', $date); ?> />&nbsp;
            <label for="<?php echo esc_attr($this->get_field_id('date')); ?>"><?php _e('Display post date?', 'prestige'); ?></label>
		</p>
   		<p>
			<input id="<?php echo $this->get_field_id('author'); ?>" name="<?php echo $this->get_field_name('author'); ?>" type="checkbox" value="1" <?php checked('1', $author); ?> />&nbsp;
            <label for="<?php echo esc_attr($this->get_field_id('author')); ?>"><?php _e('Display post author?', 'prestige'); ?></label>
		</p>       
		<?php 
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance                   = array();
		$instance['title']          = ( !empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';

        $instance['number']         = strip_tags( $new_instance['number'] );
        $instance['date']           = $new_instance['date'];
        $instance['post_title']     = $new_instance['post_title'];
        $instance['excerpt']        = $new_instance['excerpt'];
        $instance['excerpt_length'] = (int)($new_instance['excerpt_length']);
        $instance['author']         = $new_instance['author'];
        $instance['cat']            = $new_instance['cat'];
        
		return $instance;
	}

    /**
     * set length of excerpt
     */ 
    private function jf_excerpt_length($_length){
    
    	$excerpt = explode(' ', get_the_excerpt(), $_length);
    	if (count($excerpt) >= $_length) {
    		array_pop($excerpt);
    		$excerpt = implode(" ", $excerpt) . ' &hellip;';
    	} else {
    		$excerpt = implode(" ", $excerpt);
    	}
    	$excerpt = preg_replace('`\[[^\]]*\]`', '', $excerpt);
    
    	return $excerpt;
    
    }   
    
} // class JFLatestPostsWidget


?>
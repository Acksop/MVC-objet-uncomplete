<?php
/*
    Plugin Name: JF Categories List Widget
    Plugin URI: http://www.jumpeye.com
    Description: Lists the recent posts of three specified categories in three columns, highlighting the most recent post for each category.
    Version: 1.0
    Author: Jumpeye Components
    Author URI: http://www.jumpeye.com
    License: GPL2
*/

// register JFServicesWidget widget
add_action('widgets_init', create_function('', 'return register_widget("JFServicesWidget");')); 

/**
 * Adds JFServicesWidget widget.
 */
class JFServicesWidget extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	public function __construct() {
		parent::__construct(
	 		'JFServicesWidget', // Base ID
			'JF Categories List Widget', // Name (you will see it in Available Widgets)
			array( 'description' => __( 'Lists the recent posts of three specified categories in three columns, highlighting the most recent post for each category.', 'prestige' ),) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	public function widget( $args, $instance ) {
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );

        /* Custom Options */
        // Our options from the widget settings.
        $number         = (isset($instance['number'])) ? $instance['number'] : 10 ;
        $cat_1          = (isset($instance['cat_1'])) ? $instance['cat_1'] : 1 ;
        $cat_2          = (isset($instance['cat_2'])) ? $instance['cat_2'] : 1 ;
        $cat_3          = (isset($instance['cat_3'])) ? $instance['cat_3'] : 1 ;
        $icon_1         = (isset($instance['icon_1'])) ? $instance['icon_1'] : 0 ;
        $icon_2         = (isset($instance['icon_2'])) ? $instance['icon_2'] : 0 ;
        $icon_3         = (isset($instance['icon_3'])) ? $instance['icon_3'] : 0 ;    
        $excerpt        = (isset($instance['excerpt'])) ? $instance['excerpt'] : false ;
        $excerpt_length = (isset($instance['excerpt_length'])) ? (int)($instance['excerpt_length']) : 0;
        $thumbnail      = (isset($instance['thumbnail'])) ? $instance['thumbnail'] : false ;            
                
        // Before widget - as defined in your specific theme.
		echo $before_widget;
        
        // title
        if ( ! empty( $title ) )
		echo $before_title .$title . $after_title;
                
        /* Display The Widget */   

            /* Create a new post query for column 1 */
            $query = new WP_Query();
            //Send our widget options to the query
            $query->query( array(
            	'post_type'           => 'post',
                'posts_per_page'      => $number,
                'ignore_sticky_posts' => 1,
                'cat' => $cat_1
               )
            );

            $post_ids = array();
            $posts = array();
            $excerpts = array();
            echo '<div class="columns grid_6 services_widget first">';
            if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post();
                $post_id = get_the_ID();
                $permalink = get_permalink($post_id);
                $title = get_the_title($post_id);
                $posts[$permalink] = $title;
                
                $an_excerpt = '<p class="excerpt">'.
                           $this->getExcerpt($excerpt_length, $permalink).
                           '</p>';
                $excerpts[] = $an_excerpt; 
                $post_ids[] = $post_id;                          
            
            ?>  
            <?php endwhile; endif;
            wp_reset_postdata();
            
            $i=0;

            foreach($posts as $k => $v){
                if($i==0){
                    if( isset($icon_1) && $icon_1 > 0){
                        echo '<div class="services_icons" style="background-image:url('.THEME_ROOT_URI.'/images/icons/content/'.JApi::$content_icons[$icon_1].');"></div>';    
                    }
                    echo '<div class="margin_bottom_30"><h4 class="post_title_em featured"><a href="'.$k.'">'.$v.'</a></h4>';
                    if ($excerpt == true && $excerpt_length > 0) {
                        echo $excerpts[$i];
                    // thumbnail (featured image)
        			if (has_post_thumbnail($post_ids[$i]) && $thumbnail == true) { ?>
 
                    <?php
                        $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post_ids[$i] ), 'single-post-thumbnail' );
                    ?>                      
                        <div class="project_img_holder">
                            <div class="image_wrapper" style="background: url(<?php echo $image[0]; ?>) no-repeat center center; -webkit-background-size: cover;  -moz-background-size: cover;  -o-background-size: cover;  background-size: cover; filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='<?php echo $image[0]; ?>',sizingMethod='scale'); ">
                				 <a href="<?php echo $k; ?>" style="position: absolute; width: 100%; height: 100%; left: 0; top: 0;"></a>
                                 <div class="cover"></div>
                                 <div class="circle background_scheme"></div>
                                 <a class="navigator" href="<?php echo $k; ?>"></a>
                            </div>
                            <table class="table_of_shadows" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                    <td class="img_left"></td>
                                    <td class="img_center">&nbsp;</td>
                                    <td class="img_right"></td>
                                </tr>
                            </table> 
                        </div>
        			<?php
                        }                         
                    }   
                    echo '</div>'; 
                    
                } else {
                    echo '<h4 class="post_title"><a href="'.$k.'" class="color_scheme">'.$v.'</a></h4>';    
                }
                $i++;
            }
            echo '</div>';
            
            
            /* Create a new post query for column 2 */
            $query = new WP_Query();
            //Send our widget options to the query
            $query->query( array(
            	'post_type'           => 'post',
                'posts_per_page'      => $number,
                'ignore_sticky_posts' => 1,
                'cat' => $cat_2
               )
            );

            $posts = array();
            $excerpts = array();
            $post_ids = array();
            
            echo '<div class="columns grid_6 services_widget second">';
            if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post();
                $post_id = get_the_ID();
                $permalink = get_permalink($post_id);
                $title = get_the_title($post_id);
                $posts[$permalink] = $title;
                $an_excerpt = '<p class="excerpt">'.
                           $this->getExcerpt($excerpt_length, $permalink).
                           '</p>';
                $excerpts[] = $an_excerpt;  
                $post_ids[] = $post_id;                                             
            ?>  
            <?php endwhile; endif;
            
            wp_reset_postdata();
            
            $i=0;
            foreach($posts as $k => $v){
                if($i==0){
                    if( isset($icon_2) && $icon_2 > 0){
                        echo '<div class="services_icons" style="background-image:url('.THEME_ROOT_URI.'/images/icons/content/'.JApi::$content_icons[$icon_2].');"></div>';    
                    }
                    echo '<div class="margin_bottom_30"><h4 class="post_title_em featured"><a href="'.$k.'">'.$v.'</a></h4>';
                    if ($excerpt == true && $excerpt_length > 0) {
                        echo $excerpts[$i];
                    }   
                  // thumbnail (featured image)
        			if (has_post_thumbnail($post_ids[$i]) && $thumbnail == true) { ?>
                    <?php
                        $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post_ids[$i] ), 'single-post-thumbnail' );
                    ?>                      
                        <div class="project_img_holder">
                            <div class="image_wrapper" style="background: url(<?php echo $image[0]; ?>) no-repeat center center; -webkit-background-size: cover;  -moz-background-size: cover;  -o-background-size: cover;  background-size: cover; filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='<?php echo $image[0]; ?>',sizingMethod='scale'); ">
                				 <a href="<?php echo $k; ?>" style="position: absolute; width: 100%; height: 100%; left: 0; top: 0;"></a>
                                 <div class="cover"></div>
                                 <div class="circle background_scheme"></div>
                                 <a class="navigator" href="<?php echo $k; ?>"></a>
                            </div>
                            <table class="table_of_shadows" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                    <td class="img_left"></td>
                                    <td class="img_center">&nbsp;</td>
                                    <td class="img_right"></td>
                                </tr>
                            </table> 
                        </div>
        			<?php
                        }                      
                    echo '</div>'; 
                } else {
                    echo '<h4 class="post_title"><a href="'.$k.'" class="color_scheme">'.$v.'</a></h4>';    
                }
                $i++;
            }
            echo '</div>';
             
            /* Create a new post query for column 3 */
            $query = new WP_Query();
            //Send our widget options to the query
            $query->query( array(
            	'post_type'           => 'post',
                'posts_per_page'      => $number,
                'ignore_sticky_posts' => 1,
                'cat' => $cat_3
               )
            );

            $posts = array();
            $excerpts = array();
            $post_ids = array();
            
            echo '<div class="columns grid_6 services_widget">';
            if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post();
                $post_id = get_the_ID();
                $permalink = get_permalink($post_id);
                $title = get_the_title($post_id);
                $posts[$permalink] = $title;
                $an_excerpt = '<p class="excerpt">'.
                           $this->getExcerpt($excerpt_length, $permalink).
                           '</p>';
                $excerpts[] = $an_excerpt;  
                $post_ids[] = $post_id;                                           
            ?>  
            <?php endwhile; endif;
            
            wp_reset_postdata();
            
            $i=0;
            foreach($posts as $k => $v){
                if($i==0){
                    if( isset($icon_3) && $icon_3 > 0){
                        echo '<div class="services_icons" style="background-image:url('.THEME_ROOT_URI.'/images/icons/content/'.JApi::$content_icons[$icon_3].');"></div>';    
                    }
                    echo '<div class="margin_bottom_30"><h4 class="post_title_em featured"><a href="'.$k.'">'.$v.'</a></h4>';
                    if ($excerpt == true && $excerpt_length > 0) {
                        echo $excerpts[$i];
                    }   
                    // thumbnail (featured image)
        			if (has_post_thumbnail($post_ids[$i]) && $thumbnail == true) { ?>
                    <?php
                        $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post_ids[$i] ), 'single-post-thumbnail' );
                    ?>                      
                        <div class="project_img_holder">
                            <div class="image_wrapper" style="background: url(<?php echo $image[0]; ?>) no-repeat center center; -webkit-background-size: cover;  -moz-background-size: cover;  -o-background-size: cover;  background-size: cover; filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='<?php echo $image[0]; ?>',sizingMethod='scale'); ">
                				 <a href="<?php echo $k; ?>" style="position: absolute; width: 100%; height: 100%; left: 0; top: 0;"></a>
                                 <div class="cover"></div>
                                 <div class="circle background_scheme"></div>
                                 <a class="navigator" href="<?php echo $k; ?>"></a>
                            </div>
                            <table class="table_of_shadows" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                    <td class="img_left"></td>
                                    <td class="img_center">&nbsp;</td>
                                    <td class="img_right"></td>
                                </tr>
                            </table> 
                        </div>
        			<?php
                        }                     
                    echo '</div>'; 
                } else {
                    echo '<h4 class="post_title"><a href="'.$k.'" class="color_scheme">'.$v.'</a></h4>';    
                }
                $i++;
            }
            echo '</div>';
                                    
        /* After widget - as defined in your specific theme. */
		echo $after_widget;
        
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) {
        /* Default Widget Settings */
    		
    	$defaults = array(
    		'title'          => '',
    		'number'         => 10,
            'cat_1'          => 1,
            'cat_2'          => 1,
            'cat_3'          => 1,
            'icon_1'         => 0,
            'icon_2'         => 0,
            'icon_3'         => 0,
            'excerpt'        => true,
            'excerpt_length' => 50,
            'thumbnail'      => false                              
    	); 

        $instance       = wp_parse_args( (array) $instance, $defaults );   
        $title          = esc_attr( $instance['title'] );
        $number         =  $instance['number'];
        $cat_1          =  $instance['cat_1'];
        $cat_2          =  $instance['cat_2'];
        $cat_3          =  $instance['cat_3'];
        $icon_1         =  $instance['icon_1'];
        $icon_2         =  $instance['icon_2'];
        $icon_3         =  $instance['icon_3']; 
        $excerpt        =  $instance['excerpt'];
        $excerpt_length =  $instance['excerpt_length'];
        $thumbnail      =  $instance['thumbnail'];        

		?>
		<p>
    		<label for="<?php echo $this->get_field_name( 'title' ); ?>"><?php _e( 'Title:', 'prestige' ); ?></label> 
    		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php _e('Number of posts:', 'prestige'); ?></label>
			<select class="widefat" name="<?php echo $this->get_field_name('number'); ?>" id="<?php echo $this->get_field_id('number'); ?>">
				<?php for($i=1; $i<=20; $i++) { ?>
					<option <?php selected($number, $i) ?> value="<?php echo $i; ?>"><?php echo $i; ?></option>
				<?php } ?>
			</select>
		</p>  
   		<p>
			<input id="<?php echo $this->get_field_id('excerpt'); ?>" name="<?php echo $this->get_field_name('excerpt'); ?>" type="checkbox" value="1" <?php checked('1', $excerpt); ?> />&nbsp;
            <label for="<?php echo esc_attr($this->get_field_id('excerpt')); ?>"><?php _e('Display post excerpt?', 'prestige'); ?></label>
		</p>   
		<p>
    		<label for="<?php echo $this->get_field_name( 'excerpt_length' ); ?>"><?php _e( 'Lenght of excerpt:', 'prestige' ); ?></label> 
    		<input class="widefat" id="<?php echo $this->get_field_id( 'excerpt_length' ); ?>" name="<?php echo $this->get_field_name( 'excerpt_length' ); ?>" type="text" value="<?php echo $excerpt_length; ?>" />
		</p>
   		<p>
			<input id="<?php echo $this->get_field_id('thumbnail'); ?>" name="<?php echo $this->get_field_name('thumbnail'); ?>" type="checkbox" value="1" <?php checked('1', $thumbnail); ?> />&nbsp;
            <label for="<?php echo esc_attr($this->get_field_id('thumbnail')); ?>"><?php _e('Display post featured image?', 'prestige'); ?></label>
		</p>        
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('cat_1')); ?>"><?php _e('Category 1: ', 'prestige'); ?></label>
			<?php wp_dropdown_categories(array('class' => 'widefat', 'name' => $this->get_field_name('cat_1'), 'hide_empty' => 1, 'hierarchical' => 1, 'selected' => $cat_1)); ?>
		</p> 
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('icon_1')); ?>"><?php _e('Icon for Category 1: ', 'prestige'); ?></label>
			<select class="widefat" name="<?php echo $this->get_field_name('icon_1'); ?>" id="<?php echo $this->get_field_id('icon_1'); ?>">
				<?php for($i=0; $i<count(JApi::$content_icons); $i++) { 
				    $iconarr = explode('.',JApi::$content_icons[$i]);
			    ?>
					<option <?php selected($icon_1, $i) ?> value="<?php echo $i; ?>"><?php echo $iconarr[0]; ?></option>
				<?php } ?>
			</select>
		</p>          
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('cat_2')); ?>"><?php _e('Category 2: ', 'prestige'); ?></label>
			<?php wp_dropdown_categories(array('class' => 'widefat', 'name' => $this->get_field_name('cat_2'), 'hide_empty' => 1, 'hierarchical' => 1, 'selected' => $cat_2)); ?>
		</p>  
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('icon_2')); ?>"><?php _e('Icon for Category 2: ', 'prestige'); ?></label>
			<select class="widefat" name="<?php echo $this->get_field_name('icon_2'); ?>" id="<?php echo $this->get_field_id('icon_2'); ?>">
				<?php for($i=0; $i<count(JApi::$content_icons); $i++) { 
				    $iconarr = explode('.',JApi::$content_icons[$i]);
                ?>
					<option <?php selected($icon_2, $i) ?> value="<?php echo $i; ?>"><?php echo $iconarr[0]; ?></option>
				<?php } ?>
			</select>
		</p>         
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('cat_3')); ?>"><?php _e('Category 3: ', 'prestige'); ?></label>
			<?php wp_dropdown_categories(array('class' => 'widefat', 'name' => $this->get_field_name('cat_3'), 'hide_empty' => 1, 'hierarchical' => 1, 'selected' => $cat_3)); ?>
		</p> 
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('icon_3')); ?>"><?php _e('Icon for Category 3: ', 'prestige'); ?></label>
			<select class="widefat" name="<?php echo $this->get_field_name('icon_3'); ?>" id="<?php echo $this->get_field_id('icon_3'); ?>">
				<?php for($i=0; $i<count(JApi::$content_icons); $i++) { 
				    $iconarr = explode('.',JApi::$content_icons[$i]);
                ?>
					<option <?php selected($icon_3, $i) ?> value="<?php echo $i; ?>"><?php echo $iconarr[0]; ?></option>
				<?php } ?>
			</select>
		</p> 
		<?php 
	}

      
	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance                   = array();
		$instance['title']          = ( !empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
        $instance['number']         = strip_tags( $new_instance['number'] );
        $instance['cat_1']          = $new_instance['cat_1'];
        $instance['cat_2']          = $new_instance['cat_2'];
        $instance['cat_3']          = $new_instance['cat_3'];
        $instance['icon_1']         = $new_instance['icon_1'];
        $instance['icon_2']         = $new_instance['icon_2'];
        $instance['icon_3']         = $new_instance['icon_3'];
        $instance['excerpt']        = $new_instance['excerpt'];
        $instance['excerpt_length'] = (int)($new_instance['excerpt_length']);
        $instance['thumbnail']      = $new_instance['thumbnail'];        
		return $instance;
	}

    /**
     * set length of excerpt
     */ 
    private function getExcerpt($_length, $_url){
    	$excerpt = explode(' ', get_the_excerpt(), $_length);
    	if (count($excerpt) >= $_length) {
    		array_pop($excerpt);
    		$excerpt = implode(" ", $excerpt) . ' &hellip;<p class="read_more"><a class="color_scheme" href="'.$_url.'" target="_self">read more ...</a></p>';
    	} else {
    		$excerpt = implode(" ", $excerpt);
    	}
    	$excerpt = preg_replace('`\[[^\]]*\]`', '', $excerpt);
    
    	return $excerpt;
    } 
        
} // class JFServicesWidget
?>
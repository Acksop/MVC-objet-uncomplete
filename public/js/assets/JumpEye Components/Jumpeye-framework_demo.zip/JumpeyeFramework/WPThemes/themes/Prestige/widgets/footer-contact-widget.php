<?php
/*
    Plugin Name: JF Small Contact Form Widget
    Plugin URI: http://www.jumpeye.com
    Description: Displays a small and compact contact form in the footer.
    Version: 1.0
    Author: Jumpeye Components
    Author URI: http://www.jumpeye.com
    License: GPL2
*/

// register JFSimpleFooterContactFormWidget widget
add_action('widgets_init', create_function('', 'return register_widget("JFSimpleFooterContactFormWidget");')); 

/**
 * Adds JFSimpleFooterContactFormWidget widget.
 */
class JFSimpleFooterContactFormWidget extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	public function __construct() {
        
		parent::__construct(
	 		'JFSimpleFooterContactFormWidget', // Base ID
			'JF Small Contact Form Widget', // Name (you will see it in Available Widgets)
			array( 'description' => __( 'Displays a small and compact contact form in the footer.', 'prestige' )) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	public function widget( $args, $instance ) {
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );

        /* Custom Options */
        // Our options from the widget settings.
        $email = (isset($instance['email'])) ? $instance['email'] : get_option('admin_email') ;
        
        // Before widget - as defined in your specific theme.
		echo $before_widget;
        
        /* Display The Widget */
           if ( ! empty( $title ) ) echo $before_title . $title . $after_title;
 
            ?>
            <form id="jf_footer_contact_form" class="style-1" style="margin:0;" method="post" action="<?php echo THEME_ROOT_URI; ?>">
            <input type="hidden" name="jf_fc_recipient" id="jf_fc_recipient" value="<?php echo $email; ?>" />
            <input type="text" placeholder="Name" name="jf_fc_sender_name" id="jf_fc_sender_name" />
            <input type="text" placeholder="Email" name="jf_fc_sender_email" id="jf_fc_sender_email"  />
            <textarea placeholder="Message" name="jf_fc_msg" id="jf_fc_msg" cols="70"></textarea>
            <input type="button" name="jf_fc_submit" id="jf_fc_submit" value="Send message" onclick="_aSendMessage('<?php echo admin_url().'admin-ajax.php'; ?>');" />
            <div id="jf_fc_response"></div>
            </form>
            <?php
        
        /* After widget - as defined in your specific theme. */
		echo $after_widget;
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) {
	   
        /* Default Widget Settings */
    		
    	$defaults = array(
    		'title'          => '',
    		'email'          => get_option('admin_email')
    	); 

        $instance       = wp_parse_args( (array) $instance, $defaults );   
        $title          = esc_attr( $instance['title'] );
        $email          = esc_attr( $instance['email'] );
        
		?>
		<p>
    		<label for="<?php echo $this->get_field_name( 'title' ); ?>"><?php _e( 'Title:', 'prestige' ); ?></label> 
    		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
		<p>
    		<label for="<?php echo $this->get_field_name( 'email' ); ?>"><?php _e( 'Recipient\'s e-mail address:', 'prestige' ); ?></label> 
    		<input class="widefat" id="<?php echo $this->get_field_id( 'email' ); ?>" name="<?php echo $this->get_field_name( 'email' ); ?>" type="text" value="<?php echo $email; ?>" />
		</p>        
		<?php 
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance                   = array();
		$instance['title']          = ( !empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
        $instance['email']          = ( !empty( $new_instance['email'] ) ) ? strip_tags( $new_instance['email'] ) : '';
        
		return $instance;
	}

} // class JFSimpleFooterContactFormWidget
?>
<?php
/**
 * The template for displaying Search Results pages.
 *
 * @package Prestige
 * @since Prestige 1.0
 */

get_header(); 
$is_blog_fullwidth = get_option( 'prestige_metatpl_option_fullwidth' );
$sidebar_pos = get_option( 'prestige_metatpl_option_sidebar_pos' );

if( empty($is_blog_fullwidth) ){
    $is_blog_fullwidth = 'off';
}

if( empty($sidebar_pos) ){
    $sidebar_pos = 'left';
}

$grid_cols     = ($is_blog_fullwidth == 'on') ? '18' : '12';
$my_search     =& new WP_Query("s=$s & showposts=-1");
$num_results   = $my_search->post_count;
$post_per_page = get_option('posts_per_page');
?>

    <div class="row margin_top_32">
       <?php 
           if( $is_blog_fullwidth=='off' && $sidebar_pos == 'left' ) get_sidebar();
       ?>  
		<div id="primary" class="content-area columns grid_<?php echo $grid_cols; ?>">
			<div id="content" class="site-content" role="main">

			<?php 
                if ( have_posts() ) :
                
                    // top nav
                    if($num_results >= $post_per_page) :
                        JF_Frontend::getNavigation();
                    endif; 
                    
                    // Start the Loop 
				    while ( have_posts() ) : 
                        the_post();
                        get_template_part( 'content', 'search' );
                    endwhile;
                    
                    // bottom nav
                    if($num_results >= $post_per_page) :
                        JF_Frontend::getNavigation('bottom');
                    endif;
                     
                else :
                
                    get_template_part( 'no-results', 'search' ); 
                    
                endif;
            ?>

			</div><!-- #content .site-content -->
		</div><!-- #primary .content-area .columns .grid_12 -->
       <?php 
           if( $is_blog_fullwidth=='off' && $sidebar_pos == 'right' ) get_sidebar();
       ?>         
    </div><!-- .row -->
<?php get_footer(); ?>
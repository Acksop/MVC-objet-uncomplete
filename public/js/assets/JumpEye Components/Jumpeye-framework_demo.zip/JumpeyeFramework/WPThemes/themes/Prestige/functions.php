<?php
/**
 * Prestige theme functions and definitions
 *
 * @package Prestige
 * @since Prestige 1.0
 */


/** custom widgets */
include('widgets/contact-map-widget.php');
include('widgets/twitter-widget.php');
include('widgets/services-widget.php');
include('widgets/contact-form-widget.php');
include('widgets/contact-info-widget.php');
include('widgets/footer-contact-widget.php');
include('widgets/one-post-widget.php');
include('widgets/tabbed-widget.php');
include('widgets/latest-posts-widget.php');
include('widgets/latest-cat-posts-widget.php'); 
include('widgets/latest-projects-widget.php'); // use for Latest Projects

/** constants */
define( "THEME_ROOT_DIR", get_template_directory() );
define( "THEME_ROOT_URI", get_template_directory_uri() );
define( "CHILD_ROOT_DIR", get_stylesheet_directory() );
define( "CHILD_ROOT_URI", get_stylesheet_directory_uri() );
define( "ENABLE_FANCYBOX_DEFAULT", 1 );


/** Custom metabox */
add_action( 'add_meta_boxes', 'add_custom_metabox' );

/** Create the metabox */
function add_custom_metabox(){
    $screens = array( 'page' );
    foreach ($screens as $screen) {
        add_meta_box(
            'prestige_tpl_meta',
            __( 'Page Template Settings', 'prestige' ),
            'prestige_custom_metabox_callback',
            $screen,'side'
        );
    }    
}

/** Maximize excerpts length */
function custom_excerpt_length( $length ) {
	return 50;
}

add_filter( 'excerpt_length', 'custom_excerpt_length', 999 );
    
/** Render the metabox */
function prestige_custom_metabox_callback($post){
    
    global $post;
    
    $templates = array(
        'page-templates/blog.php',
        'page-templates/content.php'
    );
    
    $values   = get_post_custom( $post->ID );

    $check    = isset( $values['is_fullwidth'] ) ? esc_attr( $values['is_fullwidth'][0] ) : '';  
    $selected = isset( $values['sidebar_position'] ) ? esc_attr( $values['sidebar_position'][0] ) : '';   
  
    // Use nonce for verification (for saving data)
    wp_nonce_field( 'prestige_ptemplates_nonce', 'prestige_metabox_nonce_save' );
    
    $post_id = $_GET['post'] ? $_GET['post'] : $_POST['post_ID'] ;
    $template_file = get_post_meta($post_id,'_wp_page_template',TRUE);
    
    $display_info    = ( in_array($template_file, $templates) ) ? 'none'  : 'block';
    $display_options = ( in_array($template_file, $templates) ) ? 'block' : 'none';   
    // output in meta_box
    ?>
    <div class="prestige_tpl_options_info" style="display: <?php echo $display_info; ?>;">
        <p><?php esc_html_e( 'Additional settings appear here, when one of Prestige page templates is selected ( Page Attributes / Template )', 'prestige' ); ?></p>
    </div>
    <div class="prestige_tpl_options" style="display: <?php echo $display_options; ?>;">
        <p> 
            <label for="is_fullwidth">Full Width Page</label>
            <input type="checkbox" id="is_fullwidth" name="is_fullwidth" <?php checked( $check, 'on' ); ?> />  
        </p>
        <p> 
            <label for="my_meta_box_select">Sidebar position</label> 
            <select name="sidebar_position" id="sidebar_position"> 
                <option value="left" <?php selected( $selected, 'left' ); ?>>Left</option> 
                <option value="right" <?php selected( $selected, 'right' ); ?>>Right</option> 
            </select> 
        </p>  
    </div>   
  <?php  
}

add_action( 'save_post', 'prestige_metabox_save', 10, 2 );

/** Saving metabox values */
function prestige_metabox_save($post_id, $post){
    
    if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;  

    if( !isset( $_POST['prestige_metabox_nonce_save'] ) || !wp_verify_nonce( $_POST['prestige_metabox_nonce_save'], 'prestige_ptemplates_nonce' ) ) return;

    if( !current_user_can( 'edit_page', $post_id ) ) return;  

    // Make sure your data is set before trying to save it  
    if( isset( $_POST['sidebar_position'] ) )  {
        update_post_meta( $post_id, 'sidebar_position', esc_attr( $_POST['sidebar_position'] ) );  
    }        
          
    // Saving check-boxes  
    $chk = isset( $_POST['is_fullwidth'] ) && $_POST['is_fullwidth'] ? 'on' : 'off';  
    update_post_meta( $post_id, 'is_fullwidth', $chk );
    
    
    $template_file = get_post_meta($post_id,'_wp_page_template',TRUE);

    if($template_file == 'page-templates/blog.php'){
        if( false == get_option( 'prestige_metatpl_option_fullwidth' ) ) {     
            add_option( 'prestige_metatpl_option_fullwidth' );  
        }
        if( false == get_option( 'prestige_metatpl_option_sidebar_pos' ) ) {     
            add_option( 'prestige_metatpl_option_sidebar_pos' );  
        } 
        
        update_option('prestige_metatpl_option_fullwidth',$chk);
        update_option('prestige_metatpl_option_sidebar_pos',esc_attr( $_POST['sidebar_position'] ));               
    }             
}

/** end of Custom metabox */

/**
 * Test a plugin is activated
 * @param $_plugin_name : name of plugin
 */ 
function plugin_is_active($_plugin_name) {
    return in_array( $_plugin_name. '/' .$_plugin_name. '.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ); 
}       
 

    
/**
 * includes
 */
if( file_exists( get_template_directory().'/inc/custom-header.php' ) ) {
	require_once( get_template_directory().'/inc/custom-header.php' );
} 

/** hooks */
if( file_exists( get_template_directory().'/api/classes/hooks.php' ) ) {
	require_once( get_template_directory().'/api/classes/hooks.php' );
}

/** api */
if( file_exists( get_template_directory().'/api/classes/api.php' ) ) {
	require_once( get_template_directory().'/api/classes/api.php' );
}

/** sampledata */
if( file_exists( get_template_directory().'/sampledata/sampledata.php' ) ) {
	require_once( get_template_directory().'/sampledata/sampledata.php' );
}

/** create an instance of JApi class */
$api = new JApi();


/**
 * Define Framework class
 */ 
class Framework{
    
    private $framework_folder = '/framework';
     
    public function __construct(){}
    
    /** load js files */
    public function frameworkJS() {
		wp_enqueue_script('JFCore', THEME_ROOT_URI . $this->framework_folder.'/js/JFCore.js', array(), '1.0', false);
		wp_enqueue_script('JFMenus', THEME_ROOT_URI . $this->framework_folder.'/js/JFMenus.js', array(), '1.0', false);
        wp_enqueue_script('JFTooltips', THEME_ROOT_URI . $this->framework_folder.'/js/JFTooltips.js', array(), '1.0', false);
        if(!is_admin()){
            wp_enqueue_script('JFForms', THEME_ROOT_URI . $this->framework_folder.'/js/JFForms.js', array(), '1.0', false);    
        }
        wp_enqueue_script('frontend-js', THEME_ROOT_URI . '/js/frontend.js', array('jquery'), '1.0', false);
    }   
    
    
    /**
     * because ie8 we need to load these css separately
     */ 
    public function menuCSS(){
        wp_enqueue_style('jf-menu', THEME_ROOT_URI . $this->framework_folder.'/css/menus/JFMenu.all.min.css', array(), '1.0');
    } 
    
    
    /** load css files */
    public function frameworkCSS(){

		wp_enqueue_style('jf-grid', THEME_ROOT_URI.$this->framework_folder.'/css/JFGrid_18.min.css', array(), '1.0' );
        wp_enqueue_style('jf-alert', THEME_ROOT_URI.$this->framework_folder.'/css/alerts/JFAlert.all.min.css', array(), '1.0');
        wp_enqueue_style('jf-button', THEME_ROOT_URI.$this->framework_folder.'/css/buttons/JFButton.all.min.css', array(), '1.0');
        wp_enqueue_style('jf-table', THEME_ROOT_URI.$this->framework_folder.'/css/tables/JFTable.all.min.css', array(), '1.0');
        wp_enqueue_style('jf-tab', THEME_ROOT_URI.$this->framework_folder.'/css/tabs/JFTab.all.min.css', array(), '1.0');
        wp_enqueue_style('jf-panel', THEME_ROOT_URI.$this->framework_folder.'/css/panels/JFPanel.all.min.css', array(), '1.0');
        wp_enqueue_style('jf-tooltip', THEME_ROOT_URI.$this->framework_folder.'/css/tooltips/JFTooltip.all.min.css', array(), '1.0');
           
        // forms (we load form css in Frontend only)
        if(!is_admin()){
            wp_enqueue_style('jf-form', THEME_ROOT_URI.$this->framework_folder.'/css/forms/JFForm.all.min.css', array(), '1.0');
        }
      
        // menus
        // CSS linked in the header.php otherwise ie8 does not recognize menu styles
    }    
   
} // end of Framework class


/** 
 * Main class of FrontEnd functions
 * 
 * ! NOTES ! 
 * - create named instance ( ex: '$JFO = new JF_Frontend();' instead of 'new JF_Frontend();' )
 * - make instance to global for usage in files outside of the scope 
 *   (ex.: define 'global $JFO;' global variable in footer.php) 
 */  
class JF_Frontend {

    // slider defaults
    private $slider_defaults = Array(
          'maxWidth' => 922,
          'maxHeight' => 358,
          'imageScaleMode' => 'scaleCrop',
          'loopContent' => 'false',
          'animationType' => 'slide',
          'animationDuration' => 0.3,
          'autoSlideshow' => 'false',
          'slideshowSpeed' => 6,
          'pauseOnMouseOver' => 'false',
          'startIndex' => 0,
          'captionAlignment' => 'left',
          'captionColor' => '#ffffff',
          'autoHideControls' => 'false',
          'autoHideDelay' => 3,
          'disableAutohideOnMouseOver' => 'false',
          'showTimer' => 'true',
          'showControlBar' => 'true',
          'showNavButtons' => 'true'        
    );
    
    private $imageScaleMode   = Array(1=>'scale', 2=>'scaleCrop', 3=>'crop', 4=>'stretch');
    private $animationType    = Array(1=>'fade',  2=>'slide',     3=>'none');
    private $captionAlignment = Array(1=>'left',  2=>'center',    3=>'right');
        
    // framework object 
    protected $fw_class;
    
    // framework folder
    private $framework_folder = '/framework'; 
    
    /** 
     * use the constructor to initialize WP settings
     * (register menus, do theme supports, etc.)
     */     
    public function __construct(){
        
       $this->fw_class = new Framework();
       
       // widgetize theme
       add_action( 'widgets_init', array($this, 'jumpeye_widgets_init' ));
                       
       // load CSS and JS files to the FRONTEND
       if (!is_admin()){
           add_action('wp_enqueue_scripts', array( $this->fw_class, 'frameworkCSS') );	
           add_action('wp_enqueue_scripts', array( $this->fw_class, 'frameworkJS') );
           add_action('wp_enqueue_scripts', array( $this, 'theme_js') );
       }
                    
       // AJAX for handling send message from footer contact form  
       add_action( 'wp_ajax_footer_contact_sendmail', array( $this, 'footer_contact_sendmail_callback') ); 
       add_action( 'wp_ajax_nopriv_footer_contact_sendmail', array( $this, 'footer_contact_sendmail_callback') );

       // AJAX for handling send message from the contact form  
       add_action( 'wp_ajax_the_contact_sendmail', array( $this, 'the_contact_sendmail_callback') ); 
       add_action( 'wp_ajax_nopriv_the_contact_sendmail', array( $this, 'the_contact_sendmail_callback') );

        // to enable native navigation menu support
        register_nav_menus( array(
        	'primary' => 'Primary Menu',
        	'secondary' => 'Secondary Menu',
            'footer' => 'Footer Menu'
        ) );
        
        /*
          Enable widgets on the site (also show Appearance / Widgets menu item)
          after this, we van show sidebars and widgets
        */ 
        //register_sidebar();
        
        /* register 3 new widget areas for footer, what we can setup via Appearance / Widgets
         (also show Appearance / Widgets menu item)   
        */
        //register_sidebars(4,array('name'=>'FooterWidget %d'));
            
        /* register 3 new widget areas for content, what we can setup via Appearance / Widgets
         (also show Appearance / Widgets menu item) 
        */  
        //register_sidebars(3,array('name'=>'ContentWidget %d'));
        
        // switch on shortcode decoding in text widgets  
        add_filter('widget_text', 'do_shortcode');
        
        // remove post-edit-links
        add_filter( 'edit_post_link', '__return_false' );

    	/*
    	  Make theme available for translation
    	  Translations can be filed in the /languages/ directory
    	  If you're building a theme based on Prestige, use a find and replace
    	  to change 'prestige' to the name of your theme in all the template files
    	 */
    	load_theme_textdomain( 'prestige', get_template_directory() . '/languages' );

    	// Custom template tags for this theme.
    	require( get_template_directory() . '/inc/template-tags.php' );
    
    	// Custom functions that act independently of the theme templates
    	require( get_template_directory() . '/inc/tweaks.php' );
    
       
        // add custom background theme support
        add_action( 'after_setup_theme', array($this, 'jumpeye_register_custom_background') );
        
        add_filter('wp_trim_excerpt', array($this, 'excerpt_read_more' ));
        
        add_filter('the_content', 'do_shortcode', 11);
        add_filter('the_excerpt', 'do_shortcode', 11);
        
        remove_filter('the_excerpt', 'wpautop' );
        remove_filter('the_content', 'wpautop' );
        add_filter('the_excerpt', 'wpautop', 99);
        add_filter( 'the_content', 'wpautop' , 99);   
        add_filter( 'the_content', 'shortcode_unautop',100 );   

        // show / hide admin bar on FrontEnd (true = show, false = hide)
        $this->toggleAdminBarInFrontend();         
    }
    

    /**
     * Navigation bar
     */ 
    public static function getNavigation($_position='top'){
    ?>
          <div class="row post_navigation <?php echo $_position; ?>">
               <div class="columns grid_18">
                   <div style="float: left;">
                       <span class="older"><?php next_posts_link(__('&larr; Older posts','prestige')); ?></span>
                   </div>
                   <div style="float: right;" class="align_right">
                   <span class="newer"><?php previous_posts_link(__('Newer posts &rarr; ','prestige')); ?></span>
                   </div>
               </div>                  
          </div>     
    <?php        
    }
    
    
    /**
     * Register widgetized area and update sidebar with default widgets
     *
     * @since Prestige 1.0
     */
    public function jumpeye_widgets_init() {
    	register_sidebar( array(
    		'name' => __( 'Primary Sidebar', 'prestige' ),
    		'id' => 'sidebar-1',
    		'before_widget' => '<div id="%1$s" class="widget %2$s">',
    		'after_widget' => '</div>',
    		'before_title' => '<h1 class="widget-title">',
    		'after_title' => '</h1>',
    	) );
        
    	register_sidebar( array(
    		'name' => __( 'Secondary Sidebar', 'prestige' ),
    		'id' => 'sidebar-2',
    		'before_widget' => '<div id="%1$s" class="row widget %2$s"><div class="columns grid_18">',
    		'after_widget' => '</div></div>',
    		'before_title' => '<h1 class="widget-title">',
    		'after_title' => '</h1>',
    	) );
            
        /** Home One Post Widget */
       	register_sidebar( array(
    		'name' => __( 'Home Page Main Post Area', 'prestige' ),
    		'id' => 'one-post-widget',
    		'before_widget' => '',
    		'after_widget' => '',
    		'before_title' => '<h4 class="post_title">',
    		'after_title' => '</h4>',
    	) );
        
        /** Home Page Latest Tweets Area */
       	register_sidebar( array(
    		'name' => __( 'Home Page Recent Tweets Area', 'prestige' ),
    		'id' => 'latest-tweets-widget',
    		'before_widget' => '<div>',
    		'after_widget' => '</div>',
    		'before_title' => '<h2 class="title color_scheme">',
    		'after_title' => '</h2>',
    	) ); 
                           
        /** Home Page Featured Posts Area */
       	register_sidebar( array(
    		'name' => __( 'Home Page Featured Posts Area', 'prestige' ),
    		'id' => 'home-page-featured-posts-area',
    		'before_widget' => '<div class="row content_widget home_featured margin_top_30"><div class="grid_18 columns">',
    		'after_widget' => '</div></div>',
    		'before_title' => '<div class="row"><div class="grid_18 columns"><h2 class="widget_title home_featured">',
    		'after_title' => '</h2></div></div>',
    	) );
            
        /** Home Tabbed Widget */
       	register_sidebar( array(
    		'name' => __( 'Home Page Tabbed Content Area', 'prestige' ),
    		'id' => 'tabbed-widget',
    		'before_widget' => '<div class="tab style-2">',
    		'after_widget' => '</div>',
    		'before_title' => '',
    		'after_title' => '',
    	) );
           
        /** Home Page Recent Posts Area */
    	register_sidebar( array(
    		'name' => __( 'Home Page Recent Posts Area', 'prestige' ),
    		'id' => 'home-recent-posts-area',
    		'before_widget' => '',
            'after_widget' => '',
    		'before_title' => '',
    		'after_title' => '',
    	) );
                    
        /** Home Page Bottom Area */
       	register_sidebar( array(
    		'name' => __( 'Home Page Bottom Area', 'prestige' ),
    		'id' => 'home-page-bottom-area',
    		'before_widget' => '<div class="row content_widget"><div class="grid_18 columns">',
    		'after_widget' => '</div></div>',
    		'before_title' => '<div class="row content_widget recent_projects"><div class="grid_18 columns"><h2 class="widget_title">',
    		'after_title' => '</h2></div></div>',
    	) );
                 
        /** Home Tabbed Widget */
       	register_sidebar( array(
    		'name' => __( 'Home Page Tabbed Content Area', 'prestige' ),
    		'id' => 'tabbed-widget',
    		'before_widget' => '<div class="tab style-2">',
    		'after_widget' => '</div>',
    		'before_title' => '',
    		'after_title' => '',
    	) );
            
        /** Service widgets */
           	register_sidebar( array(
        		'name' => __( 'Services Page Categories List Area', 'prestige' ),
        		'id' => 'services-widget',
        		'before_widget' => '<div class="row services_cat_list margin_top_30">',
        		'after_widget' => '</div>',
        		'before_title' => '<div class="row"><div class="columns grid_18"><h2 class="services widget_title">',
        		'after_title' => '</h2></div></div>',
        	) );
                    
           	register_sidebar( array(
        		'name' => __( 'Services Page Bottom Area', 'prestige' ),
        		'id' => 'bottom-services-widget',
        		'before_widget' => '<div class="row margin_top_50">',
        		'after_widget' => '</div>',
        		'before_title' => '',
        		'after_title' => '',
        	) );
            
            /** Contact Map */
           	register_sidebar( array(
        		'name' => __( 'Contact Page Map Area', 'prestige' ),
        		'id' => 'google-map-widget',
        		'before_widget' => '<div class="row"><div class="grid_18 columns">',
        		'after_widget' => '</div></div>',
        		'before_title' => '<h2 class="title color_scheme">',
        		'after_title' => '</h2>',
        	) ); 
            
        /** Contact Page Form Area */
       	register_sidebar( array(
    		'name' => __( 'Contact Page Form Area', 'prestige' ),
    		'id' => 'contact-form-widget',
    		'before_widget' => '<div class="row contact_form_holder widget">',
    		'after_widget' => '</div>',
    		'before_title' => '<h2 class="widget_title">',
    		'after_title' => '</h2>',
    	) ); 
                
        /** Contact Info Widget */
       	register_sidebar( array(
    		'name' => __( 'Contact Page Info Area', 'prestige' ),
    		'id' => 'contact-info-widget',
    		'before_widget' => '<div class="row">',
    		'after_widget' => '</div>',
    		'before_title' => '<h2 class="widget_title">',
    		'after_title' => '</h2>',
    	) );
          
        /** register 4 new widget areas for footer, what we can setup via Appearance / Widgets */   
        register_sidebars(4,array('name'=>'Footer Area #%d'));                                             
    }

    
    /** Format excerpt */
    function excerpt_read_more( $_excerpt ) {
    	return str_replace( '[...]', '...', $_excerpt );
    }
    
    
    /** Page title bar */
    public static function getPageTitleBar(){
        if (! is_front_page() ) {
            if( is_page_template() ){
                if ( is_page_template('page-templates/blog.php') ) {
                    $icon = 'blog-icon';    
                } elseif ( is_page_template('page-templates/gallery.php') ) {
                    $icon = 'gallery-icon';
                } elseif ( is_page_template('page-templates/contact.php') ) {
                    $icon = 'contact-icon';
                } elseif ( is_page_template('page-templates/shortcode.php') ) {
                    $icon = 'shortcode-icon';
                } elseif ( is_page_template('page-templates/services.php') ) {
                    $icon = 'services-icon';
                } else {
                    $icon = 'default-icon';
                }                
            } elseif(is_search()){
                $icon = 'search-icon';
            } else {
                $icon = 'default-icon';
            }
            

            ?>
            <div id="page_title_bar" class="background_scheme">
                <div class="row">
                    <div class="columns grid_18" style="overflow: hidden !important;">
                        <div class="page_icon_holder">
                            <div class="circle"></div>
                            <div class="icon <?php echo $icon; ?>"></div>
                        </div>
                        <div class="title">
                            <?php
                                if(is_page()){
                                    the_title();
                                } elseif(is_search()) {
                                    printf( __( 'Search Results for: %s', 'prestige' ), '<span>' . get_search_query() . '</span>' );
                                } elseif(is_404()){
                                    _e('Content not found','prestige');
                                } elseif(is_attachment()){
                                    _e('Attachments','prestige');
                                } else {
                                    $cat = get_the_category();
                                    if(count($cat)>0){
                                        echo 'Category &raquo; '.$cat[0]->cat_name;  
                                    }
                                } 
                            ?>
                        </div>                               
                    </div>           
                </div>
            </div>            
            <?php            
        } else {
        ?>
        <!--<div id="home_top_placeholder" class="row"><div class="columns grid_18"></div></div>--> 
        <?php    
        }
    }
    
    /**
     * Ajax handler for Footer Contact form 
     */
    public function footer_contact_sendmail_callback(){
        $recipient = strip_tags($_POST['recipient']);
        $message = strip_tags($_POST['message']);
        $headers = "From: ".strip_tags($_POST['email'])." <".strip_tags($_POST['email']).">\n";
        $headers.= "Content-Type: text/html\n";
        $subject = "Message from ".get_bloginfo('name');
        return @wp_mail( $recipient, $subject, $message, $headers );
        die();
    } 
    
    /**
     * Ajax handler for The Contact form 
     */
    public function the_contact_sendmail_callback(){
        $recipient = strip_tags($_POST['recipient']);
        $message = strip_tags($_POST['message']);
        $headers = "From: ".strip_tags($_POST['email'])." <".strip_tags($_POST['email']).">\n";
        $headers.= "Content-Type: text/html\n";
        $subject = strip_tags($_POST['subject']);
        return @wp_mail( $recipient, $subject, $message, $headers );
        die();
    } 
        
    /** get slider values */
    private function getSliderValue($_key){
        $options = get_option( 'jf_theme_slider_settings' );
        
        // else if option exists in database return with its value
        if(isset($options['maxWidth'])){
            if(isset($options[$_key])){
                switch($_key){
                    case 'animationType' : return $this->animationType[$options['animationType']];
                    case 'captionAlignment' : return $this->captionAlignment[$options['captionAlignment']];   
                    case 'imageScaleMode' : return $this->imageScaleMode[$options['imageScaleMode']];
                    case 'captionColor' : return '#'.$options['captionColor'];
                    default : return $options[$_key]; 
                }
            } else {
                switch($_key){
                    case 'showTimer' : 
                    case 'showControlBar' :
                    case 'showNavButtons' : return 'false';
                }
            }
        }
      
        // default: else return with default value
        return $this->slider_defaults[$_key];
    }
     
     
    /** generate javascript for slider */      
    public function homeSlider_JS(){
        return "<script type='text/javascript'>
            JFBase.JFBlurrySlider.init({
                appendToID: 'homeSlider',
                maxWidth: " . $this->getSliderValue('maxWidth') . ",
                maxHeight: " . $this->getSliderValue('maxHeight') . ",
                imageScaleMode: '" . $this->getSliderValue('imageScaleMode') . "',
                loopContent: " . $this->getSliderValue('loopContent') . ",
                animationType: '" . $this->getSliderValue('animationType') . "',
                animationDuration: " . $this->getSliderValue('animationDuration')  .",
                autoSlideshow: " . $this->getSliderValue('autoSlideshow') . ",
                slideshowSpeed: " . $this->getSliderValue('slideshowSpeed') . ",
                pauseOnMouseOver: " . $this->getSliderValue('pauseOnMouseOver') . ",
                startIndex: " . $this->getSliderValue('startIndex') . ",
                captionAlignment: '" . $this->getSliderValue('captionAlignment') . "',
                captionColor: '" . $this->getSliderValue('captionColor') . "',
                autoHideControls: " . $this->getSliderValue('autoHideControls') . ",
                autoHideDelay: " . $this->getSliderValue('autoHideDelay') . ",
                disableAutohideOnMouseOver: " . $this->getSliderValue('disableAutohideOnMouseOver') . ",
                showTimer: " . $this->getSliderValue('showTimer') . ",
                showControlBar: " . $this->getSliderValue('showControlBar') . ",
                showNavButtons: " . $this->getSliderValue('showNavButtons') . "
            });
        </script>";
    }
    
    
    /** 
     * Get Framework path
     * @param $_e : if FALSE method returns, if TRUE method echoes
     */
    public function getFWPath($_e = false){
        if(!$_e){
            return $this->framework_folder;
        } else {
            echo $this->framework_folder;
        }
    }
    
    /** 
     * Get Home slider
     */      
    public function getHomeSlider(){
        
        $options = get_option('jf_theme_slider_settings');
        if(!$options) {
            if(class_exists('SampleData')) {
                SampleData::getSampleHomeSlider();
                return;
            }
            $maxWidth = 922;
        } else {
           $maxWidth = $options['maxWidth']; 
        }

        $slides = array();
        $one_slide = '';
        
        $slide_open =
        '<div id="homeSliderContainer">
            <div class="row">    
                <div class="grid_18 columns">
            		<div id="homeSlider" style="max-width:'.$maxWidth.'px;">
            			<div name="jf-slider_content" style="display: none">';

        $slide_close=
        '</div></div>'.
        '<table class="table_of_shadows" border="0" cellpadding="0" cellspacing="0" style="max-width: '.$maxWidth.'px; margin: 0 auto;">
                <tr>
                    <td class="post_left"></td>
                    <td class="post_center">&nbsp;</td>
                    <td class="post_right"></td>
                </tr>
            </table>'.        
        '</div></div></div>';
        
        $i=0;
        foreach(JApi::$slide_image_names as $k => $v){
            $i=$k+1;
            if( !array_key_exists($v, $options) ||
                empty($options[$v]) ||
                $options[$v] == 'http://' ) {
                break;        
            }
            
            $one_slide = '<div name="jf-slide"><div name="jf-type">image</div>';
            
            if(array_key_exists("slide_{$i}_title",$options)){
                $one_slide.= '<div name="jf-title">'.$options["slide_{$i}_title"].'</div>';
            } else {
                $one_slide.= '<div name="jf-title"></div>';
            }
            
            if(array_key_exists("slide_{$i}_description",$options)){
                $one_slide.= '<div name="jf-description">'.$options["slide_{$i}_description"].'</div>';
            } else {
                $one_slide.= '<div name="jf-description"></div>';
            }  
            
            $one_slide.= '<div name="jf-content">'.$options["slide_{$i}_image"].'</div>';
            if(array_key_exists("slide_{$i}_url",$options)){
                $one_slide.= '<div name="jf-target_url">'.esc_url($options["slide_{$i}_url"]).'</div>';
            } else {
                $one_slide.= '<div name="jf-target_url"></div>';
            }  
             
            if(array_key_exists("slide_{$i}_target",$options)){
                $one_slide.= '<div name="jf-target_window">'.$options["slide_{$i}_target"].'</div>';
            } else {
                $one_slide.= '<div name="jf-target_window"></div>';
            } 
                                                                    
            $one_slide.= '</div>'; 
            $slides[] = $one_slide; 

        }
        
        if(count($slides) > 0){
            echo $slide_open.implode('',$slides).$slide_close.
            $this->homeSlider_JS();
        }

    }
    
            
    /**
     * custom css
     */
    public static function generalCSS(){
        $options = get_option('jf_theme_design_settings');
        $css = array();
        if( isset($options['general_font_type']) ){
            ?>
        <!-- User Defined Font Family -->
            <style type="text/css">
            <?php
                if (strtolower($options['general_font_type']) != 'default'){
                ?>
                    /* Framework */
                    .button,
                    .menu ul.main-level li a,
                    .tab,
                    .panel,
                    .table,
                    .alert.message,
                    .alert.success,
                    .alert.info,
                    .alert.error,
                    .alert.warning,
                    .alert.question,
                    .custom-dropdown div.custom-head,
                    .custom-dropdown div.custom-body,
                    .jtip,
                    form.style-1 textarea,
                    /* Theme */
                    body,
                    form,
                    fieldset,
                    input,
                    button,
                    textarea,                    
                    h1, h2, h3, h4, h5,
                    div#image-navigation a,
                    div.comment div.comment_content p,
                    div.comment div.author,
                    div.post.single .post_content,
                    div.shortcode p,
                    div.post p.post_excerpt,
                    p.post_read_more a,
                    p.read_more a,
                    .date_holder span.month,
                    .date_holder span.day,
                    .excerpt,
                    .tabbed_widget .tab.style-2 dl dd a,
                    .text,
                    .gallery_img_title,
                    .contact_info_widget,
                    #top p.header_info,
                    #page_title_bar div.title,
                    #contact_map .map_text,
                    div.comment div.comment_date,
                    div.post div.post_meta_data,
                    div.post div.post_meta_data_no_thumb,
                    a.latest_post_link,
                    div.gallery_view_title,
                    .reply_button a,
                    
                    .no_post_date p.excerpt,
                    .no_post_date p.latest_post_author,
                    .latest_post_author,
                    .gallery_img_descr,
                    .tabbed_widget a,
                    #footer_widgets .widget_archive > ul li > a,
                    #footer_widgets .widget_categories > ul li.cat-item > a,
                    #footer_widgets li.widget > ul li,
                    #respond p.logged-in-as,
                    #respond p.comment-notes,
                    #secondary div.widget ul li,
                    #secondary div.widget ul li a,
                    #copyright .copyright,
                    #jf_contact_form label.captcha_label,
                    #jf_contact_form label {
                        font-family: "<?php echo $options['general_font_type']; ?>", sans-serif;
                    } 
                <?php    
                } 
            ?>
            </style>
            <?php
        }
    }     
 
      
    /**
     * Setup the WordPress core custom background feature.
     *
     * Use add_theme_support to register support for WordPress 3.4+
     * as well as provide backward compatibility for previous versions.
     * Use feature detection of wp_get_theme() which was introduced
     * in WordPress 3.4.
     *
     * Hooks into the after_setup_theme action.
     *
     */
    function jumpeye_register_custom_background() {
    	$args = array(
    		'default-color' => 'e9e0d1',
    	);
    
    	$args = apply_filters( 'jumpeye_custom_background_args', $args );
    
    	if ( function_exists( 'wp_get_theme' ) ) {
    		add_theme_support( 'custom-background', $args );
    	} else {
    		define( 'BACKGROUND_COLOR', $args['default-color'] );
    		define( 'BACKGROUND_IMAGE', $args['default-image'] );
    		add_custom_background();
    	}
    }

    
    /**
     * include latest jquery if we want to use the latest instead of WP's jQuery 
     */
    function load_jquery() {
       # http://stackoverflow.com/questions/10807200/jquery-uncaught-typeerror-property-of-object-object-window-is-not-a-funct    
       wp_deregister_script('jquery');
       wp_register_script('jquery', ("http://code.jquery.com/jquery-latest.min.js"), false, '');
       wp_enqueue_script('jquery');
    }
   
    
    /** load js files */
    function theme_js() {
    	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
    		wp_enqueue_script( 'comment-reply' );
    	}
    
    	if ( is_singular() && wp_attachment_is_image() ) {
    		wp_enqueue_script( 'keyboard-image-navigation', THEME_ROOT_URI . '/js/keyboard-image-navigation.js', array( 'jquery' ), '20120202' );
    	}        
    }
    
    
    /** load admin.js */
    function admin_js(){
        wp_enqueue_script('custom-ajax-request', THEME_ROOT_URI . '/js/admin.js', array( 'jquery' ), '1.0', false);
        wp_localize_script( 'custom-ajax-request', 'JAjax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) ) );
    }
    
    
    /** get footer links */
    function getFooterLinks(){
    ?>
        <a href="<?php echo esc_url(home_url('/')); ?>">Start</a>
        <a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
        <a href="#">Nowhere</a>
    <?php    
    }
    
    
    /** tabbed widget */
    function tabbedWidget(){
        echo '<div class="tab style-1 gradient">
					<dl>
						<dd><a href="#tab1" class="active">Recent</a></dd>
						<dd><a href="#tab2">Popular</a></dd>
						<dd><a href="#tab3">Random</a></dd>
					</dl>
					<ul>
						<li class="active">Tab 1 content ...</li>
						<li>Tab 2 content ...</li>
						<li>Tab 3 content ...</li>
					</ul>
				</div>';
    }

    
    /**
     * Show / Hide admin bar in frontend
     * @param $_set_flag : false = hide | true = show
     */
    function toggleAdminBarInFrontend($_set_flag = false){
        show_admin_bar($_set_flag);        
    } 

    
    /** 
     * show social media icons
     */
    public static function getSocialLinks(){
        $social_links = array();
        $options = get_option( 'jf_theme_social_settings' );

        if($options == false){
            return;         
        } else {
            foreach($options as $k=>$v){
                if( !empty($v) && $k!=='social_title'){
                    $social_links[] = '<div class="social_circle background_scheme"><a href="'.$v.'" target="_blank" class="social_link '.$k.'_icon"></a></div>';
                }             
            }            
        }
        
        $title = ( !isset($options['social_title'])) ? sprintf( __( 'Connect with us' )) : $options['social_title'];
        
        if(count($social_links)>0){
            echo '<h2 class="title color_scheme">'.$title.'</h2><p class="social_icons">'.
                 implode('&nbsp;',$social_links).'</p>';    
        }
    }
    
    
    /**
     * Get & Set Color scheme
     */
    public static function getColorScheme(){
        $options = get_option('jf_theme_design_settings');
        $color = (isset($options['color_scheme'])) ? $options['color_scheme'] : '#7dc70b';
        ?>
        <script type="text/javascript">
            JFBase(document).ready(function($){
                $('.color_scheme').css('color','<?php echo $color; ?>');
                $('.background_scheme').css('background-color','<?php echo $color; ?>');
            });
        </script>
        <?php 
    }  
    
    /** 
     * Show site description in the header under the site logo
     */
    public static function getDescription(){
        $descr = get_bloginfo('description');
        if( !empty($descr) ) :
        ?>
        <h2 class="site_description"><?php bloginfo( 'description' ); ?></h2> 
        <?php
        endif;
    }     
      
    /**
     * Show site logo in the header
     */         
    public static function getLogo(){
        $design_options = get_option('jf_theme_design_settings');
        $options = get_option('jf_theme_general_settings');
        
        if(isset($options['logo']) && !in_array($options['logo'], array('','http://'))){
            $logo = $options['logo'];    
        } else {
            
            $color_name = ( !isset($design_options['color_scheme'])) ? 'Green' : array_search($design_options['color_scheme'],JApi::$color_scheme);
            
            if($color_name == false){
                $logo = THEME_ROOT_URI.'/images/logo_green.png';
            } else {
                $logo = THEME_ROOT_URI.'/images/logo_'.strtolower($color_name).'.png';
            }            
        }

        if ( !in_array($logo, array('','http://')) ){
        ?>
        <a href='<?php echo esc_url(home_url('/')); ?>' title='<?php echo esc_attr(get_bloginfo('name', 'display')); ?>' rel='home'><img src='<?php echo $logo; ?>' alt='<?php echo esc_attr(get_bloginfo('name', 'display')); ?>' /></a>
        <?php    
        }  
    }                        
      
      
    /**
     * Get Header info
     */         
    public static function getHeaderInfo(){
        $options = get_option('jf_theme_general_settings');
        $info = (isset($options['header_info']) && !empty($options['header_info'])) ? '<p class="header_info">'.$options['header_info'].'</p>' : '';  
        echo $info;
    }         
      
    /** show a breadcrumb navigation */
    function getBreadcrumbNavbar() {
    	if (!is_home()) {
    		echo '<a href="';
    		echo get_option('home');
    		echo '">';
    		bloginfo('name');
    		echo "</a><span></span>";
    		if (is_category() || is_single()) {
    			the_category('title_li=');
    			if (is_single()) {
    				echo "<span></span>";
                    echo '<em>';
    				the_title();
                    echo '</em>';
    			}
    		} elseif (is_page()) {
    		    echo '<em>'; 
    			echo the_title();
                echo '</em>';
    		}
    	}
    } 
   

    /**
     * show HTML with meta information for current post: categories, tags, permalink, author, and date.
     */
    function getEntryMeta() {
    	// Translators: used between list items, there is a space after the comma.
    	$categories_list = get_the_category_list( __( ', ' ) );
    
    	// Translators: used between list items, there is a space after the comma.
    	$tag_list = get_the_tag_list( '', __( ', ' ) );
    
    	$date = sprintf( '<a href="%1$s" title="%2$s" rel="bookmark"><time class="entry-date" datetime="%3$s">%4$s</time></a>',
    		esc_url( get_permalink() ),
    		esc_attr( get_the_time() ),
    		esc_attr( get_the_date( 'c' ) ),
    		esc_html( get_the_date() )
    	);
    
    	$author = sprintf( '<span class="author vcard"><a class="url fn n" href="%1$s" title="%2$s" rel="author">%3$s</a></span>',
    		esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
    		esc_attr( sprintf( __( 'View all posts by %s' ), get_the_author() ) ),
    		get_the_author()
    	);
    
    	// Translators: 1 is category, 2 is tag, 3 is the date and 4 is the author's name.
    	if ( $tag_list ) {
    		$utility_text = __( 'This entry was posted in %1$s and tagged %2$s on %3$s<span class="by-author"> by %4$s</span>.' );
    	} elseif ( $categories_list ) {
    		$utility_text = __( 'This entry was posted in %1$s on %3$s<span class="by-author"> by %4$s</span>.' );
    	} else {
    		$utility_text = __( 'This entry was posted on %3$s<span class="by-author"> by %4$s</span>.' );
    	}
    
    	printf(
    		$utility_text,
    		$categories_list,
    		$tag_list,
    		$date,
    		$author
    	);
    }    
    

    /**
     * Displays navigation to next/previous pages when applicable.
     */
    function jf_content_nav( $html_id ) {
    	global $wp_query;
    
    	$html_id = esc_attr( $html_id );
    
    	if ( $wp_query->max_num_pages > 1 ) : ?>
    		<div id="<?php echo $html_id; ?>" class="navigation">
    			<h3 class="assistive-text"><?php _e( 'Post navigation','prestige' ); ?></h3>
    			<div class="nav-previous alignleft"><?php next_posts_link( __( '<span class="meta-nav">&larr;</span> Older posts','prestige' ) ); ?></div>
    			<div class="nav-next alignright"><?php previous_posts_link( __( 'Newer posts <span class="meta-nav">&rarr;</span>','prestige' ) ); ?></div>
    		</div><!-- #<?php echo $html_id; ?> .navigation -->
    	<?php endif;
    }
                   
} // END OF CLASS JF_Frontend  

    $JFO = new JF_Frontend(); // instantiate JF_Frontend class
    
    
/**
 * Main class of Dashboard functions
 */ 
class JF_Dashboard {
    
    // auto activate default plugins
    private $auto_activate_plugins = false;
    
    // objects 
    protected $fw_class;
        
    /** use the constructor to initialize Dashboard */    
    public function __construct(){
        
        $this->fw_class = new Framework();
        
        // load css/js files to Dashboard
        if (is_admin()){
            add_action('admin_enqueue_scripts', array( $this, 'adminCSS') );
            add_action('admin_enqueue_scripts', array( $this, 'adminJS' ));
            add_action('admin_enqueue_scripts', array( $this, 'colorpicker' ));
            add_action('admin_menu', array( $this, 'jf_theme_menu' )); 
            add_action('admin_init', array( $this, 'jf_theme_intialize_general_settings' ));
            add_action('admin_init', array( $this, 'jf_theme_intialize_design_settings' ));    
            add_action('admin_init', array( $this, 'jf_theme_intialize_slider_settings' ));        
            add_action('admin_init', array( $this, 'jf_theme_intialize_social_settings' ));
            add_action('post_edit_form_tag', array( $this, 'add_enctype' ));
            add_action( 'admin_enqueue_scripts', array( $this, 'media_uploader' ));
            
            // Automatically activate theme plugins if needed
            if($this->auto_activate_plugins){
                foreach( JApi::$theme_plugins as $k => $v){
                    $this->run_activate_plugin( $k.'/'.$v.'.php' );    
                }
            }

       	}
      
    }


    /**
     * Is Plugin Active
     * @param $_plugin
     */
    public static function isPluginActive($_plugin){
        $current = get_option( 'active_plugins' ); 
        $_plugin = strtolower($_plugin).'/'.plugin_basename( trim( $_plugin ) );
        return ( !in_array( $_plugin.'.php', $current ) ) ? false : true;
    }     
      
      
    /**
     * Activate plugins
     */ 
    public function run_activate_plugin( $_plugin ) {
        $current = get_option( 'active_plugins' );
        $_plugin = plugin_basename( trim( $_plugin ) );
    
        if ( !in_array( $_plugin, $current ) ) {
            $current[] = $_plugin;
            sort( $current );
            do_action( 'activate_plugin', trim( $_plugin ) );
            update_option( 'active_plugins', $current );
            do_action( 'activate_' . trim( $_plugin ) );
            do_action( 'activated_plugin', trim( $_plugin) );
        }
    
        return null;
    }
    
    /**
     * Admin Stylesheet
     */
    public function adminCSS(){
        wp_register_style( 'admin_stylesheet', get_template_directory_uri() . '/admin.css' );
        wp_enqueue_style( 'admin_stylesheet' );        
    }      
    
    /**
     * Admin Javascript
     */
    public function adminJS(){
        wp_enqueue_script('admin_js', THEME_ROOT_URI . '/js/admin.js', false, '1.0');
    }  
        
    /** 
     * call WP media uploader (from WP 3.5 only) 
     */ 
    function media_uploader(){
        wp_enqueue_media();    
    }
    
    
    /**
     *  Add data encoding type for file uploading
     */ 
	function add_enctype() {
		echo ' enctype="multipart/form-data"';
	}
    

    /** Retrieve options from database if any, or use default options instead */
    private function getValue($_settings, $_optarray, $_key=''){
    	$option = get_option($_optarray) ? get_option($_optarray) : Array();
        if(isset($option['nothing'])){
            foreach($_settings as $k => $v){
                if( !isset($option[$k])) $option[$k] = 0;
            }
        }        
    	$option = array_merge($_settings, $option);
        return ($_key) ? $option[$_key] : $option;
    } 
    
            
    /** create jquery colorpicer */
    function colorpicker(){
        wp_enqueue_style('colorpicker-css', THEME_ROOT_URI . '/api/js/colorpicker/css/colorpicker.css', false, '1.0');        
        wp_enqueue_script('colorpicker-js', THEME_ROOT_URI . '/api/js/colorpicker/js/colorpicker.js', false, '1.0');
    }

    
    /** add the 'Prestige Theme Options' menuitem under Appearance menu */
    function jf_theme_menu() {  
      
        add_theme_page(  
            'Prestige Theme Options',    // The title to be displayed in the browser window for this page.  
            'Prestige Theme Options',    // The text to be displayed for this menu item  
            'administrator',       // Which type of users can see this menu item  
            'jf_theme_options',    // The unique ID - that is, the slug - for this menu item  
            array($this, 'jf_theme_display') // The name of the function to call when rendering this menu's page  
        );  
      
    } // end jf_theme_menu  
    

    /** 
     * Renders a simple page to display for the theme menu defined above. 
     */ 
    function jf_theme_display() { 
    ?> 
        <!-- Create a header in the default WordPress 'wrap' container --> 
        <div class="wrap adm_jumpeye"> 
         
            <div id="icon-themes" class="icon32"></div> 
            <h2>Prestige Theme Options</h2> 
            <?php settings_errors(); ?>
            
            <?php  
                $active_tab = isset( $_GET[ 'tab' ] ) ? $_GET[ 'tab' ] : 'about_page';
            ?>   
            
            <h2 class="nav-tab-wrapper"> 
                <a href="?page=jf_theme_options&tab=about_page" class="nav-tab <?php echo $active_tab == 'about_page' ? 'nav-tab-active' : ''; ?>">About</a> 
                <a href="?page=jf_theme_options&tab=general_settings" class="nav-tab <?php echo $active_tab == 'general_settings' ? 'nav-tab-active' : ''; ?>">General settings</a>  
                <a href="?page=jf_theme_options&tab=design_settings" class="nav-tab <?php echo $active_tab == 'design_settings' ? 'nav-tab-active' : ''; ?>">Design settings</a>
                <a href="?page=jf_theme_options&tab=slider_settings" class="nav-tab <?php echo $active_tab == 'slider_settings' ? 'nav-tab-active' : ''; ?>">Slider settings</a>
                <a href="?page=jf_theme_options&tab=social_settings" class="nav-tab <?php echo $active_tab == 'social_settings' ? 'nav-tab-active' : ''; ?>">Social Settings</a>  
            </h2>
                      
            <form method="post" action="options.php" enctype="multipart/form-data"> 
                <?php  
                    
                    switch ($active_tab){
                        case 'design_settings' :
                            settings_fields( 'jf_theme_design_settings' );  
                            do_settings_sections( 'jf_theme_design_settings' );                         
                        break;
                        
                        case 'slider_settings' :
                            settings_fields( 'jf_theme_slider_settings' );  
                            do_settings_sections( 'jf_theme_slider_settings' );                         
                        break;
                                                                        
                        case 'social_settings' :
                            settings_fields( 'jf_theme_social_settings' );  
                            do_settings_sections( 'jf_theme_social_settings' );                         
                        break;
                                                
                        case 'general_settings' :
                            settings_fields( 'jf_theme_general_settings' );  
                            do_settings_sections( 'jf_theme_general_settings' );                         
                        break; 
                        
                        case 'about_page' : $this->about_page();

                        break;
                    }  
                    
                    if($active_tab != 'about_page'){
                        submit_button();     
                    }  
                ?> 
            </form> 
        </div><!-- /.wrap --> 
    <?php 
    } // end jf_theme_display


    /** show about page */
    function about_page(){
        ?>
        <p class="adm_description">The Prestige theme is a responsive business Wordpress theme built with Jumpeye framework. The theme helps you to present your business in an elegant and spectacular manner for your visitors and your website will look perfect on any device.</p>
        <p class="adm_description">The elements of the theme are listed below, to help you in the building process of your website.</p>
        <h3>1. Plugins</h3>
        <p class="adm_description">The Prestige theme comes with two included plugins:<br />
            <ul class="adm_description" style="list-style-type: square; margin-left: 20px">
                <li><strong>JF-Slider</strong> - image and content slider plugin</li>
                <li><strong>JF-UI-Elements</strong> - collection of web design elements</li>
            </ul>
        </p> 
        <p class="adm_description"><strong>JF-Slider</strong><br />
            Jumpeye framework contains an image and content slider that was added as a plugin to this Wordpress theme. Using the <strong>[jf_slider]</strong> shortcode you can easily create an image and content slider in your page without writing any HTML code. The slider can be configured in a few seconds by adding some parameters, like scale mode for the images, the maximum width and height of the slider or the animation type. The options page contains a complete list with the parameters of the slider.        
        </p>
        <p class="adm_description"><strong>JF-UI-Elements</strong><br />
            This plugin is a WordPress implementation of the Jumpeye framework UI elements. You can add UI elements in your page by inserting the shortcodes in the text editor. View the options page of the plugin in order to see the usage of the UI elements’ shortcodes.        
        </p>  
        <p class="adm_description"><strong><em><span style="color: red;">Important!</span> You must enable these two plugins to be able to use the image slider and the UI elements’ shortcodes in your pages. The Home Template of the theme also uses the JF-Slider plugin.</em></strong></p>
        <h3>2. Page Templates And Widgets</h3> 
        <p class="adm_description">The Prestige theme contains some page templates that are listed below, as well as some custom widgets that are designed for these page templates.</p>
        <p class="adm_description"><strong>Default Template</strong><br />
            This template comes with the default page layout provided by Wordpress.        
        </p>
        <p class="adm_description"><strong>Home Template</strong><br />
            Select this template to create a static home page for your website. There are some widgets that can be used on this page:<br />
            <ul class="adm_description" style="list-style-type: square; margin-left: 20px">
                <li><strong><em>JF One Post Widget</em></strong> - this widget displays one selected post in detail. It is useful to display a welcome text on the Home page for the visitors. Add this widget to the <strong><em>Home Page Main Post Area</em></strong> widget holder and it will appear automatically if the page has the Home Template applied.</li>
                <li><strong><em>JF Featured Posts Widget</em></strong> - this widget displays the recent posts of a specified category highlighting them in the content of the page. You can specify the number of featured posts and you can attach icons to them from an icon list. This widget is recommended to present the main activities of your business or other important information. Add this widget to the <strong><em>Home Page Featured Posts Area</em></strong> widget holder and it will appear automatically if the page has the Home Template applied.</li>
                <li><strong><em>JF Recent Tweets Widget</em></strong> - this widget displays the recent tweets of the specified Twitter account. You must create a Twitter widget (<a href="https://twitter.com/settings/widgets" target="_blank">https://twitter.com/settings/widgets</a>) first and add its ID to the Wordpress widget in order to display the latest tweets of the desired Twitter account. Add this widget to the <strong><em>Home Page Recent Tweets Area</em></strong> widget holder and it will appear automatically on the pages that have the Home Template applied.</li>
                <li><strong><em>JF Tabbed Widget</em></strong> - this widget displays recent posts from a specified category as tabbed content, each post in a separate tab. The widget is useful to display information about your company, services or products. Add this widget to the <strong><em>Home Page Tabbed Content Area</em></strong> widget holder and it will appear automatically if the page has the Home Template applied.</li>
                <li><strong><em>JF Recent From Widget</em></strong> - this widget displays the recent posts from a specified category. It is similar with the default Recent posts widget provided by Wordpress but it has a different design and it is useful for displaying content, like the recent news regarding your company’s activity. Add this widget to the <strong><em>Home Page Recent Posts Area</em></strong> widget holder and it will appear automatically on pages that have the Home Template applied.</li>
                <li><strong><em>JF Recent Projects Widget</em></strong> - this widget displays the recent posts of the specified  category in a thumbnail grid format. It is recommended for displaying recent projects, photos from a gallery or other photos. Add this widget to the <strong><em>Home Page Bottom Area</em></strong> widget holder and it will appear automatically on pages that have the Home Template applied.</li>                
            </ul>       
        </p>   
        
        <p class="adm_description"><strong>Services Template</strong><br />
            Select this template for displaying details of your services or products, for visitors. There are some widgets that can be used on this page:<br />
            <ul class="adm_description" style="list-style-type: square; margin-left: 20px">
                <li><strong><em>JF Categories List Widget</em></strong> - this widget lists the recent posts of three specified categories in three columns, highlighting the most recent post of each category. Add this widget to the <strong><em>Services Page Categories List Area</em></strong> widget holder and it will appear automatically on the page that has the Services Template applied.</li>
                <li><strong><em>JF One Post Widget</em></strong> - this widget displays one selected post in detail. Add this widget to the <strong><em>Services Page Bottom Area</em></strong> widget holder and it will appear automatically on the page that has the Services Template applied.</li>
            </ul>          
        </p>   
        
        <p class="adm_description"><strong>Gallery Template</strong><br />
            Select this template if you want to create a page with an image gallery. The template will apply a custom design to the default Wordpress gallery. You have to create a gallery on this page by using the “Create Gallery” option of the Media Library and insert it in the content editor.
        </p> 
        <p class="adm_description"><strong>Blog Template</strong><br />
            Select this template if you want to display the blog posts on that page.
        </p>   
        
        <p class="adm_description"><strong>Contact Template</strong><br />
            Select this template for a page on which you want to display your contact details. There are some widgets that can be used on this page:<br />
            <ul class="adm_description" style="list-style-type: square; margin-left: 20px">
                <li><strong><em>JF Contact Map Widget</em></strong> - this widget displays the specified map in an iframe. You need to place the url of the created map in the widget and set the size of its container. You can use the main map providers, like Google Maps, Yahoo Maps and others. Add this widget to the <strong><em>Contact Page Map Area</em></strong> widget holder and it will appear automatically on the page that has the Contact Template applied.</li>
                <li><strong><em>JF Contact Form Widget</em></strong> - this widget displays the contact form's inputs. Add this widget to the <strong><em>Contact Page Form Area</em></strong> widget holder and it will appear automatically on the page that has the Contact Template applied.</li>
                <li><strong><em>JF Contact Info Widget</em></strong> - this widget displays a box that contains different contact information like: address, phone number, Facebook page, Skype id and others. Add this widget to the <strong><em>Contact Page Info Area</em></strong> widget holder and it will appear automatically on the page that has the Contact Template applied.</li>
            </ul>          
        </p> 
        <p class="adm_description"><strong>Content Template</strong><br />
            Select this template if you want to add any custom content that doesn’t fit in any of the existing page templates.
        </p>                                                            
        <?php
    }
    
    /** General settings init */
    function jf_theme_intialize_general_settings() {
        // If the general_settings don't exist, create them.  
        if( false == get_option( 'jf_theme_general_settings' ) ) {     
            add_option( 'jf_theme_general_settings' );  
        }
        
        $sections = array('Domain keys'                  => 'domain_keys_section',
                          'Title'                        => 'meta_title_section',
                          'Meta description'             => 'meta_description_section',
                          'Meta keywords'                => 'meta_keywords_section',
                          'Logo'                         => 'logo_section',
                          'Favicon'                      => 'favicon_section',
                          'Header info'                  => 'header_info_section',
                          'Footer info'                  => 'copyright_text_section',
                          'Google Analytics tracking ID' => 'google_analitics_section');
        
        foreach($sections as $k => $v){
            add_settings_section(
        	    $v,
        	    $k,
        	    array($this, $v.'_callback'),
        	    'jf_theme_general_settings'
    	    ); 
        } 
        
        // add settings fields
        
        // domain keys
        add_settings_field(   
            "domain_keys",                        
            "Domain keys:",                             
            array($this, "jf_domain_keys_callback"),   
            "jf_theme_general_settings",   
            "domain_keys_section"  
        );         
                
        // Logo
        add_settings_field(   
            "logo",                        
            "Logo:",                             
            array($this, "jf_logo_callback"),   
            "jf_theme_general_settings",   
            "logo_section"  
        ); 
        
        // FavIcon
        add_settings_field(   
            "favicon",                        
            "Favicon:",                             
            array($this, "jf_favicon_callback"),   
            "jf_theme_general_settings",   
            "favicon_section"  
        ); 
                
        // Meta title (Site Title : <title></title>)
        add_settings_field(   
            "meta_title",                        
            "Title: ",                             
            array($this, "jf_meta_title_callback"),   
            "jf_theme_general_settings",   
            "meta_title_section"  
        ); 
        
        // Header Info
        add_settings_field(   
            "header_info",                        
            "Header info: ",                             
            array($this, "jf_header_info_callback"),   
            "jf_theme_general_settings",   
            "header_info_section"  
        ); 
           
        // Copyright text
        add_settings_field(   
            "copyright_text",                        
            "Footer info: ",                             
            array($this, "jf_copyright_text_callback"),   
            "jf_theme_general_settings",   
            "copyright_text_section"  
        ); 
                        
        // Meta description
        add_settings_field(   
            "meta_description",                        
            "Meta description: ",                             
            array($this, "jf_meta_description_callback"),   
            "jf_theme_general_settings",   
            "meta_description_section"  
        );         
         
        // Meta keywords
        add_settings_field(   
            "meta_keywords",                        
            "Meta keywords: ",                             
            array($this, "jf_meta_keywords_callback"),   
            "jf_theme_general_settings",   
            "meta_keywords_section"  
        ); 
        
        // Google Analitics
        add_settings_field(   
            "tracking_id",                        
            "Tracking ID: ",                             
            array($this, "jf_analytics_callback"),   
            "jf_theme_general_settings",   
            "google_analitics_section"  
        );   
                                
        register_setting('jf_theme_general_settings', 'jf_theme_general_settings', array($this, 'vanitize_general_settings'));       
    }
    
    /**
     * General settings section callbacks
     */
     
    function domain_keys_section_callback(){
        echo '<p class="adm_description">You can hide the watermark by adding a domain key. To get the domain key, go to <a href="http://www.jumpeyecomponents.com" target="_blank">www.jumpeyecomponents.com</a>, log in to your account, select the Jumpeye Framework domains option and add the Internet domain where your website will be hosted and copy the generated hash id for that particular domain. This generated hash id needs to be placed in the textfield above. You can type more domain keys for multiple domains, in which case you need to separate them with commas.</p>';    
    }
    
    function logo_section_callback(){
        echo '<p class="adm_description">If you would like to use your own custom logo image click the Upload Image button.</p>';
    }
         
    function favicon_section_callback(){
        echo '<p class="adm_description">If you want  to use your own custom favicon, click the Upload Image button.</p>';
    }
    
    function meta_title_section_callback(){
        echo '<p class="adm_description">You can set your custom title for the website in the textfield below.</p>';
    }
      
    function header_info_section_callback(){
        echo '<p class="adm_description">You can add an info text in the header area. This will be placed in the header of the page above the top search box.</p>';
    }
    
    function copyright_text_section_callback(){
        echo '<p class="adm_description">You can add an info text in the footer area. This will be placed in the footer of the page below the footer widgets.</p>';
    }
              
    function meta_description_section_callback(){
        echo '<p class="adm_description">You can add the meta description of the website below.</p>';
    }
    
    function meta_keywords_section_callback(){
        echo '<p class="adm_description">You can add some keywords for search engines in the following text input.<br />Keywords should be separated by commas. E.g.: jumpeye,framework,wordpress,themes</p>';
    }
      
    function google_analitics_section_callback(){
        echo '<p class="adm_description">You can set your Google Analytics tracking ID here. By specifying the tracking ID, the Google Analytics tracking code will be automatically added to your page.<br />For more information visit <a href="http://www.google.com/analytics/" target="_blank">http://www.google.com/analytics/</a>. Your tracking ID will be something like this: UA-XXXXX-Y.</p>';
    }
        
    /** 
     * General settings field callbacks
     */
    function jf_domain_keys_callback() {  
        $options = get_option( 'jf_theme_general_settings' );  
        $domain_keys = ''; 
        if( isset( $options['domain_keys'] ) ) { 
            $domain_keys = $options['domain_keys']; 
        } 
        echo '<input class="adm_input_500" type="text" id="domain_keys" name="jf_theme_general_settings[domain_keys]" value="' . $domain_keys . '" />';  
    }
         
    function jf_logo_callback(){
        $options = get_option( 'jf_theme_general_settings' );
        $logo = (isset($options['logo'])) ? $options['logo'] : 'http://';
        JApi::WPM_Uploader('jf_theme_general_settings','logo',$logo);
    }
         
    function jf_favicon_callback(){
        $options = get_option( 'jf_theme_general_settings' );
        $favicon = (isset($options['favicon'])) ? $options['favicon'] : 'http://';
        JApi::WPM_Uploader('jf_theme_general_settings','favicon',$favicon);
    }
    
    function jf_meta_title_callback() {  
        $options = get_option( 'jf_theme_general_settings' );  
        $title = ''; 
        if( isset( $options['meta_title'] ) ) { 
            $title = $options['meta_title']; 
        } 
        echo '<input class="adm_input_500" type="text" id="meta_title" name="jf_theme_general_settings[meta_title]" value="' . $title . '" />';  
    }
      
    function jf_header_info_callback() {  
        $options = get_option( 'jf_theme_general_settings' );  
        $info = ''; 
        if( isset( $options['header_info'] ) ) { 
            $info = $options['header_info']; 
        } 
        echo '<input class="adm_input_500" type="text" id="header_info" name="jf_theme_general_settings[header_info]" value="' . $info . '" />';  
    }
    
    function jf_copyright_text_callback() {  
        $options = get_option( 'jf_theme_general_settings' );
        $copyright = "Copyright 2013 | Powered by <a href='http://www.wordpress.org' target='_blank'>WordPress</a> | Prestige theme by <a href='http://www.jumpeye.com' target='_blank'>Jumpeye Components</a>"; 
        if( isset( $options['copyright_text'] ) ) { 
            $copyright = $options['copyright_text']; 
        } 
        echo '<input class="adm_input_500" type="text" id="copyright_text" name="jf_theme_general_settings[copyright_text]" value="' . $copyright . '" />';  
    }    
          
    function jf_meta_description_callback() {  
        $options = get_option( 'jf_theme_general_settings' );  
        $description = ''; 
        if( isset( $options['meta_description'] ) ) { 
            $description = $options['meta_description']; 
        } 
        echo '<textarea rows="6" class="adm_textarea" id="meta_description" name="jf_theme_general_settings[meta_description]">' . $description . '</textarea>';  
    }
       
    function jf_meta_keywords_callback() {  
        $options = get_option( 'jf_theme_general_settings' );  
        $keywords = ''; 
        if( isset( $options['meta_keywords'] ) ) { 
            $keywords = $options['meta_keywords']; 
        } 
        echo '<textarea rows="6" class="adm_textarea" id="meta_keywords" name="jf_theme_general_settings[meta_keywords]">' . $keywords . '</textarea>';  
    }
                 
    function jf_analytics_callback() {  
        $options = get_option( 'jf_theme_general_settings' );  
        $id = ''; 
        if( isset( $options['tracking_id'] ) ) { 
            $id = $options['tracking_id']; 
        } 
        echo '<input class="adm_input_500" type="text" id="tracking_id" name="jf_theme_general_settings[tracking_id]" value="' . $id . '" />';  
    }
        
    /** 
     * validate & sanitize display options callback
     * @param $input 
     */
    public function vanitize_general_settings( $input ){
        
        if(!isset($input['nothing'])){
            $input['nothing'] = '';    
        }

        // Define the array for the updated options  
        $output = array();  
        
        // Loop through each of the options sanitizing the data  
        foreach( $input as $key => $val ) {  
          
            if( isset ( $input[$key] ) ) {
                $output[$key] = strip_tags( stripslashes( $input[$key] ) );  
            }  
          
        } // end foreach  
          
        // Return the new collection  
        return apply_filters( 'vanitize_general_settings', $output, $input );         
    }
    
        
    /** 
     * Initializes the theme's social settings by registering the Sections, 
     * Fields, and Settings. 
     * 
     * This function is registered with the 'admin_init' hook. 
     */   
    function jf_theme_intialize_social_settings() {  
        // If the social_settings doesn't exist, create them.  
        if( false == get_option( 'jf_theme_social_settings' ) ) {     
            add_option( 'jf_theme_social_settings' );  
        }
      
        add_settings_section(  
            'social_settings_section',                  // ID used to identify this section and with which to register options  
            'Social links',                           // Title to be displayed on the administration page  
            array($this, 'jf_social_settings_callback'), // Callback used to render the description of the section  
            'jf_theme_social_settings'                   // Page on which to add this section of options  
        );
        
        // Title
        add_settings_field(   
            "social_title",                        
            "Title",                             
            array($this, "jf_social_title_callback"),   
            "jf_theme_social_settings",   
            "social_settings_section"  
        ); 
        
        // Icons            
        foreach(JApi::$social_links as $k => $v){
            add_settings_field(   
                "$v",                        
                "$k",                             
                array($this, "jf_{$v}_callback"),   
                "jf_theme_social_settings",   
                "social_settings_section"  
            );              
        }
                                      
        register_setting(  
            'jf_theme_social_settings',  
            'jf_theme_social_settings',  
            array($this, 'jf_theme_sanitize_social_settings')    
        );         
    }                   
    
    
    /** jf_social_settings_callback */
    function jf_social_settings_callback() {  
        echo '<p class="adm_description">Below you can set the URL for your desired social networks accounts.<br />If the URL is specified for a social network, the icon of that social network will be displayed on the page linked to your account.<br />You can use your custom social icons by overwriting the existing ones in the 
              <code>/theme/images/icons/social</code> folder.</p>';  
    } // end jf_general_options_callback 
    
    
    /** 
     * sanitize input fields
     * @param $input 
     */
    function jf_theme_sanitize_social_settings( $input ) {  
        // Define the array for the updated options  
        $output = array();  
      
        // Loop through each of the options sanitizing the data  
        foreach( $input as $key => $val ) {  
            if( isset ( $input[$key] ) ) { 
                $output[$key] = ($key != 'social_title') ? esc_url_raw( strip_tags( stripslashes( $input[$key] ) ) ) :
                strip_tags( stripslashes( $input[$key] ) );    
            }
        }          
        // Return the new collection  
        return apply_filters( 'jf_theme_sanitize_social_settings', $output, $input );  
    }  
    
    /** social title callback */
    function jf_social_title_callback(){
        $options = get_option( 'jf_theme_social_settings' );  
        $title = ''; 
        if( isset( $options['social_title'] ) ) { 
            $title = $options['social_title']; 
        } else {
            $title = 'Connect with us';
        }
        echo '<input class="adm_input_500" type="text" id="social_title" name="jf_theme_social_settings[social_title]" value="' . $title . '" />';  
    }
    
    /** facebook callback */
    function jf_facebook_callback() {  
        // First, we read the social_settings collection
        $options = get_option( 'jf_theme_social_settings' ); 
        // Next, we need to make sure the element is defined in the options. If not, we'll set an empty string. 
        $url = ''; 
        if( isset( $options['facebook'] ) ) { 
            $url = $options['facebook']; 
        } 
        // Render the output
        echo '<input class="adm_input_500" type="text" id="facebook" name="jf_theme_social_settings[facebook]" value="' . $url . '" />';  
    }  
        
    /** twitter callback */ 
    function jf_twitter_callback() {  
        $options = get_option( 'jf_theme_social_settings' );  
        $url = ''; 
        if( isset( $options['twitter'] ) ) { 
            $url = $options['twitter']; 
        }
        echo '<input class="adm_input_500" type="text" id="twitter" name="jf_theme_social_settings[twitter]" value="' . $url . '" />';  
    }
    
    /** Google+ callback */
    function jf_googleplus_callback() {  
        $options = get_option( 'jf_theme_social_settings' );  
        $url = ''; 
        if( isset( $options['googleplus'] ) ) { 
            $url = $options['googleplus']; 
        } 
        echo '<input class="adm_input_500" type="text" id="googleplus" name="jf_theme_social_settings[googleplus]" value="' . $url . '" />';  
    }
     
    /** Pinterest callback */
    function jf_pinterest_callback() {  
        $options = get_option( 'jf_theme_social_settings' );  
        $url = ''; 
        if( isset( $options['pinterest'] ) ) { 
            $url = $options['pinterest']; 
        } 
        echo '<input class="adm_input_500" type="text" id="pinterest" name="jf_theme_social_settings[pinterest]" value="' . $url . '" />';  
    }
      
    /** Youtube callback */
    function jf_youtube_callback() {  
        $options = get_option( 'jf_theme_social_settings' );  
        $url = ''; 
        if( isset( $options['youtube'] ) ) { 
            $url = $options['youtube']; 
        } 
        echo '<input class="adm_input_500" type="text" id="youtube" name="jf_theme_social_settings[youtube]" value="' . $url . '" />';  
    }
    
    /** Vimeo callback */
    function jf_vimeo_callback() {  
        $options = get_option( 'jf_theme_social_settings' );  
        $url = ''; 
        if( isset( $options['vimeo'] ) ) { 
            $url = $options['vimeo']; 
        } 
        echo '<input class="adm_input_500" type="text" id="vimeo" name="jf_theme_social_settings[vimeo]" value="' . $url . '" />';  
    }
     
    /** LinkedIN callback */
    function jf_linkedin_callback() {  
        $options = get_option( 'jf_theme_social_settings' );  
        $url = ''; 
        if( isset( $options['linkedin'] ) ) { 
            $url = $options['linkedin']; 
        } 
        echo '<input class="adm_input_500" type="text" id="linkedin" name="jf_theme_social_settings[linkedin]" value="' . $url . '" />';  
    }
     
    /** Flickr callback */
    function jf_flickr_callback() {  
        $options = get_option( 'jf_theme_social_settings' );  
        $url = ''; 
        if( isset( $options['flickr'] ) ) { 
            $url = $options['flickr']; 
        } 
        echo '<input class="adm_input_500" type="text" id="flickr" name="jf_theme_social_settings[flickr]" value="' . $url . '" />';  
    }
      
    /** Tumblr callback */
    function jf_tumblr_callback() {  
        $options = get_option( 'jf_theme_social_settings' );  
        $url = ''; 
        if( isset( $options['tumblr'] ) ) { 
            $url = $options['tumblr']; 
        } 
        echo '<input class="adm_input_500" class="adm_input_500" type="text" id="tumblr" name="jf_theme_social_settings[tumblr]" value="' . $url . '" />';  
    }
      
    /** MySpace callback */
    function jf_myspace_callback() {  
        $options = get_option( 'jf_theme_social_settings' );  
        $url = ''; 
        if( isset( $options['myspace'] ) ) { 
            $url = $options['myspace']; 
        } 
        echo '<input class="adm_input_500" type="text" id="myspace" name="jf_theme_social_settings[myspace]" value="' . $url . '" />';  
    }
                                    
    /** RSS callback */
    function jf_rss_callback() {  
        $options = get_option( 'jf_theme_social_settings' );  
        $url = ''; 
        if( isset( $options['rss'] ) ) { 
            $url = $options['rss']; 
        } 
        echo '<input class="adm_input_500" type="text" id="rss" name="jf_theme_social_settings[rss]" value="' . $url . '" />';  
    }


    /** 
     * Initializes the theme's slider settings by registering the Sections, 
     * Fields, and Settings. 
     * 
     * This function is registered with the 'admin_init' hook. 
     */   
    function jf_theme_intialize_slider_settings() {  
        
        // create sections
        $sections = array(
            'Slide 1'      => 'slide_1_section',
            'Slide 2'      => 'slide_2_section',
            'Slide 3'      => 'slide_3_section',
            'Slide 4'      => 'slide_4_section',
            'Slide 5'      => 'slide_5_section',
            '<br />Skin options' => 'skin_options_section'            
        );
        
        // create settings fields
        $fields = array(
            'slide_1_section' => array(
                'slide_1_image'       => 'Slide 1 image :',
                'slide_1_title'       => 'Slide 1 title :',
                'slide_1_description' => 'Slide 1 description :',
                'slide_1_url'         => 'Slide 1 url :',
                'slide_1_target'      => 'Slide 1 target :',
            ),
            'slide_2_section' => array(
                'slide_2_image'       => 'Slide 2 image :',
                'slide_2_title'       => 'Slide 2 title :',
                'slide_2_description' => 'Slide 2 description :',
                'slide_2_url'         => 'Slide 2 url :',
                'slide_2_target'      => 'Slide 2 target :',
            ),
            'slide_3_section' => array(
                'slide_3_image'       => 'Slide 3 image :',
                'slide_3_title'       => 'Slide 3 title :',
                'slide_3_description' => 'Slide 3 description :',
                'slide_3_url'         => 'Slide 3 url :',
                'slide_3_target'      => 'Slide 3 target :',
            ),
            'slide_4_section' => array(
                'slide_4_image'       => 'Slide 4 image :',
                'slide_4_title'       => 'Slide 4 title :',
                'slide_4_description' => 'Slide 4 description :',
                'slide_4_url'         => 'Slide 4 url :',
                'slide_4_target'      => 'Slide 4 target :',
            ),       
            'slide_5_section' => array(
                'slide_5_image'       => 'Slide 5 image :',
                'slide_5_title'       => 'Slide 5 title :',
                'slide_5_description' => 'Slide 5 description :',
                'slide_5_url'         => 'Slide 5 url :',
                'slide_5_target'      => 'Slide 5 target :',
            )                             
        );
        
        // slider options
        $slider_options = array(
            "maxWidth" => "The maximum width of the slider (in pixels) which is used to calculate the size ratio of the component.<br />Using this ratio the slider is then resized by the grid, when the grid is resized.",
            "maxHeight" => "The maximum height of the slider (in pixels) which is used to calculate the size ratio of the component.<br />Using this ratio the slider is then resized by the grid, when the grid is resized.",
            "imageScaleMode" => "The scaling mode is used only for images from an image slideshow (slide type is set to image).",
            "loopContent" => "If set to true, the slider will display the slides in a loop - from the last slide it will allow navigating to the next slide, in fact the first slide;<br />from the first slide it will allow navigating to the previous slide, in fact the last slide.",
            "animationType" => "Sets the type of the animation that is applied as show and hide effects for the slides.",
            "animationDuration" => "The duration of the show/hide effect for one slide expressed in seconds.",
            "autoSlideshow" => "If it is set to true, the slider will automatically navigate through the slides.",
            "slideshowSpeed" => "The amount of time (in seconds) until a slide is displayed during the slideshow - from the end of the previous transition to the start of the next one.",
            "pauseOnMouseOver" => "If set to true, the automatic slideshow will stop while the mouse is over the slider.",
            "startIndex" => "The index of the slide, which is displayed firstly. If this property is not set, the slider starts with the first slide.",
            "captionAlignment" => "Sets the alignment of the title and description within the caption area (control bar).",
            "captionColor" => "The color of the title and description. Please use long format (ex. FFFFFF)",
            "autoHideControls" => "If it is true, the controls (navigation buttons, control bar and captions) will hide automatically after a period of inactivity specified by autoHideDelay<br />or when the mouse rolls out of the slider. In case of mobile devices, the controls will display when the user taps on the slider surface.",
            "autoHideDelay" => "If autoHideControls is set to true, the controls will hide after a period of inactivity.<br />That period of inactivity is set by this property and it is measured in seconds.",
            "disableAutohideOnMouseOver" => "If set to true, the controls (navigation buttons, control bar and captions) will not hide automatically while the mouse is over the slider,<br />even if autoHideControls is set to true.",
            "showTimer" => "If it is true, the timer will be displayed in the top-right corner of the slider.",
            "showControlBar" => "If it is set to true, the slider displays the control bar.",
            "showNavButtons" => "If set to true, the slider displays the Previous and Next slide buttons.");           
        
        foreach($sections as $k => $v){
            add_settings_section(
        	    $v,
        	    $k,
        	    array($this, $v.'_callback'),
        	    'jf_theme_slider_settings'
    	    ); 
        } 
           

                        
        if( false == get_option( 'jf_theme_slider_settings' ) ) {     
            add_option( 'jf_theme_slider_settings' );  
        }
        
        /**
         * Add settings fields
         */
         
       foreach($fields as $k => $v){
           foreach($v as $k2 => $v2){
               add_settings_field(
                   $k2,
                   $v2,
                   array($this, $k2.'_callback'),
                   'jf_theme_slider_settings',
                   $k 
               );            
           } 
       }   
            
        foreach($slider_options as $k => $v){
            add_settings_field(   
                "$k",                        
                "$k",                             
                array($this, "home_slider_{$k}_callback"),   
                "jf_theme_slider_settings",   
                "skin_options_section"  
            );              
        }
                                                     
       register_setting(  
           'jf_theme_slider_settings',  
           'jf_theme_slider_settings',
           array($this, 'vanitize_general_settings')  
       );         
            
    }
    
    /** homeSlider settings section callbacks */
    function slide_1_section_callback(){}
    
    function slide_2_section_callback(){}
    
    function slide_3_section_callback(){}
    
    function slide_4_section_callback(){}
    
    function slide_5_section_callback(){}    
    
    function skin_options_section_callback(){
        echo '<p class="adm_description"></p>';    
    }
    
    /** homeSlider settings fields callbacks */
    function slide_1_image_callback(){
        $options = get_option( 'jf_theme_slider_settings' );
        $slide_1_image = (isset($options['slide_1_image'])) ? $options['slide_1_image'] : 'http://';        
        JApi::WPM_Uploader('jf_theme_slider_settings', 'slide_1_image', $slide_1_image);
    }          
      
    function slide_1_title_callback(){
        $options = get_option( 'jf_theme_slider_settings' );  
        $title = (isset($options['slide_1_title'])) ? $options['slide_1_title'] : ''; 
        echo '<input class="adm_input_500" type="text" id="slide_1_title" name="jf_theme_slider_settings[slide_1_title]" value="' . $title . '" />';  
    }                 
     
    function slide_1_description_callback(){
        $options = get_option( 'jf_theme_slider_settings' );  
        $description = (isset($options['slide_1_description'])) ? $options['slide_1_description'] : ''; 
        echo '<input class="adm_input_500" type="text" id="slide_1_description" name="jf_theme_slider_settings[slide_1_description]" value="' . $description . '" />';  
    }  
        
    function slide_1_url_callback(){
        $options = get_option( 'jf_theme_slider_settings' );  
        $url = (isset($options['slide_1_url'])) ? $options['slide_1_url'] : ''; 
        echo '<input class="adm_input_500" type="text" id="slide_1_url" name="jf_theme_slider_settings[slide_1_url]" value="' . $url . '" />';  
    }  
    
    function slide_1_target_callback(){
        $url_targets = JApi::$url_targets; 
        $default = '_blank';
        
        $options = get_option('jf_theme_slider_settings');  
        if ( ! isset( $options['slide_1_target'] ) ){
            $options['slide_1_target'] = $default;
        }
         
        echo '<select class="adm_select" id="slide_1_target"  name="jf_theme_slider_settings[slide_1_target]">';
        
        foreach($url_targets as $k => $v){
            echo '<option value="'.$v.'" '.selected( $options['slide_1_target'], $v ).'>'.$k.'</option>';    
        }
    } 
        
    function slide_2_image_callback(){
        $options = get_option( 'jf_theme_slider_settings' );
        $slide_2_image = (isset($options['slide_2_image'])) ? $options['slide_2_image'] : 'http://';        
        JApi::WPM_Uploader('jf_theme_slider_settings', 'slide_2_image', $slide_2_image);
    }          
      
    function slide_2_title_callback(){
        $options = get_option( 'jf_theme_slider_settings' );  
        $title = (isset($options['slide_2_title'])) ? $options['slide_2_title'] : ''; 
        echo '<input class="adm_input_500" type="text" id="slide_2_title" name="jf_theme_slider_settings[slide_2_title]" value="' . $title . '" />';  
    }                 
     
    function slide_2_description_callback(){
        $options = get_option( 'jf_theme_slider_settings' );  
        $description = (isset($options['slide_2_description'])) ? $options['slide_2_description'] : ''; 
        echo '<input class="adm_input_500" type="text" id="slide_2_description" name="jf_theme_slider_settings[slide_2_description]" value="' . $description . '" />';  
    }  
        
    function slide_2_url_callback(){
        $options = get_option( 'jf_theme_slider_settings' );  
        $url = (isset($options['slide_2_url'])) ? $options['slide_2_url'] : ''; 
        echo '<input class="adm_input_500" type="text" id="slide_2_url" name="jf_theme_slider_settings[slide_2_url]" value="' . $url . '" />';  
    }  
    
    function slide_2_target_callback(){
        $url_targets = JApi::$url_targets; 
        $default = '_blank';
        
        $options = get_option('jf_theme_slider_settings');  
        if ( ! isset( $options['slide_2_target'] ) ){
            $options['slide_2_target'] = $default;
        }
         
        echo '<select class="adm_select" id="slide_2_target"  name="jf_theme_slider_settings[slide_2_target]">';
        
        foreach($url_targets as $k => $v){
            echo '<option value="'.$v.'" '.selected( $options['slide_2_target'], $v ).'>'.$k.'</option>';    
        }
    }
    
    function slide_3_image_callback(){
        $options = get_option( 'jf_theme_slider_settings' );
        $slide_3_image = (isset($options['slide_3_image'])) ? $options['slide_3_image'] : 'http://';        
        JApi::WPM_Uploader('jf_theme_slider_settings', 'slide_3_image', $slide_3_image);
    }          
      
    function slide_3_title_callback(){
        $options = get_option( 'jf_theme_slider_settings' );  
        $title = (isset($options['slide_3_title'])) ? $options['slide_3_title'] : ''; 
        echo '<input class="adm_input_500" type="text" id="slide_3_title" name="jf_theme_slider_settings[slide_3_title]" value="' . $title . '" />';  
    }                 
     
    function slide_3_description_callback(){
        $options = get_option( 'jf_theme_slider_settings' );  
        $description = (isset($options['slide_3_description'])) ? $options['slide_3_description'] : ''; 
        echo '<input class="adm_input_500" type="text" id="slide_3_description" name="jf_theme_slider_settings[slide_3_description]" value="' . $description . '" />';  
    }  
        
    function slide_3_url_callback(){
        $options = get_option( 'jf_theme_slider_settings' );  
        $url = (isset($options['slide_3_url'])) ? $options['slide_3_url'] : ''; 
        echo '<input class="adm_input_500" type="text" id="slide_3_url" name="jf_theme_slider_settings[slide_3_url]" value="' . $url . '" />';  
    }  
    
    function slide_3_target_callback(){
        $url_targets = JApi::$url_targets; 
        $default = '_blank';
        
        $options = get_option('jf_theme_slider_settings');  
        if ( ! isset( $options['slide_3_target'] ) ){
            $options['slide_3_target'] = $default;
        }
         
        echo '<select class="adm_select" id="slide_3_target"  name="jf_theme_slider_settings[slide_3_target]">';
        
        foreach($url_targets as $k => $v){
            echo '<option value="'.$v.'" '.selected( $options['slide_3_target'], $v ).'>'.$k.'</option>';    
        }
    }
    
    function slide_4_image_callback(){
        $options = get_option( 'jf_theme_slider_settings' );
        $slide_4_image = (isset($options['slide_4_image'])) ? $options['slide_4_image'] : 'http://';        
        JApi::WPM_Uploader('jf_theme_slider_settings', 'slide_4_image', $slide_4_image);
    }          
      
    function slide_4_title_callback(){
        $options = get_option( 'jf_theme_slider_settings' );  
        $title = (isset($options['slide_4_title'])) ? $options['slide_4_title'] : ''; 
        echo '<input class="adm_input_500" type="text" id="slide_4_title" name="jf_theme_slider_settings[slide_4_title]" value="' . $title . '" />';  
    }                 
     
    function slide_4_description_callback(){
        $options = get_option( 'jf_theme_slider_settings' );  
        $description = (isset($options['slide_4_description'])) ? $options['slide_4_description'] : ''; 
        echo '<input class="adm_input_500" type="text" id="slide_4_description" name="jf_theme_slider_settings[slide_4_description]" value="' . $description . '" />';  
    }  
        
    function slide_4_url_callback(){
        $options = get_option( 'jf_theme_slider_settings' );  
        $url = (isset($options['slide_4_url'])) ? $options['slide_4_url'] : ''; 
        echo '<input class="adm_input_500" type="text" id="slide_4_url" name="jf_theme_slider_settings[slide_4_url]" value="' . $url . '" />';  
    }  
    
    function slide_4_target_callback(){
        $url_targets = JApi::$url_targets; 
        $default = '_blank';
        
        $options = get_option('jf_theme_slider_settings');  
        if ( ! isset( $options['slide_4_target'] ) ){
            $options['slide_4_target'] = $default;
        }
         
        echo '<select class="adm_select" id="slide_4_target"  name="jf_theme_slider_settings[slide_4_target]">';
        
        foreach($url_targets as $k => $v){
            echo '<option value="'.$v.'" '.selected( $options['slide_4_target'], $v ).'>'.$k.'</option>';    
        }
    }
    
    function slide_5_image_callback(){
        $options = get_option( 'jf_theme_slider_settings' );
        $slide_5_image = (isset($options['slide_5_image'])) ? $options['slide_5_image'] : 'http://';        
        JApi::WPM_Uploader('jf_theme_slider_settings', 'slide_5_image', $slide_5_image);
    }          
      
    function slide_5_title_callback(){
        $options = get_option( 'jf_theme_slider_settings' );  
        $title = (isset($options['slide_5_title'])) ? $options['slide_5_title'] : ''; 
        echo '<input class="adm_input_500" type="text" id="slide_5_title" name="jf_theme_slider_settings[slide_5_title]" value="' . $title . '" />';  
    }                 
     
    function slide_5_description_callback(){
        $options = get_option( 'jf_theme_slider_settings' );  
        $description = (isset($options['slide_5_description'])) ? $options['slide_5_description'] : ''; 
        echo '<input class="adm_input_500" type="text" id="slide_5_description" name="jf_theme_slider_settings[slide_5_description]" value="' . $description . '" />';  
    }  
        
    function slide_5_url_callback(){
        $options = get_option( 'jf_theme_slider_settings' );  
        $url = (isset($options['slide_5_url'])) ? $options['slide_5_url'] : ''; 
        echo '<input class="adm_input_500" type="text" id="slide_5_url" name="jf_theme_slider_settings[slide_5_url]" value="' . $url . '" />';  
    }  
    
    function slide_5_target_callback(){
        $url_targets = JApi::$url_targets; 
        $default = '_blank';
        
        $options = get_option('jf_theme_slider_settings');  
        if ( ! isset( $options['slide_5_target'] ) ){
            $options['slide_5_target'] = $default;
        }
         
        echo '<select class="adm_select" id="slide_5_target"  name="jf_theme_slider_settings[slide_5_target]">';
        
        foreach($url_targets as $k => $v){
            echo '<option value="'.$v.'" '.selected( $options['slide_5_target'], $v ).'>'.$k.'</option>';    
        }
    }
        
        
    /** Slider skin option callbacks */             
    function home_slider_maxWidth_callback(){
        $options = get_option( 'jf_theme_slider_settings' );
        $value = ( isset( $options['maxWidth'] ) ) ? $options['maxWidth'] : 922; 
        echo '<input class="adm_input_200" type="text" id="maxWidth" name="jf_theme_slider_settings[maxWidth]" value="' . $value . '" /> pixels<br />';
    }
    
    function home_slider_maxHeight_callback(){
        $options = get_option( 'jf_theme_slider_settings' );  
        $value = ( isset( $options['maxHeight'] ) ) ? $options['maxHeight'] : 358;   
        echo '<input class="adm_input_200" type="text" id="maxHeight" name="jf_theme_slider_settings[maxHeight]" value="' . $value . '" /> pixels';
    }

    function home_slider_imageScaleMode_callback() {  
        $options = get_option('jf_theme_slider_settings');  
        if ( ! isset( $options['imageScaleMode'] ) ){
            $options['imageScaleMode'] = 2;
        }  
        ?> 
        <select class="adm_select" id="imageScaleMode"  name="jf_theme_slider_settings[imageScaleMode]">
            <option value="1" <?php selected( $options['imageScaleMode'], 1 ); ?>>scale</option>
            <option value="2" <?php selected( $options['imageScaleMode'], 2 ); ?>>scaleCrop</option>
            <option value="3" <?php selected( $options['imageScaleMode'], 3 ); ?>>crop</option>
            <option value="4" <?php selected( $options['imageScaleMode'], 4 ); ?>>stretch</option>
        </select>
        <?php            
	}    
    
    function home_slider_loopContent_callback() {  
        $options = get_option('jf_theme_slider_settings');  
        if ( ! isset( $options['loopContent'] ) ){
            $options['loopContent'] = 0;
        }        
	    echo '<input type="checkbox" id="loopContent" name="jf_theme_slider_settings[loopContent]" value="1" ' . checked(1, $options['loopContent'], false) . '/>';   
	}
       
    function home_slider_animationType_callback() {  
        $options = get_option('jf_theme_slider_settings');  
        if ( ! isset( $options['animationType'] ) ){
            $options['animationType'] = 2;
        }  
        ?>
        <select class="adm_select" id="animationType"  name="jf_theme_slider_settings[animationType]">
            <option value="1" <?php selected( $options['animationType'], 1 ); ?>>fade</option>
            <option value="2" <?php selected( $options['animationType'], 2 ); ?>>slide</option>
            <option value="3" <?php selected( $options['animationType'], 3 ); ?>>none</option>
        </select>
        <?php            
	}
      
    function home_slider_animationDuration_callback() {  
        $options = get_option( 'jf_theme_slider_settings' );  
        $value = ( isset( $options['animationDuration'] ) ) ? $options['animationDuration'] : 0.3;  
        echo '<input class="adm_input_200" type="text" id="animationDuration" name="jf_theme_slider_settings[animationDuration]" value="' . $value . '" /> second(s)';        
	}
      
    function home_slider_autoSlideshow_callback() {  
        $options = get_option('jf_theme_slider_settings');  
        if ( ! isset( $options['autoSlideshow'] ) ){
            $options['autoSlideshow'] = 0;
        }          
	    echo '<input type="checkbox" id="autoSlideshow" name="jf_theme_slider_settings[autoSlideshow]" value="1" ' . checked(1, $options['autoSlideshow'], false) . '/>';   
	}    
    
    function home_slider_slideshowSpeed_callback() {  
        $options = get_option('jf_theme_slider_settings');
        $value = ( isset( $options['slideshowSpeed'] ) ) ? $options['slideshowSpeed'] : 6;  
        echo '<input class="adm_input_200" type="text" id="slideshowSpeed" name="jf_theme_slider_settings[slideshowSpeed]" value="' . $value . '" /> second(s)';        
	}  
    
    function home_slider_pauseOnMouseOver_callback() {  
        $options = get_option('jf_theme_slider_settings');  
        if ( ! isset( $options['pauseOnMouseOver'] ) ){
            $options['pauseOnMouseOver'] = 0;
        }           
  	    echo '<input type="checkbox" id="pauseOnMouseOver" name="jf_theme_slider_settings[pauseOnMouseOver]" value="1" ' . checked(1, $options['pauseOnMouseOver'], false) . '/>';   
	} 
    
    function home_slider_startIndex_callback() {  
        $options = get_option('jf_theme_slider_settings');  
        $value = ( isset( $options['startIndex'] ) ) ? $options['startIndex'] : 0; 
        echo '<input class="adm_input_200" type="text" id="startIndex" name="jf_theme_slider_settings[startIndex]" value="' . $value . '" /> second(s)';        
	}
    
    function home_slider_captionAlignment_callback() {  
        $options = get_option('jf_theme_slider_settings');  
        if ( ! isset( $options['captionAlignment'] ) ){
            $options['captionAlignment'] = 1;
        }  
        ?>
        <select class="adm_select" id="captionAlignment"  name="jf_theme_slider_settings[captionAlignment]">
            <option value="1" <?php selected( $options['captionAlignment'], 1 ); ?>>left</option>
            <option value="2" <?php selected( $options['captionAlignment'], 2 ); ?>>center</option>
            <option value="3" <?php selected( $options['captionAlignment'], 3 ); ?>>right</option>
        </select>
        <?php            
	}
    
    function home_slider_captionColor_callback() {  
        $options = get_option('jf_theme_slider_settings');  
        $value = 'FFFFFF'; 
        if( isset( $options['captionColor'] ) ) { 
            $value = $options['captionColor']; 
        } 
         
        // Render the output 
        echo '#<input class="adm_input_200" maxlength="6" size="6" type="text" id="captionColor" name="jf_theme_slider_settings[captionColor]" value="' . $value . '" />
        <script type="text/javascript">
            jQuery(document).ready(function ($) {
                $("#captionColor").ColorPicker({
                	onSubmit: function(hsb, hex, rgb, el) {
                		$(el).val(hex);
                		$(el).ColorPickerHide();
                	},
                	onBeforeShow: function () {
                		$(this).ColorPickerSetColor(this.value);
                	}
                })
                .bind("keyup", function(){
                	$(this).ColorPickerSetColor(this.value);
                });
            });            
        </script>';        
	}    
    
    function home_slider_autohideControls_callback() {  
        $options = get_option('jf_theme_slider_settings'); 
        if ( ! isset( $options['autoHideControls'] ) ){
            $options['autoHideControls'] = 0;
        }          
	    echo '<input type="checkbox" id="autoHideControls" name="jf_theme_slider_settings[autoHideControls]" value="1" ' . checked(1, $options['autoHideControls'], false) . '/>';   
	}
    
    function home_slider_autohideDelay_callback() {  
        $options = get_option('jf_theme_slider_settings');  
        $value = ( isset( $options['autoHideDelay'] ) ) ? $options['autoHideDelay'] : 3; 
        echo '<input class="adm_input_200" type="text" id="autoHideDelay" name="jf_theme_slider_settings[autoHideDelay]" value="' . $value . '" /> second(s)';        
	}
    
    function home_slider_disableAutohideOnMouseOver_callback() {  
        $options = get_option('jf_theme_slider_settings');  
        if ( ! isset( $options['disableAutohideOnMouseOver'] ) ){
            $options['disableAutohideOnMouseOver'] = 0;
        }           
	    echo '<input type="checkbox" id="disableAutohideOnMouseOver" name="jf_theme_slider_settings[disableAutohideOnMouseOver]" value="1" ' . checked(1, $options['disableAutohideOnMouseOver'], false) . '/>';   
	}
    
    function home_slider_showTimer_callback() {  
        $options = get_option('jf_theme_slider_settings');
        $checked = $this->optionCheck('showTimer') ? 'checked="checked"':'';
	    echo '<input type="checkbox" id="showTimer" name="jf_theme_slider_settings[showTimer]" value="1" ' . $checked . '/>';   
	}    
      
    function home_slider_showControlBar_callback() {  
        $options = get_option('jf_theme_slider_settings');
        $checked = $this->optionCheck('showControlBar') ? 'checked="checked"':''; 
	    echo '<input type="checkbox" id="showControlBar" name="jf_theme_slider_settings[showControlBar]" value="1" ' . $checked . '/>';   
	}
     
    function home_slider_showNavButtons_callback() {  
        $options = get_option('jf_theme_slider_settings');
        $checked = $this->optionCheck('showNavButtons') ? 'checked="checked"':'';
	    echo '<input type="checkbox" id="showNavButtons" name="jf_theme_slider_settings[showNavButtons]" value="1" ' . $checked . '/>';   
	}
    
    /** Retrieve options from database if any, or use default options instead */
    private function optionCheck($key=''){
        $settings = Array(
            'showTimer' => 1,
            'showControlBar' => 1,
            'showNavButtons' => 1
        );
    	$option = get_option('jf_theme_slider_settings') ? get_option('jf_theme_slider_settings') : Array();

        if(isset($option['maxWidth'])){
            foreach($settings as $k => $v){
                if( !isset($option[$k])) $option[$k] = 0;
            }
        }

    	$option = array_merge($settings, $option);
        return ($key) ? $option[$key] : $option;
    } 
     
   
                                                                                                            
    /** 
     * Initializes the theme's design settings by registering the Sections, 
     * Fields, and Settings. 
     * 
     * This function is registered with the 'admin_init' hook. 
     */   
    function jf_theme_intialize_design_settings() {  
        
        // create sections
        $sections = array(
            'Color scheme'      => 'color_scheme_section',
            'Font type'         => 'general_font_type_section',
            'Enable fancybox'   => 'enable_fancybox_section'
        );
        
        foreach($sections as $k => $v){
            add_settings_section(
        	    $v,
        	    $k,
        	    array($this, $v.'_callback'),
        	    'jf_theme_design_settings'
    	    ); 
        } 
                
        if( false == get_option( 'jf_theme_design_settings' ) ) {     
            add_option( 'jf_theme_design_settings' );  
        }
        
        /**
         * Add settings fields
         */
       add_settings_field(
           'color_scheme',
           'Color scheme:',
           array($this, 'color_scheme_callback'),
           'jf_theme_design_settings',
           'color_scheme_section' 
       );
       
       add_settings_field(
           'general_font_type',
           'Font type:',
           array($this, 'general_font_type_callback'),
           'jf_theme_design_settings',
           'general_font_type_section' 
       ); 
         
       add_settings_field(  
           'enable_fancybox',  
           'Enable Fancybox:',  
           array($this, 'enable_fancybox_callback'),  
           'jf_theme_design_settings',  
           'enable_fancybox_section'  
       );          
                                              
       register_setting(  
           'jf_theme_design_settings',  
           'jf_theme_design_settings',
           array($this, 'vanitize_general_settings')  
       );         
            
    }
    
    /**
     * Design settings section callbacks
     */
    function color_scheme_section_callback(){
        echo '<p class="adm_description">Here you can set the color scheme that will be used in the website.</p>';
    }
         
    function general_font_type_section_callback(){
        echo '<p class="adm_description">Here you can set the font type that will be used in the website.</p>';
    }
    
    function enable_fancybox_section_callback(){
        echo '<p class="adm_description">The theme includes the Fancybox image gallery plugin that is used to display photo slideshows in the website.<br />The plugin is enabled by default, but if you want to use a different plugin for this, you can disable it.</p>';    
    } 
    
    
    /**
     * Design settings field callbacks
     */ 
    function color_scheme_callback() {
        $color_scheme = JApi::$color_scheme; 
        $default = '#7dc70b';
        
        $options = get_option('jf_theme_design_settings');  
        if ( ! isset( $options['color_scheme'] ) ){
            $options['color_scheme'] = $default;
        }
  
        echo '<select class="adm_select" id="color_scheme"  name="jf_theme_design_settings[color_scheme]">';
        
        foreach($color_scheme as $k => $v){
            echo '<option value="'.$v.'" '.selected( $options['color_scheme'], $v ).'>'.$k.'</option>';    
        }
                     
        echo '</select>';                   
    }
        
     
    function general_font_type_callback() {  
        // fontlists
        $device_fonts = JApi::$device_fonts;
        $google_fonts = JApi::$google_fonts;
        
        $default = 'Default';
        
        $options = get_option('jf_theme_design_settings');  
        if ( ! isset( $options['general_font_type'] ) ){
            $options['general_font_type'] = $default;
        }
         
        echo '<select class="adm_select" id="general_font_type"  name="jf_theme_design_settings[general_font_type]">'.
             '<option value="Default">Default</option>'.
             '<optgroup label="Device fonts">';
        
        foreach($device_fonts as $k => $v){
            echo '<option value="'.$k.'" '.selected( $options['general_font_type'], $k ).'>'.$v.'</option>';    
        }
        
        echo '</optgroup>'.
             '<optgroup label="Google fonts">';
        foreach($google_fonts as $k => $v){
            echo '<option value="'.$k.'" '.selected( $options['general_font_type'], $k ).'>'.$v.'</option>';    
        }
                     
        echo '</select>';
	} 
             
    function enable_fancybox_callback(){
        // default
        $defaults = array( 'enable_fancybox' => 1 );
        
        $options = get_option( 'jf_theme_design_settings' );  

        $checked = $this->getValue($defaults, 'jf_theme_design_settings', 'enable_fancybox') ? 'checked="checked"':'' ;
         
        // Render the output 
        echo '<input type="checkbox" id="enable_fancybox" name="jf_theme_design_settings[enable_fancybox]" value="1"' . $checked . '/>';
    } 
    
    function jf_design_settings_googlefonts_callback() {  
        echo '<p>Add Google Fonts to your Wordpress site.<br />For the "How to get and use Google Fonts" please visit
        <a href="http://www.google.com/fonts/" target="_blank">http://www.google.com/fonts/</a> page.</p>
        <br /><p><strong>Quick use example :</strong></p><p>Put the code into the textarea below: <code>&lt;link href="http://fonts.googleapis.com/css?family=Alef:400,700" rel="stylesheet" type="text/css"&gt;</code></p>
        <p>Use font-family in your css: <code>h1 { font-family: "Alef", sans-serif; }</code></p>';  
    }    

    function jf_googlefonts_callback() {  
        $options = get_option( 'jf_theme_design_settings' );  
        $fonts = ''; 
        if( isset( $options['google_fonts'] ) ) { 
            $fonts = $options['google_fonts']; 
        } 
        echo '<textarea rows="6" cols="95" id="google_fonts" name="jf_theme_design_settings[google_fonts]">' . $fonts . '</textarea>';  
    }

          
} // end of class JF_Dashboard 
    

    $JFDO = new JF_Dashboard(); // instantiate JF_Dashboard class
    

/** PLUGIN SECTION */  

/** 
 * Main class of Prestige theme plugins
 * 
 * This CLASS do JF Plugin initialize tasks only
 * All the plugins have own CLASS and an OBJECT
 * 
 * @phase under construction 
 */  
class JF_Plugins_Wrapper{
    
    /** plugin object holders */
    public $slider_obj = null;
    public $ui_elements_obj = null;
     
    /** init */ 
    function __construct($_slider_object=null, $_ui_elements_obj = null){
        // store plugin objects
        $this->slider_obj      = $_slider_object;
        $this->ui_elements_obj = $_ui_elements_obj;
        
        // display 'Jumpeye fw' menu
        if ( is_object($this->slider_obj) ||
             is_object($this->ui_elements_obj) ){
            add_action('admin_menu', array($this,'register_jumpeye_menu_page'));
        }
    }
    
    /**
     *  add Jumpeye fw to the Dashboard menu panel
     */ 
    function register_jumpeye_menu_page() {
        add_menu_page(
            'Jumpeye fw', 
            'Jumpeye fw', 
            'add_users',
            'functions.php',
            array($this, 'jumpeye_fw'), 
            THEME_ROOT_URI.'/images/admin/plugin16.png');
            
        add_submenu_page('functions.php','','','manage_options','functions.php');
        
        if( !is_null($this->slider_obj) && is_object($this->slider_obj) ){
            add_submenu_page(
                'functions.php', 
                'Image slider', 
                'Image slider', 
                'manage_options', 
                'plugins.php?page=jf_slider_plugin_options',
                array($this->slider_obj, 'jf_slider_plugin_display')
            );
        }

        if( !is_null($this->ui_elements_obj) ){
            add_submenu_page(  
                'functions.php',
                'UI elements',                     
                'UI elements',                     
                'manage_options',                    
                'plugins.php?page=jf_ui_plugin_options',              
                array($this->ui_elements_obj, 'jf_ui_plugin_display')  
            );
        }                          
    }
    
    /** display menu landing page */ 
    function jumpeye_fw(){
        ?>
            <div class="wrap">
                <div id="icon-plugins" class="icon32"></div> 
                <h2>Jumpeye Framework Option Page</h2>
                <p><br />The Prestige theme comes with two included plugins: <br />
                <strong>- JF-Slider</strong> - image and content slider plugin<br />
                <strong>- JF-UI-Elements</strong> - collection of web design elements.<br /><br />
                You can configure them by setting up the options of the plugins. Each plugin and element<br />
                contains an example of the usage of the shortcode, so you will be able to include them easily in<br />
                your page. <br /><br />               

                Choose one plugin to set its options:
                    <ul style="margin-top: -10px;">
                    <?php if ( !is_null($this->slider_obj) && is_object($this->slider_obj) ) : ?>
                        <li>&nbsp;&nbsp;-&nbsp;&nbsp;<a href="<?php echo get_admin_url(); ?>admin.php?page=plugins.php?page=jf_slider_plugin_options">Image slider options</a></li>
                    <?php endif; ?>
                    <?php if ( !is_null($this->ui_elements_obj) && is_object($this->ui_elements_obj) ) : ?>
                        <li>&nbsp;&nbsp;-&nbsp;&nbsp;<a href="<?php echo get_admin_url(); ?>admin.php?page=plugins.php?page=jf_ui_plugin_options">UI elements options</a></li>
                    <?php endif; ?>    
                    </ul>
                <div style="clear: both;"></div>
                <br /><div style="border-top: 1px solid #FFFBCC; padding-top: 10px; font-style: italic;">
                <?php echo date('Y'); ?> &copy; <a href="http://www.jumpeye.com">Jumpeye.com</a>
                </div>
            </div>
        <?php    
        }            
    
} // END OF JF_Plugins_Wrapper    

    // check existense for each plugins
    $JF_SLIDER      = ( !isset($JF_SLIDER) )      ? null : $JF_SLIDER;
    $JF_UI_ELEMENTS = ( !isset($JF_UI_ELEMENTS) ) ? null : $JF_UI_ELEMENTS; 
    
    // make Plugin Wrapper
    new JF_Plugins_Wrapper($JF_SLIDER, $JF_UI_ELEMENTS);   
  
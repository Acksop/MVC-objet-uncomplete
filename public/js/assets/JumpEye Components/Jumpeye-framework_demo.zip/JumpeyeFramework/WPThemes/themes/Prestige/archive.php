<?php
/**
 * The template for displaying Archive pages.
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package Prestige
 * @since Prestige 1.0
 */

get_header(); 

$is_blog_fullwidth = get_option( 'prestige_metatpl_option_fullwidth' );
$sidebar_pos = get_option( 'prestige_metatpl_option_sidebar_pos' );

if( empty($is_blog_fullwidth) ){
    $is_blog_fullwidth = 'off';
}

if( empty($sidebar_pos) ){
    $sidebar_pos = 'left';
}

$grid_cols = ($is_blog_fullwidth == 'on') ? '18' : '12';
?>
    <div class="row">
       <?php 
           if( $is_blog_fullwidth=='off' && $sidebar_pos == 'left' ) get_sidebar();
       ?>     
		<div id="primary" class="content-area columns grid_<?php echo $grid_cols; ?>">
			<div id="content" class="site-content" role="main">
            <?php
                if ( have_posts() ) : 
                
                    // top nav
                    if( get_next_posts_link() == null && get_previous_posts_link() == null ){
                        // do something    
                    } else {
                        JF_Frontend::getNavigation();                   
                    }
                    
                    // Start the Loop
                    while ( have_posts() ) : 
                    
                        the_post(); 
						/* Include the Post-Format-specific template for the content.
						 * If you want to overload this in a child theme then include a file
						 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
						 */
                        $post_format = get_post_format(); 
                        if( empty ($post_format) ){
                            get_template_part( 'content-standard' );
                        } else {
                            get_template_part( 'content', $post_format );    
                        }
                        
                    endwhile;

                    // bottom nav
                    if( get_next_posts_link() == null && get_previous_posts_link() == null ){
                        // do something    
                    } else {
                        JF_Frontend::getNavigation('bottom');                  
                    } 

			    else :

				    get_template_part( 'no-results', 'archive' );

			    endif; ?>

			</div><!-- #content .site-content -->
		</div><!-- #primary .content-area -->
       <?php 
           if( $is_blog_fullwidth=='off' && $sidebar_pos == 'right' ) get_sidebar();
       ?> 
    </div><!-- .row -->
<?php get_footer(); ?>
<?php
/*
 * Template Name: Contact Template
 *
 * @package Prestige
 * @since Prestige 1.0
 */

get_header(); ?>

    <div class="row margin_top_32">
        <div class="columns grid_18">
			<?php while ( have_posts() ) : the_post(); ?>
				<?php get_template_part( 'content', 'page' ); ?>
			<?php endwhile; // end of the loop. ?>        
        </div>
    </div>
    
    <?php     
    if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Contact Page Map Area') ) :
       if(class_exists('SampleData')) 
           Sampledata::getContactMap();    
    endif;    
    ?>
    
    <!-- sidebar widgets & contact form area -->
    <div class="row">
        <div class="columns grid_6">
           <div id="secondary">
               <?php 
               if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Secondary Sidebar') ) :
                    if(class_exists('SampleData')) 
                        Sampledata::getContactSecondarySidebar();   
               endif;
               ?>   
           </div>     
        </div>
        <div class="columns grid_12">
               <?php 
               if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Contact Page Form Area') ) :
                    if(class_exists('SampleData')) 
                        Sampledata::getSampleContactForm();                  
               endif;   
               if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Contact Page Info Area') ) :
                    if(class_exists('SampleData')) 
                        Sampledata::getSampleContactInfo();                
               endif;
               ?>        
        </div>
    </div><!-- end of sidebar widgets & contact form area -->    
<?php get_footer(); ?>
<?php
/*
    Plugin Name: JF Recent Tweets Widget
    Plugin URI: http://www.jumpeye.com
    Description: Displays recent tweets of a specific Twitter account.
    Version: 1.0
    Author: Jumpeye Components
    Author URI: http://www.jumpeye.com
    License: GPL2
*/

// register JFLatestTweetsWidget widget
add_action('widgets_init', create_function('', 'return register_widget("JFLatestTweetsWidget");')); 

/**
 * Adds JFLatestTweetsWidget widget.
 */
class JFLatestTweetsWidget extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	public function __construct() {
        
		parent::__construct(
	 		'JFLatestTweetsWidget', // Base ID
			'JF Recent Tweets Widget', // Name (you will see it in Available Widgets)
			array( 'description' => __( 'Displays recent tweets of a specific Twitter account.', 'prestige' ),) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	public function widget( $args, $instance ) {
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );

        /* Custom Options -> twitter params
        * @param {string} Your Twitter widget ID.
        * @param {string} The ID of the DOM element you want to write results to. (BUILT-IN)
        * @param {int} Optional - the maximum number of tweets you want returned. Must
        *     be a number between 1 and 20.
        * @param {boolean} Optional - set true if you want urls and hash
             tags to be hyperlinked!
        * @param {boolean} Optional - Set false if you dont want user photo /
        *     name for tweet to show.
        * @param {boolean} Optional - Set false if you dont want time of tweet
        *     to show.
        * @param {function/string} Optional - A function you can specify to format
        *     tweet date/time however you like. This function takes a JavaScript date
        *     as a parameter and returns a String representation of that date.
        *     Alternatively you may specify the string 'default' to leave it with
        *     Twitter's default renderings. (BUILT-IN)
        * @param {boolean} Optional - Show retweets or not. Set false to not show.
        * @param {function/string} Optional - A function to call when data is ready. It
        *     also passes the data to this function should you wish to manipulate it
        *     yourself before outputting. If you specify this parameter you  must
        *     output data yourself! (BUILT-IN)
        */
        $twitter_widget_ID = (isset($instance['twitter_widget_ID'])) ? $instance['twitter_widget_ID'] : '357408636684869632';
        $number_of_tweets  = (isset($instance['number_of_tweets'])) ? $instance['number_of_tweets'] : 5 ;
        $tags_hyperlinked  = (isset($instance['tags_hyperlinked'])) ? (int) $instance['tags_hyperlinked'] : true ;
        $show_time         = (isset($instance['show_time'])) ? (int) $instance['show_time'] : true ;
        $show_retweets     = (isset($instance['show_retweets'])) ? (int) $instance['show_retweets'] : true ;

        $tweet_fade_delay    = (isset($instance['tweet_fade_delay'])) ? (int) $instance['tweet_fade_delay'] : 8 ;

        // Before widget - as defined in your specific theme.
		echo $before_widget;
        
        if ( ! empty( $title ) ){
	        echo $before_title . $title . $after_title;
        }        
        echo '<div class="latest_tweets_widget">';
        ?>
        <div id="latest_tweets"><div class="avatar background_scheme"></div><div class="tweet_list"><ul id="tweets"></ul></div></div>
        <script type="text/javascript"></script>
        <script type="text/javascript">
            window.onload = function(){
                
                // handle tweets    
                function handleTweets(tweets){
                    var x = tweets.length;
                    
                    var n = 0;
                    var element = document.getElementById('tweets');
                    var html = '';
                    while(n < x) {
                        html += '<li class="a_tweet">' + tweets[n] + '</li>';
                        n++;
                    }
                    element.innerHTML = html; 
                    
                    /* cutting tweets */
                    var site_color_scheme = jQuery('#site_color_scheme').text();
                    
                    var max_len = 120;

                    jQuery('div.tweet_list').css('background','#ebebeb');
                    jQuery('div.avatar').css({'padding-top':0, 'padding-bottom':0});
                    jQuery('div.tweet a').css('color', site_color_scheme); 
                    
                    jQuery('div.tweet p.text').each(function(){
                        var tweet_len = jQuery(this).text().length;
                        var tweet_text = jQuery(this).text();
                        if(tweet_len > max_len){
                            jQuery(this).text(tweet_text.substr(0,max_len)+'...');
                        }
                    }) ;
                    
                    /* end of cutting tweets */
                    
                    if(n > 1){
                        showTweets( jQuery('#tweets li:first') );    
                    } else if(n==1) {
                        jQuery('#tweets li:first').css('display','block');    
                    } else {
                        jQuery('#tweets').append('<li class="a_tweet" style="display: block;"><div class="tweet"><p class="text">No tweets.</p></div></li>');
                    }
                }
                
                /** styling twitter date */
                function parseTwitterDate(date){
                    //Tue Jul 16 2013 18:41:20 GMT+0200
                    // IE: Tue Jun 4 08:46:48 UTC+0200 2013
                    date = date+'';
                    var _time  = date.substr(16,5);
                    var _month = date.substr(4,3);
                    var _day   = date.substr(8,2);
                    var _year  = date.substr(11,4); 
                    return _month + ' ' + _day + ', ' + _year + ' at ' + _time;
                }                
                
                /** show tweets */
                function showTweets( elem ){
                    elem
                     .fadeIn()
                     .delay(<?php echo ($tweet_fade_delay*1000); ?>)
                     .fadeOut( 
                           function(){ 
                               if(elem.next().length > 0){
                                   showTweets( elem.next() );
                               } else {
                                   showTweets( elem.siblings(':first'));
                               }
                             }
                         );
                }                
                
                twitterFetcher.fetch('<?php echo $twitter_widget_ID; ?>', '', <?php echo $number_of_tweets; ?>, <?php echo $tags_hyperlinked; ?>, 0, <?php echo $show_time; ?>, parseTwitterDate, <?php echo $show_retweets; ?>, handleTweets);
            }         
        </script>
        <?php
        //<?php echo ($tweet_fade_delay*1000); 
                
        echo '</div>';

        /* After widget - as defined in your specific theme. */
		echo $after_widget;
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) {

        /* Default Widget Settings */
    		
    	$defaults = array(
    		'title'             => '',
            'twitter_widget_ID' => '357408636684869632',
            'number_of_tweets'  => 5,
            'tags_hyperlinked'  => true,
            'show_time'         => true,
            'show_retweets'     => false,
            'tweet_fade_delay'  => 8
    	); 

        $instance          =  wp_parse_args( (array) $instance, $defaults );   
        $title             =  esc_attr( $instance['title'] );
        $twitter_widget_ID =  $instance['twitter_widget_ID'];
        $number_of_tweets  =  $instance['number_of_tweets'];
        $tags_hyperlinked  =  $instance['tags_hyperlinked'];
        $show_time         =  $instance['show_time'];
        $show_retweets     =  $instance['show_retweets'];        
        $tweets_limit      =  array(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20);
        $tweet_fade_delay  =  $instance['tweet_fade_delay'];
        $delays            =  array(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20);
       
        ?>
		<p>
    		<label for="<?php echo $this->get_field_name( 'title' ); ?>"><?php _e( 'Title:', 'prestige' ); ?></label> 
    		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo $title; ?>" />
		</p> 
		<p>
    		<label for="<?php echo $this->get_field_name( 'twitter_widget_ID' ); ?>"><?php _e( 'Twitter Widget ID:', 'prestige' ); ?></label> 
    		<input class="widefat" id="<?php echo $this->get_field_id( 'twitter_widget_ID' ); ?>" name="<?php echo $this->get_field_name( 'twitter_widget_ID' ); ?>" type="text" value="<?php echo $twitter_widget_ID; ?>" />
		</p>                
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('number_of_tweets')); ?>"><?php _e('Number of tweets:', 'prestige'); ?></label>
			<select class="widefat" name="<?php echo $this->get_field_name('number_of_tweets'); ?>" id="<?php echo $this->get_field_id('number_of_tweets'); ?>">
				<?php foreach ($tweets_limit as $k => $v) { ?>
					<option <?php selected($number_of_tweets, $v) ?> value="<?php echo $v; ?>"><?php echo $v; ?></option>
				<?php } ?>
			</select>
		</p> 
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('tweet_fade_delay')); ?>"><?php _e('Delay between tweets in seconds:', 'prestige'); ?></label>
			<select class="widefat" name="<?php echo $this->get_field_name('tweet_fade_delay'); ?>" id="<?php echo $this->get_field_id('tweet_fade_delay'); ?>">
				<?php foreach ($delays as $k => $v) { ?>
					<option <?php selected($tweet_fade_delay, $v) ?> value="<?php echo $v; ?>"><?php echo $v; ?></option>
				<?php } ?>
			</select>
		</p>         
   		<p>
			<input id="<?php echo $this->get_field_id('tags_hyperlinked'); ?>" name="<?php echo $this->get_field_name('tags_hyperlinked'); ?>" type="checkbox" value="1" <?php checked('1', $tags_hyperlinked); ?> />&nbsp;
            <label for="<?php echo esc_attr($this->get_field_id('tags_hyperlinked')); ?>"><?php _e('Use hyperlinks?', 'prestige'); ?></label>
		</p> 
   		<p>
			<input id="<?php echo $this->get_field_id('show_time'); ?>" name="<?php echo $this->get_field_name('show_time'); ?>" type="checkbox" value="1" <?php checked('1', $show_time); ?> />&nbsp;
            <label for="<?php echo esc_attr($this->get_field_id('show_time')); ?>"><?php _e('Show time of tweet?', 'prestige'); ?></label>
		</p>
   		<p>
			<input id="<?php echo $this->get_field_id('show_retweets'); ?>" name="<?php echo $this->get_field_name('show_retweets'); ?>" type="checkbox" value="1" <?php checked('1', $show_retweets); ?> />&nbsp;
            <label for="<?php echo esc_attr($this->get_field_id('show_retweets')); ?>"><?php _e('Show retweets?', 'prestige'); ?></label>
		</p>                  
		<?php 
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance                      = array();
		$instance['title']             = ( !empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
        $instance['twitter_widget_ID'] = $new_instance['twitter_widget_ID'];
        $instance['number_of_tweets']  = (int)$new_instance['number_of_tweets'];
        $instance['tags_hyperlinked']  = (int)$new_instance['tags_hyperlinked'];
        $instance['show_time']         = (int)$new_instance['show_time'];
        $instance['show_retweets']     = (int)$new_instance['show_retweets'];
        $instance['tweet_fade_delay']  = (int)$new_instance['tweet_fade_delay'];
		return $instance;
	}
    
} // class JFLatestTweetsWidget
?>
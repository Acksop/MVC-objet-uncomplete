<?php
/**
 * The template for displaying 404 pages (Not Found).
 *
 * @package Prestige
 * @since Prestige 1.0
 */

get_header(); ?>
<div class="row">
	<div id="primary" class="content-area columns grid_18">
		<div id="content" class="" role="main">

			<div id="post-0" class="post error404 not-found">
				<div class="entry-header">
					<h1 class="entry-title"><?php _e( 'Oops! That page can&rsquo;t be found.', 'prestige' ); ?></h1>
				</div><!-- .entry-header -->

				<div class="entry-content">
					<p><?php _e( 'It looks like nothing was found at this location. Maybe try one of the links below or a search?', 'prestige' ); ?></p>

					<?php get_search_form(); ?>

				</div><!-- .entry-content -->
			</div><!-- #post-0 .post .error404 .not-found -->

		</div><!-- #content .site-content -->
	</div><!-- #primary .content-area -->
</div><!-- .row -->
<?php get_footer(); ?>
<?php
/**
 * Template Name: Gallery Template
 *
 * Description: Use this page template to show galleries
 *
 * @package Prestige
 * @since Prestige 1.0
 */

get_header(); ?>

    <div class="row gallery_view_control margin_top_32">
        <div class="columns grid_18">
            <div style="float: right">
                <div class="color_scheme gallery_view_title"><?php _e( 'change view:' ); ?></div>
                <ul class="gallery_change_view">
                    <li>
                        <div class="gallery_view_square background_scheme">
                            <div class="gallery_view_list"></div>
                        </div>
                    </li>
                    <li>
                        <div class="gallery_view_square background_scheme">
                            <div class="gallery_view_2_cols"></div>
                        </div> 
                    </li>   
                    <li>
                        <div class="gallery_view_square background_scheme">
                            <div class="gallery_view_3_cols"></div>
                        </div>   
                    </li>                                     
                    <li>
                        <div class="gallery_view_square background_scheme">
                            <div class="gallery_view_6_cols"></div>
                        </div>
                    </li>
                </ul> 
            </div>                                  
        </div>    
    </div>

	<div id="content" class="row main_gallery_holder">
        <div class="columns grid_18">

			<?php while ( have_posts() ) : the_post(); ?>
				<?php get_template_part( 'content', 'page' ); ?>
			<?php endwhile; // end of the loop. ?>

		</div><!-- .columns .grid_18 -->
	</div><!-- #content .row -->

<?php get_footer(); ?>
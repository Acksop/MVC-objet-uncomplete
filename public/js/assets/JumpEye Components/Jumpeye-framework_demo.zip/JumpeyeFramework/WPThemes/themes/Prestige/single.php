<?php
/**
 * The Template for displaying all single posts.
 *
 * @package Prestige
 * @since Prestige 1.0
 */

get_header();

$is_blog_fullwidth = get_option( 'prestige_metatpl_option_fullwidth' );
$sidebar_pos = get_option( 'prestige_metatpl_option_sidebar_pos' );

if( empty($is_blog_fullwidth) ){
    $is_blog_fullwidth = 'off';
}

if( empty($sidebar_pos) ){
    $sidebar_pos = 'left';
}

$grid_cols = ($is_blog_fullwidth == 'on') ? '18' : '12';
?>
    <div class="row">
       <?php 
           if( $is_blog_fullwidth=='off' && $sidebar_pos == 'left' ) get_sidebar();
       ?>     
		<div id="primary" class="content-area columns grid_<?php echo $grid_cols; ?>">
			<div id="content" class="site-content" role="main">

			<?php while ( have_posts() ) : the_post(); ?>
                <?php 
                    $category = get_the_category();
                    if($category[0]){
                        echo '<h2 class="single_post_title"><a class="color_scheme" href="'.get_category_link($category[0]->term_id ).'">'.$category[0]->cat_name.' &raquo; </a>'.get_the_title().'</h2>';
                    } 
                ?>
				<?php get_template_part( 'content', 'single' ); ?>

				<?php
					// If comments are open or we have at least one comment, load up the comment template
					if ( comments_open() || '0' != get_comments_number() )
						comments_template( '', true );
				?>

			<?php endwhile; // end of the loop. ?>

			</div><!-- #content .site-content -->
		</div><!-- #primary .content-area  .columns .grid_12 -->
       <?php 
           if( $is_blog_fullwidth=='off' && $sidebar_pos == 'right' ) get_sidebar();
       ?>  
    </div><!-- .row -->
    
<?php get_footer(); ?>
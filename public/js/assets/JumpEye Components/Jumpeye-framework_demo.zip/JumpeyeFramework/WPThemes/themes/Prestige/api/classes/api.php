<?php
/**
 * JApi class
 *
 * @package Prestige 
 */
  
class JApi{
    
    /**
     *  Fonts family holders
     */ 
    public static $device_fonts;
    public static $google_fonts;
    
    /**
     * Color scheme
     */
    public static $color_scheme; 
      
    /** 
     * Social Links
     */
    public static $social_links;  
    
    /**
     * Home slider variables
     */
    public static $url_targets;
    public static $slide_title_names;
    public static $slide_description_names;
    public static $slide_image_names;
    public static $slide_url_names;
    public static $slide_target_names;    
   
   /**
    * Default Theme Plugins
    */
    public static $theme_plugins;    
    
    /**
     * Content Icons
     */
    public static $content_icons;       
     
    /**
     * constructor method
     */ 
    public function __construct(){
        add_action( 'custom_head', array( $this,'google_fonts' ) );
        add_action( 'custom_footer', array( $this,'customFooter' ) );

        $this->theme_support();
        
        // init
        self::initColorScheme();
        self::initFonts();
        self::initSocialLinks();
        self::initHomeSlider();
        self::initDefaultPlugins();
        self::initContentIcons();
    }
    
    
    /**
     * Get .container style
     * Container background : 
     * - if user sets a background image .container follows that background-image
     * - if user sets a color to background .container follows that background-color
     * - if user sets no background-image and background-color is the default, .container applies the default
     */
     public static function container_style(){
        $bck_img = get_background_image();
        $bc_color = get_background_color();
        $container_bck = ( empty($bck_img) && ($bc_color != 'e9e0d1') ) ? 'style="background-color: #'.$bc_color.';"' : '';
        echo $container_bck;   
     }
     
        
    /** 
     * Get custom footer 
     */
    public function customFooter(){
        $this->google_analytics();  
        $this->getColorScheme();
    }
    
    
    
    /** 
     * Get site color
     */
    private function getColorScheme(){
        $design_options = get_option( 'jf_theme_design_settings' ); 
        if( !empty($design_options['color_scheme']) ){
            echo '<span id="site_color_scheme" style="display: none">'.$design_options['color_scheme'].'</span>';
        } else {
            // default : #7dc70b
            echo '<span id="site_color_scheme" style="display: none">#7dc70b</span>';
        }        
    } 
    
        
    /** 
     * create default theme plugins array
     * array key = plugin foldername
     * array value = plugin name
     */
    public static function initDefaultPlugins(){
        self::$theme_plugins = array(
            'jf-slider' => 'JF-Slider', 
            'jf-ui-elements' => 'JF-UI-elements' 
        );
    }     


    /** 
     * fill up content icons
     * Admin widget select use this list
     */
    public static function initContentIcons(){
        self::$content_icons = array(
            'none',
            'arrows.png',
            'bag.png',
            'basketball.png',
            'bicycle.png',
            'book.png',
            'bus.png',
            'camera.png',
            'car.png',
            'cart.png',
            'cocktail.png',
            'coffee.png',
            'desktop.png',
            'discount.png',
            'drink.png',
            'envelope.png',
            'filmstrip.png',
            'football.png',
            'free.png',
            'gift.png',
            'globe.png',
            'headphone.png',
            'house.png',
            'key.png',
            'laptop.png',
            'law.png',
            'list.png',
            'love.png',
            'magnifier.png',
            'married_couple.png',
            'message.png',
            'microphone.png',
            'mouse.png',
            'music_note.png',
            'new.png',
            'padlock.png',
            'pencil.png',
            'restaurant.png',
            'rugby.png',
            'sale.png',
            'settings.png',
            'shopping.png',
            'smartphone.png',
            'sound.png',
            'star.png',
            'tennis.png',
            'truck.png',
            'unlocked_padlock.png',
            'video_camera.png',
            'writing_materials.png'
        );
    }
    
       
    /** 
     * create color scheme array
     */
    public static function initColorScheme(){
        self::$color_scheme = array(
            'Yellow' => '#ffcc00',
            'Orange' => '#ff9c00',
            'Red'    => '#c90c10', 
            'Purple' => '#960cc9', 
            'Blue'   => '#0c93c9', 
            'Green'  => '#7dc70b'
        );
    }
          
    /**
     * create font families array
     */ 
    public static function initFonts(){
        self::$device_fonts = array(
            'Arial' => 'Arial',
            'Calibri' => 'Calibri',
            'Cambria' => 'Cambria',
            'Comic Sans MS' => 'Comic Sans MS',
            'Courier New' => 'Courier New',
            'Georgia' => 'Georgia',
            'Tahoma' => 'Tahoma',
            'Times New Roman' => 'Times New Roman',
            'Trebuchet MS' => 'Trebuchet MS',
            'Verdana' => 'Verdana'
        );
        self::$google_fonts = array(
            'Arimo' => 'Arimo',
            'Arvo' => 'Arvo',
            'Cabin' => 'Cabin',
            'Cuprum' => 'Cuprum',
            'Drod Sans' => 'Droid Sans',
            'Drod Serif' => 'Droid Serif',
            'Francois One' => 'Francois One',
            'Lato' => 'Lato',
            'Lobster' => 'Lobster',
            'Lora' => 'Lora',
            'Nunito' => 'Nunito',
            'Open Sans' => 'Open Sans',
            'Open Sans Condensed:300,300italic,700' => 'Open Sans Condensed',
            'Oswald' => 'Oswald',
            'Play' => 'Play',
            'PT Sans Narrow' => 'PT Sans Narrow',
            'PT Serif' => 'PT Serif',
            'Raleway' => 'Raleway',
            'Roboto' => 'Roboto',
            'Roboto Condensed' => 'Roboto Condensed',
            'Rokkitt' => 'Rokkitt',
            'Source Sans Pro' => 'Source Sans Pro',
            'Ubuntu' => 'Ubuntu',
            'Yanone Kaffeesatz' => 'Yanone Kaffeesatz'
        );        
    } 
    
    /**
     * init Home slider
     */
    public static function initHomeSlider(){
        self::$url_targets = array(
            "blank" => "_blank",  
            "self"  => "_self"
        );
        
        self::$slide_image_names = array(
            "slide_1_image",
            "slide_2_image",                
            "slide_3_image",
            "slide_4_image",
            "slide_5_image"
        ); 
        
        self::$slide_title_names = array(
            "slide_1_title",
            "slide_2_title",                
            "slide_3_title",
            "slide_4_title",
            "slide_5_title"
        );  
        
        self::$slide_url_names = array(
            "slide_1_url",
            "slide_2_url",                
            "slide_3_url",
            "slide_4_url",
            "slide_5_url"
        ); 
        
        self::$slide_description_names = array(
            "slide_1_description",
            "slide_2_description",                
            "slide_3_description",
            "slide_4_description",
            "slide_5_description"
        );  
        
        self::$slide_target_names = array(
            "slide_1_target",
            "slide_2_target",                
            "slide_3_target",
            "slide_4_target",
            "slide_5_target"
        );                                       
    }    
      
    /**
     * fillup social links array
     */
    public static function initSocialLinks(){
        self::$social_links = array(
            "Facebook"   => "facebook",
            "Twitter"    => "twitter", 
            "Google+"    => "googleplus",
            "Youtube"    => "youtube",
            "Vimeo"      => "vimeo",                              
            "RSS"        => "rss"
            /*"Pinterest"  => "pinterest",
            "LinkedIn"   => "linkedin",
            "Flickr"     => "flickr",
            "Tumblr"     => "tumblr",
            "MySpace"    => "myspace"*/
        );
    }       
        
        
    /** 
     * Add Google Fonts to the Theme
     */ 
    public function google_fonts(){
        $options = get_option( 'jf_theme_design_settings' ); 
        if( !isset($options['general_font_type']) ) return;
        $font = $options['general_font_type'];
        if(in_array($font, JApi::$google_fonts)){
        ?>
<!-- Google Fonts -->
<link href="http://fonts.googleapis.com/css?family=<?php echo str_replace(' ','+',$font); ?>" rel="stylesheet" type="text/css" />        
        <?php    
        }
    } 
    
    
    /**
     * Google Analytics
     */ 
    public function google_analytics(){
        $options = get_option( 'jf_theme_general_settings' ); 
        if( !empty($options['tracking_id']) ){
        ?>
<!-- google analytics -->
<script>
    var _gaq=[['_setAccount','<?php echo $options['tracking_id']; ?>'],['_trackPageview']];
    (function(d,t){var g=d.createElement(t),s=d.getElementsByTagName(t)[0];
    g.src=('https:'==location.protocol?'//ssl':'//www')+'.google-analytics.com/ga.js';
    s.parentNode.insertBefore(g,s)}(document,'script'));
</script>          
        <?php            
        }        
    }
    
    
    /**
     * Footer Copyright
     */ 
    public static function getFooterCopyright(){
        $options = get_option( 'jf_theme_general_settings' ); 
        $copyright = ( !empty($options['copyright_text']) ) ? $options['copyright_text'] : Sampledata::getSampleCopyright();
        echo '<div class="row" id="copyright">
                <div class="columns grid_18">
                    <div class="copyright">'.
                        $copyright.
                    '</div>
                </div>
              </div>';  
   
    }
    
        
    /** 
     * Theme supports
     */
    public function theme_support(){
        /* BUILT-IN */
        
    	// Add default posts and comments RSS feed links to head
    	add_theme_support( 'automatic-feed-links' );
                
    	// Enable support for the Aside Post Format
    	add_theme_support( 'post-formats', array( 'aside' ) );
    
    	// Add support for the Aside Post Formats
    	add_theme_support( 'post-formats', array( 'aside', ) );
                
        /* add post type support (to view Format panel on the Dashboard while post editing)
         *  available types : aside, gallery, link, image, quote, status, video, audio, chat
         *  
         *  see -> http://codex.wordpress.org/Post_Formats 
         */
        add_theme_support( 'post-formats', array( 'aside', 'gallery' ) );
            
        // add post thumbnails support
        add_theme_support( 'post-thumbnails' );   
          
                        
        /* CUSTOM */
        add_theme_support('fancybox');
    }        
    
    
    /**
     * Uploader for Favicon, Logo, Slides via WP built-in Media Libray's Uploader
     * @param $_option_settings : option settings name (E.x.: jf_theme_general_settings) 
     * @param $_field : name of the field
     * @param $_value : value of option (field) 
     * 
     * E.x. name of the input : jf_theme_general_settings[logo]
     */ 
    public static function WPM_Uploader($_option_settings, $_field, $_value){

    ?>    
<label for="<?php echo $_field; ?>">
    <input class="adm_input_file" id="<?php echo $_field; ?>" type="text" name="<?php echo $_option_settings; ?>[<?php echo $_field; ?>]" value="<?php echo $_value; ?>" /> 
    <input id="upload_<?php echo $_field; ?>_button" class="button" type="button" value="Upload Image" />
</label>
<script type="text/javascript">
jQuery(document).ready(function($){
 
    var custom_uploader;
 
    $('#upload_<?php echo $_field; ?>_button').click(function(e) {
 
        e.preventDefault();
 
        //If the uploader object has already been created, reopen the dialog
        if (custom_uploader) {
            custom_uploader.open();
            return;
        }
 
        //Extend the wp.media object
        custom_uploader = wp.media.frames.file_frame = wp.media({
            title: 'Choose Image',
            button: {
                text: 'Choose Image'
            },
            multiple: false
        });
 
        //When a file is selected, grab the URL and set it as the text field's value
        custom_uploader.on('select', function() {
            attachment = custom_uploader.state().get('selection').first().toJSON();
            $('#<?php echo $_field; ?>').val(attachment.url);
        });
 
        //Open the uploader dialog
        custom_uploader.open();
 
    });

});
</script>
<?php           
    }
    
        
} // end of JApi class
?>
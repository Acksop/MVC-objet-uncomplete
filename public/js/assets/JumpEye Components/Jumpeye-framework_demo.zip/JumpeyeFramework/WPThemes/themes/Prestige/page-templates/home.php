<?php 
/* Template Name: Home Template
 *
 * @package Prestige
 * @since Prestige 1.0
 */
 
if ( !defined('ABSPATH')) exit;

get_header(); ?>

        <!-- Home slider -->
        <?php $JFO->getHomeSlider(); ?>   
        
        <!-- Home content -->
		<?php while ( have_posts() ) : the_post(); ?>
			<?php get_template_part( 'content', 'page' ); ?>
		<?php endwhile; // end of the loop. ?>        
                       
        <!-- Home main post & Socials -->
        <div class="row welcome_post">
        <?php
        $social_options = get_option( 'jf_theme_social_settings' );
        
        $social_option_number = 0;
        
        if($social_options != false){
            foreach($social_options as $k=>$v){
                if( !empty($v) ){
                    $social_option_number++;
                }             
            }            
        }
        
        if($social_option_number > 0 || is_active_sidebar('latest-tweets-widget') ) :
        ?>
            <div class="columns grid_10">
            <!-- One Selected Post -->
           <?php 
               if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Home Page Main Post Area') ) :
                   if(class_exists('SampleData')) 
                       Sampledata::getSampleOnePostWidget();
               endif;
           ?>                          
            </div>
            <div class="columns grid_1"></div>
            <div class="columns grid_7">
                <?php 
                    JF_Frontend::getSocialLinks(); 
                    
                    if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Home Page Recent Tweets Area') ) :
                    endif;                    
                ?>
            </div>
        <?php
        else:
        ?>
            <div class="columns grid_18">
            <!-- One Selected Post -->
           <?php 
               if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Home Page Main Post Area') ) :
                   if(class_exists('SampleData')) 
                       Sampledata::getSampleOnePostWidget();
               endif;
           ?>                          
            </div>        
        <?php
        endif;
        ?>    
        </div>
        
        <!-- Latest post from ??? category -->
       <?php 
       if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Home Page Featured Posts Area') ) :
           if(class_exists('SampleData')) 
               Sampledata::getSampleCategoryPosts();
       endif; ?>   
                         
        <!-- Tab & Latest posts -->
        <div class="row tab_and_latest">
            <div class="columns grid_12 tabbed_widget">
               <?php 
                   if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Home Page Tabbed Content Area') ) :
                        if(class_exists('SampleData'))
                            SampleData::getSampleTabbedWidget();
                   endif; 
               ?>                                                
            </div>
            <div class="columns grid_6">
               <?php 
               if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Home Page Recent Posts Area') ) :
                   if(class_exists('SampleData'))
                       SampleData::getSampleLatestPosts();
               endif; 
               ?>                              
            </div>
        </div>

       <!-- Latest Projects -->
       <?php 
       if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Home Page Bottom Area') ) :
           if(class_exists('SampleData')) 
               Sampledata::getSampleProjects();
       endif;
       ?>                     
   
<?php get_footer(); ?>
<?php
/*
 * Template Name: Services Template
 *
 * @package Prestige
 * @since Prestige 1.0
 */

get_header();
?>
    <div class="row margin_top_32">
        <div class="columns grid_18">
			<?php while ( have_posts() ) : the_post(); ?>
				<?php get_template_part( 'content', 'page' ); ?>
			<?php endwhile; // end of the loop. ?>        
        </div>
    </div>
<?php    
    // Main Service Widget
       if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Services Page Categories List Area') ) :
           if(class_exists('SampleData')) 
               Sampledata::getSampleServicesHighlights();       
       endif;  
  
    // Bottom Service Widget        
       if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Services Page Bottom Area') ) :
           if(class_exists('SampleData')) 
               Sampledata::getSampleServicesBottom();           
       endif;              
get_footer(); 
?>
<?php
/*
 * Template Name: Content Template
 *
 * In the default layout Content is on the left and Sidebar is on the right
 * @package Prestige
 * @since Prestige 1.0
 */

get_header(); 

$is_fullwidth = get_post_meta( get_the_ID(), 'is_fullwidth' );
$sidebar_position = get_post_meta( get_the_ID(), 'sidebar_position' );
$grid_cols = ($is_fullwidth[0]=='on') ? '18' : '12';
?>
    <div class="row margin_top_32">
       <?php 
           if( $is_fullwidth[0]=='off' && $sidebar_position[0] == 'left' ) get_sidebar();
       ?>      
		<div id="primary" class="content-area columns grid_<?php echo $grid_cols; ?>">
			<div id="content" class="" role="main">

				<?php while ( have_posts() ) : the_post(); ?>

					<?php get_template_part( 'content', 'page' ); ?>

					<?php comments_template( '', true ); ?>

				<?php endwhile; // end of the loop. ?>

			</div><!-- #content .site-content -->
		</div><!-- #primary .content-area .columns .grid_<?php echo $grid_cols; ?> -->
       <?php 
           if( $is_fullwidth[0]=='off' && $sidebar_position[0] == 'right' ) get_sidebar();
       ?>         
    </div><!-- .row -->
<?php get_footer(); ?>
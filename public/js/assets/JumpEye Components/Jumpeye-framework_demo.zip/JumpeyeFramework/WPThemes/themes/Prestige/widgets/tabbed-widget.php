<?php
/*
    Plugin Name: JF Tabbed Widget
    Plugin URI: http://www.jumpeye.com
    Description: Displays recent posts from a specified category in a tab.
    Version: 1.0
    Author: Jumpeye Components
    Author URI: http://www.jumpeye.com
    License: GPL2
*/

// register JFTabbedWidget widget
add_action('widgets_init', create_function('', 'return register_widget("JFTabbedWidget");')); 

/**
 * Adds JFTabbedWidget widget.
 */
class JFTabbedWidget extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	public function __construct() {
        
		parent::__construct(
	 		'JFTabbedWidget', // Base ID
			'JF Tabbed Widget', // Name (you will see it in Available Widgets)
			array( 'description' => __( 'Displays recent posts from a specified category in a tab.', 'prestige' ),) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	public function widget( $args, $instance ) {
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );

        /* Custom Options */
        // Our options from the widget settings.
        
        $number         = (isset($instance['number'])) ? $instance['number'] : 3 ;
        $excerpt        = (isset($instance['excerpt'])) ? $instance['excerpt'] : false ;
        $excerpt_length = (isset($instance['excerpt_length'])) ? (int)($instance['excerpt_length']) : 0;
        $thumbnail      = (isset($instance['thumbnail'])) ? $instance['thumbnail'] : false ;
        $cat            = (isset($instance['cat'])) ? $instance['cat'] : 1 ;
        
        // title
        if ( ! empty( $title ) )
		echo $before_title . '<h4 class="widget_title color_scheme">'.$title.'</h4>'. $after_title;        
        
        // Before widget - as defined in your specific theme.
		echo $before_widget;
        
        /* Display The Widget */   
           

            /* Create a new post query */
            $query = new WP_Query();
            //Send our widget options to the query
            $query->query( array(
            	'post_type'           => 'post',
                'posts_per_page'      => $number,
                'ignore_sticky_posts' => 1,
                'cat'                 => $cat
               )
            );

            $titles = array();   // stores <dd> elements
            $contents = array(); // stores <li> elements
            $i = 1;              // post counter to set active class for first tab item
            
            if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post();
            
            $tab_content = '';
            $active = ($i==1) ? ' class="active"' : '';
            $titles[] = '<dd><a href="#'.sanitize_title(get_the_title()).'" '.$active.'>'.get_the_title().'</a></dd>';
            
            if ($excerpt == true) {
                $tab_content = '<p class="excerpt">'.$this->getExcerpt($excerpt_length, get_permalink()).'</p>';
            }   
            
            if (has_post_thumbnail() && $thumbnail == true) {
                $tab_content.='<div class="img_holder">'.
                '<a href="'.get_permalink().'" title="'.the_title_attribute('echo=0').'" rel="bookmark">'.
                //get_the_post_thumbnail(get_the_ID(), array('',''), array('class' => '', 'alt' => esc_attr(get_the_title()), 'title' => esc_attr(get_the_title()))).
                get_the_post_thumbnail().
                '</a></div>';
            }  
            
            $contents[] = '<li '.$active.'>'.$tab_content.'</li>';
            $i++; 
            endwhile; endif;
                  
            echo '<dl>'.
                  implode('',$titles).
                 '</dl>'.
                 '<ul class="tab-content style-2">'.
                 implode('',$contents).
                 '</ul>';
                 
        /* After widget - as defined in your specific theme. */
		echo '<table class="table_of_shadows" border="0" cellpadding="0" cellspacing="0" style="width:  100%; margin-top: -1px">
                <tr>
                    <td class="post_left"></td>
                    <td class="post_center">&nbsp;</td>
                    <td class="post_right"></td>
                </tr>
            </table> '.$after_widget;
        wp_reset_postdata();
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) {
	   
        /* Default Widget Settings */
    		
    	$defaults = array(
    		'title'          => '',
    		'number'         => 3,
            'excerpt'        => true,
            'excerpt_length' => 50, // WP default
            'thumbnail'      => true,
            'cat'            => 1 // category number : 1 = Uncategorized
    	); 

        $instance       = wp_parse_args( (array) $instance, $defaults );   
        $title          = esc_attr( $instance['title'] );
        $number         =  $instance['number'];
        $excerpt        =  $instance['excerpt'];
        $excerpt_length =  $instance['excerpt_length'];
        $thumbnail      =  $instance['thumbnail'];
        $cat            =  $instance['cat'];
		?>
		<p>
    		<label for="projects_<?php echo $this->get_field_name( 'title' ); ?>"><?php _e( 'Title:', 'prestige' ); ?></label> 
    		<input class="widefat" id="projects_<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('cat')); ?>"><?php _e('Category: ', 'prestige'); ?></label>
			<?php wp_dropdown_categories(array('class' => 'widefat', 'name' => $this->get_field_name('cat'), 'show_option_all' => __('All categories', 'prestige'), 'hide_empty' => 1, 'hierarchical' => 1, 'selected' => $cat)); ?>
		</p>         
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php _e('Number of tabs:', 'prestige'); ?></label>
			<select class="widefat" name="<?php echo $this->get_field_name('number'); ?>" id="<?php echo $this->get_field_id('number'); ?>">
				<?php for($i=1;$i<=5;$i++) { ?>
					<option <?php selected($number, $i) ?> value="<?php echo $i; ?>"><?php echo $i; ?></option>
				<?php } ?>
			</select>
		</p>  
   		<p>
			<input id="<?php echo $this->get_field_id('excerpt'); ?>" name="<?php echo $this->get_field_name('excerpt'); ?>" type="checkbox" value="1" <?php checked('1', $excerpt); ?> />&nbsp;
            <label for="<?php echo esc_attr($this->get_field_id('excerpt')); ?>"><?php _e('Display post excerpt?', 'prestige'); ?></label>
		</p>   
		<p>
    		<label for="<?php echo $this->get_field_name( 'excerpt_length' ); ?>"><?php _e( 'Lenght of excerpt:', 'prestige' ); ?></label> 
    		<input class="widefat" id="<?php echo $this->get_field_id( 'excerpt_length' ); ?>" name="<?php echo $this->get_field_name( 'excerpt_length' ); ?>" type="text" value="<?php echo $excerpt_length; ?>" />
		</p>
   		<p>
			<input id="<?php echo $this->get_field_id('thumbnail'); ?>" name="<?php echo $this->get_field_name('thumbnail'); ?>" type="checkbox" value="1" <?php checked('1', $thumbnail); ?> />&nbsp;
            <label for="<?php echo esc_attr($this->get_field_id('thumbnail')); ?>"><?php _e('Display post featured image?', 'prestige'); ?></label>
		</p>  
		<?php 
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance                   = array();
		$instance['title']          = ( !empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
        $instance['number']         = strip_tags( $new_instance['number'] );
        $instance['excerpt']        = $new_instance['excerpt'];
        $instance['excerpt_length'] = (int)($new_instance['excerpt_length']);
        $instance['thumbnail']      = $new_instance['thumbnail'];
        $instance['cat']            = $new_instance['cat'];
		return $instance;
	}

    /** Custom helper functions */
    
    /**
     * get Excerpt and set its length
     * @param $_length
     */ 
    private function getExcerpt($_length){
    	$excerpt = explode(' ', get_the_excerpt(), $_length);
    	if (count($excerpt) >= $_length) {
    		array_pop($excerpt);
    		$excerpt = implode(" ", $excerpt) . ' &hellip;';
    	} else {
    		$excerpt = implode(" ", $excerpt);
    	}
    	$excerpt = preg_replace('`\[[^\]]*\]`', '', $excerpt);
    
    	return $excerpt;
    }     
    
} // class JFTabbedWidget
?>
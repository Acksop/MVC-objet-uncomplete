<?php
/**
 * The template for displaying image attachments.
 *
 * @package Prestige
 * @since Prestige 1.0
 */

get_header();
?>

    <div class="row">
		<div id="primary" class="content-area image-attachment columns grid_18">

			<?php while ( have_posts() ) : the_post(); ?>
            <!-- Image Navigation -->
            <div class="row" id="image-navigation">
                <div class="grid_9 columns">
                    <span class="previous-image"><?php previous_image_link( false, __( '&larr; Previous', 'prestige' ) ); ?></span>
                </div>
                <div class="grid_9 columns align_right">
                    <span class="next-image"><?php next_image_link( false, __( 'Next &rarr;', 'prestige' ) ); ?></span>
                </div>
            </div>
            
            <!-- Image Attachment -->
            <div class="post single">
                <div class="thumbnail_holder">
 				    <div class="entry-attachment">
					    <div class="attachment post_thumbnail">
							<?php
								/**
								 * Grab the IDs of all the image attachments in a gallery so we can get the URL of the next adjacent image in a gallery,
								 * or the first image (if we're looking at the last image in a gallery), or, in a gallery of one, just the link to that image file
								 */
								$attachments = array_values( get_children( array( 'post_parent' => $post->post_parent, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => 'ASC', 'orderby' => 'menu_order ID' ) ) );
								foreach ( $attachments as $k => $attachment ) {
									if ( $attachment->ID == $post->ID )
										break;
								}
								$k++;
								// If there is more than 1 attachment in a gallery
								if ( count( $attachments ) > 1 ) {
									if ( isset( $attachments[ $k ] ) )
										// get the URL of the next image attachment
										$next_attachment_url = get_attachment_link( $attachments[ $k ]->ID );
									else
										// or get the URL of the first image attachment
										$next_attachment_url = get_attachment_link( $attachments[ 0 ]->ID );
								} else {
									// or, if there's only 1 image, get the URL of the image
									$next_attachment_url = wp_get_attachment_url();
								}
							?>

							<a href="<?php echo $next_attachment_url; ?>" title="<?php echo esc_attr( get_the_title() ); ?>" rel="attachment"><?php
								$attachment_size = apply_filters( 'jumpeye_attachment_size', array( 1200, 1200 ) ); // Filterable image size.
								echo wp_get_attachment_image( $post->ID, $attachment_size );
							?></a>
                        </div><!-- .attachment -->
                    </div><!-- .entry-attachment -->
                    
                    <!-- Image Metadata -->
                    <div class="post_meta_data">
                        <p>By <?php the_author(); ?> on <?php echo get_the_date('M j, Y'); ?>
                        <?php
                            $cat = the_category($post->ID);
                            if( !empty($cat) ){
                                 ?>
                                 in <span class="post_category"><?php the_category($post->ID); ?></span>
                                 <?php
                            }
                        ?>
                        </p>
                    </div>
                </div>
          
                <!-- Image title -->
                <h2 class="post_title"><?php the_title(); ?></h2>
                
                <!-- Image Description -->
                <p class="post_content">
                    <?php 
                        if ( ! empty( $post->post_excerpt ) ) {
                            echo do_shortcode(get_the_excerpt()).'</br>';
                        }
                        echo get_the_content(); 
                    ?>
                </p>
            </div>
            
            <!-- Image shadow -->
            <table class="table_of_shadows" border="0" cellpadding="0" cellspacing="0" style="width:  100%; margin-top: -1px">
                <tr>
                    <td class="post_left"></td>
                    <td class="post_center">&nbsp;</td>
                    <td class="post_right"></td>
                </tr>
            </table> 

			<?php //if ( ! empty( $post->post_excerpt ) ) : ?>
			<!--<div class="entry-caption">-->
				<?php //the_excerpt(); ?>
			<!--</div> -->
			<?php //endif; ?>
            
			<?php endwhile; // end of the loop. ?>

		</div><!-- #primary .content-area .image-attachment -->
    </div><!-- .row -->        
<?php get_footer(); ?>
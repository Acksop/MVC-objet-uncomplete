<?php
/**
 * The template for displaying the footer.
 * Contains the closing of the id=main div and all content after
 *
 * @package Prestige
 * @since Prestige 1.0
 */
?>
        <div id="footer">

                <div id="footer_widgets" class="row">
                    <div class="columns grid_3">
                        <?php
                        if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Area #1') ) :
                            if(class_exists('SampleData'))
                                SampleData::getEmptyFooterWidget('#1');
                        endif;
                        ?>                       
                    </div>
                    <div class="columns grid_6">
                        <?php
                        if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Area #2') ) :
                            if(class_exists('SampleData'))
                                SampleData::getEmptyFooterWidget('#2');
                        endif;
                        ?>                          
                    </div>
                    <div class="columns grid_3">
                        <?php
                        if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Area #3') ) :
                            if(class_exists('SampleData'))
                                SampleData::getEmptyFooterWidget('#3');
                        endif;
                        ?>                          
                    </div>
                    <div class="columns grid_6">
                        <?php
                        if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Area #4') ) :
                            if(class_exists('SampleData'))
                                SampleData::getEmptyFooterWidget('#4');
                        endif;
                        ?>                     
                    </div>                                                            
                </div>     

                <!-- Copyright text -->
                <?php JApi::getFooterCopyright(); ?>

        </div>
        
</div><!-- #page .container .hfeed .site -->

<?php 
    wp_footer();
    JHooks::custom_footer(); 
?>
</body>
</html>
<?php
/**
 * The template used for displaying page content in page.php
 *
 * @package Prestige
 * @since Prestige 1.0
 */
?>
<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="entry-content">
    <?php
        if ( is_page_template('page-templates/contact.php') ||
             is_page_template('page-templates/gallery.php') ||
             is_page_template('page-templates/home.php') ||
             is_page_template('page-templates/services.php') ||
             is_page_template('page-templates/shortcode.php')                                                    
        ) :
            if(get_the_content() != '') :  
            
                $home_class = (is_page_template('page-templates/home.php')) ? 'home_content' : '';
                $page_class = (!is_page_template('page-templates/gallery.php') &&
                !is_page_template('page-templates/services.php') ) ? 'page_content' : '';
            
    ?>        
        <div class="row <?php echo $home_class; ?>">
            <div class="columns grid_18">
                <div class="<?php echo $page_class; ?>">
                    <?php
                        //echo nl2br(do_shortcode(get_the_content()));
                        the_content();
                    ?>
                </div>
                <?php if (!is_page_template('page-templates/gallery.php') &&
                !is_page_template('page-templates/services.php')) : ?>
                
                <table class="table_of_shadows" border="0" cellpadding="0" cellspacing="0" style="width:  100%; margin-top: -1px">
                    <tr>
                        <td class="post_left"></td>
                        <td class="post_center">&nbsp;</td>
                        <td class="post_right"></td>
                    </tr>
                </table> 
                
                <?php endif; ?>
            </div>
        </div>
        <?php endif;
              else :
        ?>
        <div class="row">
            <div class="columns grid_18">
                <div class="page_content">
                    <?php the_content(); ?>
                </div>
                <table class="table_of_shadows" border="0" cellpadding="0" cellspacing="0" style="width:  100%; margin-top: -1px">
                    <tr>
                        <td class="post_left"></td>
                        <td class="post_center">&nbsp;</td>
                        <td class="post_right"></td>
                    </tr>
                </table> 
            </div>
        </div>                
        <?php endif; ?>                        
		<?php wp_link_pages( array( 'before' => '<div class="page-links">' . __( 'Pages:', 'prestige' ), 'after' => '</div>' ) ); ?>
		<?php edit_post_link( __( 'Edit', 'prestige' ), '<span class="edit-link">', '</span>' ); ?>
	</div><!-- .entry-content -->
</div><!-- #post-<?php the_ID(); ?> -->

This example shows how can you share your playlist on Facebook as video and not as a link.

Important note: The example in this form is NOT functional. You MUST place your path in the .xml, .fla and .html files
and then place the files on a web server!

1. In the source.xml file you have to change the absolute paths for the videos and cover images. Always use absolute paths
if you want to share the playlist as video on Facebook.

2. In the Facebook_sharing.fla file you can find the configured JCPlayer2 component and the necessary AS3 code,
which resizes the player component if the size of the stage changed.
You have to change two parameters:
- source - place the absolute path of the source.xml file in the Source textfield (JCPlayer2 panel)
- shareLink - place the absolute path of the .html file, which contains the player in the Share link textfield (JCPlayer2 panel)
Now you can re-compile the .fla file.

3. The Facebook_sharing.html file embeds the player in the HTML code and contains the necessary Facebook meta tags
to share the .swf file on Facebook as video, as follows:

<head>
    <meta property="og:title" content="JC Player 2.0 playlist" />
    <meta property="og:video" content="http://www.mydomain.com/player/Facebook_sharing.swf" />
    <meta property="og:video:width" content="550" />
    <meta property="og:video:height" content="400" />        
    <meta property="og:video:type" content="application/x-shockwave-flash" />
    <meta property="og:image" content="http://www.mydomain.com/player/thumbnail.jpg"/>
    <meta property="og:description" content="This is an example about how to share on Facebook this playlist as video and not as link."/>
</head>

Note: Don't forget to replace the path of the .swf file and thumbnail image ("http://www.mydomain.com/player/") with your path and place the files on your web server!

Important note: If after testing (sharing the playlist on Facebook) you found some problems and fixed them, you MUST make any changes in the path you have used, because Facebook is caching the shared content. This means that you have to change all the absolute paths that you used in the above files.

Read more about Facebook meta tags here: http://developers.facebook.com/docs/share/.